<?php

ob_start();
global $bakala_options;

$current_user = wp_get_current_user();
$firstname = get_user_meta($current_user->ID, 'first_name', true);
$lastname = get_user_meta($current_user->ID, 'last_name', true);
if ($firstname && $lastname) {
    $user_name = $firstname . ' ' . $lastname;
} else {
    $user_name = $current_user->display_name;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

    <link rel="profile" href="http://gmpg.org/xfn/11">
    <?php
    if (isset($bakala_options['bakala_favicon']) && strlen($bakala_options['bakala_favicon']['url']) > 0) {
        $favicon_href = $bakala_options['bakala_favicon']['url'];
    } else {
        $favicon_href = get_template_directory_uri() . '/vendor/images/favicon.png';
    }
    ?>
    <link rel="shortcut icon" href="<?php echo $favicon_href; ?>" />
    <link rel="apple-touch-icon" href="<?php echo $favicon_href; ?>">
    <meta name="msapplication-TileColor" content="#ff6600">
    <meta name="msapplication-TileImage" content="<?php echo $favicon_href; ?>">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> tabindex="0">
    <?php
    if (function_exists('wp_body_open')) {
        wp_body_open();
    } else {
        do_action('wp_body_open');
    }

    ?>
    <?php if (isset($bakala_options['google_tags']) && $bakala_options['google_tags'] == true) {
        echo $bakala_options['google_tags'];
    } ?>
    <?php if (isset($bakala_options['bakala_preload']) && $bakala_options['bakala_preload'] == 1 && is_front_page() && !isset($_GET['app']) && !isset($_COOKIE['bakala_show_preload'])) : ?>
    <script nowprocket>
        setTimeout(function () {
            var element = document.getElementById("bakala-preload");
            if (element) {
                element.style.setProperty('display', 'none', 'important');
            }
        }, 1000);
	</script>
        <div id="bakala-preload">
            <div class="bakala-preload-wrap">
                <?php if (isset($bakala_options['bakala_preload_logo']) && $bakala_options['bakala_preload_logo']['url']) : ?>
                    <div id="bakala-preload-logo">
                        <img alt="bakala-preload-logo" src="<?php echo $bakala_options['bakala_preload_logo']['url']; ?>">
                    </div>
                <?php endif; ?>
                <div id="bakala-preload-gif">
                    <?php if (isset($bakala_options['bakala_preload_gif']) && $bakala_options['bakala_preload_gif']['url']) : ?>
                        <img alt="bakala-preload-gif" src="<?php echo $bakala_options['bakala_preload_gif']['url']; ?>">
                    <?php endif; ?>
                    <?php if (isset($bakala_options['bakala_preload_css']) && $bakala_options['bakala_preload_gif']['url'] == false) {
                        $bakala_preload_css = $bakala_options['bakala_preload_css'];
                        if ($bakala_preload_css == 'spinner') {
                            echo '<div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'default') {
                            echo '<div class="lds-default"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'grid') {
                            echo '<div class="lds-grid"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'roller') {
                            echo '<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'ellipsis') {
                            echo '<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'ring') {
                            echo '<div class="lds-ring"><div></div><div></div><div></div><div></div></div>';
                        }
                    } ?>
                </div>
            </div>
        </div>
    <?php
        setcookie('bakala_show_preload', 'yes', time() + 86400, '/');
    endif;
    if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('header')) { ?>
        <?php if (!is_user_logged_in() && ($bakala_options['digits'] != true || !function_exists('digit_get_login_fields') || $bakala_options['lr_bakala'] == 1)) {
            if (isset($bakala_options['bakala_lr_logo']) && !empty($bakala_options['bakala_lr_logo'])) {
                $logo_href = $bakala_options['bakala_lr_logo']['url'];
            } elseif (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
                $logo_href = $bakala_options['site_header_logo']['url'];
            } else {
                $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
            }
            if (isset($bakala_options['m-accent-gradient']) && !empty($bakala_options['m-accent-gradient']) && isset($bakala_options['m-accent-gradient']['from']) && isset($bakala_options['m-accent-gradient']['to'])) {
        $gradient_from = $bakala_options['m-accent-gradient']['from'];
        $gradient_to = $bakala_options['m-accent-gradient']['to'];
        $style = 'style="background: linear-gradient(90deg, ' . $gradient_from . ', ' . $gradient_to . ');"';
    }
            if ($bakala_options['popup_login'] == 1) {
                if (is_mobile_or_tablet()) {
        ?>
                    <div class="modal fade" id="bakala_login" tabindex="-1" style="display: none;">
                        <div class="modal-dialog">
                            <div class="modal-content" <?= isset($style) ? $style : null ?>>
                                <?php if ($bakala_options['lr_bakala'] == 1 && bakala_is_woocommerce_active()) :
                                    get_template_part('template-parts/login-register');
                                else : ?>
                                    <!-- Begin # Login Form -->
                                    <form id="login" action="login" method="post">
                                        <div class="modal-body">


                                            <div class="form-group clearfix">
                                                <a class="c-ui-input c-ui-input--account-username"></a>
                                                <label for="p-username" style="width:100%"><?php echo _e('Username', 'bakala'); ?></label>

                                                <input name="username" type="text" id="p-username" tabindex="1" class="en" placeholder="Username">
                                            </div>

                                            <div class="form-group clearfix">
                                                <label for="p-password"><?php echo _e('Password', 'bakala'); ?></label>
                                                <a class="forget" href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
                                                <a class="c-ui-input c-ui-input--account-pass"></a>
                                                <input name="password" type="password" id="p-password" tabindex="2" class="en" placeholder="Password">
                                                <span class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                            </div>

                                            <div class="form-group clearfix">
                                                <div class="ckeckbox-control">
                                                    <input name="rememberme" type="checkbox" id="p-rememberme" class="rememberme" tabindex="3">
                                                    <label for="p-rememberme"><?php echo _e('Remember me', 'bakala'); ?></label>
                                                </div>
                                            </div>

                                            <div class="login-msg"></div>

                                            <div class="form-group clearfix" style="margin-bottom:50px;">
                                                <div class="bakala-button-container hasIcon large full">
                                                    <button type="submit" name="submit" id="wp-submit">
                                                        <span class="bakala-button blue">
                                                            <i class="bakala-button-icon bakala-button-icon-login"></i>
                                                            <span class="bakala-button-label clearfix">
                                                                <?php echo _e('Login To Site', 'bakala'); ?>
                                                            </span>
                                                        </span>
                                                    </button>
                                                </div>
                                            </div>

                                        </div>

                                        <div id="login_footerbox" class="footer box">
                                            <div class="register"><?php echo _e('You Are Not Register Before?', 'bakala'); ?>
                                                <a id="Register" target="_blank" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"><?php echo _e('Register To Site', 'bakala'); ?></a>
                                            </div>
                                        </div>
                                        <?php wp_nonce_field('ajax-login-nonce', 'p-security'); ?>
                                    </form>
                                    <!-- End # Login Form -->
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php
                } else {
                ?>
                    <div class="modal fade" id="bakala_login" tabindex="-1" style="display: none;">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="auth-modal">
                                    <div class="auth-modal-side" style="background: linear-gradient(90deg,<?= $gradient_from ?>,<?= $gradient_to ?>);">
                                        <div class="bs-logo"><img src="<?= $logo_href ?>" alt=""></div>
                                    </div>
                                    <div class="auth-modal-content">

                                        <div class="auth-modal-content-container">
                                            <header class="auth-header">
                                                <button type="button" data-bs-dismiss="modal" class="close-icon"></button>
                                            </header>
                                            <!---->
                                            <div class="auth-modal-template">
                                                <?php if ($bakala_options['lr_bakala'] == 1 && bakala_is_woocommerce_active()) :
                                                    get_template_part('template-parts/login-register');
                                                else : ?>
                                                    <!-- Begin # Login Form -->
                                                    <form id="login" action="login" method="post">
                                                        <div class="modal-body">


                                                            <div class="form-group clearfix">
                                                                <a class="c-ui-input c-ui-input--account-username"></a>
                                                                <label for="p-username" style="width:100%"><?php echo _e('Username', 'bakala'); ?></label>

                                                                <input name="username" type="text" id="p-username" tabindex="1" class="en" placeholder="Username">
                                                            </div>

                                                            <div class="form-group clearfix">
                                                                <label for="p-password"><?php echo _e('Password', 'bakala'); ?></label>
                                                                <a class="forget" href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
                                                                <a class="c-ui-input c-ui-input--account-pass"></a>
                                                                <input name="password" type="password" id="p-password" tabindex="2" class="en" placeholder="Password">
                                                                <span class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                                            </div>

                                                            <div class="form-group clearfix">
                                                                <div class="ckeckbox-control">
                                                                    <input name="rememberme" type="checkbox" id="p-rememberme" class="rememberme" tabindex="3">
                                                                    <label for="p-rememberme"><?php echo _e('Remember me', 'bakala'); ?></label>
                                                                </div>
                                                            </div>

                                                            <div class="login-msg"></div>

                                                            <div class="form-group clearfix" style="margin-bottom:50px;">
                                                                <div class="bakala-button-container hasIcon large full">
                                                                    <button type="submit" name="submit" id="wp-submit">
                                                                        <span class="bakala-button blue">
                                                                            <i class="bakala-button-icon bakala-button-icon-login"></i>
                                                                            <span class="bakala-button-label clearfix">
                                                                                <?php echo _e('Login To Site', 'bakala'); ?>
                                                                            </span>
                                                                        </span>
                                                                    </button>
                                                                </div>
                                                            </div>

                                                        </div>

                                                        <div id="login_footerbox" class="footer box">
                                                            <div class="register"><?php echo _e('You Are Not Register Before?', 'bakala'); ?>
                                                                <a id="Register" target="_blank" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"><?php echo _e('Register To Site', 'bakala'); ?></a>
                                                            </div>
                                                        </div>
                                                        <?php wp_nonce_field('ajax-login-nonce', 'p-security'); ?>
                                                    </form>
                                                    <!-- End # Login Form -->
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <!---->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        <?php
                }
            }
        }
        if (isset($bakala_options['bakala_lr_logo']) && !empty($bakala_options['bakala_lr_logo'])) {
            $logo_href = $bakala_options['bakala_lr_logo']['url'];
        } elseif (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
            $logo_href = $bakala_options['site_header_logo']['url'];
        } else {
            $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
        }
        ?>
        <?php
        if (is_mobile_or_tablet()) {
            if (isset($bakala_options['top_bar_mobile']) && $bakala_options['top_bar_mobile'] && is_front_page()) { ?>
                <div class="top-header-banner">
                    <?php if ($bakala_options['top_bar_type_mobile'] == 'bgtext') { ?>
                        <?php if ($bakala_options['top_bar_link_mobile'] && $bakala_options['top_bar_link_type_mobile'] != 'btn') { ?>
                            <a href="<?php echo $bakala_options['top_bar_link_mobile']; ?>" target="_blank">
                            <?php } ?>
                            <div class="tbar-background <?= $bakala_options['top_bar_link_type_mobile'] == 'btn' ? 'tbar-type-btn' : 'tbar-type-link' ?>">
                                <div class="tbar-text">
                                    <?php echo $bakala_options['top_bar_bgtext_text_mobile']; ?>
                                </div>
                                <?php if ($bakala_options['top_bar_link_mobile'] && $bakala_options['top_bar_link_type_mobile'] == 'btn') { ?>
                                    <div class="tbar-btn">
                                        <a href="<?= $bakala_options['top_bar_link_mobile']; ?>"><?= $bakala_options['top_bar_btn_text_mobile'] ?></a>
                                    </div>
                                <?php } ?>
                            </div>
                            <?php if ($bakala_options['top_bar_link_mobile'] && $bakala_options['top_bar_link_type_mobile'] != 'btn') { ?>
                            </a>
                        <?php } ?>
                    <?php } else { ?>
                        <?php if ($bakala_options['top_bar_link_mobile']) { ?>
                            <a href="<?php echo $bakala_options['top_bar_link_mobile']; ?>">
                            <?php } ?>
                            <div class="top-header-image">
                                <img alt="top-bar-banner" src="<?php echo $bakala_options['top_bar_image_mobile']['url']; ?>">
                            </div>
                            <?php if ($bakala_options['top_bar_link_mobile']) { ?>
                            </a>
                        <?php } ?>
                    <?php } ?>
                </div>
            <?php }
        } else {
            if (isset($bakala_options['top_bar']) && $bakala_options['top_bar']) { ?>
                <div class="top-header-banner">
                    <?php if ($bakala_options['top_bar_type'] == 'bgtext') { ?>
                        <?php if ($bakala_options['top_bar_link'] && $bakala_options['top_bar_link_type'] != 'btn') { ?>
                            <a href="<?php echo $bakala_options['top_bar_link']; ?>" target="_blank">
                            <?php } ?>
                            <div class="tbar-background <?= $bakala_options['top_bar_link_type'] == 'btn' ? 'tbar-type-btn' : 'tbar-type-link' ?>">
                                <div class="tbar-text">
                                    <?php echo $bakala_options['top_bar_bgtext_text']; ?>
                                </div>
                                <?php if ($bakala_options['top_bar_link'] && $bakala_options['top_bar_link_type'] == 'btn') { ?>
                                    <div class="tbar-btn">
                                        <a href="<?= $bakala_options['top_bar_link']; ?>"><?= $bakala_options['top_bar_btn_text'] ?></a>
                                    </div>
                                <?php } ?>
                            </div>
                            <?php if ($bakala_options['top_bar_link'] && $bakala_options['top_bar_link_type'] != 'btn') { ?>
                            </a>
                        <?php } ?>
                    <?php } else { ?>
                        <?php if ($bakala_options['top_bar_link']) { ?>
                            <a href="<?php echo $bakala_options['top_bar_link']; ?>">
                            <?php } ?>
                            <div class="top-header-image">
                                <img alt="top-bar-banner" src="<?php echo $bakala_options['top_bar_image']['url']; ?>">
                            </div>
                            <?php if ($bakala_options['top_bar_link']) { ?>
                            </a>
                        <?php } ?>
                    <?php } ?>
                </div>
        <?php }
        }
        ?>
        <?php
        if (bakala_is_woocommerce_active()) {
            global $product;
                        $product = wc_get_product(get_the_ID());

            if (is_product() && is_mobile_or_tablet()) {
                if (isset($bakala_options['logo-white']) && !empty($bakala_options['logo-white']['url'])) {
                    $logo_href = $bakala_options['logo-white']['url'];
                } else {
                    $logo_href = get_template_directory_uri() . '/vendor/images/logo-white.png';
                }
                if ($bakala_options['modern_header_mobile']) {
        ?>
                    <div class="product-more-icons">
                        <ul>
                            <?php
                            if (isset($bakala_options['show_price_change']) && $bakala_options['show_price_change']) {
                                $has_price_changes = get_post_meta(get_the_id(), 'has_price_changes', true);
                                if ($has_price_changes && $has_price_changes == 1) { ?>
                                    <li>
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#bakala_price_change">
                                            <i class="bakala-icon icon-statistics"></i>
                                            <span class="product-more-icon-text"><?php echo __('نمودار قیمت', 'bakala'); ?></span>
                                        </a>
                                    </li>
                                <?php }
                            }
                            $white_cat_compare = isset($bakala_options['white_catcompare']) ? $bakala_options['white_catcompare'] : false;
                            $compare_page = isset($bakala_options['compare_page']) ? get_permalink($bakala_options['compare_page']) : false;
                            if ($white_cat_compare && $compare_page) { ?>
                                <li>
                                    <a href="<?php echo $compare_page . '?products=' . get_the_id(); ?>" target="_blank" rel="nofollow">
                                        <i class="bakala-icon icon-compare"></i>
                                        <span class="product-more-icon-text"><?= __('مقایسه محصول', 'bakala') ?></span>
                                    </a>
                                </li>
                            <?php } else {
                                if (function_exists('yith_woocompare_premium_constructor')) {
                                    echo do_shortcode('[yith_compare_button]');
                                }
                            }
                            if (isset($bakala_options['show_share']) && $bakala_options['show_share']) { ?>
                                <li>
                                    <a data-bs-toggle="modal" data-bs-target="#bakala_sharebtn" href="#">
                                        <i class="bakala-icon icon-share"></i>
                                        <span class="product-more-icon-text"><?php echo __('به اشتراک گذاری کالا', 'bakala'); ?></span>
                                    </a>
                                </li>
                            <?php }
                            $product_video_type = get_post_meta(get_the_id(), 'video_type', true);
                            if ($product_video_type && $product_video_type != '') { ?>
                                <li>
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#modal-product-gallery" class="modal-opener">
                                        <i class="bakala-icon icon-product_video"></i>
                                        <span class="product-more-icon-text"><?php echo __('ویدئو محصول', 'bakala'); ?></span>
                                    </a>
                                </li>
                                <?php }
                            if (isset($bakala_options['show_white_catnotify']) && $bakala_options['show_white_catnotify'] && !$product->is_type('grouped')) {
                                $special_offer = is_special_offer(get_the_id());
                                if (!$special_offer || !$product->is_in_stock() || $product->get_price() == '') {
                                    $stock_subscriber = check_user_stock_notify(get_the_id(), $current_user->ID);
                                    $offer_subscriber = check_user_offer_notify(get_the_id(), $current_user->ID);
                                    if ($stock_subscriber || $offer_subscriber) {
                                        $is_subscriber = true;
                                    } else {
                                        $is_subscriber = false;
                                    }
                                ?>
                                    <li>
                                        <?php if (!is_user_logged_in()) {
                                            if ($bakala_options['popup_login'] == true) :
                                                if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                                    <i class="bakala-icon icon-notify"><?php echo do_shortcode('[dm-login-modal]'); ?></i>
                                                <?php } else { ?>
                                                    <a href="#" data-bs-toggle="modal" data-bs-target="#bakala_login">
                                                        <i class="bakala-icon icon-notify"></i>
                                                        <span class="product-more-icon-text"><?php echo __('Notify me', 'bakala'); ?></span>
                                                    </a>
                                                <?php }
                                            else : ?>
                                                <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>">
                                                    <i class="bakala-icon icon-notify"></i>
                                                    <span class="product-more-icon-text"><?php echo __('Notify me', 'bakala'); ?></span>
                                                </a>
                                            <?php endif;
                                        } else { ?>
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#bakala_product_notify">
                                                <i class="bakala-icon icon-notify <?php if ($is_subscriber) {
                                                                                        echo 'done';
                                                                                    } ?>"></i>
                                                <span class=" product-more-icon-text"><?php echo __('Notify me', 'bakala'); ?></span></a>
                                        <?php } ?>
                                    </li>
                            <?php }
                            }
                            ?>
                        </ul>
                    </div>
                    <div class="header-product modern-header">

                        <div class="right-header-product">
                            <a href="#" id="back-button" class="back-button"><i class="bakala-icon back"></i></a>
                            <?php if ($bakala_options['gallery_style_mobile'] != 'two') { ?>
                                <a href="<?= home_url() ?>" class="home-botton"><i class="bakala-icon bakala-home-icon"></i></a>
                                <div class="main">
                                    <label class="collection">
                                        <input type="checkbox">
                                        <div>
                                            <span></span>
                                        </div>
                                    </label>
                                </div>
                            <?php } ?>

                        </div>
                        <div class="left-header-product">
                            <ul class="product-tooltips not-sticky">
                                <?php if ($bakala_options['gallery_style_mobile'] != 'two') { ?>
                                    <li class="bakala-tooltip">
                                        <?php
                                        $cart_count = bakala_get_cart_count();
                                        ?>
                                        <a class="icon icon-cart" href="<?= get_permalink(wc_get_page_id('cart')); ?>"><span class="ar-spender"><?= $cart_count ?></span></a>
                                    </li>

                                    <li class="bakala-tooltip">
                                        <span class="bakala-tooltiptext"><?php echo __('Add to wishlist', 'bakala'); ?></span>
                                        <?php if (!is_user_logged_in()) {
                                            if ($bakala_options['popup_login'] == true) :
                                                if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                                    <span class="icon icon-love addtowishlist"><?php echo do_shortcode('[dm-login-modal]'); ?></span>
                                                <?php } else { ?>
                                                    <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login" class="icon icon-love addtowishlist"></a>
                                                <?php }
                                            else : ?>
                                                <a class="icon icon-love addtowishlist" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"></a>
                                            <?php endif;
                                        } else {
                                            $wishlist = get_user_meta($current_user->ID, 'bakala_wishlist', true);
                                            if (is_array($wishlist) && in_array($product->get_id(), $wishlist)) {
                                                $active = ' active';
                                            } else {
                                                $active = '';
                                            } ?>
                                            <a data-product-id="<?php echo $product->get_id() ?>" class="icon icon-love addtowishlist bakala-wishlist<?php echo $active; ?>"></a>
                                        <?php
                                        } ?>
                                    </li>
                                    <li class="bakala-tooltip">
                                        <a class="icon icon-more" id="showMoreIcons" href="#"></a>
                                    </li>
                                <?php } else { ?>
                                    <li class="bakala-tooltip">
                                        <div class="main">
                                            <label class="collection">
                                                <input type="checkbox">
                                                <div>
                                                    <span></span>
                                                </div>
                                            </label>
                                        </div>
                                    </li>
                                    <li class="bakala-tooltip">
                                        <a href="<?= home_url() ?>" class="home-botton"><i class="bakala-icon bakala-home-icon"></i></a>
                                    </li>
                                    <li class="bakala-tooltip">
                                        <?php
                                        $cart_count = bakala_get_cart_count();
                                        ?>
                                        <a class="icon icon-cart" href="<?= get_permalink(wc_get_page_id('cart')); ?>"><span class="ar-spender"><?= $cart_count ?></span></a>
                                    </li>
                                <?php } ?>
                            </ul>
                            <ul class="product-tooltips sticky">
                                <li class="bakala-tooltip">
                                    <?php
                                    $cart_count = bakala_get_cart_count();
                                    ?>
                                    <a class="icon icon-cart" href="<?= get_permalink(wc_get_page_id('cart')); ?>"><span class="ar-spender"><?= $cart_count ?></span></a>
                                </li>
                                <li class="bakala-tooltip">

                                    <?php
                                    if (is_user_logged_in()) {
                                    ?>
                                        <a class="icon icon-account" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"></a>
                                        <?php
                                    } else {
                                        if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true) {
                                            if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                                echo do_shortcode('[dm-modal]');
                                            } else {
                                        ?>
                                                <a class="icon icon-account" data-bs-toggle="modal" data-bs-target="#bakala_login" href="#"></a>
                                            <?php
                                            }
                                        } else {
                                            ?>
                                            <a class="icon icon-account" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"></a>
                                    <?php
                                        }
                                    }
                                    ?>
                                </li>
                                <li class="bakala-tooltip">
                                    <a class="icon icon-search" href="#search" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#search_modal"></a>
                                </li>
                            </ul>
                        </div>
                        <div class="off-canvas-panel_mo dialog--close" id="off-canvas_menu">
                            <a href="#" class="close-menu-button"><i class="bakala-icon close"></i></a>
                            <div class="off-canvas-panel-wrapper_mo">
                                <nav id="main-navigation_mo">
                                    <ul class="main-menu">
                                        <?php
                                        if (isset($bakala_options['mobile_menu']) && $bakala_options['mobile_menu']) {
                                            $main_nav_slug = get_term(get_nav_menu_locations()['mobile'], 'nav_menu')->slug;
                                        } else {
                                            $main_nav_slug = get_term(get_nav_menu_locations()['main'], 'nav_menu')->slug;
                                        }
                                        if (get_option('mobi_menu')) {
                                            $main_nav_id = get_option('mobi_menu');
                                        } else {
                                            $main_nav_id = $main_nav_slug;
                                        }
                                        $main_nav = wp_get_nav_menu_items($main_nav_id);
                                        if ($main_nav) {
                                            foreach ($main_nav as $menu_item) {
                                                if (is_object($menu_item) && isset($menu_item->ID)) {
                                                    $menu_item_icon = get_post_meta($menu_item->ID, '_menu_item_icon', true);
                                                }
                                                $childs = 0;
                                                if ($menu_item->menu_item_parent == '0') {
                                                    foreach ($main_nav as $menu_item_child_is) {
                                                        if ($menu_item_child_is->menu_item_parent == $menu_item->ID) {
                                                            $childs = $childs + 1;
                                                        }
                                                    }
                                                    if ($childs > 0) {
                                                        $menu_link = '#popup';
                                                    } else {
                                                        $menu_link = $menu_item->url;
                                                    }
                                        ?>
                                                    <li>
                                                        <span class="menu-title menu-title1">

                                                            <a class="btn_mo-ripple <?= $childs > 0 ? 'haschild' : '' ?> <?php if (implode('', $menu_item->classes)) echo implode('', $menu_item->classes); ?> <?= ($menu_item->url == '#' || $menu_link == '#popup') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" <?php if ($menu_item->target && $menu_link != '#popup') echo 'target="' . $menu_item->target . '" '; ?> <?php if ($menu_item->xfn) echo 'rel="' . $menu_item->xfn . '" '; ?> <?php if ($menu_item->attr_title) echo 'title="' . $menu_item->attr_title . '" '; ?> href="<?php echo $menu_link; ?>">


                                                                <?php if ($menu_item_icon) :
                                                                    $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                    if (preg_match($regx_img, $menu_item_icon) == 1) {
                                                                ?>
                                                                        <img src="<?= $menu_item_icon ?>" class="menu-item-icon" width="18">
                                                                    <?php } else { ?>
                                                                        <i class="<?= $menu_item_icon ?> menu-item-icon"></i>
                                                                <?php }
                                                                endif; ?>
                                                                <span class="pull-right"><?php echo $menu_item->title; ?></span>
                                                                <?php if ($childs > 0) { ?>
                                                                    <i class="fa fa-arrow-left next"></i>
                                                                <?php } ?>
                                                            </a>

                                                        </span>
                                                        <?php if ($childs > 0) { ?>
                                                            <ul class="collapse submenu">
                                                                <li class="go-back"><?php echo $menu_item->title; ?> <i class="fa fa-arrow-right"></i></li>
                                                                <?php
                                                                foreach ($main_nav as $menu_item_child) {
                                                                    if (is_object($menu_item_child) && isset($menu_item_child->ID)) {
                                                                        $menu_item_child_icon = get_post_meta($menu_item_child->ID, '_menu_item_icon', true);
                                                                    }
                                                                    $cchilds = 0;
                                                                    foreach ($main_nav as $menu_item_child_child_is) {

                                                                        if ($menu_item_child_child_is->menu_item_parent == $menu_item_child->ID) {
                                                                            $cchilds = $cchilds + 1;
                                                                        }
                                                                    }
                                                                    if ($cchilds > 0) {
                                                                        $cmenu_link = '#popup';
                                                                    } else {
                                                                        $cmenu_link = $menu_item_child->url;
                                                                    }
                                                                    if ($menu_item_child->menu_item_parent == $menu_item->ID) {
                                                                        $menu_item_child_class = is_array($menu_item_child->classes) ? $menu_item_child->classes : [];
                                                                ?>

                                                                        <li>
                                                                            <span class="menu-title menu-title2">
                                                                                <a class="btn_mo-ripple <?= $cchilds > 0 ? 'haschild' : '' ?> <?= ($menu_item_child->url == '#') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" href="<?php echo $cmenu_link; ?>" <?php if ($menu_item_child->target && $cmenu_link != '#popup') echo 'target="' . $menu_item_child->target . '" '; ?> <?php if ($menu_item_child->xfn) echo 'rel="' . $menu_item_child->xfn . '" '; ?> <?php if ($menu_item_child->attr_title) echo 'title="' . $menu_item_child->attr_title . '" '; ?>>

                                                                                    <?php if ($menu_item_child_icon) :
                                                                                        $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                        if (preg_match($regx_img, $menu_item_child_icon) == 1) {
                                                                                    ?>
                                                                                            <img src="<?= $menu_item_child_icon ?>" class="menu-item-icon" width="18">
                                                                                        <?php } else { ?>
                                                                                            <i class="<?= $menu_item_child_icon ?> menu-item-icon"></i>
                                                                                    <?php }
                                                                                    endif; ?>
                                                                                    <span class="pull-right"><?php echo $menu_item_child->title; ?></span>
                                                                                    <?php if ($cchilds > 0) { ?>
                                                                                        <i class="fa fa-arrow-left next"></i>
                                                                                    <?php } ?>
                                                                                </a>

                                                                            </span>
                                                                            <?php if ($cchilds > 0) { ?>
                                                                                <ul class="collapse submenu">
                                                                                    <li class="go-back"><?php echo $menu_item_child->title; ?>
                                                                                        <i class="fa fa-arrow-right"></i>
                                                                                    </li>

                                                                                    <?php
                                                                                    foreach ($main_nav as $menu_item_child_child) {
                                                                                        if (is_object($menu_item_child_child) && isset($menu_item_child_child->ID)) {
                                                                                            $menu_item_child_child_icon = get_post_meta($menu_item_child_child->ID, '_menu_item_icon', true);
                                                                                        }
                                                                                        if ($menu_item_child_child->menu_item_parent == $menu_item_child->ID) {
                                                                                            $ccchilds = 0;
                                                                                            foreach ($main_nav as $menu_item_child_child_child_is) {

                                                                                                if ($menu_item_child_child_child_is->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                    $ccchilds = $ccchilds + 1;
                                                                                                }
                                                                                            }
                                                                                    ?>
                                                                                            <li>
                                                                                                <span class="menu-title menu-title3">
                                                                                                    <a class="ch btn_mo-ripple <?= $menu_item_child_child->url == '#' ? 'next' : '' ?> <?= $ccchilds > 0 ? 'haschild' : '' ?>" href="<?= $menu_item_child_child->url ?>" property="url">
                                                                                                        <?php if ($menu_item_child_child_icon) :
                                                                                                            $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                            if (preg_match($regx_img, $menu_item_child_child_icon) == 1) {
                                                                                                        ?>
                                                                                                                <img src="<?= $menu_item_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                            <?php } else { ?>
                                                                                                                <i class="<?= $menu_item_child_child_icon ?> menu-item-icon"></i>
                                                                                                        <?php }
                                                                                                        endif; ?>
                                                                                                        <span><?= $menu_item_child_child->title ?></span>
                                                                                                        <?php if ($ccchilds > 0) { ?>
                                                                                                            <i class="fa fa-arrow-left next"></i>
                                                                                                        <?php } ?>
                                                                                                    </a>


                                                                                                </span>
                                                                                                <?php if ($ccchilds > 0) { ?>
                                                                                                    <ul class="collapse submenu">
                                                                                                        <li class="go-back"><?php echo $menu_item_child_child->title; ?>
                                                                                                            <i class="fa fa-arrow-right"></i>
                                                                                                        </li>

                                                                                                        <?php
                                                                                                        foreach ($main_nav as $menu_item_child_child_child) {
                                                                                                            if (is_object($menu_item_child_child_child) && isset($menu_item_child_child_child->ID)) {
                                                                                                                $menu_item_child_child_child_icon = get_post_meta($menu_item_child_child_child->ID, '_menu_item_icon', true);
                                                                                                            }
                                                                                                            if ($menu_item_child_child_child->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                        ?>
                                                                                                                <li>
                                                                                                                    <span class="menu-title4">
                                                                                                                        <a class="ch btn_mo-ripple" href="<?= $menu_item_child_child_child->url ?>" property="url">
                                                                                                                            <?php if ($menu_item_child_child_child_icon) :
                                                                                                                                $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                                if (preg_match($regx_img, $menu_item_child_child_child_icon) == 1) {
                                                                                                                            ?>
                                                                                                                                    <img src="<?= $menu_item_child_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                                <?php } else { ?>
                                                                                                                                    <i class="<?= $menu_item_child_child_child_icon ?> menu-item-icon"></i>
                                                                                                                            <?php }
                                                                                                                            endif; ?>
                                                                                                                            <span><?= $menu_item_child_child_child->title ?></span>

                                                                                                                        </a>

                                                                                                                    </span>

                                                                                                                </li>
                                                                                                        <?php
                                                                                                            }
                                                                                                        }

                                                                                                        echo '<li><a class="menu_mo-all" href="' . $menu_item_child_child->url . '"> همه ' . $menu_item_child_child->title . '</a></li>';

                                                                                                        ?>
                                                                                                    </ul>
                                                                                                <?php } ?>
                                                                                            </li>
                                                                                    <?php
                                                                                        }
                                                                                    }

                                                                                    echo '<li><a class="menu_mo-all" href="' . $menu_item_child->url . '"> همه ' . $menu_item_child->title . '</a></li>';

                                                                                    ?>
                                                                                </ul>
                                                                            <?php } ?>

                                                                        </li>
                                                                <?php }
                                                                }

                                                                echo '<li><a class="menu_mo-all" href="' . $menu_item->url . '"> همه ' . $menu_item->title . '</a>';

                                                                ?>
                                                            </ul>
                                                        <?php } ?>
                                                    </li>
                                        <?php }
                                            }
                                        } ?>
                                    </ul>
                                    <?php
                                    if (isset($bakala_options['enable_header_offer']) && $bakala_options['enable_header_offer'] && class_exists('WooCommerce')) {
                                        if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
                                            $term = get_term($bakala_options['offer_menu_cat']);
                                            if ($term) { ?>
                                                <a class="special-offer-link" href="<?php echo get_term_link($term); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                            <?php }
                                        } elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) { ?>
                                            <a class="special-offer-link" href="<?php echo get_permalink($bakala_options['offer_menu_link']); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                    <?php }
                                    }
                                    ?>
                                    <?php if (isset($bakala_options['night_mode']) && $bakala_options['night_mode'] == true) { ?>
                                        <div class="dk-switch-container">
                                            <span class="night-label"><?php _e('Night mode: ', 'bakala'); ?></span>
                                            <div id="night_mode_switcher" class="night_mode_switch dk-switch-wrapper clearfix <?php if ((isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') || (!isset($_COOKIE['night_mode']) && $bakala_options['default_mode'] == 'night')) {
                                                                                                                                    echo 'active';
                                                                                                                                } else {
                                                                                                                                    echo 'inactive';
                                                                                                                                } ?>">
                                                <span class="dk-switch-enabled"><?php _e('Night', 'bakala'); ?></span>
                                                <span class="dk-switch-disabled"><?php _e('Day', 'bakala'); ?></span>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </nav>
                            </div>
                            <ul class="socials">
                                <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['facebook']; ?>"><i class="icon icon-footer-facebook"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['twitter']; ?>"><i class="icon icon-footer-twitter"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['googleplus']; ?>"><i class="icon icon-footer-googleplus"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['instagram']; ?>"><i class="icon icon-footer-instagram"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['youtube']; ?>"><i class="icon icon-footer-aparat"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['vimeo']; ?>"><i class="icon icon-footer-telegram"></i></a>
                                    </li>
                                <?php } ?>
                                <?php
                                if (is_array($bakala_options['other_socials'])) {
                                    foreach ($bakala_options['other_socials'] as $item) {
                                        if (!empty($item['image'])) {
                                ?>
                                            <li>
                                                <a target="_blank" href="<?php echo $item['url']; ?>"><img class="other_socials_img" src="<?php echo $item['image'] ?>"></a>
                                            </li>
                                <?php }
                                    }
                                } ?>
                            </ul>
                        </div>
                    </div>
                <?php
                } else {
                ?>
                    <div id="header-container" class="<?php if (is_mobile_or_tablet()) {
                                                            if ($bakala_options['sticky_header_mob'] == true) {
                                                                echo 'sticky-header';
                                                            }
                                                        } else {
                                                            if ($bakala_options['sticky_header_desk'] == true) {
                                                                echo 'sticky-header';
                                                            }
                                                        } ?> mt-header t-layout-padding-reverse tw-px-3  lg:tw-pt-0 lg:tw-px-0 lg:tw-shadow-none tw-mb-3 lg:tw-mb-0  lg:tw-pb-0 xl:tw-pb-0 2xl:tw-pb-0 tw-shadow-design-bottom-2 main-header" data-v-41aa9d8a="">

                        <header <?php if (is_mobile_or_tablet()) {
                                    if ($bakala_options['sticky_header_mob'] == true) {
                                        echo 'id="navbar-primary-fixed"';
                                    }
                                } else {
                                    if ($bakala_options['sticky_header_desk'] == true) {
                                        echo 'id="navbar-primary-fixed"';
                                    }
                                } ?> class="tw-w-full <?php if (is_mobile_or_tablet()) {
                                                            if ($bakala_options['sticky_header_mob'] == true) {
                                                                echo 'mt-sticky-header';
                                                            }
                                                        } else {
                                                            if ($bakala_options['sticky_header_desk'] == true) {
                                                                echo 'mt-sticky-header';
                                                            }
                                                        } ?>" data-v-41aa9d8a="">

                            <div class="lg:tw-px-3" data-v-41aa9d8a="">
                                <?php
                                if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
                                    $logo_href = $bakala_options['site_header_logo']['url'];
                                } else {
                                    $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                                }
                                ?>
                                <div id="mobile-header" class=" tw-w-full tw-pt-4 t-row lg:tw-hidden  " data-v-41aa9d8a="">
                                    <div class="tw-w-1/3" data-v-41aa9d8a="">
                                        <div id="icon-menu" class="icon-menu-handler-svg">
                                            <div class="c-header__burger">
                                                <p class="divider-menu"></p>
                                            </div>
                                        </div>
                                        <div class="off-canvas-panel_mo dialog--close" id="off-canvas_menu">
                                            <a href="#" class="close-menu-button"><i class="bakala-icon close"></i></a>
                                            <div class="off-canvas-panel-wrapper_mo">
                                                <nav id="main-navigation_mo">
                                                    <ul class="main-menu">
                                                        <?php
                                                        if (isset($bakala_options['mobile_menu']) && $bakala_options['mobile_menu']) {
                                                            $main_nav_slug = get_term(get_nav_menu_locations()['mobile'], 'nav_menu')->slug;
                                                        } else {
                                                            $main_nav_slug = get_term(get_nav_menu_locations()['main'], 'nav_menu')->slug;
                                                        }
                                                        if (get_option('mobi_menu')) {
                                                            $main_nav_id = get_option('mobi_menu');
                                                        } else {
                                                            $main_nav_id = $main_nav_slug;
                                                        }
                                                        $main_nav = wp_get_nav_menu_items($main_nav_id);
                                                        if ($main_nav) {
                                                            foreach ($main_nav as $menu_item) {
                                                                if (is_object($menu_item) && isset($menu_item->ID)) {
                                                                    $menu_item_icon = get_post_meta($menu_item->ID, '_menu_item_icon', true);
                                                                }
                                                                $childs = 0;
                                                                if ($menu_item->menu_item_parent == '0') {
                                                                    foreach ($main_nav as $menu_item_child_is) {
                                                                        if ($menu_item_child_is->menu_item_parent == $menu_item->ID) {
                                                                            $childs = $childs + 1;
                                                                        }
                                                                    }
                                                                    if ($childs > 0) {
                                                                        $menu_link = '#popup';
                                                                    } else {
                                                                        $menu_link = $menu_item->url;
                                                                    }
                                                        ?>
                                                                    <li>
                                                                        <span class="menu-title menu-title1">

                                                                            <a class="btn_mo-ripple <?= $childs > 0 ? 'haschild' : '' ?> <?php if (implode('', $menu_item->classes)) echo implode('', $menu_item->classes); ?> <?= ($menu_item->url == '#' || $menu_link == '#popup') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" <?php if ($menu_item->target && $menu_link != '#popup') echo 'target="' . $menu_item->target . '" '; ?> <?php if ($menu_item->xfn) echo 'rel="' . $menu_item->xfn . '" '; ?> <?php if ($menu_item->attr_title) echo 'title="' . $menu_item->attr_title . '" '; ?> href="<?php echo $menu_link; ?>">


                                                                                <?php if ($menu_item_icon) :
                                                                                    $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                    if (preg_match($regx_img, $menu_item_icon) == 1) {
                                                                                ?>
                                                                                        <img src="<?= $menu_item_icon ?>" class="menu-item-icon" width="18">
                                                                                    <?php } else { ?>
                                                                                        <i class="<?= $menu_item_icon ?> menu-item-icon"></i>
                                                                                <?php }
                                                                                endif; ?>
                                                                                <span class="pull-right"><?php echo $menu_item->title; ?></span>
                                                                                <?php if ($childs > 0) { ?>
                                                                                    <i class="fa fa-arrow-left next"></i>
                                                                                <?php } ?>
                                                                            </a>

                                                                        </span>
                                                                        <?php if ($childs > 0) { ?>
                                                                            <ul class="collapse submenu">
                                                                                <li class="go-back"><?php echo $menu_item->title; ?> <i class="fa fa-arrow-right"></i></li>
                                                                                <?php
                                                                                foreach ($main_nav as $menu_item_child) {
                                                                                    if (is_object($menu_item_child) && isset($menu_item_child->ID)) {
                                                                                        $menu_item_child_icon = get_post_meta($menu_item_child->ID, '_menu_item_icon', true);
                                                                                    }
                                                                                    $cchilds = 0;
                                                                                    foreach ($main_nav as $menu_item_child_child_is) {

                                                                                        if ($menu_item_child_child_is->menu_item_parent == $menu_item_child->ID) {
                                                                                            $cchilds = $cchilds + 1;
                                                                                        }
                                                                                    }
                                                                                    if ($cchilds > 0) {
                                                                                        $cmenu_link = '#popup';
                                                                                    } else {
                                                                                        $cmenu_link = $menu_item_child->url;
                                                                                    }
                                                                                    if ($menu_item_child->menu_item_parent == $menu_item->ID) { ?>

                                                                                        <li>
                                                                                            <span class="menu-title menu-title2">
                                                                                                <a class="btn_mo-ripple <?= $cchilds > 0 ? 'haschild' : '' ?> <?php if (implode(' ', $menu_item_child->classes)) echo implode(' ', $menu_item_child->classes); ?> <?= ($menu_item_child->url == '#') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" href="<?php echo $cmenu_link; ?>" <?php if ($menu_item_child->target && $cmenu_link != '#popup') echo 'target="' . $menu_item_child->target . '" '; ?> <?php if ($menu_item_child->xfn) echo 'rel="' . $menu_item_child->xfn . '" '; ?> <?php if ($menu_item_child->attr_title) echo 'title="' . $menu_item_child->attr_title . '" '; ?>>

                                                                                                    <?php if ($menu_item_child_icon) :
                                                                                                        $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                        if (preg_match($regx_img, $menu_item_child_icon) == 1) {
                                                                                                    ?>
                                                                                                            <img src="<?= $menu_item_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                        <?php } else { ?>
                                                                                                            <i class="<?= $menu_item_child_icon ?> menu-item-icon"></i>
                                                                                                    <?php }
                                                                                                    endif; ?>
                                                                                                    <span class="pull-right"><?php echo $menu_item_child->title; ?></span>
                                                                                                    <?php if ($cchilds > 0) { ?>
                                                                                                        <i class="fa fa-arrow-left next"></i>
                                                                                                    <?php } ?>
                                                                                                </a>

                                                                                            </span>
                                                                                            <?php if ($cchilds > 0) { ?>
                                                                                                <ul class="collapse submenu">
                                                                                                    <li class="go-back"><?php echo $menu_item_child->title; ?>
                                                                                                        <i class="fa fa-arrow-right"></i>
                                                                                                    </li>

                                                                                                    <?php
                                                                                                    foreach ($main_nav as $menu_item_child_child) {
                                                                                                        if (is_object($menu_item_child_child) && isset($menu_item_child_child->ID)) {
                                                                                                            $menu_item_child_child_icon = get_post_meta($menu_item_child_child->ID, '_menu_item_icon', true);
                                                                                                        }
                                                                                                        if ($menu_item_child_child->menu_item_parent == $menu_item_child->ID) {
                                                                                                            $ccchilds = 0;
                                                                                                            foreach ($main_nav as $menu_item_child_child_child_is) {

                                                                                                                if ($menu_item_child_child_child_is->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                                    $ccchilds = $ccchilds + 1;
                                                                                                                }
                                                                                                            }
                                                                                                    ?>
                                                                                                            <li>
                                                                                                                <span class="menu-title menu-title3">
                                                                                                                    <a class="ch btn_mo-ripple <?= $menu_item_child_child->url == '#' ? 'next' : '' ?> <?= $ccchilds > 0 ? 'haschild' : '' ?>" href="<?= $menu_item_child_child->url ?>" property="url">
                                                                                                                        <?php if ($menu_item_child_child_icon) :
                                                                                                                            $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                            if (preg_match($regx_img, $menu_item_child_child_icon) == 1) {
                                                                                                                        ?>
                                                                                                                                <img src="<?= $menu_item_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                            <?php } else { ?>
                                                                                                                                <i class="<?= $menu_item_child_child_icon ?> menu-item-icon"></i>
                                                                                                                        <?php }
                                                                                                                        endif; ?>
                                                                                                                        <span><?= $menu_item_child_child->title ?></span>
                                                                                                                        <?php if ($ccchilds > 0) { ?>
                                                                                                                            <i class="fa fa-arrow-left next"></i>
                                                                                                                        <?php } ?>
                                                                                                                    </a>


                                                                                                                </span>
                                                                                                                <?php if ($ccchilds > 0) { ?>
                                                                                                                    <ul class="collapse submenu">
                                                                                                                        <li class="go-back"><?php echo $menu_item_child_child->title; ?>
                                                                                                                            <i class="fa fa-arrow-right"></i>
                                                                                                                        </li>

                                                                                                                        <?php
                                                                                                                        foreach ($main_nav as $menu_item_child_child_child) {
                                                                                                                            if (is_object($menu_item_child_child_child) && isset($menu_item_child_child_child->ID)) {
                                                                                                                                $menu_item_child_child_child_icon = get_post_meta($menu_item_child_child_child->ID, '_menu_item_icon', true);
                                                                                                                            }
                                                                                                                            if ($menu_item_child_child_child->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                                        ?>
                                                                                                                                <li>
                                                                                                                                    <span class="menu-title4">
                                                                                                                                        <a class="ch btn_mo-ripple" href="<?= $menu_item_child_child_child->url ?>" property="url">
                                                                                                                                            <?php if ($menu_item_child_child_child_icon) :
                                                                                                                                                $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                                                if (preg_match($regx_img, $menu_item_child_child_child_icon) == 1) {
                                                                                                                                            ?>
                                                                                                                                                    <img src="<?= $menu_item_child_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                                                <?php } else { ?>
                                                                                                                                                    <i class="<?= $menu_item_child_child_child_icon ?> menu-item-icon"></i>
                                                                                                                                            <?php }
                                                                                                                                            endif; ?>
                                                                                                                                            <span><?= $menu_item_child_child_child->title ?></span>

                                                                                                                                        </a>

                                                                                                                                    </span>

                                                                                                                                </li>
                                                                                                                        <?php
                                                                                                                            }
                                                                                                                        }

                                                                                                                        echo '<li><a class="menu_mo-all" href="' . $menu_item_child_child->url . '"> همه ' . $menu_item_child_child->title . '</a></li>';

                                                                                                                        ?>
                                                                                                                    </ul>
                                                                                                                <?php } ?>
                                                                                                            </li>
                                                                                                    <?php
                                                                                                        }
                                                                                                    }

                                                                                                    echo '<li><a class="menu_mo-all" href="' . $menu_item_child->url . '"> همه ' . $menu_item_child->title . '</a></li>';

                                                                                                    ?>
                                                                                                </ul>
                                                                                            <?php } ?>

                                                                                        </li>
                                                                                <?php }
                                                                                }

                                                                                echo '<li><a class="menu_mo-all" href="' . $menu_item->url . '"> همه ' . $menu_item->title . '</a>';

                                                                                ?>
                                                                            </ul>
                                                                        <?php } ?>
                                                                    </li>
                                                        <?php }
                                                            }
                                                        } ?>
                                                    </ul>
                                                    <?php
                                                    if (isset($bakala_options['enable_header_offer']) && $bakala_options['enable_header_offer'] && class_exists('WooCommerce')) {
                                                        if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
                                                            $term = get_term($bakala_options['offer_menu_cat']);
                                                            if ($term) { ?>
                                                                <a class="special-offer-link" href="<?php echo get_term_link($term); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                                            <?php }
                                                        } elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) { ?>
                                                            <a class="special-offer-link" href="<?php echo get_permalink($bakala_options['offer_menu_link']); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                                    <?php }
                                                    }
                                                    ?>
                                                    <?php if (isset($bakala_options['night_mode']) && $bakala_options['night_mode'] == true) { ?>
                                                        <div class="dk-switch-container">
                                                            <span class="night-label"><?php _e('Night mode: ', 'bakala'); ?></span>
                                                            <div id="night_mode_switcher" class="night_mode_switch dk-switch-wrapper clearfix <?php if ((isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') || (!isset($_COOKIE['night_mode']) && $bakala_options['default_mode'] == 'night')) {
                                                                                                                                                    echo 'active';
                                                                                                                                                } else {
                                                                                                                                                    echo 'inactive';
                                                                                                                                                } ?>">
                                                                <span class="dk-switch-enabled"><?php _e('Night', 'bakala'); ?></span>
                                                                <span class="dk-switch-disabled"><?php _e('Day', 'bakala'); ?></span>
                                                            </div>
                                                        </div>
                                                    <?php } ?>
                                                </nav>
                                            </div>
                                            <ul class="socials">
                                                <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                                    <li>
                                                        <a target="_blank" href="<?php echo $bakala_options['facebook']; ?>"><i class="icon icon-footer-facebook"></i></a>
                                                    </li>
                                                <?php } ?>
                                                <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                                    <li>
                                                        <a target="_blank" href="<?php echo $bakala_options['twitter']; ?>"><i class="icon icon-footer-twitter"></i></a>
                                                    </li>
                                                <?php } ?>
                                                <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                                    <li>
                                                        <a target="_blank" href="<?php echo $bakala_options['googleplus']; ?>"><i class="icon icon-footer-googleplus"></i></a>
                                                    </li>
                                                <?php } ?>
                                                <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                                    <li>
                                                        <a target="_blank" href="<?php echo $bakala_options['instagram']; ?>"><i class="icon icon-footer-instagram"></i></a>
                                                    </li>
                                                <?php } ?>
                                                <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                                    <li>
                                                        <a target="_blank" href="<?php echo $bakala_options['youtube']; ?>"><i class="icon icon-footer-aparat"></i></a>
                                                    </li>
                                                <?php } ?>
                                                <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                                    <li>
                                                        <a target="_blank" href="<?php echo $bakala_options['vimeo']; ?>"><i class="icon icon-footer-telegram"></i></a>
                                                    </li>
                                                <?php } ?>
                                                <?php
                                                if (is_array($bakala_options['other_socials'])) {
                                                    foreach ($bakala_options['other_socials'] as $item) {
                                                        if (!empty($item['image'])) {
                                                ?>
                                                            <li>
                                                                <a target="_blank" href="<?php echo $item['url']; ?>"><img class="other_socials_img" src="<?php echo $item['image'] ?>"></a>
                                                            </li>
                                                <?php }
                                                    }
                                                } ?>
                                            </ul>
                                        </div>
                                    </div>
                                    <a href="/" aria-current="page" class="tw-w-1/3 nuxt-link-exact-active nuxt-link-active" data-v-d5b73d68="" data-v-41aa9d8a=""><span class="tw-mx-auto tw-w-16 tw-h-6 tw-block" data-v-41aa9d8a=""><img data-name="image-img" src="<?= $logo_href ?>" class="tw-w-full tw-h-full tw-transition-opacity tw-duration-500">
                                            <!----></span></a>
                                </div>
                                <div class="t-flex-between-center lg:tw-min-h-[3.25rem] tw-z-10 tw-py-1 lg:tw-pt-2" data-v-41aa9d8a="">
                                    <div class="tw-z-[59] t-row tw-relative tw-my-3 tw-w-full lg:tw-flex-row lg:tw-justify-between lg:tw-my-0 lg:tw-w-4/5 lg:tw-space-x-5 lg:tw-space-x-reverse" data-v-41aa9d8a="">
                                        <?php if (!is_mobile_or_tablet()) { ?>
                                            <div data-v-41aa9d8a="" class="tw-cursor-pointer tw-block tw-ml-2 lg:tw-ml-0"><span class="lg:tw-ml-6 tw-pointer lg:tw-min-w-[4.5rem] tw-block tw-w-20 tw-h-9"><a href="<?php echo home_url('/'); ?>"><img data-name="image-img" src="<?= $logo_href ?>" alt="لوگو سایت" class="tw-w-full tw-h-full tw-transition-opacity tw-duration-500"></a>
                                                    <!----></span></div>
                                            <div data-v-585821db="" data-v-41aa9d8a="" class="mbt-menu-categories-desktop tw-z-[-1] tw-absolute tw-left-0 tw-right-0 lg:tw-relative tw-hidden tw-pt-3 tw-isolate lg:tw-block" style="transform: translate(0px, 0px);flex:2;">
                                                <div data-v-585821db="" class="mbt-menu-categories-child-desktop tw-relative tw-flex tw-items-center" style="opacity: 1;">
                                                    <?php if (function_exists('ubermenu')) :
                                                        ubermenu('main', array('theme_location' => 'uber'));
                                                    else :
                                                        bkm_menu();
                                                    endif;
                                                    ?>
                                                </div>
                                            </div>
                                        <?php } ?>
                                        <div class="t-row tw-w-full" data-v-41aa9d8a="" style="flex:1">
                                            <div class="tw-flex tw-flex-col tw-items-center tw-w-full lg:tw-flex-row  tw-w-[85%] lg:tw-w-full lg:min-h-[3.25rem] lg:tw-mt-0" data-v-a7a31ca8="" data-v-41aa9d8a="">
                                                <div data-name="menu-wrapper" data-trigger-add="tw-w-full lg:tw-z-[81] tw-rounded-t-none lg:tw-rounded " data-items-add="lg:tw-z-[80] lg:tw-bg-white tw-duration-100 tw-ease lg:tw-top-[3.25rem] lg:t-shadow-search
     lg:tw-px-4
    " data-items-delete="tw-z-30 tw-z-40 tw-border tw-scale-0 tw-rounded-t-none tw-px-2 " class="lg:tw-z-[80] tw-w-full tw-ease-linear lg:tw-w-full tw-relative" data-v-d7998d90="" data-v-a7a31ca8="">
                                                    <?php if (isset($bakala_options['show_search']) && $bakala_options['show_search']) { ?>
                                                        <div class="navbar-search w-100">
                                                            <?php echo do_shortcode('[wcas-search-form]'); ?>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="tw-w-[15%] lg:tw-hidden" data-v-41aa9d8a="">


                                            </div>
                                        </div>
                                    </div>
                                    <div data-v-41aa9d8a="" class="lg:tw-min-h-[3rem] tw-hidden tw-items-center tw-space-x-3 tw-space-x-reverse lg:tw-flex">
                                        <div data-v-104ce55b="" data-v-41aa9d8a="">
                                            <div data-v-d7998d90="" data-v-104ce55b="" data-name="menu-wrapper" class="tw-relative tbar" data-items-delete="tw-rounded-t-none tw-border tw-shadow-lg tw-z-30 tw-z-40" data-items-add="tw-transform tw-translate-y-2 tw-shadow-design tw-z-[80] lg:tw-top-[2.75rem]">
                                                <div style="display:flex">
                                                    <?php if (!is_user_logged_in()) {

                                                        if ($bakala_options['lr_bakala'] == 1 && $bakala_options['popup_login'] == true) {

                                                    ?>
                                                            <a href="#bakala_login" class="bakala_lr_btn">
                                                                <div class="bakala-header-account">
                                                                    <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                                                    <div class="bakala-header-account-text">
                                                                        <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?></strong>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                            <?php
                                                        } else {
                                                            if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true && $bakala_options['lr_bakala'] == 0) {
                                                                if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                                                    echo do_shortcode('[dm-login-modal]');
                                                                } else { ?>
                                                                    <a data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login" class="bakala_lr_btn">
                                                                        <div class="bakala-header-account">
                                                                            <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                                                            <div class="bakala-header-account-text">
                                                                                <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?></strong>
                                                                            </div>
                                                                        </div>
                                                                    </a>
                                                                <?php
                                                                }
                                                            } else { ?>
                                                                <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" class="bakala_lr_btn">
                                                                    <div class="bakala-header-account">
                                                                        <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                                                        <div class="bakala-header-account-text">
                                                                            <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?></strong>
                                                                        </div>
                                                                    </div>
                                                                </a>
                                                            <?php } ?>
                                                            <?php if (!function_exists('digits_addon_digoneclickls')) { ?>

                                                        <?php }
                                                        }
                                                    } else {
                                                        ?>
                                                        <div class="bakala-header-account">
                                                            <i class="bakala-header-account-icon bakala-icon icon-account"></i>

                                                            <div class="bakala-header-account-text">
                                                                <strong><?= $user_name ?></strong>
                                                            </div>
                                                        </div>
                                                        <a class="c-header__btn-user js-dropdown-toggle">
                                                            <div class="user-menu-toggle">

                                                            </div>

                                                        </a>

                                                        <div class="c-header__user-dropdown js-dropdown-menu" style="display: none;">

                                                            <?php if (!is_user_logged_in()) {
                                                                if ($bakala_options['lr_bakala'] == 1) {
                                                            ?>
                                                                    <a data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login" class="c-header__user-dropdown-login">
                                                                        <?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?>
                                                                    </a>
                                                                    <?php
                                                                } else {
                                                                    if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true) {
                                                                        if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                                                            echo do_shortcode('[dm-login-modal]');
                                                                        } else { ?>
                                                                            <a data-bs-toggle="modal" data-bs-target="#bakala_login" class="c-header__user-dropdown-login">
                                                                                <?php echo _e('Login', 'bakala'); ?>
                                                                            </a>
                                                                        <?php
                                                                        }
                                                                    } else { ?>
                                                                        <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>" class="c-header__user-dropdown-login">
                                                                            <?php echo _e('Login', 'bakala'); ?>
                                                                        </a>
                                                                    <?php } ?>
                                                                    <?php if (!function_exists('digits_addon_digoneclickls')) { ?>
                                                                        <div class="c-header__user-dropdown-sign-up">
                                                                            <span>
                                                                                <?php echo _e('New user?', 'bakala'); ?>
                                                                            </span>
                                                                            <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>">
                                                                                <?php echo _e('Register', 'bakala'); ?>
                                                                            </a>
                                                                        </div>
                                                                <?php }
                                                                } ?>
                                                            <?php } ?>

                                                            <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" class="c-header__user-dropdown-action c-header__user-dropdown-action--profile" data-event="profile_click" data-event-category="header_section" data-event-label="logged_in: False">
                                                                <div>
                                                                    <div class="profile-avatar">
                                                                        <?php echo get_avatar($current_user->ID, 48); ?>
                                                                    </div>
                                                                    <div class="profile-name">
                                                                        <span>
                                                                            <?= $user_name ?>
                                                                        </span>
                                                                        <i class="fa fa-chevron-left"></i>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                            <?php
                                                            if (!empty($bakala_options['top_bar_trackorder']) || $bakala_options['myaccount_tracking_order'] == 1) {
                                                                if (isset($bakala_options['top_bar_trackorder']) && $bakala_options['top_bar_trackorder']) {
                                                                    $order_tracking_link = get_permalink($bakala_options['top_bar_trackorder']);
                                                                } elseif (!$bakala_options['top_bar_trackorder']) {
                                                                    $order_tracking_link = get_permalink(get_option('woocommerce_myaccount_page_id')) . 'your-tracking/';
                                                                }

                                                            ?>
                                                                <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?= $order_tracking_link ?>">
                                                                    <span class="orders-menu"></span>
                                                                    <?php echo _e('Track Order', 'bakala'); ?>
                                                                </a>
                                                            <?php
                                                            }
                                                            ?>
                                                            <?php if (is_plugin_active('address-plus/address-plus.php')) { ?>
                              <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('addressplus-addresses'); ?>">
                                <span class="icon icon-address"></span>
                                <?php echo _e('My Addresses', 'bakala'); ?>
                              </a>
                          <?php } ?>
                                                            <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-wishlist'); ?>">
                                                                <span class="icon icon-love"></span>
                                                                <?php echo _e('My Wishlist', 'bakala'); ?>
                                                            </a>
                                                            <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-comments'); ?>">
                                                                <span class="icon my-comments"></span>
                                                                <?php echo _e('نقد و نظرات', 'bakala'); ?>
                                                            </a>
                                                            <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-notifications'); ?>">
                                                                <span class="icon my-notes"></span>
                                                                <?php echo _e('اعلانات', 'bakala'); ?>
                                                            </a>

                                                            <?php if (is_user_logged_in()) { ?>
                                                                <a href="<?php echo wp_logout_url(home_url()); ?>" class="c-header__user-dropdown-action c-header__user-dropdown-action--logout">
                                                                    <i class="bakala-loguot"></i>
                                                                    <?= $bakala_options['logout-label'] ? $bakala_options['logout-label'] : _e('خروج از حساب کاربری', 'bakala'); ?>
                                                                </a>
                                                            <?php } ?>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div data-v-41aa9d8a="">
                                            <?php if (isset($bakala_options['show_cart']) && $bakala_options['show_cart'] && $bakala_options['catalog_mode'] == false && class_exists('WooCommerce') && !is_cart() && !is_checkout()) {
                                                $cart_count = bakala_get_cart_count();
                                                if ($bakala_options['force_login_cart'] == 1 && !is_user_logged_in()) {
                                                    $cart_text = '<i class="bakala-icon more-icon"></i>';
                                                } else {
                                                    if ($cart_count > 0) {
                                                        $cart_text = wc_price(WC()->cart->subtotal);
                                                    } else {
                                                        $cart_text = __('is empty', 'bakala');
                                                    }
                                                }
                                            ?>
                                                <div class="cart-box<?php if ($cart_count > 0) {
                                                                        echo ' fill';
                                                                    } ?>">
                                                    <div class="dk-button-container hasIcon">
                                                        <div class="dk-button green header-cart">
                                                            <div class="header-cart-icon">
                                                                <i class="dk-button-icon dk-button-icon-cart"></i>
                                                            </div>
                                                            <div class="header-cart-text">
                                                                <?php if ($cart_count > 1) { ?>
                                                                    <span><?= $cart_count ?> کالا</span>
                                                                <?php } else { ?>
                                                                    <span><?= esc_html__('Cart', 'bakala'); ?></span>
                                                                <?php } ?>
                                                            </div>

                                                        </div>
                                                    </div>
                                                    <div class="mini-cart-dropdown" style="display:none">
                                                        <?php woocommerce_mini_cart(); ?>
                                                    </div>

                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div> <!---->
                            <?php
                            if (is_mobile_or_tablet()) {
                                if ($bakala_options['header_categories_enable_mobile'] == '1' && !empty($bakala_options['header_categories'])) { ?>
                                    <div class="bakala-product-categories-header">
                                        <?php foreach ($bakala_options['header_categories'] as $category_id) {
                                            $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
                                            $image_url = wp_get_attachment_url($thumbnail_id);
                                            $term = get_term_by('id', $category_id, 'product_cat');
                                            $link = get_term_link($term->slug, 'product_cat');

                                        ?>
                                            <a href="<?php echo $link ?>" class="bakala-product-category-header">
                                                <div class="bakala-product-category-header-img">
                                                    <img src="<?= $image_url ?>" alt="<?= $term->name ?>" loading="lazy" style="filter: blur(0px);">
                                                </div>
                                                <span class="bakala-product-category-header-title" style="color: rgba(0, 0, 0, 0.56);"><?= $term->name ?></span>
                                            </a>
                                        <?php } ?>
                                    </div>
                                <?php }
                            } else {
                                if ($bakala_options['header_categories_enable_pc'] == '1' && !empty($bakala_options['header_categories']) && (is_home() || is_front_page())) { ?>
                                    <div class="bakala-product-categories-header">
                                        <?php foreach ($bakala_options['header_categories'] as $category_id) {
                                            $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
                                            $image_url = wp_get_attachment_url($thumbnail_id);
                                            $term = get_term_by('id', $category_id, 'product_cat');
                                            $link = get_term_link($term->slug, 'product_cat');

                                        ?>
                                            <a href="<?php echo $link ?>" class="bakala-product-category-header">
                                                <div class="bakala-product-category-header-img">
                                                    <img src="<?= $image_url ?>" alt="<?= $term->name ?>" loading="lazy" style="filter: blur(0px);">
                                                </div>
                                                <span class="bakala-product-category-header-title" style="color: rgba(0, 0, 0, 0.56);"><?= $term->name ?></span>
                                            </a>
                                        <?php } ?>
                                    </div>
                            <?php }
                            }
                            ?>
                        </header>

                    </div>
                <?php
                }
            } else {
                ?>
                <div id="header-container" class="<?php if (is_mobile_or_tablet()) {
                                                        if ($bakala_options['sticky_header_mob'] == true) {
                                                            echo 'sticky-header';
                                                        }
                                                    } else {
                                                        if ($bakala_options['sticky_header_desk'] == true) {
                                                            echo 'sticky-header';
                                                        }
                                                    } ?> mt-header t-layout-padding-reverse tw-px-3  lg:tw-pt-0 lg:tw-px-0 lg:tw-shadow-none tw-mb-3 lg:tw-mb-0  lg:tw-pb-0 xl:tw-pb-0 2xl:tw-pb-0 tw-shadow-design-bottom-2 main-header" data-v-41aa9d8a="">

                    <header <?php if (is_mobile_or_tablet()) {
                                if ($bakala_options['sticky_header_mob'] == true) {
                                    echo 'id="navbar-primary-fixed"';
                                }
                            } else {
                                if ($bakala_options['sticky_header_desk'] == true) {
                                    echo 'id="navbar-primary-fixed"';
                                }
                            } ?> class="tw-w-full <?php if (is_mobile_or_tablet()) {
                                                        if ($bakala_options['sticky_header_mob'] == true) {
                                                            echo 'mt-sticky-header';
                                                        }
                                                    } else {
                                                        if ($bakala_options['sticky_header_desk'] == true) {
                                                            echo 'mt-sticky-header';
                                                        }
                                                    } ?>" data-v-41aa9d8a="">

                        <div class="lg:tw-px-3" data-v-41aa9d8a="">
                            <?php
                            if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
                                $logo_href = $bakala_options['site_header_logo']['url'];
                            } else {
                                $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                            }
                            ?>
                            <div id="mobile-header" class=" tw-w-full tw-pt-4 t-row lg:tw-hidden  " data-v-41aa9d8a="">
                                <div class="tw-w-1/3" data-v-41aa9d8a="">
                                    <div id="icon-menu" class="icon-menu-handler-svg">
                                        <div class="c-header__burger">
                                            <p class="divider-menu"></p>
                                        </div>
                                    </div>
                                    <div class="off-canvas-panel_mo dialog--close" id="off-canvas_menu">
                                        <a href="#" class="close-menu-button"><i class="bakala-icon close"></i></a>
                                        <div class="off-canvas-panel-wrapper_mo">
                                            <nav id="main-navigation_mo">
                                                <ul class="main-menu">
                                                    <?php
                                                    if (isset($bakala_options['mobile_menu']) && $bakala_options['mobile_menu']) {
                                                        $main_nav_slug = get_term(get_nav_menu_locations()['mobile'], 'nav_menu')->slug;
                                                    } else {
                                                        $main_nav_slug = get_term(get_nav_menu_locations()['main'], 'nav_menu')->slug;
                                                    }
                                                    if (get_option('mobi_menu')) {
                                                        $main_nav_id = get_option('mobi_menu');
                                                    } else {
                                                        $main_nav_id = $main_nav_slug;
                                                    }
                                                    $main_nav = wp_get_nav_menu_items($main_nav_id);
                                                    if ($main_nav) {
                                                        foreach ($main_nav as $menu_item) {
                                                            if (is_object($menu_item) && isset($menu_item->ID)) {
                                                                $menu_item_icon = get_post_meta($menu_item->ID, '_menu_item_icon', true);
                                                            }
                                                            $childs = 0;
                                                            if ($menu_item->menu_item_parent == '0') {
                                                                foreach ($main_nav as $menu_item_child_is) {
                                                                    if ($menu_item_child_is->menu_item_parent == $menu_item->ID) {
                                                                        $childs = $childs + 1;
                                                                    }
                                                                }
                                                                if ($childs > 0) {
                                                                    $menu_link = '#popup';
                                                                } else {
                                                                    $menu_link = $menu_item->url;
                                                                }
                                                    ?>
                                                                <li>
                                                                    <span class="menu-title menu-title1">

                                                                        <a class="btn_mo-ripple <?= $childs > 0 ? 'haschild' : '' ?> <?php if (implode('', $menu_item->classes)) echo implode('', $menu_item->classes); ?> <?= ($menu_item->url == '#' || $menu_link == '#popup') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" <?php if ($menu_item->target && $menu_link != '#popup') echo 'target="' . $menu_item->target . '" '; ?> <?php if ($menu_item->xfn) echo 'rel="' . $menu_item->xfn . '" '; ?> <?php if ($menu_item->attr_title) echo 'title="' . $menu_item->attr_title . '" '; ?> href="<?php echo $menu_link; ?>">


                                                                            <?php if ($menu_item_icon) :
                                                                                $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                if (preg_match($regx_img, $menu_item_icon) == 1) {
                                                                            ?>
                                                                                    <img src="<?= $menu_item_icon ?>" class="menu-item-icon" width="18">
                                                                                <?php } else { ?>
                                                                                    <i class="<?= $menu_item_icon ?> menu-item-icon"></i>
                                                                            <?php }
                                                                            endif; ?>
                                                                            <span class="pull-right"><?php echo $menu_item->title; ?></span>
                                                                            <?php if ($childs > 0) { ?>
                                                                                <i class="fa fa-arrow-left next"></i>
                                                                            <?php } ?>
                                                                        </a>

                                                                    </span>
                                                                    <?php if ($childs > 0) { ?>
                                                                        <ul class="collapse submenu">
                                                                            <li class="go-back"><?php echo $menu_item->title; ?> <i class="fa fa-arrow-right"></i></li>
                                                                            <?php
                                                                            foreach ($main_nav as $menu_item_child) {
                                                                                if (is_object($menu_item_child) && isset($menu_item_child->ID)) {
                                                                                    $menu_item_child_icon = get_post_meta($menu_item_child->ID, '_menu_item_icon', true);
                                                                                }
                                                                                $cchilds = 0;
                                                                                foreach ($main_nav as $menu_item_child_child_is) {

                                                                                    if ($menu_item_child_child_is->menu_item_parent == $menu_item_child->ID) {
                                                                                        $cchilds = $cchilds + 1;
                                                                                    }
                                                                                }
                                                                                if ($cchilds > 0) {
                                                                                    $cmenu_link = '#popup';
                                                                                } else {
                                                                                    $cmenu_link = $menu_item_child->url;
                                                                                }
                                                                                if ($menu_item_child->menu_item_parent == $menu_item->ID) { ?>

                                                                                    <li>
                                                                                        <span class="menu-title menu-title2">
                                                                                            <a class="btn_mo-ripple <?= $cchilds > 0 ? 'haschild' : '' ?> <?php if (implode(' ', $menu_item_child->classes)) echo implode(' ', $menu_item_child->classes); ?> <?= ($menu_item_child->url == '#') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" href="<?php echo $cmenu_link; ?>" <?php if ($menu_item_child->target && $cmenu_link != '#popup') echo 'target="' . $menu_item_child->target . '" '; ?> <?php if ($menu_item_child->xfn) echo 'rel="' . $menu_item_child->xfn . '" '; ?> <?php if ($menu_item_child->attr_title) echo 'title="' . $menu_item_child->attr_title . '" '; ?>>

                                                                                                <?php if ($menu_item_child_icon) :
                                                                                                    $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                    if (preg_match($regx_img, $menu_item_child_icon) == 1) {
                                                                                                ?>
                                                                                                        <img src="<?= $menu_item_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                    <?php } else { ?>
                                                                                                        <i class="<?= $menu_item_child_icon ?> menu-item-icon"></i>
                                                                                                <?php }
                                                                                                endif; ?>
                                                                                                <span class="pull-right"><?php echo $menu_item_child->title; ?></span>
                                                                                                <?php if ($cchilds > 0) { ?>
                                                                                                    <i class="fa fa-arrow-left next"></i>
                                                                                                <?php } ?>
                                                                                            </a>

                                                                                        </span>
                                                                                        <?php if ($cchilds > 0) { ?>
                                                                                            <ul class="collapse submenu">
                                                                                                <li class="go-back"><?php echo $menu_item_child->title; ?>
                                                                                                    <i class="fa fa-arrow-right"></i>
                                                                                                </li>

                                                                                                <?php
                                                                                                foreach ($main_nav as $menu_item_child_child) {
                                                                                                    if (is_object($menu_item_child_child) && isset($menu_item_child_child->ID)) {
                                                                                                        $menu_item_child_child_icon = get_post_meta($menu_item_child_child->ID, '_menu_item_icon', true);
                                                                                                    }
                                                                                                    if ($menu_item_child_child->menu_item_parent == $menu_item_child->ID) {
                                                                                                        $ccchilds = 0;
                                                                                                        foreach ($main_nav as $menu_item_child_child_child_is) {

                                                                                                            if ($menu_item_child_child_child_is->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                                $ccchilds = $ccchilds + 1;
                                                                                                            }
                                                                                                        }
                                                                                                ?>
                                                                                                        <li>
                                                                                                            <span class="menu-title menu-title3">
                                                                                                                <a class="ch btn_mo-ripple <?= $menu_item_child_child->url == '#' ? 'next' : '' ?> <?= $ccchilds > 0 ? 'haschild' : '' ?>" href="<?= $menu_item_child_child->url ?>" property="url">
                                                                                                                    <?php if ($menu_item_child_child_icon) :
                                                                                                                        $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                        if (preg_match($regx_img, $menu_item_child_child_icon) == 1) {
                                                                                                                    ?>
                                                                                                                            <img src="<?= $menu_item_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                        <?php } else { ?>
                                                                                                                            <i class="<?= $menu_item_child_child_icon ?> menu-item-icon"></i>
                                                                                                                    <?php }
                                                                                                                    endif; ?>
                                                                                                                    <span><?= $menu_item_child_child->title ?></span>
                                                                                                                    <?php if ($ccchilds > 0) { ?>
                                                                                                                        <i class="fa fa-arrow-left next"></i>
                                                                                                                    <?php } ?>
                                                                                                                </a>


                                                                                                            </span>
                                                                                                            <?php if ($ccchilds > 0) { ?>
                                                                                                                <ul class="collapse submenu">
                                                                                                                    <li class="go-back"><?php echo $menu_item_child_child->title; ?>
                                                                                                                        <i class="fa fa-arrow-right"></i>
                                                                                                                    </li>

                                                                                                                    <?php
                                                                                                                    foreach ($main_nav as $menu_item_child_child_child) {
                                                                                                                        if (is_object($menu_item_child_child_child) && isset($menu_item_child_child_child->ID)) {
                                                                                                                            $menu_item_child_child_child_icon = get_post_meta($menu_item_child_child_child->ID, '_menu_item_icon', true);
                                                                                                                        }
                                                                                                                        if ($menu_item_child_child_child->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                                    ?>
                                                                                                                            <li>
                                                                                                                                <span class="menu-title4">
                                                                                                                                    <a class="ch btn_mo-ripple" href="<?= $menu_item_child_child_child->url ?>" property="url">
                                                                                                                                        <?php if ($menu_item_child_child_child_icon) :
                                                                                                                                            $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                                            if (preg_match($regx_img, $menu_item_child_child_child_icon) == 1) {
                                                                                                                                        ?>
                                                                                                                                                <img src="<?= $menu_item_child_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                                            <?php } else { ?>
                                                                                                                                                <i class="<?= $menu_item_child_child_child_icon ?> menu-item-icon"></i>
                                                                                                                                        <?php }
                                                                                                                                        endif; ?>
                                                                                                                                        <span><?= $menu_item_child_child_child->title ?></span>

                                                                                                                                    </a>

                                                                                                                                </span>

                                                                                                                            </li>
                                                                                                                    <?php
                                                                                                                        }
                                                                                                                    }

                                                                                                                    echo '<li><a class="menu_mo-all" href="' . $menu_item_child_child->url . '"> همه ' . $menu_item_child_child->title . '</a></li>';

                                                                                                                    ?>
                                                                                                                </ul>
                                                                                                            <?php } ?>
                                                                                                        </li>
                                                                                                <?php
                                                                                                    }
                                                                                                }

                                                                                                echo '<li><a class="menu_mo-all" href="' . $menu_item_child->url . '"> همه ' . $menu_item_child->title . '</a></li>';

                                                                                                ?>
                                                                                            </ul>
                                                                                        <?php } ?>

                                                                                    </li>
                                                                            <?php }
                                                                            }

                                                                            echo '<li><a class="menu_mo-all" href="' . $menu_item->url . '"> همه ' . $menu_item->title . '</a>';

                                                                            ?>
                                                                        </ul>
                                                                    <?php } ?>
                                                                </li>
                                                    <?php }
                                                        }
                                                    } ?>
                                                </ul>
                                                <?php
                                                if (isset($bakala_options['enable_header_offer']) && $bakala_options['enable_header_offer'] && class_exists('WooCommerce')) {
                                                    if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
                                                        $term = get_term($bakala_options['offer_menu_cat']);
                                                        if ($term) { ?>
                                                            <a class="special-offer-link" href="<?php echo get_term_link($term); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                                        <?php }
                                                    } elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) { ?>
                                                        <a class="special-offer-link" href="<?php echo get_permalink($bakala_options['offer_menu_link']); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                                <?php }
                                                }
                                                ?>
                                                <?php if (isset($bakala_options['night_mode']) && $bakala_options['night_mode'] == true) { ?>
                                                    <div class="dk-switch-container">
                                                        <span class="night-label"><?php _e('Night mode: ', 'bakala'); ?></span>
                                                        <div id="night_mode_switcher" class="night_mode_switch dk-switch-wrapper clearfix <?php if ((isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') || (!isset($_COOKIE['night_mode']) && $bakala_options['default_mode'] == 'night')) {
                                                                                                                                                echo 'active';
                                                                                                                                            } else {
                                                                                                                                                echo 'inactive';
                                                                                                                                            } ?>">
                                                            <span class="dk-switch-enabled"><?php _e('Night', 'bakala'); ?></span>
                                                            <span class="dk-switch-disabled"><?php _e('Day', 'bakala'); ?></span>
                                                        </div>
                                                    </div>
                                                <?php } ?>
                                            </nav>
                                        </div>
                                        <ul class="socials">
                                            <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                                <li>
                                                    <a target="_blank" href="<?php echo $bakala_options['facebook']; ?>"><i class="icon icon-footer-facebook"></i></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                                <li>
                                                    <a target="_blank" href="<?php echo $bakala_options['twitter']; ?>"><i class="icon icon-footer-twitter"></i></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                                <li>
                                                    <a target="_blank" href="<?php echo $bakala_options['googleplus']; ?>"><i class="icon icon-footer-googleplus"></i></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                                <li>
                                                    <a target="_blank" href="<?php echo $bakala_options['instagram']; ?>"><i class="icon icon-footer-instagram"></i></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                                <li>
                                                    <a target="_blank" href="<?php echo $bakala_options['youtube']; ?>"><i class="icon icon-footer-aparat"></i></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                                <li>
                                                    <a target="_blank" href="<?php echo $bakala_options['vimeo']; ?>"><i class="icon icon-footer-telegram"></i></a>
                                                </li>
                                            <?php } ?>
                                            <?php
                                            if (is_array($bakala_options['other_socials'])) {
                                                foreach ($bakala_options['other_socials'] as $item) {
                                                    if (!empty($item['image'])) {
                                            ?>
                                                        <li>
                                                            <a target="_blank" href="<?php echo $item['url']; ?>"><img class="other_socials_img" src="<?php echo $item['image'] ?>"></a>
                                                        </li>
                                            <?php }
                                                }
                                            } ?>
                                        </ul>
                                    </div>
                                </div>
                                <a href="/" aria-current="page" class="tw-w-1/3 nuxt-link-exact-active nuxt-link-active" data-v-d5b73d68="" data-v-41aa9d8a=""><span class="tw-mx-auto tw-w-16 tw-h-6 tw-block" data-v-41aa9d8a=""><img data-name="image-img" src="<?= $logo_href ?>" class="tw-w-full tw-h-full tw-transition-opacity tw-duration-500">
                                        <!----></span></a><?php if (isset($bakala_options['header_tell']) && $bakala_options['header_tell']) { ?>
                                    <a href="<?= !empty($bakala_options['headerinfobar_tell_phone']) ? 'tel:' . $bakala_options['headerinfobar_tell_phone'] : get_permalink($bakala_options['headerinfobar_tell_page']); ?>" class="c-header__faq"></a>
                                <?php } ?>
                            </div>
                            <div class="t-flex-between-center lg:tw-min-h-[3.25rem] tw-z-10 tw-py-1 lg:tw-pt-2" data-v-41aa9d8a="">
                                <div class="tw-z-[59] t-row tw-relative tw-my-3 tw-w-full lg:tw-flex-row lg:tw-justify-between lg:tw-my-0 lg:tw-w-4/5 lg:tw-space-x-5 lg:tw-space-x-reverse" data-v-41aa9d8a="">
                                    <?php if (!is_mobile_or_tablet()) { ?>
                                        <div data-v-41aa9d8a="" class="tw-cursor-pointer tw-block tw-ml-2 lg:tw-ml-0"><span class="lg:tw-ml-6 tw-pointer lg:tw-min-w-[4.5rem] tw-block tw-w-20 tw-h-9"><a href="<?php echo home_url('/'); ?>"><img data-name="image-img" src="<?= $logo_href ?>" alt="لوگو سایت" class="tw-w-full tw-h-full tw-transition-opacity tw-duration-500"></a>
                                                <!----></span></div>
                                        <div data-v-585821db="" data-v-41aa9d8a="" class="mbt-menu-categories-desktop tw-z-[-1] tw-absolute tw-left-0 tw-right-0 lg:tw-relative tw-hidden tw-pt-3 tw-isolate lg:tw-block" style="transform: translate(0px, 0px);flex:2;">
                                            <div data-v-585821db="" class="mbt-menu-categories-child-desktop tw-relative tw-flex tw-items-center" style="opacity: 1;">
                                                <?php if (function_exists('ubermenu')) :
                                                    ubermenu('main', array('theme_location' => 'uber'));
                                                else :
                                                    bkm_menu();
                                                endif;
                                                ?>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <div class="t-row tw-w-full" data-v-41aa9d8a="" style="flex:1">
                                        <div class="tw-flex tw-flex-col tw-items-center tw-w-full lg:tw-flex-row  tw-w-[85%] lg:tw-w-full lg:min-h-[3.25rem] lg:tw-mt-0" data-v-a7a31ca8="" data-v-41aa9d8a="">
                                            <div data-name="menu-wrapper" data-trigger-add="tw-w-full lg:tw-z-[81] tw-rounded-t-none lg:tw-rounded " data-items-add="lg:tw-z-[80] lg:tw-bg-white tw-duration-100 tw-ease lg:tw-top-[3.25rem] lg:t-shadow-search
     lg:tw-px-4
    " data-items-delete="tw-z-30 tw-z-40 tw-border tw-scale-0 tw-rounded-t-none tw-px-2 " class="d-flex align-items-center lg:tw-z-[80] tw-w-full tw-ease-linear lg:tw-w-full tw-relative" data-v-d7998d90="" data-v-a7a31ca8="">
                                                <?php if (isset($bakala_options['show_search']) && $bakala_options['show_search']) { ?>
                                                    <div class="navbar-search w-100">
                                                        <?php echo do_shortcode('[wcas-search-form]'); ?>
                                                    </div>
                                                <?php } ?>
                                                <div class="modern-header-icons">
                                                    <?php
                                                    if (isset($bakala_options['enable_location']) && $bakala_options['enable_location'] == true) {
                                                    ?>
                                                        <div class="toolbar clearfix">
                                                            <div class="header-location site-location">
                                                                <a href="#">
                                                                    <span class="location-description"><?php esc_html_e('Your Location', 'bakala'); ?></span>
                                                                    <?php if (bakala_location() == 'all') { ?>
                                                                        <div class="current-location"><?php esc_html_e('Select a Location to filter', 'bakala'); ?></div>
                                                                    <?php } else { ?>
                                                                        <div class="current-location activated"><?php echo esc_html(bakala_location()); ?></div>
                                                                    <?php } ?>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    <?php
                                                    }
                                                    ?>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="tw-w-[15%] lg:tw-hidden" data-v-41aa9d8a="">


                                        </div>
                                    </div>
                                </div>
                                <div data-v-41aa9d8a="" class="lg:tw-min-h-[3rem] tw-hidden tw-items-center tw-space-x-3 tw-space-x-reverse lg:tw-flex">
                                    <div data-v-104ce55b="" data-v-41aa9d8a="">
                                        <div data-v-d7998d90="" data-v-104ce55b="" data-name="menu-wrapper" class="tw-relative tbar" data-items-delete="tw-rounded-t-none tw-border tw-shadow-lg tw-z-30 tw-z-40" data-items-add="tw-transform tw-translate-y-2 tw-shadow-design tw-z-[80] lg:tw-top-[2.75rem]">
                                            <div style="display:flex">
                                                <?php if (!is_user_logged_in()) {

                                                    if ($bakala_options['lr_bakala'] == 1 && $bakala_options['popup_login'] == true) {

                                                ?>
                                                        <button type="button" class="bakala_lr_btn popup" style="background: transparent;border: none;">
                                                            <div class="bakala-header-account">
                                                                <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                                                <div class="bakala-header-account-text">
                                                                    <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?></strong>
                                                                </div>
                                                            </div>
                                                        </button>
                                                        <?php
                                                    } else {
                                                        if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true && $bakala_options['lr_bakala'] == 0) {
                                                            if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                                                echo do_shortcode('[dm-login-modal]');
                                                            } else { ?>
                                                                <button type="button" style="background: transparent;border: none;" data-bs-toggle="modal" data-bs-target="#bakala_login" class="bakala_lr_btn popup">
                                                                    <div class="bakala-header-account">
                                                                        <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                                                        <div class="bakala-header-account-text">
                                                                            <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?></strong>
                                                                        </div>
                                                                    </div>
                                                                </button>
                                                            <?php
                                                            }
                                                        } else { ?>
                                                            <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" class="bakala_lr_btn">
                                                                <div class="bakala-header-account">
                                                                    <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                                                    <div class="bakala-header-account-text">
                                                                        <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?></strong>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        <?php } ?>
                                                        <?php if (!function_exists('digits_addon_digoneclickls')) { ?>

                                                    <?php }
                                                    }
                                                } else {
                                                    ?>
                                                    <div class="bakala-header-account">
                                                        <i class="bakala-header-account-icon bakala-icon icon-account"></i>

                                                        <div class="bakala-header-account-text">
                                                            <strong><?= $user_name ?></strong>
                                                        </div>
                                                    </div>
                                                    <a class="c-header__btn-user js-dropdown-toggle">
                                                        <div class="user-menu-toggle">

                                                        </div>

                                                    </a>

                                                    <div class="c-header__user-dropdown js-dropdown-menu" style="display: none;">

                                                        <?php if (!is_user_logged_in()) {
                                                            if ($bakala_options['lr_bakala'] == 1) {
                                                        ?>
                                                                <a data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login" class="c-header__user-dropdown-login">
                                                                    <?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?>
                                                                </a>
                                                                <?php
                                                            } else {
                                                                if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true) {
                                                                    if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                                                        echo do_shortcode('[dm-login-modal]');
                                                                    } else { ?>
                                                                        <a data-bs-toggle="modal" data-bs-target="#bakala_login" class="c-header__user-dropdown-login">
                                                                            <?php echo _e('Login', 'bakala'); ?>
                                                                        </a>
                                                                    <?php
                                                                    }
                                                                } else { ?>
                                                                    <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>" class="c-header__user-dropdown-login">
                                                                        <?php echo _e('Login', 'bakala'); ?>
                                                                    </a>
                                                                <?php } ?>
                                                                <?php if (!function_exists('digits_addon_digoneclickls')) { ?>
                                                                    <div class="c-header__user-dropdown-sign-up">
                                                                        <span>
                                                                            <?php echo _e('New user?', 'bakala'); ?>
                                                                        </span>
                                                                        <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>">
                                                                            <?php echo _e('Register', 'bakala'); ?>
                                                                        </a>
                                                                    </div>
                                                            <?php }
                                                            } ?>
                                                        <?php } ?>

                                                        <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" class="c-header__user-dropdown-action c-header__user-dropdown-action--profile" data-event="profile_click" data-event-category="header_section" data-event-label="logged_in: False">
                                                            <div>
                                                                <div class="profile-avatar">
                                                                    <?php echo get_avatar($current_user->ID, 48); ?>
                                                                </div>
                                                                <div class="profile-name">
                                                                    <span>
                                                                        <?= $user_name ?>
                                                                    </span>
                                                                    <i class="fa fa-chevron-left"></i>
                                                                </div>
                                                            </div>
                                                        </a>
                                                        <?php
                                                        if (!empty($bakala_options['top_bar_trackorder']) || $bakala_options['myaccount_tracking_order'] == 1) {
                                                            if (isset($bakala_options['top_bar_trackorder']) && $bakala_options['top_bar_trackorder']) {
                                                                $order_tracking_link = get_permalink($bakala_options['top_bar_trackorder']);
                                                            } elseif (!$bakala_options['top_bar_trackorder']) {
                                                                $order_tracking_link = get_permalink(get_option('woocommerce_myaccount_page_id')) . 'your-tracking/';
                                                            }

                                                        ?>
                                                            <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?= $order_tracking_link ?>">
                                                                <span class="orders-menu"></span>
                                                                <?php echo _e('Track Order', 'bakala'); ?>
                                                            </a>
                                                        <?php
                                                        }
                                                        ?>
                                                        <?php if (is_plugin_active('address-plus/address-plus.php')) { ?>
                              <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('addressplus-addresses'); ?>">
                                <span class="icon icon-address"></span>
                                <?php echo _e('My Addresses', 'bakala'); ?>
                              </a>
                          <?php } ?>
                                                        <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-wishlist'); ?>">
                                                            <span class="icon icon-love"></span>
                                                            <?php echo _e('My Wishlist', 'bakala'); ?>
                                                        </a>
                                                        <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-comments'); ?>">
                                                            <span class="icon my-comments"></span>
                                                            <?php echo _e('نقد و نظرات', 'bakala'); ?>
                                                        </a>
                                                        <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-notifications'); ?>">
                                                            <span class="icon my-notes"></span>
                                                            <?php echo _e('اعلانات', 'bakala'); ?>
                                                        </a>

                                                        <?php if (is_user_logged_in()) { ?>
                                                            <a href="<?php echo wp_logout_url(home_url()); ?>" class="c-header__user-dropdown-action c-header__user-dropdown-action--logout">
                                                                <i class="bakala-loguot"></i>
                                                                <?= $bakala_options['logout-label'] ? $bakala_options['logout-label'] : _e('خروج از حساب کاربری', 'bakala'); ?>
                                                            </a>
                                                        <?php } ?>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div data-v-41aa9d8a="">
                                        <?php if (isset($bakala_options['show_cart']) && $bakala_options['show_cart'] && $bakala_options['catalog_mode'] == false && class_exists('WooCommerce') && !is_cart() && !is_checkout()) {
                                            $cart_count = bakala_get_cart_count();
                                            if ($bakala_options['force_login_cart'] == 1 && !is_user_logged_in()) {
                                                $cart_text = '<i class="bakala-icon more-icon"></i>';
                                            } else {
                                                if ($cart_count > 0) {
                                                    $cart_text = wc_price(WC()->cart->subtotal);
                                                } else {
                                                    $cart_text = 'خالی می باشد';
                                                }
                                            }
                                        ?>
                                            <div class="cart-box<?php if ($cart_count > 0) {
                                                                    echo ' fill';
                                                                } ?>">
                                                <div class="dk-button-container hasIcon">
                                                    <div class="dk-button green header-cart">
                                                        <div class="header-cart-icon">
                                                            <i class="dk-button-icon dk-button-icon-cart"></i>
                                                        </div>
                                                        <div class="header-cart-text">
                                                            <?php if ($cart_count > 1) { ?>
                                                                <span><?= $cart_count ?> کالا</span>
                                                            <?php } else { ?>
                                                                <span>سبد خرید</span>
                                                            <?php } ?>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="mini-cart-dropdown" style="display:none">
                                                    <?php woocommerce_mini_cart(); ?>
                                                </div>

                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div> <!---->
                        <?php
                        if (is_mobile_or_tablet()) {
                            if ($bakala_options['header_categories_enable_mobile'] == '1' && !empty($bakala_options['header_categories'])) { ?>
                                <div class="bakala-product-categories-header">
                                    <?php foreach ($bakala_options['header_categories'] as $category_id) {
                                        $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
                                        $image_url = wp_get_attachment_url($thumbnail_id);
                                        $term = get_term_by('id', $category_id, 'product_cat');
                                        $link = get_term_link($term->slug, 'product_cat');

                                    ?>
                                        <a href="<?php echo $link ?>" class="bakala-product-category-header">
                                            <div class="bakala-product-category-header-img">
                                                <img src="<?= $image_url ?>" alt="<?= $term->name ?>" loading="lazy" style="filter: blur(0px);">
                                            </div>
                                            <span class="bakala-product-category-header-title" style="color: rgba(0, 0, 0, 0.56);"><?= $term->name ?></span>
                                        </a>
                                    <?php } ?>
                                </div>
                            <?php }
                        } else {
                            if ($bakala_options['header_categories_enable_pc'] == '1' && !empty($bakala_options['header_categories']) && (is_home() || is_front_page())) { ?>
                                <div class="bakala-product-categories-header">
                                    <?php foreach ($bakala_options['header_categories'] as $category_id) {
                                        $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
                                        $image_url = wp_get_attachment_url($thumbnail_id);
                                        $term = get_term_by('id', $category_id, 'product_cat');
                                        $link = get_term_link($term->slug, 'product_cat');

                                    ?>
                                        <a href="<?php echo $link ?>" class="bakala-product-category-header">
                                            <div class="bakala-product-category-header-img">
                                                <img src="<?= $image_url ?>" alt="<?= $term->name ?>" loading="lazy" style="filter: blur(0px);">
                                            </div>
                                            <span class="bakala-product-category-header-title" style="color: rgba(0, 0, 0, 0.56);"><?= $term->name ?></span>
                                        </a>
                                    <?php } ?>
                                </div>
                        <?php }
                        }
                        ?>
                    </header>

                </div>

            <?php
            }
        } else {
            ?>
            <div id="header-container" class="<?php if (is_mobile_or_tablet()) {
                                                    if ($bakala_options['sticky_header_mob'] == true) {
                                                        echo 'sticky-header';
                                                    }
                                                } else {
                                                    if ($bakala_options['sticky_header_desk'] == true) {
                                                        echo 'sticky-header';
                                                    }
                                                } ?> mt-header t-layout-padding-reverse tw-px-3  lg:tw-pt-0 lg:tw-px-0 lg:tw-shadow-none tw-mb-3 lg:tw-mb-0  lg:tw-pb-0 xl:tw-pb-0 2xl:tw-pb-0 tw-shadow-design-bottom-2 main-header" data-v-41aa9d8a="">

                <header <?php if (is_mobile_or_tablet()) {
                            if ($bakala_options['sticky_header_mob'] == true) {
                                echo 'id="navbar-primary-fixed"';
                            }
                        } else {
                            if ($bakala_options['sticky_header_desk'] == true) {
                                echo 'id="navbar-primary-fixed"';
                            }
                        } ?> class="tw-w-full <?php if (is_mobile_or_tablet()) {
                                                    if ($bakala_options['sticky_header_mob'] == true) {
                                                        echo 'mt-sticky-header';
                                                    }
                                                } else {
                                                    if ($bakala_options['sticky_header_desk'] == true) {
                                                        echo 'mt-sticky-header';
                                                    }
                                                } ?>" data-v-41aa9d8a="">

                    <div class="lg:tw-px-3" data-v-41aa9d8a="">
                        <?php
                        if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
                            $logo_href = $bakala_options['site_header_logo']['url'];
                        } else {
                            $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                        }
                        ?>
                        <div id="mobile-header" class=" tw-w-full tw-pt-4 t-row lg:tw-hidden  " data-v-41aa9d8a="">
                            <div class="tw-w-1/3" data-v-41aa9d8a="">
                                <div id="icon-menu" class="icon-menu-handler-svg">
                                    <div class="c-header__burger">
                                        <p class="divider-menu"></p>
                                    </div>
                                </div>
                                <div class="off-canvas-panel_mo dialog--close" id="off-canvas_menu">
                                    <a href="#" class="close-menu-button"><i class="bakala-icon close"></i></a>
                                    <div class="off-canvas-panel-wrapper_mo">
                                        <nav id="main-navigation_mo">
                                            <ul class="main-menu">
                                                <?php
                                                if (isset($bakala_options['mobile_menu']) && $bakala_options['mobile_menu']) {
                                                    $main_nav_slug = get_term(get_nav_menu_locations()['mobile'], 'nav_menu')->slug;
                                                } else {
                                                    $main_nav_slug = get_term(get_nav_menu_locations()['main'], 'nav_menu')->slug;
                                                }
                                                if (get_option('mobi_menu')) {
                                                    $main_nav_id = get_option('mobi_menu');
                                                } else {
                                                    $main_nav_id = $main_nav_slug;
                                                }
                                                $main_nav = wp_get_nav_menu_items($main_nav_id);
                                                if ($main_nav) {
                                                    foreach ($main_nav as $menu_item) {
                                                        if (is_object($menu_item) && isset($menu_item->ID)) {
                                                            $menu_item_icon = get_post_meta($menu_item->ID, '_menu_item_icon', true);
                                                        }
                                                        $childs = 0;
                                                        if ($menu_item->menu_item_parent == '0') {
                                                            foreach ($main_nav as $menu_item_child_is) {
                                                                if ($menu_item_child_is->menu_item_parent == $menu_item->ID) {
                                                                    $childs = $childs + 1;
                                                                }
                                                            }
                                                            if ($childs > 0) {
                                                                $menu_link = '#popup';
                                                            } else {
                                                                $menu_link = $menu_item->url;
                                                            }
                                                ?>
                                                            <li>
                                                                <span class="menu-title menu-title1">

                                                                    <a class="btn_mo-ripple <?= $childs > 0 ? 'haschild' : '' ?> <?php if (implode('', $menu_item->classes)) echo implode('', $menu_item->classes); ?> <?= ($menu_item->url == '#' || $menu_link == '#popup') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" <?php if ($menu_item->target && $menu_link != '#popup') echo 'target="' . $menu_item->target . '" '; ?> <?php if ($menu_item->xfn) echo 'rel="' . $menu_item->xfn . '" '; ?> <?php if ($menu_item->attr_title) echo 'title="' . $menu_item->attr_title . '" '; ?> href="<?php echo $menu_link; ?>">


                                                                        <?php if ($menu_item_icon) :
                                                                            $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                            if (preg_match($regx_img, $menu_item_icon) == 1) {
                                                                        ?>
                                                                                <img src="<?= $menu_item_icon ?>" class="menu-item-icon" width="18">
                                                                            <?php } else { ?>
                                                                                <i class="<?= $menu_item_icon ?> menu-item-icon"></i>
                                                                        <?php }
                                                                        endif; ?>
                                                                        <span class="pull-right"><?php echo $menu_item->title; ?></span>
                                                                        <?php if ($childs > 0) { ?>
                                                                            <i class="fa fa-arrow-left next"></i>
                                                                        <?php } ?>
                                                                    </a>

                                                                </span>
                                                                <?php if ($childs > 0) { ?>
                                                                    <ul class="collapse submenu">
                                                                        <li class="go-back"><?php echo $menu_item->title; ?> <i class="fa fa-arrow-right"></i></li>
                                                                        <?php
                                                                        foreach ($main_nav as $menu_item_child) {
                                                                            if (is_object($menu_item_child) && isset($menu_item_child->ID)) {
                                                                                $menu_item_child_icon = get_post_meta($menu_item_child->ID, '_menu_item_icon', true);
                                                                            }
                                                                            $cchilds = 0;
                                                                            foreach ($main_nav as $menu_item_child_child_is) {

                                                                                if ($menu_item_child_child_is->menu_item_parent == $menu_item_child->ID) {
                                                                                    $cchilds = $cchilds + 1;
                                                                                }
                                                                            }
                                                                            if ($cchilds > 0) {
                                                                                $cmenu_link = '#popup';
                                                                            } else {
                                                                                $cmenu_link = $menu_item_child->url;
                                                                            }
                                                                            if ($menu_item_child->menu_item_parent == $menu_item->ID) { ?>

                                                                                <li>
                                                                                    <span class="menu-title menu-title2">
                                                                                        <a class="btn_mo-ripple <?= $cchilds > 0 ? 'haschild' : '' ?> <?php if (implode(' ', $menu_item_child->classes)) echo implode(' ', $menu_item_child->classes); ?> <?= ($menu_item_child->url == '#') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" href="<?php echo $cmenu_link; ?>" <?php if ($menu_item_child->target && $cmenu_link != '#popup') echo 'target="' . $menu_item_child->target . '" '; ?> <?php if ($menu_item_child->xfn) echo 'rel="' . $menu_item_child->xfn . '" '; ?> <?php if ($menu_item_child->attr_title) echo 'title="' . $menu_item_child->attr_title . '" '; ?>>

                                                                                            <?php if ($menu_item_child_icon) :
                                                                                                $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                if (preg_match($regx_img, $menu_item_child_icon) == 1) {
                                                                                            ?>
                                                                                                    <img src="<?= $menu_item_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                <?php } else { ?>
                                                                                                    <i class="<?= $menu_item_child_icon ?> menu-item-icon"></i>
                                                                                            <?php }
                                                                                            endif; ?>
                                                                                            <span class="pull-right"><?php echo $menu_item_child->title; ?></span>
                                                                                            <?php if ($cchilds > 0) { ?>
                                                                                                <i class="fa fa-arrow-left next"></i>
                                                                                            <?php } ?>
                                                                                        </a>

                                                                                    </span>
                                                                                    <?php if ($cchilds > 0) { ?>
                                                                                        <ul class="collapse submenu">
                                                                                            <li class="go-back"><?php echo $menu_item_child->title; ?>
                                                                                                <i class="fa fa-arrow-right"></i>
                                                                                            </li>

                                                                                            <?php
                                                                                            foreach ($main_nav as $menu_item_child_child) {
                                                                                                if (is_object($menu_item_child_child) && isset($menu_item_child_child->ID)) {
                                                                                                    $menu_item_child_child_icon = get_post_meta($menu_item_child_child->ID, '_menu_item_icon', true);
                                                                                                }
                                                                                                if ($menu_item_child_child->menu_item_parent == $menu_item_child->ID) {
                                                                                                    $ccchilds = 0;
                                                                                                    foreach ($main_nav as $menu_item_child_child_child_is) {

                                                                                                        if ($menu_item_child_child_child_is->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                            $ccchilds = $ccchilds + 1;
                                                                                                        }
                                                                                                    }
                                                                                            ?>
                                                                                                    <li>
                                                                                                        <span class="menu-title menu-title3">
                                                                                                            <a class="ch btn_mo-ripple <?= $menu_item_child_child->url == '#' ? 'next' : '' ?> <?= $ccchilds > 0 ? 'haschild' : '' ?>" href="<?= $menu_item_child_child->url ?>" property="url">
                                                                                                                <?php if ($menu_item_child_child_icon) :
                                                                                                                    $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                    if (preg_match($regx_img, $menu_item_child_child_icon) == 1) {
                                                                                                                ?>
                                                                                                                        <img src="<?= $menu_item_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                    <?php } else { ?>
                                                                                                                        <i class="<?= $menu_item_child_child_icon ?> menu-item-icon"></i>
                                                                                                                <?php }
                                                                                                                endif; ?>
                                                                                                                <span><?= $menu_item_child_child->title ?></span>
                                                                                                                <?php if ($ccchilds > 0) { ?>
                                                                                                                    <i class="fa fa-arrow-left next"></i>
                                                                                                                <?php } ?>
                                                                                                            </a>


                                                                                                        </span>
                                                                                                        <?php if ($ccchilds > 0) { ?>
                                                                                                            <ul class="collapse submenu">
                                                                                                                <li class="go-back"><?php echo $menu_item_child_child->title; ?>
                                                                                                                    <i class="fa fa-arrow-right"></i>
                                                                                                                </li>

                                                                                                                <?php
                                                                                                                foreach ($main_nav as $menu_item_child_child_child) {
                                                                                                                    if (is_object($menu_item_child_child_child) && isset($menu_item_child_child_child->ID)) {
                                                                                                                        $menu_item_child_child_child_icon = get_post_meta($menu_item_child_child_child->ID, '_menu_item_icon', true);
                                                                                                                    }
                                                                                                                    if ($menu_item_child_child_child->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                                ?>
                                                                                                                        <li>
                                                                                                                            <span class="menu-title4">
                                                                                                                                <a class="ch btn_mo-ripple" href="<?= $menu_item_child_child_child->url ?>" property="url">
                                                                                                                                    <?php if ($menu_item_child_child_child_icon) :
                                                                                                                                        $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                                        if (preg_match($regx_img, $menu_item_child_child_child_icon) == 1) {
                                                                                                                                    ?>
                                                                                                                                            <img src="<?= $menu_item_child_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                                        <?php } else { ?>
                                                                                                                                            <i class="<?= $menu_item_child_child_child_icon ?> menu-item-icon"></i>
                                                                                                                                    <?php }
                                                                                                                                    endif; ?>
                                                                                                                                    <span><?= $menu_item_child_child_child->title ?></span>

                                                                                                                                </a>

                                                                                                                            </span>

                                                                                                                        </li>
                                                                                                                <?php
                                                                                                                    }
                                                                                                                }

                                                                                                                echo '<li><a class="menu_mo-all" href="' . $menu_item_child_child->url . '"> همه ' . $menu_item_child_child->title . '</a></li>';

                                                                                                                ?>
                                                                                                            </ul>
                                                                                                        <?php } ?>
                                                                                                    </li>
                                                                                            <?php
                                                                                                }
                                                                                            }

                                                                                            echo '<li><a class="menu_mo-all" href="' . $menu_item_child->url . '"> همه ' . $menu_item_child->title . '</a></li>';

                                                                                            ?>
                                                                                        </ul>
                                                                                    <?php } ?>

                                                                                </li>
                                                                        <?php }
                                                                        }

                                                                        echo '<li><a class="menu_mo-all" href="' . $menu_item->url . '"> همه ' . $menu_item->title . '</a>';

                                                                        ?>
                                                                    </ul>
                                                                <?php } ?>
                                                            </li>
                                                <?php }
                                                    }
                                                } ?>
                                            </ul>
                                            <?php
                                            if (isset($bakala_options['enable_header_offer']) && $bakala_options['enable_header_offer'] && class_exists('WooCommerce')) {
                                                if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
                                                    $term = get_term($bakala_options['offer_menu_cat']);
                                                    if ($term) { ?>
                                                        <a class="special-offer-link" href="<?php echo get_term_link($term); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                                    <?php }
                                                } elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) { ?>
                                                    <a class="special-offer-link" href="<?php echo get_permalink($bakala_options['offer_menu_link']); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                            <?php }
                                            }
                                            ?>
                                            <?php if (isset($bakala_options['night_mode']) && $bakala_options['night_mode'] == true) { ?>
                                                <div class="dk-switch-container">
                                                    <span class="night-label"><?php _e('Night mode: ', 'bakala'); ?></span>
                                                    <div id="night_mode_switcher" class="night_mode_switch dk-switch-wrapper clearfix <?php if ((isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') || (!isset($_COOKIE['night_mode']) && $bakala_options['default_mode'] == 'night')) {
                                                                                                                                            echo 'active';
                                                                                                                                        } else {
                                                                                                                                            echo 'inactive';
                                                                                                                                        } ?>">
                                                        <span class="dk-switch-enabled"><?php _e('Night', 'bakala'); ?></span>
                                                        <span class="dk-switch-disabled"><?php _e('Day', 'bakala'); ?></span>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        </nav>
                                    </div>
                                    <ul class="socials">
                                        <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                            <li>
                                                <a target="_blank" href="<?php echo $bakala_options['facebook']; ?>"><i class="icon icon-footer-facebook"></i></a>
                                            </li>
                                        <?php } ?>
                                        <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                            <li>
                                                <a target="_blank" href="<?php echo $bakala_options['twitter']; ?>"><i class="icon icon-footer-twitter"></i></a>
                                            </li>
                                        <?php } ?>
                                        <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                            <li>
                                                <a target="_blank" href="<?php echo $bakala_options['googleplus']; ?>"><i class="icon icon-footer-googleplus"></i></a>
                                            </li>
                                        <?php } ?>
                                        <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                            <li>
                                                <a target="_blank" href="<?php echo $bakala_options['instagram']; ?>"><i class="icon icon-footer-instagram"></i></a>
                                            </li>
                                        <?php } ?>
                                        <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                            <li>
                                                <a target="_blank" href="<?php echo $bakala_options['youtube']; ?>"><i class="icon icon-footer-aparat"></i></a>
                                            </li>
                                        <?php } ?>
                                        <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                            <li>
                                                <a target="_blank" href="<?php echo $bakala_options['vimeo']; ?>"><i class="icon icon-footer-telegram"></i></a>
                                            </li>
                                        <?php } ?>
                                        <?php
                                        if (is_array($bakala_options['other_socials'])) {
                                            foreach ($bakala_options['other_socials'] as $item) {
                                                if (!empty($item['image'])) {
                                        ?>
                                                    <li>
                                                        <a target="_blank" href="<?php echo $item['url']; ?>"><img class="other_socials_img" src="<?php echo $item['image'] ?>"></a>
                                                    </li>
                                        <?php }
                                            }
                                        } ?>
                                    </ul>
                                </div>
                            </div>
                            <a href="/" aria-current="page" class="tw-w-1/3 nuxt-link-exact-active nuxt-link-active" data-v-d5b73d68="" data-v-41aa9d8a=""><span class="tw-mx-auto tw-w-16 tw-h-6 tw-block" data-v-41aa9d8a=""><img data-name="image-img" src="<?= $logo_href ?>" class="tw-w-full tw-h-full tw-transition-opacity tw-duration-500">
                                    <!----></span></a>
                        </div>
                        <div class="t-flex-between-center lg:tw-min-h-[3.25rem] tw-z-10 tw-py-1 lg:tw-pt-2" data-v-41aa9d8a="">
                            <div class="tw-z-[59] t-row tw-relative tw-my-3 tw-w-full lg:tw-flex-row lg:tw-justify-between lg:tw-my-0 lg:tw-w-4/5 lg:tw-space-x-5 lg:tw-space-x-reverse" data-v-41aa9d8a="">
                                <?php if (!is_mobile_or_tablet()) { ?>
                                    <div data-v-41aa9d8a="" class="tw-cursor-pointer tw-block tw-ml-2 lg:tw-ml-0"><span class="lg:tw-ml-6 tw-pointer lg:tw-min-w-[4.5rem] tw-block tw-w-20 tw-h-9"><a href="<?php echo home_url('/'); ?>"><img data-name="image-img" src="<?= $logo_href ?>" alt="لوگو سایت" class="tw-w-full tw-h-full tw-transition-opacity tw-duration-500"></a>
                                            <!----></span></div>
                                    <div data-v-585821db="" data-v-41aa9d8a="" class="mbt-menu-categories-desktop tw-z-[-1] tw-absolute tw-left-0 tw-right-0 lg:tw-relative tw-hidden tw-pt-3 tw-isolate lg:tw-block" style="transform: translate(0px, 0px);flex:2;">
                                        <div data-v-585821db="" class="mbt-menu-categories-child-desktop tw-relative tw-flex tw-items-center" style="opacity: 1;">
                                            <?php if (function_exists('ubermenu')) :
                                                ubermenu('main', array('theme_location' => 'uber'));
                                            else :
                                                bkm_menu();
                                            endif;
                                            ?>
                                        </div>
                                    </div>
                                <?php } ?>
                                <div class="t-row tw-w-full" data-v-41aa9d8a="" style="flex:1">
                                    <div class="tw-flex tw-flex-col tw-items-center tw-w-full lg:tw-flex-row  tw-w-[85%] lg:tw-w-full lg:min-h-[3.25rem] lg:tw-mt-0" data-v-a7a31ca8="" data-v-41aa9d8a="">
                                        <div data-name="menu-wrapper" data-trigger-add="tw-w-full lg:tw-z-[81] tw-rounded-t-none lg:tw-rounded " data-items-add="lg:tw-z-[80] lg:tw-bg-white tw-duration-100 tw-ease lg:tw-top-[3.25rem] lg:t-shadow-search
     lg:tw-px-4
    " data-items-delete="tw-z-30 tw-z-40 tw-border tw-scale-0 tw-rounded-t-none tw-px-2 " class="lg:tw-z-[80] tw-w-full tw-ease-linear lg:tw-w-full tw-relative" data-v-d7998d90="" data-v-a7a31ca8="">
                                            <?php if (isset($bakala_options['show_search']) && $bakala_options['show_search']) { ?>
                                                <div class="navbar-search w-100">
                                                    <?php echo do_shortcode('[wcas-search-form]'); ?>
                                                </div>
                                            <?php } ?>

                                        </div>
                                    </div>
                                    <div class="tw-w-[15%] lg:tw-hidden" data-v-41aa9d8a="">


                                    </div>
                                </div>
                            </div>
                            <div data-v-41aa9d8a="" class="lg:tw-min-h-[3rem] tw-hidden tw-items-center tw-space-x-3 tw-space-x-reverse lg:tw-flex">
                                <div data-v-104ce55b="" data-v-41aa9d8a="">
                                    <div data-v-d7998d90="" data-v-104ce55b="" data-name="menu-wrapper" class="tw-relative tbar" data-items-delete="tw-rounded-t-none tw-border tw-shadow-lg tw-z-30 tw-z-40" data-items-add="tw-transform tw-translate-y-2 tw-shadow-design tw-z-[80] lg:tw-top-[2.75rem]">
                                        <div style="display:flex">
                                            <?php if (!is_user_logged_in()) {

                                                if ($bakala_options['lr_bakala'] == 1 && $bakala_options['popup_login'] == true) {

                                            ?>
                                                    <a href="#bakala_login" class="bakala_lr_btn">
                                                        <div class="bakala-header-account">
                                                            <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                                            <div class="bakala-header-account-text">
                                                                <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?></strong>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    <?php
                                                } else {
                                                    if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true && $bakala_options['lr_bakala'] == 0) {
                                                        if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                                            echo do_shortcode('[dm-login-modal]');
                                                        } else { ?>
                                                            <a data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login" class="bakala_lr_btn">
                                                                <div class="bakala-header-account">
                                                                    <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                                                    <div class="bakala-header-account-text">
                                                                        <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?></strong>
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        <?php
                                                        }
                                                    } else { ?>
                                                        <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" class="bakala_lr_btn">
                                                            <div class="bakala-header-account">
                                                                <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                                                <div class="bakala-header-account-text">
                                                                    <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?></strong>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    <?php } ?>
                                                    <?php if (!function_exists('digits_addon_digoneclickls')) { ?>

                                                <?php }
                                                }
                                            } else {
                                                ?>
                                                <div class="bakala-header-account">
                                                    <i class="bakala-header-account-icon bakala-icon icon-account"></i>

                                                    <div class="bakala-header-account-text">
                                                        <strong><?= $user_name ?></strong>
                                                    </div>
                                                </div>
                                                <a class="c-header__btn-user js-dropdown-toggle">
                                                    <div class="user-menu-toggle">

                                                    </div>

                                                </a>

                                                <div class="c-header__user-dropdown js-dropdown-menu" style="display: none;">

                                                    <?php if (!is_user_logged_in()) {
                                                        if ($bakala_options['lr_bakala'] == 1) {
                                                    ?>
                                                            <a data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login" class="c-header__user-dropdown-login">
                                                                <?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?>
                                                            </a>
                                                            <?php
                                                        } else {
                                                            if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true) {
                                                                if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                                                    echo do_shortcode('[dm-login-modal]');
                                                                } else { ?>
                                                                    <a data-bs-toggle="modal" data-bs-target="#bakala_login" class="c-header__user-dropdown-login">
                                                                        <?php echo _e('Login', 'bakala'); ?>
                                                                    </a>
                                                                <?php
                                                                }
                                                            } else { ?>
                                                                <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>" class="c-header__user-dropdown-login">
                                                                    <?php echo _e('Login', 'bakala'); ?>
                                                                </a>
                                                            <?php } ?>
                                                            <?php if (!function_exists('digits_addon_digoneclickls')) { ?>
                                                                <div class="c-header__user-dropdown-sign-up">
                                                                    <span>
                                                                        <?php echo _e('New user?', 'bakala'); ?>
                                                                    </span>
                                                                    <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>">
                                                                        <?php echo _e('Register', 'bakala'); ?>
                                                                    </a>
                                                                </div>
                                                        <?php }
                                                        } ?>
                                                    <?php } ?>

                                                    <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" class="c-header__user-dropdown-action c-header__user-dropdown-action--profile" data-event="profile_click" data-event-category="header_section" data-event-label="logged_in: False">
                                                        <div>
                                                            <div class="profile-avatar">
                                                                <?php echo get_avatar($current_user->ID, 48); ?>
                                                            </div>
                                                            <div class="profile-name">
                                                                <span>
                                                                    <?= $user_name ?>
                                                                </span>
                                                                <i class="fa fa-chevron-left"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                    <?php
                                                    if (!empty($bakala_options['top_bar_trackorder']) || $bakala_options['myaccount_tracking_order'] == 1) {
                                                        if (isset($bakala_options['top_bar_trackorder']) && $bakala_options['top_bar_trackorder']) {
                                                            $order_tracking_link = get_permalink($bakala_options['top_bar_trackorder']);
                                                        } elseif (!$bakala_options['top_bar_trackorder']) {
                                                            $order_tracking_link = get_permalink(get_option('woocommerce_myaccount_page_id')) . 'your-tracking/';
                                                        }

                                                    ?>
                                                        <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?= $order_tracking_link ?>">
                                                            <span class="orders-menu"></span>
                                                            <?php echo _e('Track Order', 'bakala'); ?>
                                                        </a>
                                                    <?php
                                                    }
                                                    ?>
                                                    <?php if (is_plugin_active('address-plus/address-plus.php')) { ?>
                              <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('addressplus-addresses'); ?>">
                                <span class="icon icon-address"></span>
                                <?php echo _e('My Addresses', 'bakala'); ?>
                              </a>
                          <?php } ?>
                                                    <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-wishlist'); ?>">
                                                        <span class="icon icon-love"></span>
                                                        <?php echo _e('My Wishlist', 'bakala'); ?>
                                                    </a>
                                                    <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-comments'); ?>">
                                                        <span class="icon my-comments"></span>
                                                        <?php echo _e('نقد و نظرات', 'bakala'); ?>
                                                    </a>
                                                    <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-notifications'); ?>">
                                                        <span class="icon my-notes"></span>
                                                        <?php echo _e('اعلانات', 'bakala'); ?>
                                                    </a>

                                                    <?php if (is_user_logged_in()) { ?>
                                                        <a href="<?php echo wp_logout_url(home_url()); ?>" class="c-header__user-dropdown-action c-header__user-dropdown-action--logout">
                                                            <i class="bakala-loguot"></i>
                                                            <?= $bakala_options['logout-label'] ? $bakala_options['logout-label'] : _e('خروج از حساب کاربری', 'bakala'); ?>
                                                        </a>
                                                    <?php } ?>
                                                </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div data-v-41aa9d8a="">
                                    <?php if (isset($bakala_options['show_cart']) && $bakala_options['show_cart'] && $bakala_options['catalog_mode'] == false && class_exists('WooCommerce') && !is_cart() && !is_checkout()) {
                                        $cart_count = bakala_get_cart_count();
                                        if ($bakala_options['force_login_cart'] == 1 && !is_user_logged_in()) {
                                            $cart_text = '<i class="bakala-icon more-icon"></i>';
                                        } else {
                                            if ($cart_count > 0) {
                                                $cart_text = wc_price(WC()->cart->subtotal);
                                            } else {
                                                $cart_text = __('is empty', 'bakala');
                                            }
                                        }
                                    ?>
                                        <div class="cart-box<?php if ($cart_count > 0) {
                                                                echo ' fill';
                                                            } ?>">
                                            <div class="dk-button-container hasIcon">
                                                <div class="dk-button green header-cart">
                                                    <div class="header-cart-icon">
                                                        <i class="dk-button-icon dk-button-icon-cart"></i>
                                                    </div>
                                                    <div class="header-cart-text">
                                                        <?php if ($cart_count > 1) { ?>
                                                            <span><?= $cart_count ?> کالا</span>
                                                        <?php } else { ?>
                                                            <span><?= esc_html__('Cart', 'bakala'); ?></span>
                                                        <?php } ?>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="mini-cart-dropdown" style="display:none">
                                                <?php woocommerce_mini_cart(); ?>
                                            </div>

                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div> <!---->
                    <?php
                    if (is_mobile_or_tablet()) {
                        if ($bakala_options['header_categories_enable_mobile'] == '1' && !empty($bakala_options['header_categories'])) { ?>
                            <div class="bakala-product-categories-header">
                                <?php foreach ($bakala_options['header_categories'] as $category_id) {
                                    $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
                                    $image_url = wp_get_attachment_url($thumbnail_id);
                                    $term = get_term_by('id', $category_id, 'product_cat');
                                    $link = get_term_link($term->slug, 'product_cat');

                                ?>
                                    <a href="<?php echo $link ?>" class="bakala-product-category-header">
                                        <div class="bakala-product-category-header-img">
                                            <img src="<?= $image_url ?>" alt="<?= $term->name ?>" loading="lazy" style="filter: blur(0px);">
                                        </div>
                                        <span class="bakala-product-category-header-title" style="color: rgba(0, 0, 0, 0.56);"><?= $term->name ?></span>
                                    </a>
                                <?php } ?>
                            </div>
                        <?php }
                    } else {
                        if ($bakala_options['header_categories_enable_pc'] == '1' && !empty($bakala_options['header_categories']) && (is_home() || is_front_page())) { ?>
                            <div class="bakala-product-categories-header">
                                <?php foreach ($bakala_options['header_categories'] as $category_id) {
                                    $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
                                    $image_url = wp_get_attachment_url($thumbnail_id);
                                    $term = get_term_by('id', $category_id, 'product_cat');
                                    $link = get_term_link($term->slug, 'product_cat');

                                ?>
                                    <a href="<?php echo $link ?>" class="bakala-product-category-header">
                                        <div class="bakala-product-category-header-img">
                                            <img src="<?= $image_url ?>" alt="<?= $term->name ?>" loading="lazy" style="filter: blur(0px);">
                                        </div>
                                        <span class="bakala-product-category-header-title" style="color: rgba(0, 0, 0, 0.56);"><?= $term->name ?></span>
                                    </a>
                                <?php } ?>
                            </div>
                    <?php }
                    }
                    ?>
                </header>

            </div>
        <?php
        }
        ?>


    <?php
    }
    ?>