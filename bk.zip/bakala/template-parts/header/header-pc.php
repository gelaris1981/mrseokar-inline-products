<?php

ob_start();
global $bakala_options;

$current_user = wp_get_current_user();
$firstname = get_user_meta($current_user->ID, 'first_name', true);
$lastname = get_user_meta($current_user->ID, 'last_name', true);
if ($firstname && $lastname) {
  $user_name = $firstname . ' ' . $lastname;
} else {
  $user_name = $current_user->display_name;
}

?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

  <link rel="profile" href="http://gmpg.org/xfn/11">
  <?php
  if (isset($bakala_options['bakala_favicon']) && strlen($bakala_options['bakala_favicon']['url']) > 0) {
    $favicon_href = $bakala_options['bakala_favicon']['url'];
  } else {
    $favicon_href = get_template_directory_uri() . '/vendor/images/favicon.png';
  }
  ?>
  <link rel="shortcut icon" href="<?php echo $favicon_href; ?>" />
  <link rel="apple-touch-icon" href="<?php echo $favicon_href; ?>">
  <meta name="msapplication-TileColor" content="#ff6600">
  <meta name="msapplication-TileImage" content="<?php echo $favicon_href; ?>">
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  <?php
  if (function_exists('wp_body_open')) {
    wp_body_open();
  } else {
    do_action('wp_body_open');
  }

  ?>
  <?php if (isset($bakala_options['google_tags']) && $bakala_options['google_tags'] == true) {
    echo $bakala_options['google_tags'];
  } ?>
  <?php if (isset($bakala_options['bakala_preload']) && $bakala_options['bakala_preload'] == 1) : 
  if(is_front_page() && !isset($_GET['app']) && !isset($_COOKIE['bakala_show_preload'])){
  ?>
  	<script nowprocket>
        setTimeout(function () {
            var element = document.getElementById("bakala-preload");
            if (element) {
                element.style.setProperty('display', 'none', 'important');
            }
        }, 1000);

	</script>
    <div id="bakala-preload">
      <div class="bakala-preload-wrap">
        <?php if (isset($bakala_options['bakala_preload_logo']) && $bakala_options['bakala_preload_logo']['url']) : ?>
          <div id="bakala-preload-logo">
            <img alt="bakala-preload-logo" src="<?php echo $bakala_options['bakala_preload_logo']['url']; ?>">
          </div>
        <?php endif; ?>
        <div id="bakala-preload-gif">
          <?php if (isset($bakala_options['bakala_preload_gif']) && $bakala_options['bakala_preload_gif']['url']) : ?>
            <img alt="bakala-preload-gif" src="<?php echo $bakala_options['bakala_preload_gif']['url']; ?>">
          <?php endif; ?>
          <?php if (isset($bakala_options['bakala_preload_css']) && $bakala_options['bakala_preload_gif']['url'] == false) {
            $bakala_preload_css = $bakala_options['bakala_preload_css'];
            if ($bakala_preload_css == 'spinner') {
              echo '<div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
            } elseif ($bakala_preload_css == 'default') {
              echo '<div class="lds-default"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
            } elseif ($bakala_preload_css == 'grid') {
              echo '<div class="lds-grid"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
            } elseif ($bakala_preload_css == 'roller') {
              echo '<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
            } elseif ($bakala_preload_css == 'ellipsis') {
              echo '<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>';
            } elseif ($bakala_preload_css == 'ring') {
              echo '<div class="lds-ring"><div></div><div></div><div></div><div></div></div>';
            }
          } ?>
        </div>
      </div>
    </div>
  <?php
    setcookie('bakala_show_preload', 'yes', time() + 86400, '/');
  }
  endif;
   if (!is_user_logged_in() && ($bakala_options['digits'] != true || !function_exists('digit_get_login_fields') || $bakala_options['lr_bakala'] == 1)) {
      if (isset($bakala_options['bakala_lr_logo']) && !empty($bakala_options['bakala_lr_logo'])) {
        $logo_href = $bakala_options['bakala_lr_logo']['url'];
      } elseif (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
        $logo_href = $bakala_options['site_header_logo']['url'];
      } else {
        $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
      }
      $gradient_from = '#F00045';
      $gradient_to = '#D6003C';
      if (isset($bakala_options['accent-gradient']) && !empty($bakala_options['accent-gradient']) && isset($bakala_options['accent-gradient']['from']) && isset($bakala_options['accent-gradient']['to'])) {
        $gradient_from = $bakala_options['accent-gradient']['from'];
        $gradient_to = $bakala_options['accent-gradient']['to'];
        $style = 'style="background: linear-gradient(90deg, ' . $gradient_from . ', ' . $gradient_to . ');"';
    }
      if ($bakala_options['popup_login'] == 1) {
        if ($bakala_options['lr_style'] == 'two') {
    ?>
          <div class="modal fade bakala_login_style_two" id="bakala_login" tabindex="-1" style="display: none;">
            <div class="modal-dialog">
                <div class="modal-content" >
                    <div class="bs-logo"><img src="<?= $logo_href ?>" alt=""></div>
                    <?php if ($bakala_options['lr_bakala'] == 1 && bakala_is_woocommerce_active()) :
                        get_template_part('template-parts/login-register');
                    else : ?>
                        <!-- Begin # Login Form -->
                        <form id="login" action="login" method="post">
                            <div class="modal-body">


                                <div class="form-group clearfix">
                                    <a class="c-ui-input c-ui-input--account-username"></a>
                                    <label for="p-username" style="width:100%"><?php echo _e('Username', 'bakala'); ?></label>

                                    <input name="username" type="text" id="p-username" tabindex="1" class="en" placeholder="Username">
                                </div>

                                <div class="form-group clearfix">
                                    <label for="p-password"><?php echo _e('Password', 'bakala'); ?></label>
                                    <a class="forget" href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
                                    <a class="c-ui-input c-ui-input--account-pass"></a>
                                    <input name="password" type="password" id="p-password" tabindex="2" class="en" placeholder="Password">
                                    <span class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                </div>

                                <div class="form-group clearfix">
                                    <div class="ckeckbox-control">
                                        <input name="rememberme" type="checkbox" id="p-rememberme" class="rememberme" tabindex="3">
                                        <label for="p-rememberme"><?php echo _e('Remember me', 'bakala'); ?></label>
                                    </div>
                                </div>

                                <div class="login-msg"></div>

                                <div class="form-group clearfix" style="margin-bottom:50px;">
                                    <div class="bakala-button-container hasIcon large full">
                                        <button type="submit" name="submit" id="wp-submit">
                                            <span class="bakala-button blue">
                                                <i class="bakala-button-icon bakala-button-icon-login"></i>
                                                <span class="bakala-button-label clearfix">
                                                    <?php echo _e('Login To Site', 'bakala'); ?>
                                                </span>
                                            </span>
                                        </button>
                                    </div>
                                </div>

                            </div>

                            <div id="login_footerbox" class="footer box">
                                <div class="register"><?php echo _e('You Are Not Register Before?', 'bakala'); ?>
                                    <a id="Register" target="_blank" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"><?php echo _e('Register To Site', 'bakala'); ?></a>
                                </div>
                            </div>
                            <?php wp_nonce_field('ajax-login-nonce', 'p-security'); ?>
                        </form>
                        <!-- End # Login Form -->
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
        } else {
        ?>
          <div class="modal fade bakala_login_style_one" id="bakala_login" tabindex="-1" style="display: none;">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="auth-modal">
                            <div class="auth-modal-side"
                                 <?= isset($style) ? $style : null ?>>
                                <div class="bs-logo"><img src="<?= $logo_href ?>" alt=""></div>
                            </div>
                            <div class="auth-modal-content">

                                <div class="auth-modal-content-container">
                                    <header class="auth-header">
                                        <button type="button" data-bs-dismiss="modal" class="close-icon"></button>
                                    </header>
                                    <!---->
                                    <div class="auth-modal-template">
                                        <?php if ($bakala_options['lr_bakala'] == 1 && bakala_is_woocommerce_active()) :
                                            get_template_part('template-parts/login-register');
                                        else : ?>
                                            <!-- Begin # Login Form -->
                                            <form id="login" action="login" method="post">
                                                <div class="modal-body">


                                                    <div class="form-group clearfix">
                                                        <a class="c-ui-input c-ui-input--account-username"></a>
                                                        <label for="p-username"
                                                               style="width:100%"><?php echo _e('Username', 'bakala'); ?></label>

                                                        <input name="username" type="text" id="p-username" tabindex="1"
                                                               class="en" placeholder="Username">
                                                    </div>

                                                    <div class="form-group clearfix">
                                                        <label for="p-password"><?php echo _e('Password', 'bakala'); ?></label>
                                                        <a class="forget"
                                                           href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
                                                        <a class="c-ui-input c-ui-input--account-pass"></a>
                                                        <input name="password" type="password" id="p-password"
                                                               tabindex="2" class="en" placeholder="Password">
                                                        <span class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                                    </div>

                                                    <div class="form-group clearfix">
                                                        <div class="ckeckbox-control">
                                                            <input name="rememberme" type="checkbox" id="p-rememberme"
                                                                   class="rememberme" tabindex="3">
                                                            <label for="p-rememberme"><?php echo _e('Remember me', 'bakala'); ?></label>
                                                        </div>
                                                    </div>

                                                    <div class="login-msg"></div>

                                                    <div class="form-group clearfix" style="margin-bottom:50px;">
                                                        <div class="bakala-button-container hasIcon large full">
                                                            <button type="submit" name="submit" id="wp-submit">
                                                                    <span class="bakala-button blue">
                                                                        <i class="bakala-button-icon bakala-button-icon-login"></i>
                                                                        <span class="bakala-button-label clearfix">
                                                                            <?php echo _e('Login To Site', 'bakala'); ?>
                                                                        </span>
                                                                    </span>
                                                            </button>
                                                        </div>
                                                    </div>

                                                </div>

                                                <div id="login_footerbox" class="footer box">
                                                    <div class="register"><?php echo _e('You Are Not Register Before?', 'bakala'); ?>
                                                        <a id="Register" target="_blank"
                                                           href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"><?php echo _e('Register To Site', 'bakala'); ?></a>
                                                    </div>
                                                </div>
                                                <?php wp_nonce_field('ajax-login-nonce', 'p-security'); ?>
                                            </form>
                                            <!-- End # Login Form -->
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <!---->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    <?php
        }
      }
    }
    if (isset($bakala_options['bakala_lr_logo']) && !empty($bakala_options['bakala_lr_logo'])) {
      $logo_href = $bakala_options['bakala_lr_logo']['url'];
    } elseif (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
      $logo_href = $bakala_options['site_header_logo']['url'];
    } else {
      $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
    }
    ?>
    <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo" src="<?= $logo_href ?>">
      <div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
    </div>
    
  <?php if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('header')) { ?>
    
    <header class="site-header shadow-sm <?php if (isset($bakala_options['sticky_header_desk']) && $bakala_options['sticky_header_desk'] == true) {
                                            echo 'sticky-header';
                                          } ?>">
      <div class="row header">
        <?php if (isset($bakala_options['top_bar']) && $bakala_options['top_bar']) { ?>
          <div class="top-header-banner">
            <?php if ($bakala_options['top_bar_type'] == 'bgtext') { ?>
              <?php if ($bakala_options['top_bar_link'] && $bakala_options['top_bar_link_type'] != 'btn') { ?>
                <a href="<?php echo $bakala_options['top_bar_link']; ?>" target="_blank">
                <?php } ?>
                <div class="tbar-background <?= $bakala_options['top_bar_link_type'] == 'btn' ? 'tbar-type-btn' : 'tbar-type-link' ?>">
                  <div class="tbar-text">
                    <?php echo $bakala_options['top_bar_bgtext_text']; ?>
                  </div>
                  <?php if ($bakala_options['top_bar_link'] && $bakala_options['top_bar_link_type'] == 'btn') { ?>
                    <div class="tbar-btn">
                      <a href="<?= $bakala_options['top_bar_link']; ?>"><?= $bakala_options['top_bar_btn_text'] ?></a>
                    </div>
                  <?php } ?>
                </div>
                <?php if ($bakala_options['top_bar_link'] && $bakala_options['top_bar_link_type'] != 'btn') { ?>
                </a>
              <?php } ?>
            <?php } else { ?>
              <?php if ($bakala_options['top_bar_link']) { ?>
                <a href="<?php echo $bakala_options['top_bar_link']; ?>">
                <?php } ?>
                <div class="top-header-image">
                  <img alt="top-bar-banner" src="<?php echo $bakala_options['top_bar_image']['url']; ?>">
                </div>
                <?php if ($bakala_options['top_bar_link']) { ?>
                </a>
              <?php } ?>
            <?php } ?>
          </div>
        <?php } ?>


        <div class="container-bakala <?= is_user_logged_in() ? 'logged-in' : 'not-logged-in' ?>">
          <div class="align-items-center container-bakala justify-content-between mx-auto px-4 row">
            <div class="align-items-center col-md-7 d-flex">
              <?php
              if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
                $logo_href = $bakala_options['site_header_logo']['url'];
              } else {
                $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
              }
              ?>
              <a class="white-logo header-logo" href="<?php echo home_url('/'); ?>"><img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>"></a>
              <?php
              if (isset($bakala_options['dark_logo']) && strlen($bakala_options['dark_logo']['url']) > 0) {
                $dark_logo = $bakala_options['dark_logo']['url'];
                echo '<a class="dark-logo" href="' . home_url('/') . '"><img src="' . $dark_logo . '" alt="' . get_bloginfo("name") . '"></a>';
              } ?>
              <?php if (isset($bakala_options['show_search']) && $bakala_options['show_search']) {
                if(empty($bakala_options['search_shortcode'])){
                    $shortcode = do_shortcode('[wcas-search-form]');
                }else{
                    $shortcode = do_shortcode(''.$bakala_options['search_shortcode'],'');
                }
                 ?>
                <div class="navbar-search w-100">
                  <?php echo $shortcode; ?>
                </div>
              <?php } ?>
            </div>

            <div class="align-items-center col-md-5 d-flex header-icons justify-content-end p-0">
              <?php
              if (isset($bakala_options['enable_location']) && $bakala_options['enable_location'] == true) {
              ?>
                <div class="header-location site-location">
                  <a href="#">
                    <span class="location-description">
                      <?php esc_html_e('Your Location', 'bakala'); ?>
                    </span>
                    <?php if (bakala_location() == 'all') { ?>
                      <div class="current-location">
                        <?php esc_html_e('Select a Location', 'bakala'); ?>
                      </div>
                    <?php } else { ?>
                      <div class="current-location activated">
                        <?php echo esc_html(bakala_location()); ?>
                      </div>
                    <?php } ?>
                  </a>
                </div>
              <?php
              }
              ?>
<?php if (class_exists('WooCommerce')) { ?>
<div class="header-skeleton">
    <div class="header-skeleton-item" style="width: 134px; height: 50px;"></div>
    <div class="header-skeleton-divider"></div>
    <div class="header-skeleton-item" style="width: 70px; height: 50px;"></div>
</div>
                <div class="bakala_account_cart">
              
                <div class="tbar">

                  <div class="c-header__btn-container">
                   
                      <?php if (!is_user_logged_in()) {
                      ?>
                        <style>
                          a.c-header__btn-user {
                            display: flex;
                            align-items: center;
                            justify-content: center;
                          }

                          a.c-header__btn-user:after {
                            content: unset;
                          }
                        </style>
                        <?php
                        if ($bakala_options['lr_bakala'] == 1 && $bakala_options['popup_login'] == true) {

                        ?>
                          <button type="button" class="bakala_lr_btn popup" style="background: transparent;border: none;">
                            <div class="bakala-header-account">
                              <div class="bakala-header-account-text">
                                <small><?= esc_html__('account', 'bakala'); ?></small>
                                <strong><?= $bakala_options['lr-label'] ? __($bakala_options['lr-label'],'bakala') : _e('login / register', 'bakala'); ?></strong>
                              </div>
                              <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                              <i class="bakala-header-account-icon bakala-icon icon-arrow"></i>
                            </div>
                          </button>
                          <?php
                        } else {
                          if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true && $bakala_options['lr_bakala'] == 0) {
                            if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                              echo do_shortcode('[dm-modal]');
                            } else { ?>

                              <button type="button" style="background: transparent;border: none;" data-bs-toggle="modal" data-bs-target="#bakala_login" class="bakala_lr_btn popup">
                                <div class="bakala-header-account">
                                  <div class="bakala-header-account-text">
                                    <small><?= esc_html__('account', 'bakala'); ?></small>
                                    <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('login / register', 'bakala'); ?></strong>
                                  </div>
                                  <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                  <i class="bakala-header-account-icon bakala-icon icon-arrow"></i>
                                </div>
                              </button>
                            <?php
                            }
                          } else { ?>
                            <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" class="bakala_lr_btn">
                              <div class="bakala-header-account">
                                <div class="bakala-header-account-text">
                                  <small><?= esc_html__('account', 'bakala'); ?></small>
                                  <strong><?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('login / register', 'bakala'); ?></strong>
                                </div>
                                <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                                <i class="bakala-header-account-icon bakala-icon icon-arrow"></i>
                              </div>
                            </a>
                          <?php } ?>
                          <?php if (!function_exists('digits_addon_digoneclickls')) { ?>

                        <?php }
                        }
                      } else {
                        ?>
                        <div class="bakala-header-account">

                          <div class="bakala-header-account-text">
                            <small><?= esc_html__('account', 'bakala'); ?></small>
                            <strong><?= $user_name ?></strong>
                          </div>
                          <i class="bakala-header-account-icon bakala-icon icon-account"></i>
                          <i class="bakala-header-account-icon bakala-icon icon-arrow"></i>
                        </div>
                        <a class="c-header__btn-user js-dropdown-toggle">
                          <div class="user-menu-toggle">

                          </div>

                        </a>

                        <div class="c-header__user-dropdown js-dropdown-menu" style="display: none;">

                          <?php if (!is_user_logged_in()) {
                            if ($bakala_options['lr_bakala'] == 1) {
                          ?>
                              <button type="button" style="background: transparent;border: none;" data-bs-toggle="modal" data-bs-target="#bakala_login" class="c-header__user-dropdown-login">
                                <?= $bakala_options['lr-label'] ? $bakala_options['lr-label'] : _e('ورود / ثبت نام', 'bakala'); ?>
                              </button>
                              <?php
                            } else {
                              if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true) {
                                if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                  echo do_shortcode('[dm-modal]');
                                } else { ?>
                                  <button type="button" style="background: transparent;border: none;" data-bs-toggle="modal" data-bs-target="#bakala_login" class="c-header__user-dropdown-login">
                                    <?php echo _e('Login', 'bakala'); ?>
                                  </button>
                                <?php
                                }
                              } else { ?>
                                <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>" class="c-header__user-dropdown-login">
                                  <?php echo _e('Login', 'bakala'); ?>
                                </a>
                              <?php } ?>
                              <?php if (!function_exists('digits_addon_digoneclickls')) { ?>
                                <div class="c-header__user-dropdown-sign-up">
                                  <span>
                                    <?php echo _e('New user?', 'bakala'); ?>
                                  </span>
                                  <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>">
                                    <?php echo _e('Register', 'bakala'); ?>
                                  </a>
                                </div>
                            <?php }
                            } ?>
                          <?php } ?>

                          <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>" class="c-header__user-dropdown-action c-header__user-dropdown-action--profile" data-event="profile_click" data-event-category="header_section" data-event-label="logged_in: False">
                            <div>
                              <div class="profile-avatar">
                                <?php echo get_avatar($current_user->ID, 48); ?>
                              </div>
                              <div class="profile-name">
                                <span>
                                  <?= $user_name ?>
                                </span>
                                <i class="fa fa-chevron-left"></i>
                              </div>
                            </div>
                          </a>
                          <?php
                          if (!empty($bakala_options['top_bar_trackorder']) || $bakala_options['myaccount_tracking_order'] == 1) {
                            if (isset($bakala_options['top_bar_trackorder']) && $bakala_options['top_bar_trackorder']) {
                              $order_tracking_link = get_permalink($bakala_options['top_bar_trackorder']);
                            } elseif (!$bakala_options['top_bar_trackorder']) {
                              $order_tracking_link = get_permalink(get_option('woocommerce_myaccount_page_id')) . 'your-tracking/';
                            }

                          ?>
                            <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?= $order_tracking_link ?>">
                              <span class="orders-menu"></span>
                              <?php echo _e('Track Order', 'bakala'); ?>
                            </a>
                          <?php
                          }
                          if(is_plugin_active( 'dokan-lite/dokan.php' ) && dokan_is_user_seller(get_current_user_id())){
                              $dashboard_url = dokan_get_page_url( 'dashboard', 'dokan' );
                          ?>
                          <a class="c-header__user-dropdown-action c-header__user-dropdown-action--dokan" href="<?= $dashboard_url ?>">
                              <span class="icon icon-dashboard"></span>
                              <?php echo _e('vendor dashboard', 'bakala'); ?>
                            </a>
            
                          <?php
                          }
                          if (is_plugin_active('address-plus/address-plus.php')) { ?>
                              <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('addressplus-addresses'); ?>">
                                <span class="icon icon-address"></span>
                                <?php echo _e('My Addresses', 'bakala'); ?>
                              </a>
                          <?php } ?>
                          <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-wishlist'); ?>">
                            <span class="icon icon-love"></span>
                            <?php echo _e('My Wishlist', 'bakala'); ?>
                          </a>
                          <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-comments'); ?>">
                            <span class="icon my-comments"></span>
                            <?php echo _e('Criticism and comments', 'bakala'); ?>
                          </a>
                          <?php if ($bakala_options['account_notification'] == 1) { ?>
                            <a class="c-header__user-dropdown-action c-header__user-dropdown-action--orders" href="<?php echo wc_get_account_endpoint_url('your-notifications'); ?>">
                              <span class="icon my-notes"></span>
                              <?php echo _e('اعلانات', 'bakala'); ?>
                            </a>
                          <?php } ?>
                          <?php if (is_user_logged_in()) { ?>
                            <a href="<?php echo wp_logout_url(home_url()); ?>" class="c-header__user-dropdown-action c-header__user-dropdown-action--logout">
                              <i class="bakala-loguot"></i>
                              <?= $bakala_options['logout-label'] ? $bakala_options['logout-label'] : _e('log out account', 'bakala'); ?>
                            </a>
                          <?php } ?>
                        </div>
                      <?php } ?>
                    

                  </div>
                </div>

              

              <?php if (isset($bakala_options['show_cart']) && $bakala_options['show_cart'] && $bakala_options['catalog_mode'] == false && class_exists('WooCommerce') && !is_cart() && !is_checkout()) {
                $cart_count = bakala_get_cart_count();
                if ($bakala_options['force_login_cart'] == 1 && !is_user_logged_in()) {
                  $cart_text = '<i class="bakala-icon more-icon"></i>';
                } else {
                  if ($cart_count > 0) {
                    $cart_text = wc_price(WC()->cart->subtotal);
                  } else {
                    $cart_text = __('is empty', 'bakala');
                  }
                }
              ?>
                <div class="cart-box<?php if ($cart_count > 0) {
                                      echo ' fill';
                                    } ?>">
                  <div class="dk-button-container hasIcon">
                    <div class="dk-button green header-cart">
                      <div class="header-cart-text">
                        <small><?= esc_html__('Cart', 'bakala'); ?></small>
                        <strong class="bill"><span class="price"><?= $cart_text ?></span></strong>
                      </div>
                      <div class="header-cart-icon">
                        <i class="dk-button-icon dk-button-icon-cart"></i>
                        <div class="dk-button-label clearfix">
                          <div class="dk-button-labelname">
                            <?php echo _e('Cart', 'bakala'); ?>
                          </div>
                          <span class="cart-items-count">
                            <?php echo ($cart_count); ?>
                          </span>
                          <?php if ($cart_count > 0) {
                            echo '<i class="fa fa-angle-down"></i>';
                          } ?>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="mini-cart-dropdown bakala_mini_cart" style="display:none">
                    <?php woocommerce_mini_cart(); ?>
                  </div>

                </div>
              <?php } ?>
                </div>
<?php } ?>
            </div>
          </div>

        </div>
      </div>

      <div id="<?= $bakala_options['sticky_header_desk'] == true ? 'navbar-primary-fixed' : 'navbar-primary' ?>" class="row navbar-primary nav-down <?php if (isset($bakala_options['sticky_header_desk']) && $bakala_options['sticky_header_desk'] == true) {
                                                                                                                                                      echo ' mobile-top-bar';
                                                                                                                                                    } ?>">
        <div class="container-bakala main-menu-div">
          <?php if (function_exists('ubermenu')) :
            ubermenu('main', array('theme_location' => 'uber'));
          else :
            bkm_menu();
          endif;

          if (isset($bakala_options['header_tell']) && $bakala_options['header_tell'] && !empty($bakala_options['headerinfobar_tell_phone'])) { ?>
            <div class="header-call">
              <a class="header-call-btn" href="<?php echo get_permalink($bakala_options['headerinfobar_tell_page']); ?>" dir="ltr" style="gap: 4px;">
                <i class="bakala-icon support-icon"></i>
                <div class="block" style="font-size: 15px;direction: ltr !important;"><?= $bakala_options['headerinfobar_tell_phone'] ?></div>
              </a>
            </div>
          <?php
          } ?>

        </div>
        <?php if ($bakala_options['header_categories_enable_pc'] == '1' && class_exists('WooCommerce') && !empty($bakala_options['header_categories']) && (is_home() || is_front_page())) { ?>
          <div class="bakala-product-categories-header">
            <?php foreach ($bakala_options['header_categories'] as $category_id) {
              $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
              $image_url = wp_get_attachment_url($thumbnail_id);
              $term = get_term_by('id', $category_id, 'product_cat');
              $link = get_term_link($term->slug, 'product_cat');

            ?>
              <a href="<?php echo $link ?>" class="bakala-product-category-header">
                <div class="bakala-product-category-header-img">
                  <img src="<?= $image_url ?>" alt="<?= $term->name ?>" loading="lazy" style="filter: blur(0px);">
                </div>
                <span class="bakala-product-category-header-title" style="color: rgba(0, 0, 0, 0.56);"><?= $term->name ?></span>
              </a>
            <?php } ?>
          </div>
        <?php }

        ?>
      </div>
    </header>
  <?php }