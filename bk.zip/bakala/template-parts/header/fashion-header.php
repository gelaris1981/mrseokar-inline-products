<?php
global $bakala_options;

if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
    $logo_href = $bakala_options['site_header_logo']['url'];
} else {
    $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
}
$current_user = wp_get_current_user();
$firstname = get_user_meta($current_user->ID, 'first_name', true);
$lastname = get_user_meta($current_user->ID, 'last_name', true);
if ($firstname && $lastname) {
    $user_name = $firstname . ' ' . $lastname;
} else {
    $user_name = $current_user->display_name;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <?php
    if (isset($bakala_options['bakala_favicon']) && strlen($bakala_options['bakala_favicon']['url']) > 0) {
        $favicon_href = $bakala_options['bakala_favicon']['url'];
    } else {
        $favicon_href = get_template_directory_uri() . '/vendor/images/favicon.png';
    }
    ?>
    <link rel="shortcut icon" href="<?php echo $favicon_href; ?>" />
    <link rel="apple-touch-icon" href="<?php echo $favicon_href; ?>">
    <meta name="msapplication-TileColor" content="#ff6600">
    <meta name="msapplication-TileImage" content="<?php echo $favicon_href; ?>">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <?php
    if (function_exists('wp_body_open')) {
        wp_body_open();
    } else {
        do_action('wp_body_open');
    }

    ?>
    <?php if (isset($bakala_options['google_tags']) && $bakala_options['google_tags'] == true) {
        echo $bakala_options['google_tags'];
    } ?>
    <?php if (isset($bakala_options['bakala_preload']) && $bakala_options['bakala_preload'] == 1 && is_front_page() && !isset($_GET['app'])) : ?>
        <div id="bakala-preload">
            <div class="bakala-preload-wrap">
                <?php if (isset($bakala_options['bakala_preload_logo']) && $bakala_options['bakala_preload_logo']['url']) : ?>
                    <div id="bakala-preload-logo">
                        <img alt="bakala-preload-logo" src="<?php echo $bakala_options['bakala_preload_logo']['url']; ?>">
                    </div>
                <?php endif; ?>
                <div id="bakala-preload-gif">
                    <?php if (isset($bakala_options['bakala_preload_gif']) && $bakala_options['bakala_preload_gif']['url']) : ?>
                        <img alt="bakala-preload-gif" src="<?php echo $bakala_options['bakala_preload_gif']['url']; ?>">
                    <?php endif; ?>
                    <?php if (isset($bakala_options['bakala_preload_css']) && $bakala_options['bakala_preload_gif']['url'] == false) {
                        $bakala_preload_css = $bakala_options['bakala_preload_css'];
                        if ($bakala_preload_css == 'spinner') {
                            echo '<div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'default') {
                            echo '<div class="lds-default"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'grid') {
                            echo '<div class="lds-grid"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'roller') {
                            echo '<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'ellipsis') {
                            echo '<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'ring') {
                            echo '<div class="lds-ring"><div></div><div></div><div></div><div></div></div>';
                        }
                    } ?>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php if (!is_user_logged_in() && ($bakala_options['digits'] != true || !function_exists('digit_get_login_fields') || $bakala_options['lr_bakala'] == 1)) { 
    if (isset($bakala_options['bakala_lr_logo']) && $bakala_options['bakala_lr_logo']['url']){
    $logo_href=$bakala_options['bakala_lr_logo']['url'];
}elseif (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
    $logo_href = $bakala_options['site_header_logo']['url'];
} else {
    $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
}

    if (empty($bakala_options['lr_bg']['from'])) {
		$gradient_from = $bakala_options['accent-gradient']['from'];
	} else {
		$gradient_from = $bakala_options['lr_bg']['from'];
	}
	if (empty($bakala_options['lr_bg']['to'])) {
		$gradient_to = $bakala_options['accent-gradient']['to'];
	} else {
		$gradient_to = $bakala_options['lr_bg']['to'];
	}
    ?>
         <div class="modal fade" id="bakala_login" tabindex="-1" style="display: none;">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="auth-modal">
                <div class="auth-modal-side" style="background: linear-gradient(90deg,<?= $gradient_from ?>,<?= $gradient_to ?>);">
                    <div class="bs-logo"><img src="<?= $logo_href ?>" alt=""></div>
                </div>
                <div class="auth-modal-content">

                    <div class="auth-modal-content-container">
                        <header class="auth-header">
                            <button type="button" data-bs-dismiss="modal" class="close-icon"></button>
                        </header>
                        <!---->
                        <div class="auth-modal-template">
                                                    <?php if ($bakala_options['lr_bakala'] == 1 && bakala_is_woocommerce_active()) :
                            get_template_part('template-parts/login-register');
                        else : ?>
                            <!-- Begin # Login Form -->
                            <form id="login" action="login" method="post">
                                <div class="modal-body">



                                    <div class="form-group clearfix">
                                        <a class="c-ui-input c-ui-input--account-username"></a>
                                        <label for="p-username" style="width:100%"><?php echo _e('Username', 'bakala'); ?></label>

                                        <input name="username" type="text" id="p-username" tabindex="1" class="en" placeholder="Username">
                                    </div>

                                    <div class="form-group clearfix">
                                        <label for="p-password"><?php echo _e('Password', 'bakala'); ?></label>
                                        <a class="forget" href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
                                        <a class="c-ui-input c-ui-input--account-pass"></a>
                                        <input name="password" type="password" id="p-password" tabindex="2" class="en" placeholder="Password">
                                        <span class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                    </div>

                                    <div class="form-group clearfix">
                                        <div class="ckeckbox-control">
                                            <input name="rememberme" type="checkbox" id="p-rememberme" class="rememberme" tabindex="3">
                                            <label for="p-rememberme"><?php echo _e('Remember me', 'bakala'); ?></label>
                                        </div>
                                    </div>

                                    <div class="login-msg"></div>

                                    <div class="form-group clearfix" style="margin-bottom:50px;">
                                        <div class="bakala-button-container hasIcon large full">
                                            <button type="submit" name="submit" id="wp-submit">
                                                <span class="bakala-button blue">
                                                    <i class="bakala-button-icon bakala-button-icon-login"></i>
                                                    <span class="bakala-button-label clearfix">
                                                        <?php echo _e('Login To Site', 'bakala'); ?>
                                                    </span>
                                                </span>
                                            </button>
                                        </div>
                                    </div>

                                </div>

                                <div id="login_footerbox" class="footer box">
                                    <div class="register"><?php echo _e('You Are Not Register Before?', 'bakala'); ?>
                                        <a id="Register" target="_blank" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"><?php echo _e('Register To Site', 'bakala'); ?></a>
                                    </div>
                                </div>
                                <?php wp_nonce_field('ajax-login-nonce', 'p-security'); ?>
                            </form>
                            <!-- End # Login Form -->
                        <?php endif; ?>
                        </div>
                    </div>
                    <!---->
                </div>
            </div>
        </div>
    </div>
</div>
    <?php } ?>
    <div class="container-bakala white_catbody">
        <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo" src="<?= $logo_href ?>">
            <div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
        </div>
        
        <?php if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('header')) { ?>
            <header class="main-navigation">
                <div class="navigation-general container">
                    <div class="for-user">
                        <button class="cart-btn">
                            <span class="bakala-icon icon-add-to-basket"></span>
                        </button>
                        <div class="header-submenu" id="cartMenu">
                            <?php if (WC()->cart->is_empty()){ ?>
                                <div class="img-box">
                                    <img src="<?= get_template_directory_uri().'/vendor/images/empty-basket.png' ?>" alt="empty cart">
                                </div>
                            <?php } ?>
                           <?php woocommerce_mini_cart(); ?>
                        </div>
                        <?php if (is_user_logged_in()) { ?>
                            <button class="wishlist-btn notauthorized">
                                <span class="bakala-icon icon-fav-bt"></span>
                            </button>
                        <?php } ?>
                        <div class="profile-container">
                            <?php if (is_user_logged_in()) { ?>
                                <div class="profile">
                                    <span class="icon-profile-bt bakala-icon"></span>
                                    <span id="profile-customer-name"><?= $user_name ?> عزیز</span>
                                    <div class="down-arrow">
                                        <span class="bakala-icon icon-arrow-down"></span>
                                    </div>
                                    <div class="header-submenu" id="profileMenu">
                                        <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>">
                                            <div class="profile-avatar">
                                                <?php echo get_avatar($current_user->ID, 30); ?>
                                            </div>
                                            <span><?= __('Account','bakala') ?></span>
                                        </a>
                                        <a href="<?php echo wc_get_account_endpoint_url('orders'); ?>">
                                            <span class="bakala-icon icon-order-detail color-main"></span>
                                            <span><?= __('Orders','bakala') ?></span>
                                        </a>
                                        <a href="<?php echo wc_get_account_endpoint_url('your-comments'); ?>">
                                            <span class="bakala-icon icon-comments color-main"></span>
                                            <span><?= __('Criticism and comments','bakala') ?></span>
                                        </a>
                                        <a href="<?php echo wc_get_account_endpoint_url('your-notifications'); ?>">
                                            <span class="bakala-icon icon-notif color-main"></span>
                                            <span><?= __('Notifications','bakala') ?></span>
                                        </a>
                                        
                                        <a href="<?php echo wp_logout_url(home_url()); ?>" id="profile-customer-logout">
                                            <span class="bakala-icon icon-logout-profile color-orang"></span>
                                            <span><?= __('log out account','bakala') ?></span>
                                        </a>
                                    </div>
                                </div>
                            <?php } else { ?>
                                <a class="login-register" data-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login" type="button"><?= __('login / register','bakala') ?></a>
                            <?php } ?>
                        </div>

                    </div>

                    <div class="search-box">
                        <?php echo do_shortcode('[wcas-search-form]'); ?>
                    </div>

                    <div class="site-logo">
                        <a class="logo" href="<?php echo home_url('/'); ?>">
                            <img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>">
                        </a>
                    </div>

                    <span class="close-search">
                        <span class="bakala-icon icon-cancel"></span>
                    </span>

                </div>

                <nav class="navigation-catrgories">
                    <div class="container-bakala main-menu-div">
                        <?php if (function_exists('ubermenu')) :
                            ubermenu('main', array('theme_location' => 'uber'));
                        else :
                            bkm_menu();
                        endif;
                        ?>
                    </div>
                </nav>
            </header>
        <?php } ?>