<?php if (!defined('ABSPATH')) exit;
global $bakala_options;
?>


    <div class="checkout-headers">
        <ul>
            <li class="nav"><a href="<?php echo wc_get_cart_url(); ?>"></a>
                <p><?php _e('Cart', 'bakala'); ?></p><span>1</span>
            </li>
            <li class="bar"><span></span></li>
            <li class="nav">
				<?php if ( ($bakala_options['force_login_cart'] == 1 || $bakala_options['force_login_in_cart'] == 1) && !is_user_logged_in() ){ ?>
				<a href="#" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login"></a>
				<?php }else{
	?>
				<a href="<?php echo wc_get_checkout_url(); ?>"></a>
<?php
} ?>
                <p><?php _e('Billing', 'bakala'); ?></p><span>2</span>
            </li>
            <li class="bar"><span></span></li>
            <li class="nav">
                <p><?php _e('Factor', 'bakala'); ?></p><span>3</span>
            </li>
        </ul>
    </div>