<?php

ob_start();
global $bakala_options;
$current_user = wp_get_current_user();
if (bakala_is_woocommerce_active()) {
    if (function_exists('is_product') && is_product()) {
        $product = wc_get_product(get_the_ID());
    }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="theme-color" content="<?php echo esc_attr($bakala_options['theme-color']); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <?php
    if (isset($bakala_options['bakala_favicon']) && strlen($bakala_options['bakala_favicon']['url']) > 0) {
        $favicon_href = $bakala_options['bakala_favicon']['url'];
    } else {
        $favicon_href = get_template_directory_uri() . '/vendor/images/favicon.png';
    }
    ?>
    <link rel="shortcut icon" href="<?php echo $favicon_href; ?>" />
    <link rel="apple-touch-icon" href="<?php echo $favicon_href; ?>">
    <meta name="msapplication-TileColor" content="#ff6600">
    <meta name="msapplication-TileImage" content="<?php echo $favicon_href; ?>">
    <?php wp_head(); ?>
    <?php if (!empty($bakala_options['tracking_code'])) {
        echo $bakala_options['tracking_code'];
    } ?>
</head>

<body <?php body_class(); ?> tabindex="0">
    <?php if (isset($bakala_options['google_tags']) && $bakala_options['google_tags'] == true) {
        echo $bakala_options['google_tags'];
    } ?>
    <?php if (isset($bakala_options['bakala_preload']) && $bakala_options['bakala_preload'] == 1 && is_front_page() && !isset($_GET['app']) && !isset($_COOKIE['bakala_show_preload'])) : ?>
        <script nowprocket>
            setTimeout(function() {
                var element = document.getElementById("bakala-preload");
                if (element) {
                    element.style.setProperty('display', 'none', 'important');
                }
            }, 1000);
        </script>
        <div id="bakala-preload">
            <div class="bakala-preload-wrap">
                <?php if (isset($bakala_options['bakala_preload_logo']) && $bakala_options['bakala_preload_logo']['url']) : ?>
                    <div id="bakala-preload-logo">
                        <img alt="bakala-preload-logo" src="<?php echo $bakala_options['bakala_preload_logo']['url']; ?>">
                    </div>
                <?php endif; ?>
                <div id="bakala-preload-gif">
                    <?php if (isset($bakala_options['bakala_preload_gif']) && $bakala_options['bakala_preload_gif']['url']) : ?>
                        <img alt="bakala-preload-gif" src="<?php echo $bakala_options['bakala_preload_gif']['url']; ?>">
                    <?php endif;
                    if (isset($bakala_options['bakala_preload_css']) && $bakala_options['bakala_preload_gif']['url'] == false) {
                        $bakala_preload_css = $bakala_options['bakala_preload_css'];
                        if ($bakala_preload_css == 'spinner') {
                            echo '<div class="lds-spinner"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'default') {
                            echo '<div class="lds-default"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'grid') {
                            echo '<div class="lds-grid"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'roller') {
                            echo '<div class="lds-roller"><div></div><div></div><div></div><div></div><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'ellipsis') {
                            echo '<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>';
                        } elseif ($bakala_preload_css == 'ring') {
                            echo '<div class="lds-ring"><div></div><div></div><div></div><div></div></div>';
                        }
                    } ?>
                </div>
            </div>
        </div>
    <?php
        setcookie('bakala_show_preload', 'yes', time() + 86400, '/');

    endif;
    if (isset($bakala_options['lr_bg_mobile']['from']) && !empty($bakala_options['lr_bg_mobile']['from']) &&
        isset($bakala_options['lr_bg_mobile']['to']) && !empty($bakala_options['lr_bg_mobile']['to'])) {
        
        $style = 'style="background: linear-gradient(45deg, ' . $bakala_options['lr_bg_mobile']['from'] . ', ' . $bakala_options['lr_bg_mobile']['to'] . ')"';
        
    } elseif (isset($bakala_options['darkmode']) && $bakala_options['darkmode'] == '1' &&
            isset($bakala_options['darkmode_background_color']) && !empty($bakala_options['darkmode_background_color'])) {
        
        $style = 'style="background: ' . $bakala_options['darkmode_background_color'] . '"';
        
    } else {
        $style = '';
    }

    if (!is_user_logged_in() && ($bakala_options['digits'] != true || !function_exists('digit_get_login_fields'))) { ?>
        <div class="modal fade" id="bakala_login" tabindex="-1" style="display: none;">
            <div class="modal-dialog">
                <div class="modal-content" <?= isset($style) ? $style : null ?>>
                    <?php if ($bakala_options['lr_bakala'] == 1 && bakala_is_woocommerce_active()) :
                        get_template_part('template-parts/login-register');
                    else : ?>
                        <!-- Begin # Login Form -->
                        <form id="login" action="login" method="post">
                            <div class="modal-body">


                                <div class="form-group clearfix">
                                    <a class="c-ui-input c-ui-input--account-username"></a>
                                    <label for="p-username" style="width:100%"><?php echo _e('Username', 'bakala'); ?></label>

                                    <input name="username" type="text" id="p-username" tabindex="1" class="en" placeholder="Username">
                                </div>

                                <div class="form-group clearfix">
                                    <label for="p-password"><?php echo _e('Password', 'bakala'); ?></label>
                                    <a class="forget" href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
                                    <a class="c-ui-input c-ui-input--account-pass"></a>
                                    <input name="password" type="password" id="p-password" tabindex="2" class="en" placeholder="Password">
                                    <span class="fa fa-fw fa-eye field-icon toggle-password"></span>
                                </div>

                                <div class="form-group clearfix">
                                    <div class="ckeckbox-control">
                                        <input name="rememberme" type="checkbox" id="p-rememberme" class="rememberme" tabindex="3">
                                        <label for="p-rememberme"><?php echo _e('Remember me', 'bakala'); ?></label>
                                    </div>
                                </div>

                                <div class="login-msg"></div>

                                <div class="form-group clearfix" style="margin-bottom:50px;">
                                    <div class="bakala-button-container hasIcon large full">
                                        <button type="submit" name="submit" id="wp-submit">
                                            <span class="bakala-button blue">
                                                <i class="bakala-button-icon bakala-button-icon-login"></i>
                                                <span class="bakala-button-label clearfix">
                                                    <?php echo _e('Login To Site', 'bakala'); ?>
                                                </span>
                                            </span>
                                        </button>
                                    </div>
                                </div>

                            </div>

                            <div id="login_footerbox" class="footer box">
                                <div class="register"><?php echo _e('You Are Not Register Before?', 'bakala'); ?>
                                    <a id="Register" target="_blank" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"><?php echo _e('Register To Site', 'bakala'); ?></a>
                                </div>
                            </div>
                            <?php wp_nonce_field('ajax-login-nonce', 'p-security'); ?>
                        </form>
                        <!-- End # Login Form -->
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php }
    if ($bakala_options['modern_header_mobile'] == 1 || is_null($bakala_options['modern_header_mobile'])) {
        if (isset($bakala_options['top_bar_mobile']) && $bakala_options['top_bar_mobile']) { ?>
            <div class="top-header-banner">
                <?php if ($bakala_options['top_bar_type_mobile'] == 'bgtext') { ?>
                    <?php if ($bakala_options['top_bar_link_mobile'] && $bakala_options['top_bar_link_type_mobile'] != 'btn') { ?>
                        <a href="<?php echo $bakala_options['top_bar_link_mobile']; ?>" target="_blank">
                        <?php } ?>
                        <div class="tbar-background <?= $bakala_options['top_bar_link_type_mobile'] == 'btn' ? 'tbar-type-btn' : 'tbar-type-link' ?>">
                            <div class="tbar-text">
                                <?php echo $bakala_options['top_bar_bgtext_text_mobile']; ?>
                            </div>
                            <?php if ($bakala_options['top_bar_link_mobile'] && $bakala_options['top_bar_link_type_mobile'] == 'btn') { ?>
                                <div class="tbar-btn">
                                    <a href="<?= $bakala_options['top_bar_link_mobile']; ?>"><?= $bakala_options['top_bar_btn_text_mobile'] ?></a>
                                </div>
                            <?php } ?>
                        </div>
                        <?php if ($bakala_options['top_bar_link_mobile'] && $bakala_options['top_bar_link_type_mobile'] != 'btn') { ?>
                        </a>
                    <?php } ?>
                <?php } else { ?>
                    <?php if ($bakala_options['top_bar_link_mobile']) { ?>
                        <a href="<?php echo $bakala_options['top_bar_link_mobile']; ?>">
                        <?php } ?>
                        <div class="top-header-image">
                            <img alt="top-bar-banner" src="<?php echo $bakala_options['top_bar_image_mobile']['url']; ?>">
                        </div>
                        <?php if ($bakala_options['top_bar_link_mobile']) { ?>
                        </a>
                    <?php } ?>
                <?php } ?>
            </div>
        <?php }
        if (isset($bakala_options['modern_header_mobile_style']) && $bakala_options['modern_header_mobile_style'] == 'two') {
        ?>
            <div class="off-canvas-panel_mo dialog--close" id="off-canvas_menu">
                <a href="#" class="close-menu-button"><i class="bakala-icon close"></i></a>
                <div class="off-canvas-panel-wrapper_mo">
                    <nav id="main-navigation_mo">
                        <ul class="main-menu">
                            <?php
                            if (isset($bakala_options['mobile_menu']) && $bakala_options['mobile_menu']) {
                                // بررسی کنید که مکان منوی 'mobile' وجود داشته باشد
                                $nav_locations = get_nav_menu_locations();
                                if (isset($nav_locations['mobile'])) {
                                    $term = get_term($nav_locations['mobile'], 'nav_menu');
                                    // بررسی کنید که term یک شیء معتبر WP_Term باشد و خطا ندهد
                                    if (!is_wp_error($term) && !empty($term->slug)) {
                                        $main_nav_slug = $term->slug;
                                    }
                                }
                            } else {
                                // بررسی کنید که مکان منوی 'main' وجود داشته باشد
                                $nav_locations = get_nav_menu_locations();
                                if (isset($nav_locations['main'])) {
                                    $term = get_term($nav_locations['main'], 'nav_menu');
                                    // بررسی کنید که term یک شیء معتبر WP_Term باشد و خطا ندهد
                                    if (!is_wp_error($term) && !empty($term->slug)) {
                                        $main_nav_slug = $term->slug;
                                    }
                                }
                            }

                            if (get_option('mobi_menu')) {
                                $main_nav_id = get_option('mobi_menu');
                            } else {
                                $main_nav_id = $main_nav_slug;
                            }
                            $main_nav = wp_get_nav_menu_items($main_nav_id);
                            if ($main_nav) {
                                foreach ($main_nav as $menu_item) {
                                    if (is_object($menu_item) && isset($menu_item->ID)) {
                                        $menu_item_icon = get_post_meta($menu_item->ID, '_menu_item_icon', true);
                                    }
                                    $childs = 0;
                                    if ($menu_item->menu_item_parent == '0') {
                                        foreach ($main_nav as $menu_item_child_is) {
                                            if ($menu_item_child_is->menu_item_parent == $menu_item->ID) {
                                                $childs = $childs + 1;
                                            }
                                        }
                                        if ($childs > 0) {
                                            $menu_link = '#popup';
                                        } else {
                                            $menu_link = $menu_item->url;
                                        }
                            ?>
                                        <li>
                                            <span class="menu-title menu-title1">

                                                <a class="btn_mo-ripple <?= $childs > 0 ? 'haschild' : '' ?> <?php if (implode('', $menu_item->classes)) echo implode('', $menu_item->classes); ?> <?= ($menu_item->url == '#' || $menu_link == '#popup') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" <?php if ($menu_item->target && $menu_link != '#popup') echo 'target="' . $menu_item->target . '" '; ?> <?php if ($menu_item->xfn) echo 'rel="' . $menu_item->xfn . '" '; ?> <?php if ($menu_item->attr_title) echo 'title="' . $menu_item->attr_title . '" '; ?> href="<?php echo $menu_link; ?>">


                                                    <?php if ($menu_item_icon) :
                                                        $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                        if (preg_match($regx_img, $menu_item_icon) == 1) {
                                                    ?>
                                                            <img src="<?= $menu_item_icon ?>" class="menu-item-icon" width="18">
                                                        <?php } else { ?>
                                                            <i class="<?= $menu_item_icon ?> menu-item-icon"></i>
                                                    <?php }
                                                    endif; ?>
                                                    <span class="pull-right"><?php echo $menu_item->title; ?></span>
                                                    <?php if ($childs > 0) { ?>
                                                        <i class="fa fa-arrow-left next"></i>
                                                    <?php } ?>
                                                </a>

                                            </span>
                                            <?php if ($childs > 0) { ?>
                                                <ul class="collapse submenu">
                                                    <li class="go-back"><?php echo $menu_item->title; ?> <i class="fa fa-arrow-right"></i></li>
                                                    <?php
                                                    foreach ($main_nav as $menu_item_child) {
                                                        if (is_object($menu_item_child) && isset($menu_item_child->ID)) {
                                                            $menu_item_child_icon = get_post_meta($menu_item_child->ID, '_menu_item_icon', true);
                                                        }
                                                        $cchilds = 0;
                                                        foreach ($main_nav as $menu_item_child_child_is) {

                                                            if ($menu_item_child_child_is->menu_item_parent == $menu_item_child->ID) {
                                                                $cchilds = $cchilds + 1;
                                                            }
                                                        }
                                                        if ($cchilds > 0) {
                                                            $cmenu_link = '#popup';
                                                        } else {
                                                            $cmenu_link = $menu_item_child->url;
                                                        }
                                                        if ($menu_item_child->menu_item_parent == $menu_item->ID) { ?>

                                                            <li>
                                                                <span class="menu-title menu-title2">
                                                                    <a class="btn_mo-ripple <?= $cchilds > 0 ? 'haschild' : '' ?> <?php if (implode(' ', $menu_item_child->classes)) echo implode(' ', $menu_item_child->classes); ?> <?= ($menu_item_child->url == '#') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" href="<?php echo $cmenu_link; ?>" <?php if ($menu_item_child->target && $cmenu_link != '#popup') echo 'target="' . $menu_item_child->target . '" '; ?> <?php if ($menu_item_child->xfn) echo 'rel="' . $menu_item_child->xfn . '" '; ?> <?php if ($menu_item_child->attr_title) echo 'title="' . $menu_item_child->attr_title . '" '; ?>>

                                                                        <?php if ($menu_item_child_icon) :
                                                                            $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                            if (preg_match($regx_img, $menu_item_child_icon) == 1) {
                                                                        ?>
                                                                                <img src="<?= $menu_item_child_icon ?>" class="menu-item-icon" width="18">
                                                                            <?php } else { ?>
                                                                                <i class="<?= $menu_item_child_icon ?> menu-item-icon"></i>
                                                                        <?php }
                                                                        endif; ?>
                                                                        <span class="pull-right"><?php echo $menu_item_child->title; ?></span>
                                                                        <?php if ($cchilds > 0) { ?>
                                                                            <i class="fa fa-arrow-left next"></i>
                                                                        <?php } ?>
                                                                    </a>

                                                                </span>
                                                                <?php if ($cchilds > 0) { ?>
                                                                    <ul class="collapse submenu">
                                                                        <li class="go-back"><?php echo $menu_item_child->title; ?>
                                                                            <i class="fa fa-arrow-right"></i>
                                                                        </li>

                                                                        <?php
                                                                        foreach ($main_nav as $menu_item_child_child) {
                                                                            if (is_object($menu_item_child_child) && isset($menu_item_child_child->ID)) {
                                                                                $menu_item_child_child_icon = get_post_meta($menu_item_child_child->ID, '_menu_item_icon', true);
                                                                            }
                                                                            if ($menu_item_child_child->menu_item_parent == $menu_item_child->ID) {
                                                                                $ccchilds = 0;
                                                                                foreach ($main_nav as $menu_item_child_child_child_is) {

                                                                                    if ($menu_item_child_child_child_is->menu_item_parent == $menu_item_child_child->ID) {
                                                                                        $ccchilds = $ccchilds + 1;
                                                                                    }
                                                                                }
                                                                        ?>
                                                                                <li>
                                                                                    <span class="menu-title menu-title3">
                                                                                        <a class="ch btn_mo-ripple <?= $menu_item_child_child->url == '#' ? 'next' : '' ?> <?= $ccchilds > 0 ? 'haschild' : '' ?>" href="<?= $menu_item_child_child->url ?>" property="url">
                                                                                            <?php if ($menu_item_child_child_icon) :
                                                                                                $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                if (preg_match($regx_img, $menu_item_child_child_icon) == 1) {
                                                                                            ?>
                                                                                                    <img src="<?= $menu_item_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                <?php } else { ?>
                                                                                                    <i class="<?= $menu_item_child_child_icon ?> menu-item-icon"></i>
                                                                                            <?php }
                                                                                            endif; ?>
                                                                                            <span><?= $menu_item_child_child->title ?></span>
                                                                                            <?php if ($ccchilds > 0) { ?>
                                                                                                <i class="fa fa-arrow-left next"></i>
                                                                                            <?php } ?>
                                                                                        </a>


                                                                                    </span>
                                                                                    <?php if ($ccchilds > 0) { ?>
                                                                                        <ul class="collapse submenu">
                                                                                            <li class="go-back"><?php echo $menu_item_child_child->title; ?>
                                                                                                <i class="fa fa-arrow-right"></i>
                                                                                            </li>

                                                                                            <?php
                                                                                            foreach ($main_nav as $menu_item_child_child_child) {
                                                                                                if (is_object($menu_item_child_child_child) && isset($menu_item_child_child_child->ID)) {
                                                                                                    $menu_item_child_child_child_icon = get_post_meta($menu_item_child_child_child->ID, '_menu_item_icon', true);
                                                                                                }
                                                                                                if ($menu_item_child_child_child->menu_item_parent == $menu_item_child_child->ID) {
                                                                                            ?>
                                                                                                    <li>
                                                                                                        <span class="menu-title4">
                                                                                                            <a class="ch btn_mo-ripple" href="<?= $menu_item_child_child_child->url ?>" property="url">
                                                                                                                <?php if ($menu_item_child_child_child_icon) :
                                                                                                                    $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                    if (preg_match($regx_img, $menu_item_child_child_child_icon) == 1) {
                                                                                                                ?>
                                                                                                                        <img src="<?= $menu_item_child_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                    <?php } else { ?>
                                                                                                                        <i class="<?= $menu_item_child_child_child_icon ?> menu-item-icon"></i>
                                                                                                                <?php }
                                                                                                                endif; ?>
                                                                                                                <span><?= $menu_item_child_child_child->title ?></span>

                                                                                                            </a>

                                                                                                        </span>

                                                                                                    </li>
                                                                                            <?php
                                                                                                }
                                                                                            }

                                                                                            echo '<li><a class="menu_mo-all" href="' . $menu_item_child_child->url . '"> همه ' . $menu_item_child_child->title . '</a></li>';

                                                                                            ?>
                                                                                        </ul>
                                                                                    <?php } ?>
                                                                                </li>
                                                                        <?php
                                                                            }
                                                                        }

                                                                        echo '<li><a class="menu_mo-all" href="' . $menu_item_child->url . '"> همه ' . $menu_item_child->title . '</a></li>';

                                                                        ?>
                                                                    </ul>
                                                                <?php } ?>

                                                            </li>
                                                    <?php }
                                                    }

                                                    echo '<li><a class="menu_mo-all" href="' . $menu_item->url . '"> همه ' . $menu_item->title . '</a>';

                                                    ?>
                                                </ul>
                                            <?php } ?>
                                        </li>
                            <?php }
                                }
                            } ?>
                        </ul>
                        <?php
                        if (isset($bakala_options['enable_header_offer']) && $bakala_options['enable_header_offer'] && class_exists('WooCommerce')) {
                            if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
                                $term = get_term($bakala_options['offer_menu_cat']);
                                if ($term) { ?>
                                    <a class="special-offer-link" href="<?php echo get_term_link($term); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                <?php }
                            } elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) { ?>
                                <a class="special-offer-link" href="<?php echo get_permalink($bakala_options['offer_menu_link']); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                        <?php }
                        }
                        ?>
                        <?php if (isset($bakala_options['night_mode']) && $bakala_options['night_mode'] == true) { ?>
                            <div class="dk-switch-container">
                                <span class="night-label"><?php _e('Night mode: ', 'bakala'); ?></span>
                                <div id="night_mode_switcher" class="night_mode_switch dk-switch-wrapper clearfix <?php if ((isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') || (!isset($_COOKIE['night_mode']) && $bakala_options['default_mode'] == 'night')) {
                                                                                                                        echo 'active';
                                                                                                                    } else {
                                                                                                                        echo 'inactive';
                                                                                                                    } ?>">
                                    <span class="dk-switch-enabled"><?php _e('Night', 'bakala'); ?></span>
                                    <span class="dk-switch-disabled"><?php _e('Day', 'bakala'); ?></span>
                                </div>
                            </div>
                        <?php } ?>
                    </nav>
                </div>
                <?php if (!empty($bakala_options['facebook']) || !empty($bakala_options['twitter']) || !empty($bakala_options['googleplus']) || !empty($bakala_options['instagram']) || !empty($bakala_options['youtube']) || !empty($bakala_options['vimeo']) || $bakala_options['other_socials']) { ?>

                    <ul class="socials">
                        <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                            <li>
                                <a target="_blank" href="<?php echo $bakala_options['facebook']; ?>"><i class="icon icon-footer-facebook"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                            <li>
                                <a target="_blank" href="<?php echo $bakala_options['twitter']; ?>"><i class="icon icon-footer-twitter"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                            <li>
                                <a target="_blank" href="<?php echo $bakala_options['googleplus']; ?>"><i class="icon icon-footer-googleplus"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                            <li>
                                <a target="_blank" href="<?php echo $bakala_options['instagram']; ?>"><i class="icon icon-footer-instagram"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                            <li>
                                <a target="_blank" href="<?php echo $bakala_options['youtube']; ?>"><i class="icon icon-footer-aparat"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                            <li>
                                <a target="_blank" href="<?php echo $bakala_options['vimeo']; ?>"><i class="icon icon-footer-telegram"></i></a>
                            </li>
                        <?php } ?>
                        <?php
                        if (is_array($bakala_options['other_socials'])) {
                            foreach ($bakala_options['other_socials'] as $item) {
                        ?>
                                <li>
                                    <a target="_blank" href="<?php echo $item['url']; ?>"><img class="other_socials_img" src="<?php echo $item['image'] ?>"></a>
                                </li>
                        <?php }
                        } ?>
                    </ul>
                <?php } ?>
            </div>
            <div class="modern-header style_two nav-down <?= $bakala_options['sticky_header_mob'] == true ? 'sticky-header' : ''; ?>" id="<?= $bakala_options['sticky_header_mob'] == true ? 'navbar-primary-fixed' : 'navbar-primary'; ?>">
                <div class="modern-header-main">
<?php if (is_front_page()) {
                        $tag = 'h1';
                    } else {
                        $tag = 'div';
                    } ?>
                    <<?php echo $tag; ?> class="logo no-lazy"> <?php
                                                                if (isset($bakala_options['logo-white']) && !empty($bakala_options['logo-white']['url'])) {
                                                                    $logo_href = $bakala_options['logo-white']['url'];
                                                                } else {
                                                                    $logo_href = get_template_directory_uri() . '/vendor/images/logo-white.png';
                                                                }
                                                                ?>
                        <div property="name">
                            <a href="<?php echo home_url('/'); ?>" title="<?php echo get_bloginfo(); ?>" target="_self">
                                <img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>">
                            </a>
                        </div>
                    </<?php echo $tag; ?>>
                    <div class="modern-header-search">
                        <div class="c-ui-input c-ui-input--search"></div>
                        <?php
                        if(empty($bakala_options['search_shortcode'])){
                    $shortcode = do_shortcode('[wcas-search-form]');
                }else{
                    $shortcode = do_shortcode(''.$bakala_options['search_shortcode'],'');
                }
                         echo $shortcode; ?>
                    </div>
                    
                    <div class="modern-header-icons">

                        <?php 
                        if (isset($bakala_options['header_tell']) && $bakala_options['header_tell'] && $bakala_options['bottom_navbar_enable'] == 1) { ?>
                            <a href="<?= !empty($bakala_options['headerinfobar_tell_phone']) ? 'tel:' . $bakala_options['headerinfobar_tell_phone'] : get_permalink($bakala_options['headerinfobar_tell_page']); ?>" class="c-header__faq"></a>
                        <?php } ?>
                    </div>

                </div>


            </div>
            <?php
        } else {
            if (bakala_is_woocommerce_active()) {

                if (is_product()) {
                    if (isset($bakala_options['logo-white']) && !empty($bakala_options['logo-white']['url'])) {
                        $logo_href = $bakala_options['logo-white']['url'];
                    } else {
                        $logo_href = get_template_directory_uri() . '/vendor/images/logo-white.png';
                    }
            ?>
                    <div class="product-more-icons">
                        <ul>
                            <?php
                            if (isset($bakala_options['show_price_change']) && $bakala_options['show_price_change']) {
                                $has_price_changes = get_post_meta(get_the_id(), 'has_price_changes', true);
                                if ($has_price_changes && $has_price_changes == 1) { ?>
                                    <li>
                                        <a href="#" data-bs-toggle="modal" data-bs-target="#bakala_price_change">
                                            <i class="bakala-icon icon-statistics"></i>
                                            <span class="product-more-icon-text"><?php echo __('Price chart', 'bakala'); ?></span>
                                        </a>
                                    </li>
                                <?php }
                            }
                            $white_cat_compare = isset($bakala_options['white_catcompare']) ? $bakala_options['white_catcompare'] : false;
                            $compare_page = isset($bakala_options['compare_page']) ? get_permalink($bakala_options['compare_page']) : false;
                            if ($white_cat_compare && $compare_page) { ?>
                                <li>
                                    <a href="<?php echo $compare_page . '?products=' . get_the_id(); ?>" target="_blank" rel="nofollow">
                                        <i class="bakala-icon icon-compare"></i>
                                        <span class="product-more-icon-text"><?= __('Product comparison', 'bakala') ?></span>
                                    </a>
                                </li>
                            <?php } else {
                                if (function_exists('yith_woocompare_premium_constructor')) {
                                    echo do_shortcode('[yith_compare_button]');
                                }
                            }
                            if (isset($bakala_options['show_share']) && $bakala_options['show_share']) { ?>
                                <li>
                                    <a data-bs-toggle="modal" data-bs-target="#bakala_sharebtn" href="#">
                                        <i class="bakala-icon icon-share"></i>
                                        <span class="product-more-icon-text"><?php echo __('share bakala', 'bakala'); ?></span>
                                    </a>
                                </li>
                            <?php }
                            $product_video_type = get_post_meta(get_the_id(), 'video_type', true);
                            if ($product_video_type && $product_video_type != '') { ?>
                                <li>
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#modal-product-gallery" class="modal-opener">
                                        <i class="bakala-icon icon-product_video"></i>
                                        <span class="product-more-icon-text"><?php echo __('Product video', 'bakala'); ?></span>
                                    </a>
                                </li>
                                <?php }
                            if (isset($bakala_options['show_white_catnotify']) && $bakala_options['show_white_catnotify'] && !$product->is_type('grouped')) {
                                $special_offer = is_special_offer(get_the_id());
                                if (!$special_offer || !$product->is_in_stock() || $product->get_price() == '') {
                                    $stock_subscriber = check_user_stock_notify(get_the_id(), $current_user->ID);
                                    $offer_subscriber = check_user_offer_notify(get_the_id(), $current_user->ID);
                                    if ($stock_subscriber || $offer_subscriber) {
                                        $is_subscriber = true;
                                    } else {
                                        $is_subscriber = false;
                                    }
                                ?>
                                    <li>
                                        <?php if (!is_user_logged_in()) {
                                            if ($bakala_options['popup_login'] == true) :
                                                if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                                    <i class="bakala-icon icon-notify"><?php echo do_shortcode('[dm-login-modal]'); ?></i>
                                                <?php } else { ?>
                                                    <a href="#" data-bs-toggle="modal" data-bs-target="#bakala_login">
                                                        <i class="bakala-icon icon-notify"></i>
                                                        <span class="product-more-icon-text"><?php echo __('Notify me', 'bakala'); ?></span>
                                                    </a>
                                                <?php }
                                            else : ?>
                                                <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>">
                                                    <i class="bakala-icon icon-notify"></i>
                                                    <span class="product-more-icon-text"><?php echo __('Notify me', 'bakala'); ?></span>
                                                </a>
                                            <?php endif;
                                        } else { ?>
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#bakala_product_notify">
                                                <i class="bakala-icon icon-notify <?php if ($is_subscriber) {
                                                                                        echo 'done';
                                                                                    } ?>"></i>
                                                <span class=" product-more-icon-text"><?php echo __('Notify me', 'bakala'); ?></span></a>
                                        <?php } ?>
                                    </li>
                            <?php }
                            }
                            ?>
                        </ul>
                    </div>
                    <div class="header-product modern-header">

                        <div class="right-header-product">
                            <a href="#" id="back-button" class="back-button"><i class="bakala-icon back"></i></a>

                            <?php if ($bakala_options['gallery_style_mobile'] != 'two') { ?>
                                <div class="main">
                                    <label class="collection">
                                        <input type="checkbox">
                                        <div>
                                            <span></span>
                                        </div>
                                    </label>
                                </div>
                            <?php } ?>
                            <?php if (isset($bakala_options['home_button']) && $bakala_options['home_button'] == 1) {
                                if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
                                    $logo_href = $bakala_options['site_header_logo']['url'];
                                } else {
                                    $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                                }
                            ?>
                                <div property="name" class="<?= $bakala_options['home_button_type'] == 'icon' ? 'home-botton' : 'home-logo' ?>">

                                    <a href="<?php echo home_url('/'); ?>" title="<?php echo get_bloginfo(); ?>" target="_self">
                                        <?php if ($bakala_options['home_button_type'] != 'icon') { ?>
                                            <img class="product_menu_logo" src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>">
                                        <?php } else { ?>
                                            <i class="bakala-icon bakala-home-icon"></i>
                                        <?php } ?>

                                    </a>
                                </div>
                            <?php } ?>
                        </div>
                        <div class="left-header-product">
                            <ul class="product-tooltips not-sticky">
                                <?php if ($bakala_options['gallery_style_mobile'] != 'two') { ?>
                                    <li class="bakala-tooltip">
                                        <?php
                                        $cart_count = bakala_get_cart_count();
                                        ?>
                                        <a class="icon icon-cart" href="<?= get_permalink(wc_get_page_id('cart')); ?>"><span class="ar-spender"><?= $cart_count ?></span></a>
                                    </li>

                                    <li class="bakala-tooltip">
                                        <span class="bakala-tooltiptext"><?php echo __('Add to wishlist', 'bakala'); ?></span>
                                        <?php if (!is_user_logged_in()) {
                                            if ($bakala_options['popup_login'] == true) :
                                                if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                                    <a href="?login=true" onclick="jQuery('this').digits_login_modal(jQuery(this));return false;" class="icon icon-love addtowishlist"></a>
                                                <?php } else { ?>
                                                    <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login" class="icon icon-love addtowishlist"></a>
                                                <?php }
                                            else : ?>
                                                <a class="icon icon-love addtowishlist" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"></a>
                                            <?php endif;
                                        } else {
                                            $wishlist = get_user_meta($current_user->ID, 'bakala_wishlist', true);
                                            if (is_array($wishlist) && in_array($product->get_id(), $wishlist)) {
                                                $active = ' active';
                                            } else {
                                                $active = '';
                                            } ?>
                                            <a data-product-id="<?php echo $product->get_id() ?>" class="icon icon-love addtowishlist bakala-wishlist<?php echo $active; ?>"></a>
                                        <?php
                                        } ?>
                                    </li>
                                    <li class="bakala-tooltip">
                                        <a class="icon icon-more" id="showMoreIcons" href="#"></a>
                                    </li>
                                <?php } else { ?>
                                    <li class="bakala-tooltip">
                                        <div class="main">
                                            <label class="collection">
                                                <input type="checkbox">
                                                <div>
                                                    <span></span>
                                                </div>
                                            </label>
                                        </div>
                                    </li>

                                    <li class="bakala-tooltip">
                                        <?php
                                        $cart_count = bakala_get_cart_count();
                                        ?>
                                        <a class="icon icon-cart" href="<?= get_permalink(wc_get_page_id('cart')); ?>"><span class="ar-spender"><?= $cart_count ?></span></a>
                                    </li>
                                <?php } ?>
                            </ul>
                            <ul class="product-tooltips sticky">
                                <li class="bakala-tooltip">
                                    <?php
                                    $cart_count = bakala_get_cart_count();
                                    ?>
                                    <a class="icon icon-cart" href="<?= get_permalink(wc_get_page_id('cart')); ?>"><span class="ar-spender"><?= $cart_count ?></span></a>
                                </li>
                                <li class="bakala-tooltip">

                                    <?php
                                    if (is_user_logged_in()) {
                                    ?>
                                        <a class="icon icon-account" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"></a>
                                        <?php
                                    } else {
                                        if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true) {
                                            if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                                echo do_shortcode('[dm-modal]');
                                            } else {
                                        ?>
                                                <a class="icon icon-account" data-bs-toggle="modal" data-bs-target="#bakala_login" href="#"></a>
                                            <?php
                                            }
                                        } else {
                                            ?>
                                            <a class="icon icon-account" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"></a>
                                    <?php
                                        }
                                    }
                                    ?>
                                </li>
                                <li class="bakala-tooltip">
                                    <a class="icon icon-search" href="#search" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#search_modal"></a>
                                </li>
                            </ul>
                        </div>
                        <div class="off-canvas-panel_mo dialog--close" id="off-canvas_menu">
                            <a href="#" class="close-menu-button"><i class="bakala-icon close"></i></a>
                            <div class="off-canvas-panel-wrapper_mo">
                                <nav id="main-navigation_mo">
                                    <ul class="main-menu">
                                        <?php
                                        if (isset($bakala_options['mobile_menu']) && $bakala_options['mobile_menu']) {
                                            $main_nav_slug = get_term(get_nav_menu_locations()['mobile'], 'nav_menu')->slug;
                                        } else {
                                            $main_nav_slug = get_term(get_nav_menu_locations()['main'], 'nav_menu')->slug;
                                        }
                                        if (get_option('mobi_menu')) {
                                            $main_nav_id = get_option('mobi_menu');
                                        } else {
                                            $main_nav_id = $main_nav_slug;
                                        }
                                        $main_nav = wp_get_nav_menu_items($main_nav_id);
                                        if ($main_nav) {
                                            foreach ($main_nav as $menu_item) {
                                                if (is_object($menu_item) && isset($menu_item->ID)) {
                                                    $menu_item_icon = get_post_meta($menu_item->ID, '_menu_item_icon', true);
                                                }
                                                $childs = 0;
                                                if ($menu_item->menu_item_parent == '0') {
                                                    foreach ($main_nav as $menu_item_child_is) {
                                                        if ($menu_item_child_is->menu_item_parent == $menu_item->ID) {
                                                            $childs = $childs + 1;
                                                        }
                                                    }
                                                    if ($childs > 0) {
                                                        $menu_link = '#popup';
                                                    } else {
                                                        $menu_link = $menu_item->url;
                                                    }
                                        ?>
                                                    <li>
                                                        <span class="menu-title menu-title1">

                                                            <a class="btn_mo-ripple <?= $childs > 0 ? 'haschild' : '' ?> <?php if (implode('', $menu_item->classes)) echo implode('', $menu_item->classes); ?> <?= ($menu_item->url == '#' || $menu_link == '#popup') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" <?php if ($menu_item->target && $menu_link != '#popup') echo 'target="' . $menu_item->target . '" '; ?> <?php if ($menu_item->xfn) echo 'rel="' . $menu_item->xfn . '" '; ?> <?php if ($menu_item->attr_title) echo 'title="' . $menu_item->attr_title . '" '; ?> href="<?php echo $menu_link; ?>">


                                                                <?php if ($menu_item_icon) :
                                                                    $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                    if (preg_match($regx_img, $menu_item_icon) == 1) {
                                                                ?>
                                                                        <img src="<?= $menu_item_icon ?>" class="menu-item-icon" width="18">
                                                                    <?php } else { ?>
                                                                        <i class="<?= $menu_item_icon ?> menu-item-icon"></i>
                                                                <?php }
                                                                endif; ?>
                                                                <span class="pull-right"><?php echo $menu_item->title; ?></span>
                                                                <?php if ($childs > 0) { ?>
                                                                    <i class="fa fa-arrow-left next"></i>
                                                                <?php } ?>
                                                            </a>

                                                        </span>
                                                        <?php if ($childs > 0) { ?>
                                                            <ul class="collapse submenu">
                                                                <li class="go-back"><?php echo $menu_item->title; ?> <i class="fa fa-arrow-right"></i></li>
                                                                <?php
                                                                foreach ($main_nav as $menu_item_child) {
                                                                    if (is_object($menu_item_child) && isset($menu_item_child->ID)) {
                                                                        $menu_item_child_icon = get_post_meta($menu_item_child->ID, '_menu_item_icon', true);
                                                                    }
                                                                    $cchilds = 0;
                                                                    foreach ($main_nav as $menu_item_child_child_is) {

                                                                        if ($menu_item_child_child_is->menu_item_parent == $menu_item_child->ID) {
                                                                            $cchilds = $cchilds + 1;
                                                                        }
                                                                    }
                                                                    if ($cchilds > 0) {
                                                                        $cmenu_link = '#popup';
                                                                    } else {
                                                                        $cmenu_link = $menu_item_child->url;
                                                                    }
                                                                    if ($menu_item_child->menu_item_parent == $menu_item->ID) {
                                                                        $menu_item_child_class = is_array($menu_item_child->classes) ? $menu_item_child->classes : [];
                                                                ?>

                                                                        <li>
                                                                            <span class="menu-title menu-title2">
                                                                                <a class="btn_mo-ripple <?= $cchilds > 0 ? 'haschild' : '' ?> <?= ($menu_item_child->url == '#') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" href="<?php echo $cmenu_link; ?>" <?php if ($menu_item_child->target && $cmenu_link != '#popup') echo 'target="' . $menu_item_child->target . '" '; ?> <?php if ($menu_item_child->xfn) echo 'rel="' . $menu_item_child->xfn . '" '; ?> <?php if ($menu_item_child->attr_title) echo 'title="' . $menu_item_child->attr_title . '" '; ?>>

                                                                                    <?php if ($menu_item_child_icon) :
                                                                                        $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                        if (preg_match($regx_img, $menu_item_child_icon) == 1) {
                                                                                    ?>
                                                                                            <img src="<?= $menu_item_child_icon ?>" class="menu-item-icon" width="18">
                                                                                        <?php } else { ?>
                                                                                            <i class="<?= $menu_item_child_icon ?> menu-item-icon"></i>
                                                                                    <?php }
                                                                                    endif; ?>
                                                                                    <span class="pull-right"><?php echo $menu_item_child->title; ?></span>
                                                                                    <?php if ($cchilds > 0) { ?>
                                                                                        <i class="fa fa-arrow-left next"></i>
                                                                                    <?php } ?>
                                                                                </a>

                                                                            </span>
                                                                            <?php if ($cchilds > 0) { ?>
                                                                                <ul class="collapse submenu">
                                                                                    <li class="go-back"><?php echo $menu_item_child->title; ?>
                                                                                        <i class="fa fa-arrow-right"></i>
                                                                                    </li>

                                                                                    <?php
                                                                                    foreach ($main_nav as $menu_item_child_child) {
                                                                                        if (is_object($menu_item_child_child) && isset($menu_item_child_child->ID)) {
                                                                                            $menu_item_child_child_icon = get_post_meta($menu_item_child_child->ID, '_menu_item_icon', true);
                                                                                        }
                                                                                        if ($menu_item_child_child->menu_item_parent == $menu_item_child->ID) {
                                                                                            $ccchilds = 0;
                                                                                            foreach ($main_nav as $menu_item_child_child_child_is) {

                                                                                                if ($menu_item_child_child_child_is->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                    $ccchilds = $ccchilds + 1;
                                                                                                }
                                                                                            }
                                                                                    ?>
                                                                                            <li>
                                                                                                <span class="menu-title menu-title3">
                                                                                                    <a class="ch btn_mo-ripple <?= $menu_item_child_child->url == '#' ? 'next' : '' ?> <?= $ccchilds > 0 ? 'haschild' : '' ?>" href="<?= $menu_item_child_child->url ?>" property="url">
                                                                                                        <?php if ($menu_item_child_child_icon) :
                                                                                                            $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                            if (preg_match($regx_img, $menu_item_child_child_icon) == 1) {
                                                                                                        ?>
                                                                                                                <img src="<?= $menu_item_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                            <?php } else { ?>
                                                                                                                <i class="<?= $menu_item_child_child_icon ?> menu-item-icon"></i>
                                                                                                        <?php }
                                                                                                        endif; ?>
                                                                                                        <span><?= $menu_item_child_child->title ?></span>
                                                                                                        <?php if ($ccchilds > 0) { ?>
                                                                                                            <i class="fa fa-arrow-left next"></i>
                                                                                                        <?php } ?>
                                                                                                    </a>


                                                                                                </span>
                                                                                                <?php if ($ccchilds > 0) { ?>
                                                                                                    <ul class="collapse submenu">
                                                                                                        <li class="go-back"><?php echo $menu_item_child_child->title; ?>
                                                                                                            <i class="fa fa-arrow-right"></i>
                                                                                                        </li>

                                                                                                        <?php
                                                                                                        foreach ($main_nav as $menu_item_child_child_child) {
                                                                                                            if (is_object($menu_item_child_child_child) && isset($menu_item_child_child_child->ID)) {
                                                                                                                $menu_item_child_child_child_icon = get_post_meta($menu_item_child_child_child->ID, '_menu_item_icon', true);
                                                                                                            }
                                                                                                            if ($menu_item_child_child_child->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                        ?>
                                                                                                                <li>
                                                                                                                    <span class="menu-title4">
                                                                                                                        <a class="ch btn_mo-ripple" href="<?= $menu_item_child_child_child->url ?>" property="url">
                                                                                                                            <?php if ($menu_item_child_child_child_icon) :
                                                                                                                                $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                                if (preg_match($regx_img, $menu_item_child_child_child_icon) == 1) {
                                                                                                                            ?>
                                                                                                                                    <img src="<?= $menu_item_child_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                                <?php } else { ?>
                                                                                                                                    <i class="<?= $menu_item_child_child_child_icon ?> menu-item-icon"></i>
                                                                                                                            <?php }
                                                                                                                            endif; ?>
                                                                                                                            <span><?= $menu_item_child_child_child->title ?></span>

                                                                                                                        </a>

                                                                                                                    </span>

                                                                                                                </li>
                                                                                                        <?php
                                                                                                            }
                                                                                                        }

                                                                                                        echo '<li><a class="menu_mo-all" href="' . $menu_item_child_child->url . '"> همه ' . $menu_item_child_child->title . '</a></li>';

                                                                                                        ?>
                                                                                                    </ul>
                                                                                                <?php } ?>
                                                                                            </li>
                                                                                    <?php
                                                                                        }
                                                                                    }

                                                                                    echo '<li><a class="menu_mo-all" href="' . $menu_item_child->url . '"> همه ' . $menu_item_child->title . '</a></li>';

                                                                                    ?>
                                                                                </ul>
                                                                            <?php } ?>

                                                                        </li>
                                                                <?php }
                                                                }

                                                                echo '<li><a class="menu_mo-all" href="' . $menu_item->url . '"> همه ' . $menu_item->title . '</a>';

                                                                ?>
                                                            </ul>
                                                        <?php } ?>
                                                    </li>
                                        <?php }
                                            }
                                        } ?>
                                    </ul>
                                    <?php
                                    if (isset($bakala_options['enable_header_offer']) && $bakala_options['enable_header_offer'] && class_exists('WooCommerce')) {
                                        if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
                                            $term = get_term($bakala_options['offer_menu_cat']);
                                            if ($term) { ?>
                                                <a class="special-offer-link" href="<?php echo get_term_link($term); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                            <?php }
                                        } elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) { ?>
                                            <a class="special-offer-link" href="<?php echo get_permalink($bakala_options['offer_menu_link']); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                    <?php }
                                    }
                                    ?>
                                    <?php if (isset($bakala_options['night_mode']) && $bakala_options['night_mode'] == true) { ?>
                                        <div class="dk-switch-container">
                                            <span class="night-label"><?php _e('Night mode: ', 'bakala'); ?></span>
                                            <div id="night_mode_switcher" class="night_mode_switch dk-switch-wrapper clearfix <?php if ((isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') || (!isset($_COOKIE['night_mode']) && $bakala_options['default_mode'] == 'night')) {
                                                                                                                                    echo 'active';
                                                                                                                                } else {
                                                                                                                                    echo 'inactive';
                                                                                                                                } ?>">
                                                <span class="dk-switch-enabled"><?php _e('Night', 'bakala'); ?></span>
                                                <span class="dk-switch-disabled"><?php _e('Day', 'bakala'); ?></span>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </nav>
                            </div>
                            <?php if (!empty($bakala_options['facebook']) || !empty($bakala_options['twitter']) || !empty($bakala_options['googleplus']) || !empty($bakala_options['instagram']) || !empty($bakala_options['youtube']) || !empty($bakala_options['vimeo']) || $bakala_options['other_socials']) { ?>
                                <ul class="socials">
                                    <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                        <li>
                                            <a target="_blank" href="<?php echo $bakala_options['facebook']; ?>"><i class="icon icon-footer-facebook"></i></a>
                                        </li>
                                    <?php } ?>
                                    <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                        <li>
                                            <a target="_blank" href="<?php echo $bakala_options['twitter']; ?>"><i class="icon icon-footer-twitter"></i></a>
                                        </li>
                                    <?php } ?>
                                    <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                        <li>
                                            <a target="_blank" href="<?php echo $bakala_options['googleplus']; ?>"><i class="icon icon-footer-googleplus"></i></a>
                                        </li>
                                    <?php } ?>
                                    <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                        <li>
                                            <a target="_blank" href="<?php echo $bakala_options['instagram']; ?>"><i class="icon icon-footer-instagram"></i></a>
                                        </li>
                                    <?php } ?>
                                    <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                        <li>
                                            <a target="_blank" href="<?php echo $bakala_options['youtube']; ?>"><i class="icon icon-footer-aparat"></i></a>
                                        </li>
                                    <?php } ?>
                                    <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                        <li>
                                            <a target="_blank" href="<?php echo $bakala_options['vimeo']; ?>"><i class="icon icon-footer-telegram"></i></a>
                                        </li>
                                    <?php }
                                    ?>
                                    <?php
                                    if (is_array($bakala_options['other_socials'])) {
                                        foreach ($bakala_options['other_socials'] as $item) {
                                            if (!empty($item['image'])) {
                                    ?>
                                                <li>
                                                    <a target="_blank" href="<?php echo $item['url']; ?>"><img class="other_socials_img" src="<?php echo $item['image'] ?>"></a>
                                                </li>
                                    <?php }
                                        }
                                    } ?>
                                </ul>
                            <?php } ?>
                        </div>
                    </div>
                    <?php if ($bakala_options['modern_header_mobile_search'] == 1) { ?>
                        <div class="modern-header-search">


                            <div class="c-ui-input c-ui-input--search"></div>
                            <?php if(empty($bakala_options['search_shortcode'])){
                    $shortcode = do_shortcode('[wcas-search-form]');
                }else{
                    $shortcode = do_shortcode(''.$bakala_options['search_shortcode'],'');
                }
                         echo $shortcode; ?>

                        </div>
                    <?php } ?>
                <?php
                } else {
                ?>
                    <div class="off-canvas-panel_mo dialog--close" id="off-canvas_menu">
                        <a href="#" class="close-menu-button"><i class="bakala-icon close"></i></a>
                        <div class="off-canvas-panel-wrapper_mo">
                            <nav id="main-navigation_mo">
                                <ul class="main-menu">

                                    <?php
                                    if (isset($bakala_options['mobile_menu']) && $bakala_options['mobile_menu'] && isset(get_nav_menu_locations()['mobile'])) {
                                        $main_nav_slug = get_term(get_nav_menu_locations()['mobile'], 'nav_menu')->slug;
                                    } else {
                                        $main_nav_slug = get_term(get_nav_menu_locations()['main'], 'nav_menu')->slug;
                                    }
                                    if (get_option('mobi_menu')) {
                                        $main_nav_id = get_option('mobi_menu');
                                    } else {
                                        $main_nav_id = $main_nav_slug;
                                    }
                                    $main_nav = wp_get_nav_menu_items($main_nav_id);
                                    if ($main_nav) {
                                        foreach ($main_nav as $menu_item) {
                                            if (is_object($menu_item) && isset($menu_item->ID)) {
                                                $menu_item_icon = get_post_meta($menu_item->ID, '_menu_item_icon', true);
                                            }
                                            $childs = 0;
                                            if ($menu_item->menu_item_parent == '0') {
                                                foreach ($main_nav as $menu_item_child_is) {
                                                    if ($menu_item_child_is->menu_item_parent == $menu_item->ID) {
                                                        $childs = $childs + 1;
                                                    }
                                                }
                                                if ($childs > 0) {
                                                    $menu_link = '#popup';
                                                } else {
                                                    $menu_link = $menu_item->url;
                                                }
                                    ?>
                                                <li>
                                                    <span class="menu-title menu-title1">

                                                        <a class="btn_mo-ripple <?= $childs > 0 ? 'haschild' : '' ?> <?php if (implode('', $menu_item->classes)) echo implode('', $menu_item->classes); ?> <?= ($menu_item->url == '#' || $menu_link == '#popup') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" <?php if ($menu_item->target && $menu_link != '#popup') echo 'target="' . $menu_item->target . '" '; ?> <?php if ($menu_item->xfn) echo 'rel="' . $menu_item->xfn . '" '; ?> <?php if ($menu_item->attr_title) echo 'title="' . $menu_item->attr_title . '" '; ?> href="<?php echo $menu_link; ?>">


                                                            <?php if ($menu_item_icon) :
                                                                $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                if (preg_match($regx_img, $menu_item_icon) == 1) {
                                                            ?>
                                                                    <img src="<?= $menu_item_icon ?>" class="menu-item-icon" width="18">
                                                                <?php } else { ?>
                                                                    <i class="<?= $menu_item_icon ?> menu-item-icon"></i>
                                                            <?php }
                                                            endif; ?>
                                                            <span class="pull-right"><?php echo $menu_item->title; ?></span>
                                                            <?php if ($childs > 0) { ?>
                                                                <i class="fa fa-arrow-left next"></i>
                                                            <?php } ?>
                                                        </a>

                                                    </span>
                                                    <?php if ($childs > 0) { ?>
                                                        <ul class="collapse submenu">
                                                            <li class="go-back"><?php echo $menu_item->title; ?> <i class="fa fa-arrow-right"></i></li>
                                                            <?php
                                                            foreach ($main_nav as $menu_item_child) {
                                                                if (is_object($menu_item_child) && isset($menu_item_child->ID)) {
                                                                    $menu_item_child_icon = get_post_meta($menu_item_child->ID, '_menu_item_icon', true);
                                                                }
                                                                $cchilds = 0;
                                                                foreach ($main_nav as $menu_item_child_child_is) {

                                                                    if ($menu_item_child_child_is->menu_item_parent == $menu_item_child->ID) {
                                                                        $cchilds = $cchilds + 1;
                                                                    }
                                                                }
                                                                if ($cchilds > 0) {
                                                                    $cmenu_link = '#popup';
                                                                } else {
                                                                    $cmenu_link = $menu_item_child->url;
                                                                }
                                                                if ($menu_item_child->menu_item_parent == $menu_item->ID) { ?>

                                                                    <li>
                                                                        <span class="menu-title menu-title2">
                                                                            <a class="btn_mo-ripple <?= $cchilds > 0 ? 'haschild' : '' ?> <?php if (implode(' ', $menu_item_child->classes)) echo implode(' ', $menu_item_child->classes); ?> <?= ($menu_item_child->url == '#') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" href="<?php echo $cmenu_link; ?>" <?php if ($menu_item_child->target && $cmenu_link != '#popup') echo 'target="' . $menu_item_child->target . '" '; ?> <?php if ($menu_item_child->xfn) echo 'rel="' . $menu_item_child->xfn . '" '; ?> <?php if ($menu_item_child->attr_title) echo 'title="' . $menu_item_child->attr_title . '" '; ?>>

                                                                                <?php if ($menu_item_child_icon) :
                                                                                    $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                    if (preg_match($regx_img, $menu_item_child_icon) == 1) {
                                                                                ?>
                                                                                        <img src="<?= $menu_item_child_icon ?>" class="menu-item-icon" width="18">
                                                                                    <?php } else { ?>
                                                                                        <i class="<?= $menu_item_child_icon ?> menu-item-icon"></i>
                                                                                <?php }
                                                                                endif; ?>
                                                                                <span class="pull-right"><?php echo $menu_item_child->title; ?></span>
                                                                                <?php if ($cchilds > 0) { ?>
                                                                                    <i class="fa fa-arrow-left next"></i>
                                                                                <?php } ?>
                                                                            </a>

                                                                        </span>
                                                                        <?php if ($cchilds > 0) { ?>
                                                                            <ul class="collapse submenu">
                                                                                <li class="go-back"><?php echo $menu_item_child->title; ?>
                                                                                    <i class="fa fa-arrow-right"></i>
                                                                                </li>

                                                                                <?php
                                                                                foreach ($main_nav as $menu_item_child_child) {
                                                                                    if (is_object($menu_item_child_child) && isset($menu_item_child_child->ID)) {
                                                                                        $menu_item_child_child_icon = get_post_meta($menu_item_child_child->ID, '_menu_item_icon', true);
                                                                                    }
                                                                                    if ($menu_item_child_child->menu_item_parent == $menu_item_child->ID) {
                                                                                        $ccchilds = 0;
                                                                                        foreach ($main_nav as $menu_item_child_child_child_is) {

                                                                                            if ($menu_item_child_child_child_is->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                $ccchilds = $ccchilds + 1;
                                                                                            }
                                                                                        }
                                                                                ?>
                                                                                        <li>
                                                                                            <span class="menu-title menu-title3">
                                                                                                <a class="ch btn_mo-ripple <?= $menu_item_child_child->url == '#' ? 'next' : '' ?> <?= $ccchilds > 0 ? 'haschild' : '' ?>" href="<?= $menu_item_child_child->url ?>" property="url">
                                                                                                    <?php if ($menu_item_child_child_icon) :
                                                                                                        $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                        if (preg_match($regx_img, $menu_item_child_child_icon) == 1) {
                                                                                                    ?>
                                                                                                            <img src="<?= $menu_item_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                        <?php } else { ?>
                                                                                                            <i class="<?= $menu_item_child_child_icon ?> menu-item-icon"></i>
                                                                                                    <?php }
                                                                                                    endif; ?>
                                                                                                    <span><?= $menu_item_child_child->title ?></span>
                                                                                                    <?php if ($ccchilds > 0) { ?>
                                                                                                        <i class="fa fa-arrow-left next"></i>
                                                                                                    <?php } ?>
                                                                                                </a>


                                                                                            </span>
                                                                                            <?php if ($ccchilds > 0) { ?>
                                                                                                <ul class="collapse submenu">
                                                                                                    <li class="go-back"><?php echo $menu_item_child_child->title; ?>
                                                                                                        <i class="fa fa-arrow-right"></i>
                                                                                                    </li>

                                                                                                    <?php
                                                                                                    foreach ($main_nav as $menu_item_child_child_child) {
                                                                                                        if (is_object($menu_item_child_child_child) && isset($menu_item_child_child_child->ID)) {
                                                                                                            $menu_item_child_child_child_icon = get_post_meta($menu_item_child_child_child->ID, '_menu_item_icon', true);
                                                                                                        }
                                                                                                        if ($menu_item_child_child_child->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                    ?>
                                                                                                            <li>
                                                                                                                <span class="menu-title4">
                                                                                                                    <a class="ch btn_mo-ripple" href="<?= $menu_item_child_child_child->url ?>" property="url">
                                                                                                                        <?php if ($menu_item_child_child_child_icon) :
                                                                                                                            $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                            if (preg_match($regx_img, $menu_item_child_child_child_icon) == 1) {
                                                                                                                        ?>
                                                                                                                                <img src="<?= $menu_item_child_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                            <?php } else { ?>
                                                                                                                                <i class="<?= $menu_item_child_child_child_icon ?> menu-item-icon"></i>
                                                                                                                        <?php }
                                                                                                                        endif; ?>
                                                                                                                        <span><?= $menu_item_child_child_child->title ?></span>

                                                                                                                    </a>

                                                                                                                </span>

                                                                                                            </li>
                                                                                                    <?php
                                                                                                        }
                                                                                                    }

                                                                                                    echo '<li><a class="menu_mo-all" href="' . $menu_item_child_child->url . '"> همه ' . $menu_item_child_child->title . '</a></li>';

                                                                                                    ?>
                                                                                                </ul>
                                                                                            <?php } ?>
                                                                                        </li>
                                                                                <?php
                                                                                    }
                                                                                }

                                                                                echo '<li><a class="menu_mo-all" href="' . $menu_item_child->url . '"> همه ' . $menu_item_child->title . '</a></li>';

                                                                                ?>
                                                                            </ul>
                                                                        <?php } ?>

                                                                    </li>
                                                            <?php }
                                                            }

                                                            echo '<li><a class="menu_mo-all" href="' . $menu_item->url . '"> همه ' . $menu_item->title . '</a>';

                                                            ?>
                                                        </ul>
                                                    <?php } ?>
                                                </li>
                                    <?php }
                                        }
                                    } ?>
                                </ul>
                                <?php
                                if (isset($bakala_options['enable_header_offer']) && $bakala_options['enable_header_offer'] && class_exists('WooCommerce')) {
                                    if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
                                        $term = get_term($bakala_options['offer_menu_cat']);
                                        if ($term) { ?>
                                            <a class="special-offer-link" href="<?php echo get_term_link($term); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                        <?php }
                                    } elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) { ?>
                                        <a class="special-offer-link" href="<?php echo get_permalink($bakala_options['offer_menu_link']); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                <?php }
                                }
                                ?>
                                <?php if (isset($bakala_options['night_mode']) && $bakala_options['night_mode'] == true) { ?>
                                    <div class="dk-switch-container">
                                        <span class="night-label"><?php _e('Night mode: ', 'bakala'); ?></span>
                                        <div id="night_mode_switcher" class="night_mode_switch dk-switch-wrapper clearfix <?php if ((isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') || (!isset($_COOKIE['night_mode']) && $bakala_options['default_mode'] == 'night')) {
                                                                                                                                echo 'active';
                                                                                                                            } else {
                                                                                                                                echo 'inactive';
                                                                                                                            } ?>">
                                            <span class="dk-switch-enabled"><?php _e('Night', 'bakala'); ?></span>
                                            <span class="dk-switch-disabled"><?php _e('Day', 'bakala'); ?></span>
                                        </div>
                                    </div>
                                <?php } ?>
                            </nav>
                        </div>
                        <?php if (!empty($bakala_options['facebook']) || !empty($bakala_options['twitter']) || !empty($bakala_options['googleplus']) || !empty($bakala_options['instagram']) || !empty($bakala_options['youtube']) || !empty($bakala_options['vimeo']) || $bakala_options['other_socials']) { ?>

                            <ul class="socials">
                                <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['facebook']; ?>"><i class="icon icon-footer-facebook"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['twitter']; ?>"><i class="icon icon-footer-twitter"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['googleplus']; ?>"><i class="icon icon-footer-googleplus"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['instagram']; ?>"><i class="icon icon-footer-instagram"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['youtube']; ?>"><i class="icon icon-footer-aparat"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $bakala_options['vimeo']; ?>"><i class="icon icon-footer-telegram"></i></a>
                                    </li>
                                <?php } ?>
                                <?php
                                if (is_array($bakala_options['other_socials'])) {
                                    foreach ($bakala_options['other_socials'] as $item) {
                                ?>
                                        <li>
                                            <a target="_blank" href="<?php echo $item['url']; ?>"><img class="other_socials_img" src="<?php echo $item['image'] ?>"></a>
                                        </li>
                                <?php }
                                }

                                ?>
                            </ul>
                        <?php } ?>
                    </div>
                    <div class="modern-header nav-down <?= $bakala_options['sticky_header_mob'] == true ? 'sticky-header' : ''; ?>" id="<?= $bakala_options['sticky_header_mob'] == true ? 'navbar-primary-fixed' : 'navbar-primary'; ?>">
                        <div class="modern-header-main">
                            <div class="panel-handler col-3 p-0" data-type="popup-handler" id="off-canvas_menu_icon">
                                <div id="icon-menu" class="icon-menu-handler-svg">
                                    <div class="c-header__burger">
                                        <p class="divider-menu"></p>
                                    </div>
                                </div>

                            </div>
                            <?php if (is_front_page()) {
                                $tag = 'h1';
                            } else {
                                $tag = 'div';
                            } ?>
                            <<?php echo $tag; ?> class="logo no-lazy"> <?php
                                                                        if (isset($bakala_options['logo-white']) && !empty($bakala_options['logo-white']['url'])) {
                                                                            $logo_href = $bakala_options['logo-white']['url'];
                                                                        } else {
                                                                            $logo_href = get_template_directory_uri() . '/vendor/images/logo-white.png';
                                                                        }
                                                                        ?>
                                <div property="name">
                                    <a href="<?php echo home_url('/'); ?>" title="<?php echo get_bloginfo(); ?>" target="_self">
                                        <img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>">
                                    </a>
                                </div>
                            </<?php echo $tag; ?>>
                            <div class="modern-header-icons">
                                <?php
                                if (isset($bakala_options['enable_location']) && $bakala_options['enable_location'] == true) {
                                ?>
                                    <div class="toolbar clearfix">
                                        <div class="header-location site-location">
                                            <a href="#">
                                                <span class="location-description"><?php esc_html_e('Your Location', 'bakala'); ?></span>
                                                <?php if (bakala_location() == 'all') { ?>
                                                    <div class="current-location"><?php esc_html_e('Select a Location to filter', 'bakala'); ?></div>
                                                <?php } else { ?>
                                                    <div class="current-location activated"><?php echo esc_html(bakala_location()); ?></div>
                                                <?php } ?>
                                            </a>
                                        </div>
                                    </div>
                                <?php
                                }
                                ?>
                                <?php if (isset($bakala_options['header_tell']) && $bakala_options['header_tell'] && $bakala_options['bottom_navbar_enable'] == 1 && $bakala_options['enable_location'] == false) { ?>
                                    <a href="<?= !empty($bakala_options['headerinfobar_tell_phone']) ? 'tel:' . $bakala_options['headerinfobar_tell_phone'] : get_permalink($bakala_options['headerinfobar_tell_page']); ?>" class="c-header__faq"></a>
                                <?php } ?>
                            </div>

                        </div>
                        <?php if ($bakala_options['modern_header_mobile_search'] == 1) { ?>
                            <div class="c-ui-input c-ui-input--search"></div>
                            <?php if(empty($bakala_options['search_shortcode'])){
                    $shortcode = do_shortcode('[wcas-search-form]');
                }else{
                    $shortcode = do_shortcode(''.$bakala_options['search_shortcode'],'');
                }
                         echo $shortcode; ?>
                        <?php } ?>
                    </div>

                <?php
                }
            } else {
                ?>
                <div class="off-canvas-panel_mo dialog--close" id="off-canvas_menu">
                    <a href="#" class="close-menu-button"><i class="bakala-icon close"></i></a>
                    <div class="off-canvas-panel-wrapper_mo">
                        <nav id="main-navigation_mo">
                            <ul class="main-menu">
                                <?php
                                if (isset($bakala_options['mobile_menu']) && $bakala_options['mobile_menu']) {
                                    $main_nav_slug = get_term(get_nav_menu_locations()['mobile'], 'nav_menu')->slug;
                                } else {
                                    $main_nav_slug = get_term(get_nav_menu_locations()['main'], 'nav_menu')->slug;
                                }
                                if (get_option('mobi_menu')) {
                                    $main_nav_id = get_option('mobi_menu');
                                } else {
                                    $main_nav_id = $main_nav_slug;
                                }
                                $main_nav = wp_get_nav_menu_items($main_nav_id);
                                if ($main_nav) {
                                    foreach ($main_nav as $menu_item) {
                                        if (is_object($menu_item) && isset($menu_item->ID)) {
                                            $menu_item_icon = get_post_meta($menu_item->ID, '_menu_item_icon', true);
                                        }
                                        $childs = 0;
                                        if ($menu_item->menu_item_parent == '0') {
                                            foreach ($main_nav as $menu_item_child_is) {
                                                if ($menu_item_child_is->menu_item_parent == $menu_item->ID) {
                                                    $childs = $childs + 1;
                                                }
                                            }
                                            if ($childs > 0) {
                                                $menu_link = '#popup';
                                            } else {
                                                $menu_link = $menu_item->url;
                                            }
                                ?>
                                            <li>
                                                <span class="menu-title menu-title1">

                                                    <a class="btn_mo-ripple <?= $childs > 0 ? 'haschild' : '' ?> <?php if (implode('', $menu_item->classes)) echo implode('', $menu_item->classes); ?> <?= ($menu_item->url == '#' || $menu_link == '#popup') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" <?php if ($menu_item->target && $menu_link != '#popup') echo 'target="' . $menu_item->target . '" '; ?> <?php if ($menu_item->xfn) echo 'rel="' . $menu_item->xfn . '" '; ?> <?php if ($menu_item->attr_title) echo 'title="' . $menu_item->attr_title . '" '; ?> href="<?php echo $menu_link; ?>">


                                                        <?php if ($menu_item_icon) :
                                                            $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                            if (preg_match($regx_img, $menu_item_icon) == 1) {
                                                        ?>
                                                                <img src="<?= $menu_item_icon ?>" class="menu-item-icon" width="18">
                                                            <?php } else { ?>
                                                                <i class="<?= $menu_item_icon ?> menu-item-icon"></i>
                                                        <?php }
                                                        endif; ?>
                                                        <span class="pull-right"><?php echo $menu_item->title; ?></span>
                                                        <?php if ($childs > 0) { ?>
                                                            <i class="fa fa-arrow-left next"></i>
                                                        <?php } ?>
                                                    </a>

                                                </span>
                                                <?php if ($childs > 0) { ?>
                                                    <ul class="collapse submenu">
                                                        <li class="go-back"><?php echo $menu_item->title; ?> <i class="fa fa-arrow-right"></i></li>
                                                        <?php
                                                        foreach ($main_nav as $menu_item_child) {
                                                            if (is_object($menu_item_child) && isset($menu_item_child->ID)) {
                                                                $menu_item_child_icon = get_post_meta($menu_item_child->ID, '_menu_item_icon', true);
                                                            }
                                                            $cchilds = 0;
                                                            foreach ($main_nav as $menu_item_child_child_is) {

                                                                if ($menu_item_child_child_is->menu_item_parent == $menu_item_child->ID) {
                                                                    $cchilds = $cchilds + 1;
                                                                }
                                                            }
                                                            if ($cchilds > 0) {
                                                                $cmenu_link = '#popup';
                                                            } else {
                                                                $cmenu_link = $menu_item_child->url;
                                                            }
                                                            if ($menu_item_child->menu_item_parent == $menu_item->ID) { ?>

                                                                <li>
                                                                    <span class="menu-title menu-title2">
                                                                        <a class="btn_mo-ripple <?= $cchilds > 0 ? 'haschild' : '' ?> <?php if (implode(' ', $menu_item_child->classes)) echo implode(' ', $menu_item_child->classes); ?> <?= ($menu_item_child->url == '#') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" href="<?php echo $cmenu_link; ?>" <?php if ($menu_item_child->target && $cmenu_link != '#popup') echo 'target="' . $menu_item_child->target . '" '; ?> <?php if ($menu_item_child->xfn) echo 'rel="' . $menu_item_child->xfn . '" '; ?> <?php if ($menu_item_child->attr_title) echo 'title="' . $menu_item_child->attr_title . '" '; ?>>

                                                                            <?php if ($menu_item_child_icon) :
                                                                                $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                if (preg_match($regx_img, $menu_item_child_icon) == 1) {
                                                                            ?>
                                                                                    <img src="<?= $menu_item_child_icon ?>" class="menu-item-icon" width="18">
                                                                                <?php } else { ?>
                                                                                    <i class="<?= $menu_item_child_icon ?> menu-item-icon"></i>
                                                                            <?php }
                                                                            endif; ?>
                                                                            <span class="pull-right"><?php echo $menu_item_child->title; ?></span>
                                                                            <?php if ($cchilds > 0) { ?>
                                                                                <i class="fa fa-arrow-left next"></i>
                                                                            <?php } ?>
                                                                        </a>

                                                                    </span>
                                                                    <?php if ($cchilds > 0) { ?>
                                                                        <ul class="collapse submenu">
                                                                            <li class="go-back"><?php echo $menu_item_child->title; ?>
                                                                                <i class="fa fa-arrow-right"></i>
                                                                            </li>

                                                                            <?php
                                                                            foreach ($main_nav as $menu_item_child_child) {
                                                                                if (is_object($menu_item_child_child) && isset($menu_item_child_child->ID)) {
                                                                                    $menu_item_child_child_icon = get_post_meta($menu_item_child_child->ID, '_menu_item_icon', true);
                                                                                }
                                                                                if ($menu_item_child_child->menu_item_parent == $menu_item_child->ID) {
                                                                                    $ccchilds = 0;
                                                                                    foreach ($main_nav as $menu_item_child_child_child_is) {

                                                                                        if ($menu_item_child_child_child_is->menu_item_parent == $menu_item_child_child->ID) {
                                                                                            $ccchilds = $ccchilds + 1;
                                                                                        }
                                                                                    }
                                                                            ?>
                                                                                    <li>
                                                                                        <span class="menu-title menu-title3">
                                                                                            <a class="ch btn_mo-ripple <?= $menu_item_child_child->url == '#' ? 'next' : '' ?> <?= $ccchilds > 0 ? 'haschild' : '' ?>" href="<?= $menu_item_child_child->url ?>" property="url">
                                                                                                <?php if ($menu_item_child_child_icon) :
                                                                                                    $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                    if (preg_match($regx_img, $menu_item_child_child_icon) == 1) {
                                                                                                ?>
                                                                                                        <img src="<?= $menu_item_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                    <?php } else { ?>
                                                                                                        <i class="<?= $menu_item_child_child_icon ?> menu-item-icon"></i>
                                                                                                <?php }
                                                                                                endif; ?>
                                                                                                <span><?= $menu_item_child_child->title ?></span>
                                                                                                <?php if ($ccchilds > 0) { ?>
                                                                                                    <i class="fa fa-arrow-left next"></i>
                                                                                                <?php } ?>
                                                                                            </a>


                                                                                        </span>
                                                                                        <?php if ($ccchilds > 0) { ?>
                                                                                            <ul class="collapse submenu">
                                                                                                <li class="go-back"><?php echo $menu_item_child_child->title; ?>
                                                                                                    <i class="fa fa-arrow-right"></i>
                                                                                                </li>

                                                                                                <?php
                                                                                                foreach ($main_nav as $menu_item_child_child_child) {
                                                                                                    if (is_object($menu_item_child_child_child) && isset($menu_item_child_child_child->ID)) {
                                                                                                        $menu_item_child_child_child_icon = get_post_meta($menu_item_child_child_child->ID, '_menu_item_icon', true);
                                                                                                    }
                                                                                                    if ($menu_item_child_child_child->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                ?>
                                                                                                        <li>
                                                                                                            <span class="menu-title4">
                                                                                                                <a class="ch btn_mo-ripple" href="<?= $menu_item_child_child_child->url ?>" property="url">
                                                                                                                    <?php if ($menu_item_child_child_child_icon) :
                                                                                                                        $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                        if (preg_match($regx_img, $menu_item_child_child_child_icon) == 1) {
                                                                                                                    ?>
                                                                                                                            <img src="<?= $menu_item_child_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                        <?php } else { ?>
                                                                                                                            <i class="<?= $menu_item_child_child_child_icon ?> menu-item-icon"></i>
                                                                                                                    <?php }
                                                                                                                    endif; ?>
                                                                                                                    <span><?= $menu_item_child_child_child->title ?></span>

                                                                                                                </a>

                                                                                                            </span>

                                                                                                        </li>
                                                                                                <?php
                                                                                                    }
                                                                                                }

                                                                                                echo '<li><a class="menu_mo-all" href="' . $menu_item_child_child->url . '"> همه ' . $menu_item_child_child->title . '</a></li>';

                                                                                                ?>
                                                                                            </ul>
                                                                                        <?php } ?>
                                                                                    </li>
                                                                            <?php
                                                                                }
                                                                            }

                                                                            echo '<li><a class="menu_mo-all" href="' . $menu_item_child->url . '"> همه ' . $menu_item_child->title . '</a></li>';

                                                                            ?>
                                                                        </ul>
                                                                    <?php } ?>

                                                                </li>
                                                        <?php }
                                                        }

                                                        echo '<li><a class="menu_mo-all" href="' . $menu_item->url . '"> همه ' . $menu_item->title . '</a>';

                                                        ?>
                                                    </ul>
                                                <?php } ?>
                                            </li>
                                <?php }
                                    }
                                } ?>
                            </ul>
                            <?php
                            if (isset($bakala_options['enable_header_offer']) && $bakala_options['enable_header_offer'] && class_exists('WooCommerce')) {
                                if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
                                    $term = get_term($bakala_options['offer_menu_cat']);
                                    if ($term) { ?>
                                        <a class="special-offer-link" href="<?php echo get_term_link($term); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                    <?php }
                                } elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) { ?>
                                    <a class="special-offer-link" href="<?php echo get_permalink($bakala_options['offer_menu_link']); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                            <?php }
                            }
                            ?>
                            <?php if (isset($bakala_options['night_mode']) && $bakala_options['night_mode'] == true) { ?>
                                <div class="dk-switch-container">
                                    <span class="night-label"><?php _e('Night mode: ', 'bakala'); ?></span>
                                    <div id="night_mode_switcher" class="night_mode_switch dk-switch-wrapper clearfix <?php if ((isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') || (!isset($_COOKIE['night_mode']) && $bakala_options['default_mode'] == 'night')) {
                                                                                                                            echo 'active';
                                                                                                                        } else {
                                                                                                                            echo 'inactive';
                                                                                                                        } ?>">
                                        <span class="dk-switch-enabled"><?php _e('Night', 'bakala'); ?></span>
                                        <span class="dk-switch-disabled"><?php _e('Day', 'bakala'); ?></span>
                                    </div>
                                </div>
                            <?php } ?>
                        </nav>
                    </div>
                    <?php if (!empty($bakala_options['facebook']) || !empty($bakala_options['twitter']) || !empty($bakala_options['googleplus']) || !empty($bakala_options['instagram']) || !empty($bakala_options['youtube']) || !empty($bakala_options['vimeo']) || $bakala_options['other_socials']) { ?>

                        <ul class="socials">
                            <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                <li>
                                    <a target="_blank" href="<?php echo $bakala_options['facebook']; ?>"><i class="icon icon-footer-facebook"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                <li>
                                    <a target="_blank" href="<?php echo $bakala_options['twitter']; ?>"><i class="icon icon-footer-twitter"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                <li>
                                    <a target="_blank" href="<?php echo $bakala_options['googleplus']; ?>"><i class="icon icon-footer-googleplus"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                <li>
                                    <a target="_blank" href="<?php echo $bakala_options['instagram']; ?>"><i class="icon icon-footer-instagram"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                <li>
                                    <a target="_blank" href="<?php echo $bakala_options['youtube']; ?>"><i class="icon icon-footer-aparat"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                <li>
                                    <a target="_blank" href="<?php echo $bakala_options['vimeo']; ?>"><i class="icon icon-footer-telegram"></i></a>
                                </li>
                            <?php } ?>
                            <?php
                            if (is_array($bakala_options['other_socials'])) {
                                foreach ($bakala_options['other_socials'] as $item) {
                            ?>
                                    <li>
                                        <a target="_blank" href="<?php echo $item['url']; ?>"><img class="other_socials_img" src="<?php echo $item['image'] ?>"></a>
                                    </li>
                            <?php }
                            } ?>
                        </ul>
                    <?php } ?>
                </div>
                <div class="modern-header nav-down <?= $bakala_options['sticky_header_mob'] == true ? 'sticky-header' : ''; ?>" id="<?= $bakala_options['sticky_header_mob'] == true ? 'navbar-primary-fixed' : 'navbar-primary'; ?>">
                    <div class="modern-header-main">
                        <div class="panel-handler col-3 p-0" data-type="popup-handler" id="off-canvas_menu_icon">
                            <div id="icon-menu" class="icon-menu-handler-svg">
                                <div class="c-header__burger">
                                    <p class="divider-menu"></p>
                                </div>
                            </div>

                        </div>
                        <?php if (is_front_page()) {
                            $tag = 'h1';
                        } else {
                            $tag = 'div';
                        } ?>
                        <<?php echo $tag; ?> class="logo no-lazy"> <?php
                                                                    if (isset($bakala_options['logo-white']) && !empty($bakala_options['logo-white']['url'])) {
                                                                        $logo_href = $bakala_options['logo-white']['url'];
                                                                    } else {
                                                                        $logo_href = get_template_directory_uri() . '/vendor/images/logo-white.png';
                                                                    }
                                                                    ?>
                            <div property="name">
                                <a href="<?php echo home_url('/'); ?>" title="<?php echo get_bloginfo(); ?>" target="_self">
                                    <img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>">
                                </a>
                            </div>
                        </<?php echo $tag; ?>>
                        <div class="modern-header-icons">

                            <?php if (isset($bakala_options['header_tell']) && $bakala_options['header_tell'] && $bakala_options['bottom_navbar_enable'] == 1 && $bakala_options['enable_location'] == false) { ?>
                                <a href="<?= !empty($bakala_options['headerinfobar_tell_phone']) ? 'tel:' . $bakala_options['headerinfobar_tell_phone'] : get_permalink($bakala_options['headerinfobar_tell_page']); ?>" class="c-header__faq"></a>
                            <?php } ?>
                        </div>

                    </div>


                </div>

            <?php
            }
        }
    } else {
        if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('header')) { ?>
            <div class="container-fluid matrix-wolfbody no-padding">

                <div class="mobile-top-bar basic-header nav-down <?= $bakala_options['sticky_header_mob'] == true ? 'sticky-header' : ''; ?>" id="<?= $bakala_options['sticky_header_mob'] == true ? 'navbar-primary-fixed' : 'navbar-primary'; ?>">

                    <?php if (isset($bakala_options['top_bar_mobile']) && $bakala_options['top_bar_mobile']) { ?>
                        <div class="top-header-banner">
                            <?php if ($bakala_options['top_bar_type_mobile'] == 'bgtext') { ?>
                                <?php if ($bakala_options['top_bar_link_mobile']) { ?>
                                    <a href="<?php echo $bakala_options['top_bar_link_mobile']; ?>" target="_blank">
                                    <?php } ?>
                                    <div class="tbar-background">
                                        <?php echo $bakala_options['top_bar_bgtext_text_mobile']; ?>
                                    </div>
                                    <?php if ($bakala_options['top_bar_link_mobile']) { ?>
                                    </a>
                                <?php } ?>
                            <?php } else { ?>
                                <?php if ($bakala_options['top_bar_link_mobile']) { ?>
                                    <a href="<?php echo $bakala_options['top_bar_link_mobile']; ?>">
                                    <?php } ?>
                                    <div class="top-header-image">
                                        <img alt="top-bar-banner" src="<?php echo $bakala_options['top_bar_image_mobile']['url']; ?>">
                                    </div>
                                    <?php if ($bakala_options['top_bar_link_mobile']) { ?>
                                    </a>
                                <?php } ?>
                            <?php } ?>
                        </div>
                    <?php } ?>

                    <div class="col-lg-12 col-xs-12 col-sm-12 col-md-12 main-header" style="position: unset">
                        <div class="toolbar bakala_sb_row">
                            <div class="panel-handler menu-header p-0" data-type="popup-handler" id="off-canvas_menu_icon">
                                <div id="icon-menu" class="icon-menu-handler-svg">
                                    <div class="c-header__burger">
                                        <p class="divider-menu"></p>
                                    </div>
                                </div>
                                <div class="off-canvas-panel_mo dialog--close" id="off-canvas_menu">
                                    <a href="#" class="close-menu-button"><i class="bakala-icon close"></i></a>
                                    <div class="off-canvas-panel-wrapper_mo">
                                        <div class="off-canvas-logo">
                                            <?php
                                            if (isset($bakala_options['logo-white']) && !empty($bakala_options['logo-white']['url'])) {
                                                $logo_href = $bakala_options['logo-white']['url'];
                                            } else {
                                                $logo_href = get_template_directory_uri() . '/vendor/images/logo-white.png';
                                            }
                                            ?>
                                            <div property="name">
                                                <a class="white-logo" href="<?php echo home_url('/'); ?>" title="<?php echo get_bloginfo(); ?>" target="_self">
                                                    <img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>">
                                                </a>
                                                <?php if ($bakala_options['night_mode'] == true && isset($bakala_options['dark_logo_mobile']) && strlen($bakala_options['dark_logo_mobile']['url']) > 0) {
                                                    $dark_logo = $bakala_options['dark_logo_mobile']['url']; ?>
                                                    <a class="dark-logo" href="<?php echo home_url('/'); ?>" title="<?php echo get_bloginfo(); ?>" target="_self">
                                                        <img src="<?php echo $dark_logo; ?>" alt="<?php echo get_bloginfo(); ?>">
                                                    </a>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <nav id="main-navigation_mo">
                                            <ul class="main-menu">
                                                <?php
                                                if (isset($bakala_options['mobile_menu']) && $bakala_options['mobile_menu']) {
                                                    $main_nav_slug = get_term(get_nav_menu_locations()['mobile'], 'nav_menu')->slug;
                                                } else {
                                                    $main_nav_slug = get_term(get_nav_menu_locations()['main'], 'nav_menu')->slug;
                                                }
                                                if (get_option('mobi_menu')) {
                                                    $main_nav_id = get_option('mobi_menu');
                                                } else {
                                                    $main_nav_id = $main_nav_slug;
                                                }
                                                $main_nav = wp_get_nav_menu_items($main_nav_id);
                                                if ($main_nav) {
                                                    foreach ($main_nav as $menu_item) {
                                                        if (is_object($menu_item) && isset($menu_item->ID)) {
                                                            $menu_item_icon = get_post_meta($menu_item->ID, '_menu_item_icon', true);
                                                        }
                                                        $childs = 0;
                                                        if ($menu_item->menu_item_parent == '0') {
                                                            foreach ($main_nav as $menu_item_child_is) {
                                                                if ($menu_item_child_is->menu_item_parent == $menu_item->ID) {
                                                                    $childs = $childs + 1;
                                                                }
                                                            }
                                                            if ($childs > 0) {
                                                                $menu_link = '#popup';
                                                            } else {
                                                                $menu_link = $menu_item->url;
                                                            }
                                                ?>
                                                            <li>
                                                                <span class="menu-title menu-title1">

                                                                    <a class="btn_mo-ripple <?= $childs > 0 ? 'haschild' : '' ?> <?php if (implode('', $menu_item->classes)) echo implode('', $menu_item->classes); ?> <?= ($menu_item->url == '#' || $menu_link == '#popup') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" <?php if ($menu_item->target && $menu_link != '#popup') echo 'target="' . $menu_item->target . '" '; ?> <?php if ($menu_item->xfn) echo 'rel="' . $menu_item->xfn . '" '; ?> <?php if ($menu_item->attr_title) echo 'title="' . $menu_item->attr_title . '" '; ?> href="<?php echo $menu_link; ?>">


                                                                        <?php if ($menu_item_icon) :
                                                                            $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                            if (preg_match($regx_img, $menu_item_icon) == 1) {
                                                                        ?>
                                                                                <img src="<?= $menu_item_icon ?>" class="menu-item-icon" width="18">
                                                                            <?php } else { ?>
                                                                                <i class="<?= $menu_item_icon ?> menu-item-icon"></i>
                                                                        <?php }
                                                                        endif; ?>
                                                                        <span class="pull-right"><?php echo $menu_item->title; ?></span>
                                                                        <?php if ($childs > 0) { ?>
                                                                            <i class="fa fa-arrow-left next"></i>
                                                                        <?php } ?>
                                                                    </a>

                                                                </span>
                                                                <?php if ($childs > 0) { ?>
                                                                    <ul class="collapse submenu">
                                                                        <li class="go-back"><?php echo $menu_item->title; ?>
                                                                            <i class="fa fa-arrow-right"></i>
                                                                        </li>
                                                                        <?php
                                                                        foreach ($main_nav as $menu_item_child) {
                                                                            if (is_object($menu_item_child) && isset($menu_item_child->ID)) {
                                                                                $menu_item_child_icon = get_post_meta($menu_item_child->ID, '_menu_item_icon', true);
                                                                            }
                                                                            $cchilds = 0;
                                                                            foreach ($main_nav as $menu_item_child_child_is) {

                                                                                if ($menu_item_child_child_is->menu_item_parent == $menu_item_child->ID) {
                                                                                    $cchilds = $cchilds + 1;
                                                                                }
                                                                            }
                                                                            if ($cchilds > 0) {
                                                                                $cmenu_link = '#popup';
                                                                            } else {
                                                                                $cmenu_link = $menu_item_child->url;
                                                                            }
                                                                            if ($menu_item_child->menu_item_parent == $menu_item->ID) { ?>

                                                                                <li>
                                                                                    <span class="menu-title menu-title2">
                                                                                        <a class="btn_mo-ripple <?= $cchilds > 0 ? 'haschild' : '' ?> <?php if (is_array($menu_item_child->classes)) echo implode(' ', $menu_item_child->classes); ?> <?= ($menu_item_child->url == '#') ? 'next' : '' ?>" data-ripple-color="rgba(190,190,190,0.75)" href="<?php echo $cmenu_link; ?>" <?php if ($menu_item_child->target && $cmenu_link != '#popup') echo 'target="' . $menu_item_child->target . '" '; ?> <?php if ($menu_item_child->xfn) echo 'rel="' . $menu_item_child->xfn . '" '; ?> <?php if ($menu_item_child->attr_title) echo 'title="' . $menu_item_child->attr_title . '" '; ?>>

                                                                                            <?php if ($menu_item_child_icon) :
                                                                                                $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                if (preg_match($regx_img, $menu_item_child_icon) == 1) {
                                                                                            ?>
                                                                                                    <img src="<?= $menu_item_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                <?php } else { ?>
                                                                                                    <i class="<?= $menu_item_child_icon ?> menu-item-icon"></i>
                                                                                            <?php }
                                                                                            endif; ?>
                                                                                            <span class="pull-right"><?php echo $menu_item_child->title; ?></span>
                                                                                            <?php if ($cchilds > 0) { ?>
                                                                                                <i class="fa fa-arrow-left next"></i>
                                                                                            <?php } ?>
                                                                                        </a>

                                                                                    </span>
                                                                                    <?php if ($cchilds > 0) { ?>
                                                                                        <ul class="collapse submenu">
                                                                                            <li class="go-back"><?php echo $menu_item_child->title; ?>
                                                                                                <i class="fa fa-arrow-right"></i>
                                                                                            </li>

                                                                                            <?php
                                                                                            foreach ($main_nav as $menu_item_child_child) {
                                                                                                if (is_object($menu_item_child_child) && isset($menu_item_child_child->ID)) {
                                                                                                    $menu_item_child_child_icon = get_post_meta($menu_item_child_child->ID, '_menu_item_icon', true);
                                                                                                }
                                                                                                if ($menu_item_child_child->menu_item_parent == $menu_item_child->ID) {
                                                                                                    $ccchilds = 0;
                                                                                                    foreach ($main_nav as $menu_item_child_child_child_is) {

                                                                                                        if ($menu_item_child_child_child_is->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                            $ccchilds = $ccchilds + 1;
                                                                                                        }
                                                                                                    }
                                                                                            ?>
                                                                                                    <li>
                                                                                                        <span class="menu-title menu-title3">
                                                                                                            <a class="ch btn_mo-ripple <?= $menu_item_child_child->url == '#' ? 'next' : '' ?> <?= $ccchilds > 0 ? 'haschild' : '' ?>" href="<?= $menu_item_child_child->url ?>" property="url">
                                                                                                                <?php if ($menu_item_child_child_icon) :
                                                                                                                    $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                    if (preg_match($regx_img, $menu_item_child_child_icon) == 1) {
                                                                                                                ?>
                                                                                                                        <img src="<?= $menu_item_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                    <?php } else { ?>
                                                                                                                        <i class="<?= $menu_item_child_child_icon ?> menu-item-icon"></i>
                                                                                                                <?php }
                                                                                                                endif; ?>
                                                                                                                <span><?= $menu_item_child_child->title ?></span>
                                                                                                                <?php if ($ccchilds > 0) { ?>
                                                                                                                    <i class="fa fa-arrow-left next"></i>
                                                                                                                <?php } ?>
                                                                                                            </a>


                                                                                                        </span>
                                                                                                        <?php if ($ccchilds > 0) { ?>
                                                                                                            <ul class="collapse submenu">
                                                                                                                <li class="go-back"><?php echo $menu_item_child_child->title; ?>
                                                                                                                    <i class="fa fa-arrow-right"></i>
                                                                                                                </li>

                                                                                                                <?php
                                                                                                                foreach ($main_nav as $menu_item_child_child_child) {
                                                                                                                    if (is_object($menu_item_child_child_child) && isset($menu_item_child_child_child->ID)) {
                                                                                                                        $menu_item_child_child_child_icon = get_post_meta($menu_item_child_child_child->ID, '_menu_item_icon', true);
                                                                                                                    }
                                                                                                                    if ($menu_item_child_child_child->menu_item_parent == $menu_item_child_child->ID) {
                                                                                                                ?>
                                                                                                                        <li>
                                                                                                                            <span class="menu-title4">
                                                                                                                                <a class="ch btn_mo-ripple" href="<?= $menu_item_child_child_child->url ?>" property="url">
                                                                                                                                    <?php if ($menu_item_child_child_child_icon) :
                                                                                                                                        $regx_img = "/.*\/\/[^\/]+\/?.*\/.*\.[A-Za-z]{2,3}/";
                                                                                                                                        if (preg_match($regx_img, $menu_item_child_child_child_icon) == 1) {
                                                                                                                                    ?>
                                                                                                                                            <img src="<?= $menu_item_child_child_child_icon ?>" class="menu-item-icon" width="18">
                                                                                                                                        <?php } else { ?>
                                                                                                                                            <i class="<?= $menu_item_child_child_child_icon ?> menu-item-icon"></i>
                                                                                                                                    <?php }
                                                                                                                                    endif; ?>
                                                                                                                                    <span><?= $menu_item_child_child_child->title ?></span>

                                                                                                                                </a>

                                                                                                                            </span>

                                                                                                                        </li>
                                                                                                                <?php
                                                                                                                    }
                                                                                                                }

                                                                                                                echo '<li><a class="menu_mo-all" href="' . $menu_item_child_child->url . '"> همه ' . $menu_item_child_child->title . '</a></li>';

                                                                                                                ?>
                                                                                                            </ul>
                                                                                                        <?php } ?>
                                                                                                    </li>
                                                                                            <?php
                                                                                                }
                                                                                            }

                                                                                            echo '<li><a class="menu_mo-all" href="' . $menu_item_child->url . '"> همه ' . $menu_item_child->title . '</a></li>';

                                                                                            ?>
                                                                                        </ul>
                                                                                    <?php } ?>

                                                                                </li>
                                                                        <?php }
                                                                        }

                                                                        echo '<li><a class="menu_mo-all" href="' . $menu_item->url . '"> همه ' . $menu_item->title . '</a>';

                                                                        ?>
                                                                    </ul>
                                                                <?php } ?>
                                                            </li>
                                                <?php }
                                                    }
                                                } ?>
                                            </ul>
                                            <?php
                                            if (isset($bakala_options['enable_header_offer']) && $bakala_options['enable_header_offer'] && class_exists('WooCommerce')) {
                                                if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
                                                    $term = get_term($bakala_options['offer_menu_cat']);
                                                    if ($term) { ?>
                                                        <a class="special-offer-link" href="<?php echo get_term_link($term); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                                    <?php }
                                                } elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) { ?>
                                                    <a class="special-offer-link" href="<?php echo get_permalink($bakala_options['offer_menu_link']); ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
                                            <?php }
                                            }
                                            ?>
                                            <?php if (isset($bakala_options['night_mode']) && $bakala_options['night_mode'] == true) { ?>
                                                <div class="dk-switch-container">
                                                    <span class="night-label"><?php _e('Night mode: ', 'bakala'); ?></span>
                                                    <div id="night_mode_switcher" class="night_mode_switch dk-switch-wrapper clearfix <?php if ((isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') || (!isset($_COOKIE['night_mode']) && $bakala_options['default_mode'] == 'night')) {
                                                                                                                                            echo 'active';
                                                                                                                                        } else {
                                                                                                                                            echo 'inactive';
                                                                                                                                        } ?>">
                                                        <span class="dk-switch-enabled"><?php _e('Night', 'bakala'); ?></span>
                                                        <span class="dk-switch-disabled"><?php _e('Day', 'bakala'); ?></span>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        </nav>
                                    </div>
                                </div>
                            </div>
                            <div class="header-logo">
                                <?php if (is_front_page()) {
                                    $tag = 'h1';
                                } else {
                                    $tag = 'div';
                                } ?>
                                <<?php echo $tag; ?> class="logo"> <?php
                                                                    if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
                                                                        $logo_href = $bakala_options['site_header_logo']['url'];
                                                                    } else {
                                                                        $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                                                                    }
                                                                    ?>
                                    <div property="name">
                                        <a href="<?php echo home_url('/'); ?>" title="<?php echo get_bloginfo(); ?>" target="_self">
                                            <img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>">
                                        </a>
                                    </div>
                                </<?php echo $tag; ?>>
                            </div>
                            <div class="header-icons">

                                <?php if (isset($bakala_options['header_tell']) && $bakala_options['header_tell']) { ?>
                                    <a href="<?= !empty($bakala_options['headerinfobar_tell_phone']) ? 'tel:' . $bakala_options['headerinfobar_tell_phone'] : get_permalink($bakala_options['headerinfobar_tell_page']); ?>" class="c-header__faq"></a>
                                <?php } ?>
                            </div>


                        </div>
                        <div class="search-toolbar-item bakala_sb_row">
                            <div class="top-header-search">
                                <div class="c-ui-input c-ui-input--search"></div>
                                <?php if(empty($bakala_options['search_shortcode'])){
                    $shortcode = do_shortcode('[wcas-search-form]');
                }else{
                    $shortcode = do_shortcode(''.$bakala_options['search_shortcode'],'');
                }
                         echo $shortcode; ?>
                            </div>
                            <div class="header-icons">
                                <div class="toolbar-item">
                                    <?php if (is_user_logged_in()) { ?>
                                        <a class="profile-menu-handler profile-menu-handler-logged-in" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>">

                                        </a>
                                    <?php } else { ?>
                                        <?php if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true) {
                                            if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                                                echo do_shortcode('[dm-modal]');
                                            } else { ?>
                                                <button class="profile-menu-handler popup" style="background: transparent;border: none;" type="button"><i class="bakala-icon icon-login"></i> <span>ورود</span></button>
                                            <?php }
                                        } else { ?>
                                            <a class="profile-menu-handler" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>">
                                            </a>
                                        <?php } ?>
                                    <?php } ?>
                                    </li>
                                </div>
                                <div class="toolbar-item">
                                    <?php
                                    $cart_count = bakala_get_cart_count();
                                    ?>
                                    <a class="bakala-icon icon-cart" href="<?= get_permalink(wc_get_page_id('cart')); ?>"><span class="ar-spender"><?= $cart_count ?></span></a>
                                    </li>
                                </div>
                            </div>
                        </div>

                        <?php if ($bakala_options['header_categories_enable_mobile'] == '1' && !empty($bakala_options['header_categories'])) { ?>
                            <div class="bakala-product-categories-header">
                                <?php foreach ($bakala_options['header_categories'] as $category_id) {
                                    $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
                                    $image_url = wp_get_attachment_url($thumbnail_id);
                                    $term = get_term_by('id', $category_id, 'product_cat');
                                    $link = get_term_link($term->slug, 'product_cat');

                                ?>
                                    <a href="<?php echo $link ?>" class="bakala-product-category-header">
                                        <div class="bakala-product-category-header-img">
                                            <img src="<?= $image_url ?>" alt="<?= $term->name ?>" loading="lazy" style="filter: blur(0px);">
                                        </div>
                                        <span class="bakala-product-category-header-title" style="color: rgba(0, 0, 0, 0.56);"><?= $term->name ?></span>
                                    </a>
                                <?php } ?>
                            </div>
                        <?php }

                        ?>
                        <?php
                        if (isset($bakala_options['enable_location']) && $bakala_options['enable_location'] == true) {
                        ?>
                            <div class="toolbar clearfix">
                                <div class="header-location site-location">
                                    <a href="#">
                                        <span class="location-description"><?php esc_html_e('Your Location', 'bakala'); ?></span>
                                        <?php if (bakala_location() == 'all') { ?>
                                            <div class="current-location"><?php esc_html_e('Select a Location to filter', 'bakala'); ?></div>
                                        <?php } else { ?>
                                            <div class="current-location activated"><?php echo esc_html(bakala_location()); ?></div>
                                        <?php } ?>
                                    </a>
                                </div>
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            <?php } ?>
            <?php
        }
        if (bakala_is_woocommerce_active()) {
            if (is_cart() || is_checkout()) : ?>
                <div class="checkout-header">
                    <ul>
                        <li class="nav"><a href="<?php echo wc_get_cart_url(); ?>"></a>
                            <p><?php _e('Cart', 'bakala'); ?></p><span>1</span>
                        </li>
                        <li class="bar"><span></span></li>
                        <li class="nav">
                            <?php if (($bakala_options['force_login_cart'] == 1 || $bakala_options['force_login_in_cart'] == 1) && !is_user_logged_in()) { ?>
                                <a href="#" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login"></a>
                            <?php } else {
                            ?>
                                <a href="<?php echo wc_get_checkout_url(); ?>"></a>
                            <?php
                            } ?>
                            <p><?php _e('Billing', 'bakala'); ?></p><span>2</span>
                        </li>
                        <li class="bar"><span></span></li>
                        <li class="nav">
                            <p><?php _e('Factor', 'bakala'); ?></p><span>3</span>
                        </li>
                    </ul>
                </div>
        <?php endif;
        }
