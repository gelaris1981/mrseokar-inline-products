<?php if (!defined('ABSPATH')) exit;
global $bakala_options;
?>
<?php if (is_cart() && is_user_logged_in() && $bakala_options['save_for_later']==1) :
	$sflps = get_save_for_later();
	$sfl_count = count($sflps);
    if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
        $logo_href = $bakala_options['site_header_logo']['url'];
    } else {
        $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
    }
global $woocommerce;
$cart_count= $woocommerce->cart->cart_contents_count;
?>

    <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo" src="<?= $logo_href ?>">
        <div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
    </div>
<?php endif;
var_dump($bakala_options['force_login_in_cart']);
 ?>
<?php if (!$_GET['tab'] == 'next-shopping') : ?>
<div class="checkout-header">
    <ul>
        <li class="nav"><a href="<?php echo wc_get_cart_url(); ?>"></a>
            <p><?php _e('Cart', 'bakala'); ?></p><span>1</span>
        </li>
        <li class="bar"><span></span></li>
        <li class="nav">
            <?php if ( ($bakala_options['force_login_cart'] == 1 || $bakala_options['force_login_in_cart'] == 1) && !is_user_logged_in() ){ ?>
				<a href="#" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login"></a>
				<?php }else{
	?>
				<a href="<?php echo wc_get_checkout_url(); ?>"></a>
<?php
} ?>
            <p><?php _e('Billing', 'bakala'); ?></p><span>2</span>
        </li>
        <li class="bar"><span></span></li>
        <li class="nav">
            <p><?php _e('Factor', 'bakala'); ?></p><span>3</span>
        </li>
    </ul>
</div>
<?php endif; ?>