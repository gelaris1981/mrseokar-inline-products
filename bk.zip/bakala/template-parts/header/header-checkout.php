<?php

if (!is_mobile_or_tablet()) {


?>
	<?php

	global $bakala_options;

	$current_user = wp_get_current_user();


	?>
	<!DOCTYPE html>
	<html <?php language_attributes(); ?> class="no-js no-svg">

	<head>
		<meta charset="<?php bloginfo('charset'); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
		<link rel="profile" href="http://gmpg.org/xfn/11">
		<?php
		if (isset($bakala_options['bakala_favicon']) && strlen($bakala_options['bakala_favicon']['url']) > 0) {
			$favicon_href = $bakala_options['bakala_favicon']['url'];
		} else {
			$favicon_href = get_template_directory_uri() . '/vendor/images/favicon.png';
		}
		?>
		<link rel="shortcut icon" href="<?php echo $favicon_href; ?>" />
		<link rel="apple-touch-icon" href="<?php echo $favicon_href; ?>">
		<meta name="msapplication-TileColor" content="#ff6600">
		<meta name="msapplication-TileImage" content="<?php echo $favicon_href; ?>">
		<?php wp_head(); ?>
		<?php if (!empty($bakala_options['tracking_code'])) {
			echo $bakala_options['tracking_code'];
		} ?>
		<?php if (!empty($bakala_options['custom_css'])) {
			echo '<style id="user-style">' . $bakala_options['custom_css'] . ' </style>';
		} ?>
	</head>
	<?php $night_mode = '';
	if (isset($_COOKIE['night_mode']) && $_COOKIE['night_mode'] == 'active') $night_mode = 'night'; ?>

	<body <?php body_class($night_mode); ?>>
		<?php if (isset($bakala_options['google_tags']) && $bakala_options['google_tags'] == true) {
			echo $bakala_options['google_tags'];
		} ?>
		<div class="container-bakala white_catbody">
			<?php if (is_cart() || is_checkout()) { ?>
				<div class="row header checkout-header">
					<div class="container-bakala">
						<div class="container-bakala header-row">
							<div class="col-md-3 row header-logo">
								<?php
								if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
									$logo_href = $bakala_options['site_header_logo']['url'];
								} else {
									$logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
								}
								?>
								<a class="white-logo" href="<?php echo home_url('/'); ?>"><img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>" style="display:block"></a>

							</div>
						</div>
					</div>
					<?php get_template_part('template-parts/header/checkout-header-pc'); ?>
				</div>
			<?php } ?>
			<?php if (!is_user_logged_in() && ($bakala_options['digits'] != true || !function_exists('digit_get_login_fields'))) {
				if (isset($bakala_options['bakala_lr_logo']) && $bakala_options['bakala_lr_logo']['url']) {
					$logo_href = $bakala_options['bakala_lr_logo']['url'];
				} elseif (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
					$logo_href = $bakala_options['site_header_logo']['url'];
				} else {
					$logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
				}

				if (empty($bakala_options['lr_bg']['from'])) {
					$gradient_from = $bakala_options['accent-gradient']['from'];
				} else {
					$gradient_from = $bakala_options['lr_bg']['from'];
				}
				if (empty($bakala_options['lr_bg']['to'])) {
					$gradient_to = $bakala_options['accent-gradient']['to'];
				} else {
					$gradient_to = $bakala_options['lr_bg']['to'];
				}
				if ($bakala_options['lr_style'] == 'two') {
			?>
					<div class="modal fade bakala_login_style_two" id="bakala_login" tabindex="-1" style="display: none;">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="bs-logo"><img src="<?= $logo_href ?>" alt=""></div>
								<?php if ($bakala_options['lr_bakala'] == 1 && bakala_is_woocommerce_active()) :
									get_template_part('template-parts/login-register');
								else : ?>
									<!-- Begin # Login Form -->
									<form id="login" action="login" method="post">
										<div class="modal-body">


											<div class="form-group clearfix">
												<a class="c-ui-input c-ui-input--account-username"></a>
												<label for="p-username" style="width:100%"><?php echo _e('Username', 'bakala'); ?></label>

												<input name="username" type="text" id="p-username" tabindex="1" class="en" placeholder="Username">
											</div>

											<div class="form-group clearfix">
												<label for="p-password"><?php echo _e('Password', 'bakala'); ?></label>
												<a class="forget" href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
												<a class="c-ui-input c-ui-input--account-pass"></a>
												<input name="password" type="password" id="p-password" tabindex="2" class="en" placeholder="Password">
												<span class="fa fa-fw fa-eye field-icon toggle-password"></span>
											</div>

											<div class="form-group clearfix">
												<div class="ckeckbox-control">
													<input name="rememberme" type="checkbox" id="p-rememberme" class="rememberme" tabindex="3">
													<label for="p-rememberme"><?php echo _e('Remember me', 'bakala'); ?></label>
												</div>
											</div>

											<div class="login-msg"></div>

											<div class="form-group clearfix" style="margin-bottom:50px;">
												<div class="bakala-button-container hasIcon large full">
													<button type="submit" name="submit" id="wp-submit">
														<span class="bakala-button blue">
															<i class="bakala-button-icon bakala-button-icon-login"></i>
															<span class="bakala-button-label clearfix">
																<?php echo _e('Login To Site', 'bakala'); ?>
															</span>
														</span>
													</button>
												</div>
											</div>

										</div>

										<div id="login_footerbox" class="footer box">
											<div class="register"><?php echo _e('You Are Not Register Before?', 'bakala'); ?>
												<a id="Register" target="_blank" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"><?php echo _e('Register To Site', 'bakala'); ?></a>
											</div>
										</div>
										<?php wp_nonce_field('ajax-login-nonce', 'p-security'); ?>
									</form>
									<!-- End # Login Form -->
								<?php endif; ?>
							</div>
						</div>
					</div>
				<?php
				} else {
				?>
					<div class="modal fade bakala_login_style_one" id="bakala_login" tabindex="-1" style="display: none;">
						<div class="modal-dialog">
							<div class="modal-content">
								<div class="auth-modal">
									<div class="auth-modal-side" style="background: linear-gradient(90deg,<?= $gradient_from ?>,<?= $gradient_to ?>);">
										<div class="bs-logo"><img src="<?= $logo_href ?>" alt=""></div>
									</div>
									<div class="auth-modal-content">

										<div class="auth-modal-content-container">
											<header class="auth-header">
												<button type="button" data-bs-dismiss="modal" class="close-icon"></button>
											</header>
											<!---->
											<div class="auth-modal-template">
												<?php if ($bakala_options['lr_bakala'] == 1 && bakala_is_woocommerce_active()) :
													get_template_part('template-parts/login-register');
												else : ?>
													<!-- Begin # Login Form -->
													<form id="login" action="login" method="post">
														<div class="modal-body">


															<div class="form-group clearfix">
																<a class="c-ui-input c-ui-input--account-username"></a>
																<label for="p-username" style="width:100%"><?php echo _e('Username', 'bakala'); ?></label>

																<input name="username" type="text" id="p-username" tabindex="1" class="en" placeholder="Username">
															</div>

															<div class="form-group clearfix">
																<label for="p-password"><?php echo _e('Password', 'bakala'); ?></label>
																<a class="forget" href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
																<a class="c-ui-input c-ui-input--account-pass"></a>
																<input name="password" type="password" id="p-password" tabindex="2" class="en" placeholder="Password">
																<span class="fa fa-fw fa-eye field-icon toggle-password"></span>
															</div>

															<div class="form-group clearfix">
																<div class="ckeckbox-control">
																	<input name="rememberme" type="checkbox" id="p-rememberme" class="rememberme" tabindex="3">
																	<label for="p-rememberme"><?php echo _e('Remember me', 'bakala'); ?></label>
																</div>
															</div>

															<div class="login-msg"></div>

															<div class="form-group clearfix" style="margin-bottom:50px;">
																<div class="bakala-button-container hasIcon large full">
																	<button type="submit" name="submit" id="wp-submit">
																		<span class="bakala-button blue">
																			<i class="bakala-button-icon bakala-button-icon-login"></i>
																			<span class="bakala-button-label clearfix">
																				<?php echo _e('Login To Site', 'bakala'); ?>
																			</span>
																		</span>
																	</button>
																</div>
															</div>

														</div>

														<div id="login_footerbox" class="footer box">
															<div class="register"><?php echo _e('You Are Not Register Before?', 'bakala'); ?>
																<a id="Register" target="_blank" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')); ?>"><?php echo _e('Register To Site', 'bakala'); ?></a>
															</div>
														</div>
														<?php wp_nonce_field('ajax-login-nonce', 'p-security'); ?>
													</form>
													<!-- End # Login Form -->
												<?php endif; ?>
											</div>
										</div>
										<!---->
									</div>
								</div>
							</div>
						</div>
					</div>
		<?php
				}
			}
		}