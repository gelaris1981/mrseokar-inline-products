<?php

global $bakala_options, $post;

?>

</div><!-- #content -->
<div class="modal fade" id="search-modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?= __('Search products', 'bakala') ?></h5>
                <button type="button" class="btn-close mx-0" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <?php echo do_shortcode('[wcas-search-form]'); ?>
                <div class="search-alert">
                    <svg xmlns:xlink="http://www.w3.org/1999/xlink" _ngcontent-wkc-c98=""
                         xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 100 100">
                        <g _ngcontent-wkc-c98="" id="box-search" transform="translate(0.11 0.5)">
                            <path _ngcontent-wkc-c98="" id="Path_247" data-name="Path 247"
                                  d="M3.17,7.44,44.45,31.329l41-23.749" transform="translate(2.867 19.992)" fill="none"
                                  stroke="#162C5B" stroke-linecap="round" stroke-linejoin="round"
                                  stroke-width="5px"></path>
                            <path _ngcontent-wkc-c98="" id="Path_248" data-name="Path 248" d="M12,54.942V12.54"
                                  transform="translate(35.317 38.734)" fill="none" stroke="#162C5B"
                                  stroke-linecap="round" stroke-linejoin="round" stroke-width="5px"></path>
                            <path _ngcontent-wkc-c98="" id="Path_249" data-name="Path 249"
                                  d="M92.243,52.63V35.52c0-6.452-4.628-14.305-10.285-17.438L56.994,4.244c-5.329-2.992-14.025-2.992-19.355,0L12.675,18.082C7.018,21.214,2.39,29.068,2.39,35.52V61.98c0,6.451,4.628,14.305,10.285,17.438L37.639,93.256A20.251,20.251,0,0,0,47.317,95.5a20.251,20.251,0,0,0,9.677-2.244"
                                  transform="translate(0 0)" fill="none" stroke="#162C5B" stroke-linecap="round"
                                  stroke-linejoin="round" stroke-width="5px"></path>
                            <path _ngcontent-wkc-c98="" id="Path_250" data-name="Path 250"
                                  d="M30.96,44.92A14.96,14.96,0,1,0,16,29.96,14.96,14.96,0,0,0,30.96,44.92Z"
                                  transform="translate(50.017 47.775)" fill="none" stroke="#162C5B"
                                  stroke-linecap="round" stroke-linejoin="round" stroke-width="5px"></path>
                            <path _ngcontent-wkc-c98="" id="Path_251" data-name="Path 251" d="M26.675,25.675,22,21"
                                  transform="translate(72.067 69.825)" fill="none" stroke="#162C5B"
                                  stroke-linecap="round" stroke-linejoin="round" stroke-width="5px"></path>
                            <path _ngcontent-wkc-c98="" id="Path_256" data-name="Path 256"
                                  d="M52.328,47.265V29.98L7.51,4.1" transform="translate(19.493 6.02)" fill="none"
                                  stroke="#162C5B" stroke-linecap="round" stroke-linejoin="round"
                                  stroke-width="5px"></path>
                        </g>
                    </svg>
                    <p><?= __('Search for the product you want.', 'bakala') ?></p>
                </div>
            </div>

        </div>
    </div>
</div>
<?php
if (isset($bakala_options['modern_header_mobile_style']) && $bakala_options['modern_header_mobile_style'] == 'two') {
    require_once __DIR__ . "/bottom-navbar.php";
} else {
    if (bakala_is_woocommerce_active()) {
        if (!is_product() && !is_cart() && !is_checkout() && ($bakala_options['bottom_navbar_enable'] == 1 || $bakala_options['modern_header_mobile'] == 1 || is_null($bakala_options['modern_header_mobile']))) {
            require_once __DIR__ . "/bottom-navbar.php";
        }
        if (is_product() && $bakala_options['bottom_navbar_enable'] == 1 && $bakala_options['cart_fixed'] == 0) {
            require_once __DIR__ . "/bottom-navbar.php";
        }
    }
}
?>
<?php

if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('footer')) {
    if (isset($bakala_options['scrollup']) && $bakala_options['scrollup'] == true) : ?>
        <div class="u-flex u-justify-between u-items-center items-center">
            <?php if ($bakala_options['footer_logo'] != 0) { ?>
                <div class="c-new-footer__logo"> <?php
                    if (isset($bakala_options['site_footer_logo']) && !empty($bakala_options['site_footer_logo']['url'])) {
                        $logo_href = $bakala_options['site_footer_logo']['url'];
                    } else {
                        $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                    }
                    ?>
                    <div property="name">
                        <div class="white-logo">
                            <img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>">
                        </div>

                    </div>
                </div>
            <?php }
             ?>
            <a href="#" id="scrollUp" style="<?= is_cart() || is_checkout() ? 'visibility:hidden' : null ?>">
                <div id="js-jump-to-top" class="c-new-footer__jump-to-top-container"><span
                            class="c-new-footer__jump-to-top-label"><?php echo _e('Back to Top', 'bakala'); ?></span>
                    <span class="c-new-footer__jump-to-top-icon"></span>
                </div>
        </div></a>

        <?php 
            
        if (isset($bakala_options['footerinfobar']) && $bakala_options['footerinfobar']) { ?>
            <div class="c-new-footer__contact-info-container">
                <?php if (!empty($bakala_options['footer_location'])) { ?>
                    <div class="u-flex">
                        <i class="bakala-icon icon-map"></i>
                        <span><?= $bakala_options['footer_location'] ?></span>
                    </div>
                <?php } ?>
                <div class="u-flex"><?php if (isset($bakala_options['footerinfobar_phone']) && $bakala_options['footerinfobar_phone']) { ?>
                        <span><?= empty($bakala_options['footerinfobar_phone_label']) ? __('Phone: ', 'bakala') : $bakala_options['footerinfobar_phone_label']; ?></span>
                        <a class="c-new-footer__phone-number"
                           href="<?php echo 'tel:' . $bakala_options['footerinfobar_phone']; ?>"><?php echo $bakala_options['footerinfobar_phone']; ?></a>
                    <?php } ?>
                </div>
                <div class="c-new-footer__support-email">
                    <?php if (isset($bakala_options['footerinfobar_email']) && $bakala_options['footerinfobar_email']) { ?>
                    <span><?= empty($bakala_options['footerinfobar_email_label']) ? __('Email: ', 'bakala') : $bakala_options['footerinfobar_email_label']; ?></span><a
                            class="c-new-footer__email"><?php echo $bakala_options['footerinfobar_email']; ?></a>
                </div>
            <?php } ?>
                <div class="c-new-footer__support-label">
                    <?php if (isset($bakala_options['footerinfobar_slogan']) && $bakala_options['footerinfobar_slogan']) { ?>
                        <?php echo $bakala_options['footerinfobar_slogan']; ?><?php } ?></div>
            </div>
        <?php } ?>
    <?php endif; ?>
    <footer class="footer-section">
        <div class="container-bakala">

            <div class="row footer-newsletter">
                <div class="container-bakala">
                    <div class="container-bakala footer-div">

                        <div class="col-md-9 no-padding">
                            <div class="row">
                                <?php if (is_active_sidebar('subscribe-col-1')) {
                                    dynamic_sidebar('subscribe-col-1');
                                } ?>
                            </div>
                            <div class="row">
                                <?php if (is_active_sidebar('subscribe-col-2')) {
                                    dynamic_sidebar('subscribe-col-2');
                                } ?>
                            </div>

                            <div class="row">
                                <?php if (is_active_sidebar('subscribe-col-3')) {
                                    dynamic_sidebar('subscribe-col-3');
                                } ?>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if (isset($bakala_options['footerinfobar']) && $bakala_options['footerinfobar']) { ?>
            <div class="row footerinfobar">
                <div class="container-bakala">
                    <div class="container-bakala footer-div">
                        <?php if (isset($bakala_options['show-apps']) && $bakala_options['show-apps']) { ?>
                            <ul class="apps">
                                <div class="c-new-footer__app-links-container">
                                    <div class="u-flex u-justify-between u-items-center app">
                                        <?php if (isset($bakala_options['app_img']) && !empty($bakala_options['app_img']['url'])) { ?>
                                            <div class="c-new-footer__app-links-logo">
                                                <img src="<?php echo $bakala_options['app_img']['url']; ?>"> <?php if (isset($bakala_options['app_title']) && $bakala_options['app_title']) { ?>
                                                    <span class="c-new-footer__app-links-label"><?php echo $bakala_options['app_title']; ?></span><?php } ?>

                                            </div>
                                        <?php } ?>
                                        <div class="c-new-footer__app-images-container">
                                            <?php if (isset($bakala_options['google_play']) && $bakala_options['google_play']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['google_play']; ?>"
                                                       class="google_play-icon"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/google_play.png'; ?>"
                                                                alt="google play icon"></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['soundcloud']) && $bakala_options['soundcloud']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['soundcloud']; ?>"
                                                       class="android-icon"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/android_app.png'; ?>"
                                                                alt="android app icon"></a>
                                                </li>
                                            <?php } ?>

                                            <?php if (isset($bakala_options['myket']) && $bakala_options['myket']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['myket']; ?>" class="myket"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/myket.png'; ?>"
                                                                alt="myket icon"></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['vine']) && $bakala_options['vine']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['vine']; ?>"
                                                       class="ios-icon"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/ios_app.png'; ?>"
                                                                alt="ios app icon"></a>
                                                </li>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </ul> <?php } ?>
                    </div>
                </div>
            </div>
        <?php } ?>



        <?php
        $display = true;
        if (!is_front_page()) {
            if (isset($bakala_options['footer-home']) && $bakala_options['footer-home']) {
                $display = false;
            }
        }
        if ($display) {
            ?>
            <div class="col-md-3 no-padding">
                <div class="subscribe-social">
                    <div class="col-md-5 no-padding">
                        <div class="r-flex p-items-center"><?php if (isset($bakala_options['social_title']) && $bakala_options['social_title']) { ?>
                                <div class="c-new-footer__social-links-label"><?php echo $bakala_options['social_title']; ?></div>
                            <?php } ?>
                        </div>
                        <div class="l-flex p-items-center">
                            <ul class="socials">
                                <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['facebook']; ?>"><i
                                                    class="icon icon-footer-facebook"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['twitter']; ?>"><i
                                                    class="icon icon-footer-twitter"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['googleplus']; ?>"><i
                                                    class="icon icon-footer-googleplus"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['instagram']; ?>"><i
                                                    class="icon icon-footer-instagram"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['youtube']; ?>"><i
                                                    class="icon icon-footer-aparat"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['vimeo']; ?>"><i
                                                    class="icon icon-footer-telegram"></i></a>
                                    </li>
                                <?php } ?>
                                <?php
                                if (is_array($bakala_options['other_socials'])) {
                                    foreach ($bakala_options['other_socials'] as $item) {
                                        if (!empty($item['image'])) {
                                            ?>
                                            <li>
                                                <a target="_blank" rel="nofollow"
                                                   href="<?php echo $item['url']; ?>"><img class="other_socials_img"
                                                                                           src="<?php echo $item['image'] ?>"></a>
                                            </li>
                                        <?php }
                                    }
                                } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php if (isset($bakala_options['footersubscribe']) && $bakala_options['footersubscribe']) { ?>

                <div class="subscribe-form-div">
                    <div class="widget-title"><?php echo $bakala_options['footer_newsletter_title']; ?></div>
                    <div id="subscribe-form">
                        <?php echo do_shortcode($bakala_options["footer_newsletter_marketing_text"]); ?>
                    </div>
                </div>
            <?php } ?>
            <div class="row about-bar">
                <div class="container-bakala">
                    <div class="container-bakala footer-div">
                        <div class="col-md-9 no-padding footer_description">
                            <?php if (isset($bakala_options['footer_credit'])) {
                                echo '<div class="footer_description_inner">';
                                echo $bakala_options['footer_credit'];
                                echo '</div>';
                                echo '<span class="footer_more" data-less="' . __('Less', 'bakala') . '" data-more="' . __('More', 'bakala') . '">' . __('More', 'bakala') . '</span>';
                            } ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
        <div class="namad col-md-3 no-padding">
            <?php if (isset($bakala_options['mobile-footer-text'])) {
                echo $bakala_options['mobile-footer-text'];
            } ?>
        </div>
        <div class="row copyright-bar">
            <div class="container-bakala">
                <div class="container-bakala footer-div">


                    <div class="copyright-bar-text">
                        <div class="no-padding section-one">
                        <span><?php if (isset($bakala_options['copyright-one']) && $bakala_options['copyright-one']) {
                                echo $bakala_options['copyright-one'];
                            } ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if (isset($bakala_options['footer_fixed_box']) && $bakala_options['footer_fixed_box'] && is_front_page()) { ?>
            <div class="mobile-fixed-box">
                <span class="close"></span>
                <?php if (isset($bakala_options['fixed_box_img']) && strlen($bakala_options['fixed_box_img']['url']) > 0) {
                    echo '<img src="' . $bakala_options["fixed_box_img"]["url"] . '" alt="promotion">';
                }
                if (isset($bakala_options['fixed_box_title']) && $bakala_options['fixed_box_title']) {
                    echo '<span>' . $bakala_options['fixed_box_title'] . '</span>';
                }
                if (isset($bakala_options['fixed_box_link']) && $bakala_options['fixed_box_link'] && $bakala_options['fixed_box_btntxt']) {
                    echo '<a href="' . $bakala_options['fixed_box_link'] . '">' . $bakala_options['fixed_box_btntxt'] . '</a>';
                } ?>
            </div>
        <?php } ?>
    </footer>

    <?php
}
?>
<?php if (!empty($bakala_options['custom_js'])) {
    echo '<script>' . $bakala_options['custom_js'] . ' </script>';
}
if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
    $logo_href = $bakala_options['site_header_logo']['url'];
} else {
    $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
}
?>
<div class="dialog__overlay" style="display:none;"></div>
<div class="page-modal lr-loader" style="display:none;">
    <div class="page-content" id="loader"><img alt="site-logo" class="site-logo" src="<?= $logo_href ?>">
        <div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i
                    class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i
                    class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i
                    class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
    </div>
</div>

<div class="modal fade" id="search_modal" tabindex="-1" style="display: none;">
    <div class="modal-dialog">

        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-title"><?= __('Search products', 'bakala') ?></div>
                <button type="button" data-bs-dismiss="modal" class="close-icon"></button>
            </div>
            <?php if (empty($bakala_options['search_shortcode'])) {
                $shortcode = do_shortcode('[wcas-search-form]');
            } else {
                $shortcode = do_shortcode('' . $bakala_options['search_shortcode'], '');
            }
            echo $shortcode;
            ?>
            <div class="search-alert">
                <svg xmlns:xlink="http://www.w3.org/1999/xlink" _ngcontent-wkc-c98="" xmlns="http://www.w3.org/2000/svg"
                     width="96" height="96" viewBox="0 0 100 100">
                    <g _ngcontent-wkc-c98="" id="box-search" transform="translate(0.11 0.5)">
                        <path _ngcontent-wkc-c98="" id="Path_247" data-name="Path 247"
                              d="M3.17,7.44,44.45,31.329l41-23.749" transform="translate(2.867 19.992)" fill="none"
                              stroke="#162C5B" stroke-linecap="round" stroke-linejoin="round" stroke-width="5px"></path>
                        <path _ngcontent-wkc-c98="" id="Path_248" data-name="Path 248" d="M12,54.942V12.54"
                              transform="translate(35.317 38.734)" fill="none" stroke="#162C5B" stroke-linecap="round"
                              stroke-linejoin="round" stroke-width="5px"></path>
                        <path _ngcontent-wkc-c98="" id="Path_249" data-name="Path 249"
                              d="M92.243,52.63V35.52c0-6.452-4.628-14.305-10.285-17.438L56.994,4.244c-5.329-2.992-14.025-2.992-19.355,0L12.675,18.082C7.018,21.214,2.39,29.068,2.39,35.52V61.98c0,6.451,4.628,14.305,10.285,17.438L37.639,93.256A20.251,20.251,0,0,0,47.317,95.5a20.251,20.251,0,0,0,9.677-2.244"
                              transform="translate(0 0)" fill="none" stroke="#162C5B" stroke-linecap="round"
                              stroke-linejoin="round" stroke-width="5px"></path>
                        <path _ngcontent-wkc-c98="" id="Path_250" data-name="Path 250"
                              d="M30.96,44.92A14.96,14.96,0,1,0,16,29.96,14.96,14.96,0,0,0,30.96,44.92Z"
                              transform="translate(50.017 47.775)" fill="none" stroke="#162C5B" stroke-linecap="round"
                              stroke-linejoin="round" stroke-width="5px"></path>
                        <path _ngcontent-wkc-c98="" id="Path_251" data-name="Path 251" d="M26.675,25.675,22,21"
                              transform="translate(72.067 69.825)" fill="none" stroke="#162C5B" stroke-linecap="round"
                              stroke-linejoin="round" stroke-width="5px"></path>
                        <path _ngcontent-wkc-c98="" id="Path_256" data-name="Path 256" d="M52.328,47.265V29.98L7.51,4.1"
                              transform="translate(19.493 6.02)" fill="none" stroke="#162C5B" stroke-linecap="round"
                              stroke-linejoin="round" stroke-width="5px"></path>
                    </g>
                </svg>
                <p><?= __('Search for the product you want.', 'bakala') ?></p>
            </div>
        </div>
    </div>
</div>

<script>
    function skeletonLoader() {
        document.querySelectorAll(".skeleton_loader_enable .bk_stories__elements__item").forEach(function (item) {
            item.querySelector(".bk_stories__skeleton--image").style.display = 'none';
            item.querySelector(".bk_stories__elements__item__picture--img").style.display = 'block';
            item.querySelector(".bk_stories__skeleton--title").style.display = 'none';
            item.querySelector(".bk_stories__elements__item__title").style.display = 'block';
            item.querySelector(".bk_stories__elements__item__picture svg").style.display = 'block';
        });

        var imgElement = document.querySelector(".bakala_picture_slider .swiper-slide img");

        if (imgElement) {
            var imageHeight = imgElement.clientHeight;
            document.querySelectorAll(".bakala_picture_slider .swiper-skeleton-loader").forEach(function (loader) {
                loader.style.height = imageHeight + 'px';
            });
        }

        document.querySelectorAll(".bakala_picture_slider .swiper-skeleton-loader").forEach(function (loader) {
            loader.style.display = 'none';
        });

        document.querySelectorAll(".skeleton_loader_enable .bakala_picture_slider .swiper").forEach(function (swiper) {
            swiper.style.display = 'block';
        });

        document.querySelectorAll(".bakala_banner_skeleton").forEach(function (banner) {
            banner.style.display = 'none';
        });
        document.querySelectorAll(".bakala_banner").forEach(function (banner) {
            banner.style.display = 'block';
        });

        document.querySelectorAll(".skeleton_loader_enable .product-box-inner").forEach(function (inner) {
            inner.style.display = 'block';
        });

        document.querySelectorAll(".skeleton_loader_enable .product-skeleton-loader").forEach(function (loader) {
            loader.style.display = 'none';
        });

        document.querySelectorAll(".skeleton_loader_enable .bakala_pro_carousel").forEach(function (carousel) {
            carousel.classList.remove("pro_carousel_loading");
        });
    }

    setTimeout(function () {
        skeletonLoader();
    }, 500);
</script>