<?php global $bakala_options;
if(isset($bakala_options['bottom_navbar_type']) && $bakala_options['bottom_navbar_enable'] == 1){
    $cart_count = 0;
     if(class_exists('WooCommerce')){
$cart_count = bakala_get_cart_count();
     }

if ($bakala_options['bottom_navbar_type'] == 1) {
    $show_label = true;
} else {
    $show_label = false;
}

?>

<nav class="mobile-bottom-nav">
 <?php if (isset($bakala_options['modern_header_mobile_style']) && $bakala_options['modern_header_mobile_style'] == 'two'): ?>
        <div class="mobile-bottom-nav__item">
            <a class="mobile-bottom-nav__item-content" id="icon-menu" href="#">
                <i class="mobile-bottom-nav__item-icon bakala-menu-icon "></i>
                <?php if ($show_label): ?>
                    <span class="mobile-bottom-nav__item-label"><?= __('منو', 'bakala') ?></span>
                <?php endif; ?>
            </a>
        </div>
    <?php endif;
    if ($bakala_options['bottom_navbar_home']): ?>
        <div class="mobile-bottom-nav__item">
            <a class="mobile-bottom-nav__item-content" href="<?= get_home_url(); ?>">
                <i class="mobile-bottom-nav__item-icon bakala-home-icon "></i>
                <?php if ($show_label): ?>
                    <span class="mobile-bottom-nav__item-label"><?= __('خانه', 'bakala') ?></span>
                <?php endif; ?>
            </a>
        </div>
    <?php endif;
    if (($bakala_options['modern_header_mobile'] == 1 || is_null($bakala_options['modern_header_mobile'])) && $bakala_options['modern_header_mobile_style'] != 'two') {
        ?>
        <div class="mobile-bottom-nav__item mobile_bottom_nav_search">
            <a class="mobile-bottom-nav__item-content" href="#search" data-bs-toggle="modal" data-bs-toggle="modal"
               data-bs-target="#search_modal">
                <i class="mobile-bottom-nav__item-icon bakala-search-icon"></i>
                <?php if ($show_label): ?>
                    <span class="mobile-bottom-nav__item-label"><?= __('جستجو', 'bakala') ?></span>
                <?php endif; ?>
            </a>
        </div>
    <?php }
    if ( class_exists('WooCommerce') && $bakala_options['modern_header_mobile'] == 1 || is_null($bakala_options['modern_header_mobile'])) {
        ?>
        <div class="mobile-bottom-nav__item mobile_bottom_nav_tell">
            <a class="mobile-bottom-nav__item-content" href="<?= get_permalink(wc_get_page_id('cart')); ?>">
                <i class="mobile-bottom-nav__item-icon bakala-cart-icon">
                    <span class="bakala-cart-count" id="BasketHeaderCount"><?= $cart_count ?></span>
                </i>
            </a>
        </div>

        <?php
    }
    if ($bakala_options['bottom_navbar_categories']):
        if ($bakala_options['categories_page']) {
            $link = $bakala_options['categories_page'];
        } else {
            $link = wc_get_page_id('shop');
        }
        ?>
        <div class="mobile-bottom-nav__item mobile_bottom_nav_cats">
            <a class="mobile-bottom-nav__item-content" href="<?= get_permalink($link); ?>">
                <i class="mobile-bottom-nav__item-icon bakala-categories-icon"></i>
                <?php if ($show_label): ?>
                    <span class="mobile-bottom-nav__item-label"><?= __('category', 'bakala') ?></span>
                <?php endif; ?>
            </a>
        </div>
    <?php endif; ?>

    <?php
    if ($bakala_options['modern_header_mobile'] == 1 || is_null($bakala_options['modern_header_mobile'])) {
        ?>
        <div class="mobile-bottom-nav__item mobile_bottom_nav_account">
            <?php
            if (is_user_logged_in()) {
                ?>
                <a class="mobile-bottom-nav__item-content"
                   href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')); ?>">
                    <i class="mobile-bottom-nav__item-icon bakala-account-icon"></i>
                    <?php if ($show_label): ?>
                        <span class="mobile-bottom-nav__item-label"><?= __('account', 'bakala') ?></span>
                    <?php endif; ?>
                </a>
                <?php
            } else {
                if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true) {
                    if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                        ?>
                        <a class="mobile-bottom-nav__item-content" href="?login=true" onclick="jQuery('this').digits_login_modal(jQuery(this));return false;" attr-disclick="1" class="digits-login-modal" type="1">

                        <i class="mobile-bottom-nav__item-icon bakala-account-icon"></i>
                        <?php if ($show_label): ?>
                            <span class="mobile-bottom-nav__item-label"><?= __('حساب کاربری', 'bakala') ?></span>
                        <?php endif; ?>
                    </a>
                        <?php
                    } else {
                        ?>
                        <button type="button" style="background: transparent;border: none;"
                                class="mobile-bottom-nav__item-content" data-bs-toggle="modal"
                                data-bs-target="#bakala_login">
                            <i class="mobile-bottom-nav__item-icon bakala-account-icon"></i>
                            <?php if ($show_label): ?>
                                <span class="mobile-bottom-nav__item-label"><?= __('account', 'bakala') ?></span>
                            <?php endif; ?>
                        </button>
                        <?php
                    }
                } else {
                    ?>
                    <a class="mobile-bottom-nav__item-content"
                       href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>">

                        <i class="mobile-bottom-nav__item-icon bakala-account-icon"></i>
                        <?php if ($show_label): ?>
                            <span class="mobile-bottom-nav__item-label"><?= __('حساب کاربری', 'bakala') ?></span>
                        <?php endif; ?>
                    </a>
                    <?php
                }
            }
            ?>
        </div>
    <?php } ?>
    <?php
    if ($bakala_options['modern_header_mobile'] == 0 && isset($bakala_options['modern_header_mobile'])) {
        ?>
        <div class="mobile-bottom-nav__item mobile_bottom_nav_cart">
            <a class="mobile-bottom-nav__item-content" href="<?= get_permalink(wc_get_page_id('cart')); ?>">
                <i class="mobile-bottom-nav__item-icon bakala-cart-icon"><span class="bakala-cart-count"
                                                                               id="BasketHeaderCount"><?= $cart_count ?></span></i>
            </a>
        </div>
        <div class="mobile-bottom-nav__item mobile_bottom_nav_tell">
            <a class="mobile-bottom-nav__item-content"
               href="<?= !empty($bakala_options['headerinfobar_tell_phone']) ? 'tel:' . $bakala_options['headerinfobar_tell_phone'] : get_permalink($bakala_options['headerinfobar_tell_page']); ?>">
                <i class="mobile-bottom-nav__item-icon bakala-phone-icon"></i>
                <?php if ($show_label): ?>
                    <span class="mobile-bottom-nav__item-label"><?= __('تماس با ما', 'bakala') ?></span>
                <?php endif; ?>
            </a>
        </div>
        <div class="mobile-bottom-nav__item mobile_bottom_nav_account">
            <?php
            if (is_user_logged_in()) {
            ?>
            <a class="mobile-bottom-nav__item-content"
               href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')); ?>">
                <?php
                }else{
                if (isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true) {
                if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) {
                    echo do_shortcode('[dm-modal]');
                }else{
                ?>
                <a class="mobile-bottom-nav__item-content" data-bs-toggle="modal" data-bs-target="#bakala_login"
                   href="#">
                    <?php
                    }
                    }else{
                    ?>
                    <a class="mobile-bottom-nav__item-content"
                       href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>">
                        <?php
                        }
                        }
                        ?>
                        <i class="mobile-bottom-nav__item-icon bakala-account-icon"></i>
                        <?php if ($show_label): ?>
                            <span class="mobile-bottom-nav__item-label"><?= __('account', 'bakala') ?></span>
                        <?php endif; ?>
                    </a>
        </div>
        <?php
    }
    ?>
</nav>
<!--created by danial frd-->
<script>
    // jQuery(document).ready(function($) {
    //     $(document).find('.mobile-bottom-nav').find('.mobile-bottom-nav__item').removeClass('mobile-bottom-nav__item--active');
    // })

    jQuery(document).ready(function ($) {
        $('.mobile-bottom-nav__item-content').click(function () {
            $(this).parents('.mobile-bottom-nav').children('.mobile-bottom-nav__item').removeClass('mobile-bottom-nav__item--active');
            $(this).parent().addClass('mobile-bottom-nav__item--active');
        })
    })
</script>
<!--created by danial frd-->
<?php }