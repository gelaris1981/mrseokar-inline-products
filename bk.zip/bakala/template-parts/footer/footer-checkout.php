<?php

global $bakala_options;

?>
<?php if (is_cart() || is_checkout()) { ?>
</div><!-- #content -->
<footer class="footer-section checkout-footer">
  	<?php if ( isset($bakala_options['footerinfobar']) && $bakala_options['footerinfobar'] ) { ?>
        <div class="row footerinfobar">
			<div class="container-bakala">
				<div class="container-bakala footer-div">
					<ul>
						<?php if ( isset($bakala_options['footerinfobar_email']) && $bakala_options['footerinfobar_email'] ) { ?>
						<li><i class="icon icon-info-message"></i><span><?php _e('Email: ','bakala'); ?></span><a><?php echo $bakala_options['footerinfobar_email'];?></a></li>
						<?php } ?>
						<?php if ( isset($bakala_options['footerinfobar_faq']) && $bakala_options['footerinfobar_faq'] ) { ?>
						<li><i class="icon icon-info-faq"></i><a href="<?php echo get_permalink($bakala_options['footerinfobar_faq_p']); ?>"><?php echo $bakala_options['footerinfobar_faq'];?></a></li>
						<?php } ?>
						<?php if ( isset($bakala_options['footerinfobar_phone']) && $bakala_options['footerinfobar_phone'] ) { ?>
						<li><i class="icon icon-info-tell"></i><span><?php _e('Phone: ','bakala'); ?></span><a href="<?php echo get_permalink($bakala_options['footerinfobar_phone_p']); ?>"><?php echo $bakala_options['footerinfobar_phone'];?></a></li>
						<?php } ?>
					</ul>
					<div class="copun-notice">
					    <?php _e('It is possible to use the gift card or discount code on the payment page.','bakala'); ?>
					</div>
					<div class="no-padding section-two">
						<span><?php if ( isset($bakala_options['copyright-two']) && $bakala_options['copyright-two'] ) { echo $bakala_options['copyright-two']; } ?></span>
					</div>
				</div>
			</div>
        </div>
	<?php } ?>
</footer>
	<?php } ?>

<?php if(!empty($bakala_options['custom_js'])){ echo '<script>'.$bakala_options['custom_js'].' </script>'; } ?>
<div class="dialog__overlay" style="display:none;"></div>
