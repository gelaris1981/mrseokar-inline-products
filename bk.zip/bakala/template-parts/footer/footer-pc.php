<?php

global $bakala_options;

?>

    </div><!-- #content -->

<?php
if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('footer')) {
    if (isset($bakala_options['footerproducts']) && $bakala_options['footerproducts'] && class_exists('WooCommerce')) {
        white_catviewed_products();
    }
    $display = true;
    if (!is_front_page()) {
        if (isset($bakala_options['footer-home']) && $bakala_options['footer-home']) {
            $display = false;
        }
    }
    if ($bakala_options['footer_style'] == 'old') {
        ?>
        <div class="footer-about">
            <?php if (isset($bakala_options['scrollup']) && $bakala_options['scrollup'] == true) : ?>
                <div class="u-flex u-justify-between u-items-center items-center">
                    <?php if($bakala_options['footer_logo'] != 0){ ?>
                        <div class="c-new-footer__logo"> <?php
                        if (isset($bakala_options['site_footer_logo']) && !empty($bakala_options['site_footer_logo']['url'])) {
                            $logo_href = $bakala_options['site_footer_logo']['url'];
                        } else {
                            $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                        }
                        ?>
                        <div property="name">
                            <div class="white-logo">
                                <img
                                        src="<?php echo $logo_href; ?>"
                                        alt="<?php echo get_bloginfo(); ?>"
                                >
                            </div>
                            <?php


                            ?>
                            <?php if (isset($bakala_options['dark_logo_mobile']) && strlen($bakala_options['dark_logo_mobile']['url']) > 0) {
                                $dark_logo = $bakala_options['dark_logo_mobile']['url']; ?>
                                <a class="dark-logo" href="<?php echo home_url('/'); ?>"
                                   title="<?php echo get_bloginfo(); ?>" target="_self">
                                    <img
                                            src="<?php echo $dark_logo; ?>"
                                            alt="<?php echo get_bloginfo(); ?>"
                                    >
                                </a>
                            <?php } ?>

                            <?php
                            ?>

                        </div>
                    </div>
                    <?php } ?>
                    <a href="#" id="scrollUp">
                        <div id="js-jump-to-top" class="c-new-footer__jump-to-top-container"><span
                                    class="c-new-footer__jump-to-top-label"><?php echo _e('Back to Top', 'bakala'); ?></span>
                            <span class="c-new-footer__jump-to-top-icon"></span>
                        </div>
                    </a>
                </div>

                <?php if (isset($bakala_options['footerinfobar']) && $bakala_options['footerinfobar']) { ?>
                    <div class="c-new-footer__contact-info-container">
                    <?php if (isset($bakala_options['footerinfobar_phone']) && $bakala_options['footerinfobar_phone']) { ?>
                        <span><?php _e('Phone: ', 'bakala'); ?></span>
                        <a class="c-new-footer__phone-number"
                           href="<?php echo get_permalink($bakala_options['footerinfobar_phone_p']); ?>"><?php echo $bakala_options['footerinfobar_phone']; ?></a>
                    <?php } ?>
                    <?php if (isset($bakala_options['footerinfobar_slogan']) && $bakala_options['footerinfobar_slogan']) { ?>
                        <span class="c-new-footer__phone-number-separator">|</span>
                        <span><?php echo $bakala_options['footerinfobar_slogan']; ?></span>
                    <?php } ?>
                    <span class="c-new-footer__phone-number-separator">|</span>
                    <?php if (isset($bakala_options['footerinfobar_email']) && $bakala_options['footerinfobar_email']) { ?>
                        <span><?php _e('Email: ', 'bakala'); ?></span><a
                                class="c-new-footer__email"><?php echo $bakala_options['footerinfobar_email']; ?></a>
                        </div>
                    <?php } ?>
                <?php } ?>
                <?php if(!empty($bakala_options['footer_location'])){ ?>
                    <div class="c-new-footer__contact-info-container">
                        <div class="bakala_footer_support_text">
                            <i class="bakala-icon icon-map"></i>
                            <span><?php echo $bakala_options['footer_location']; ?></span>
                        </div>
                    </div>
                    <?php } ?>
            <?php endif; ?>
        </div>
        <footer class="footer-section">
            <div class="container-bakala">

                <div class="row footer-newsletter">
                    <div class="container-bakala">
                        <div class="container-bakala footer-div">
                            <div class="footer-svg">
                                <nav class="c-footer__feature-innerbox">
                                    <?php if ($bakala_options['switch_Express_Shipping'] == true) { ?>
                                    <<?= empty($bakala_options['Express_Shipping']) ? 'div' : 'a' ?>
                                    class="c-footer__badge"
                                    href="<?php if (isset($bakala_options['Express_Shipping']) && $bakala_options['Express_Shipping']) {
                                        echo get_permalink($bakala_options['Express_Shipping']);
                                    } ?>" target="_blank">
                                    <div class="c-footer__feature-item c-footer__feature-item--1" <?php if ($bakala_options['img_Express_Shipping']['url'] != '') {
                                        echo 'style="background-image:url(' . $bakala_options['img_Express_Shipping']['url'] . ')"';
                                    } ?>>
                                        <?php echo $bakala_options['text_Express_Shipping']; ?>
                                    </div>
                                </<?= empty($bakala_options['Express_Shipping']) ? 'div' : 'a' ?>>
                                <?php } ?>
                                <?php if ($bakala_options['switch_Payment_at_the_place'] == true) { ?>
                                <<?= empty($bakala_options['Payment_at_the_place']) ? 'div' : 'a' ?>
                                class="c-footer__badge"
                                href="<?php if (isset($bakala_options['Payment_at_the_place']) && $bakala_options['Payment_at_the_place']) {
                                    echo get_permalink($bakala_options['Payment_at_the_place']);
                                } ?>" target="_blank">
                                <div class="c-footer__feature-item c-footer__feature-item--4" <?php if ($bakala_options['img_Payment_at_the_place']['url'] != '') {
                                    echo 'style="background-image:url(' . $bakala_options['img_Payment_at_the_place']['url'] . ')"';
                                } ?>>
                                    <?php echo $bakala_options['text_Payment_at_the_place']; ?>
                                </div>
                            </<?= empty($bakala_options['Payment_at_the_place']) ? 'div' : 'a' ?>>
                            <?php } ?>
                            <?php if ($bakala_options['switch_back_guarantee'] == true) { ?>
                            <<?= empty($bakala_options['back_guarantee']) ? 'div' : 'a' ?> class="c-footer__badge"
                            href="<?php if (isset($bakala_options['back_guarantee']) && $bakala_options['back_guarantee']) {
                                echo get_permalink($bakala_options['back_guarantee']);
                            } ?>" target="_blank">
                            <div class="c-footer__feature-item c-footer__feature-item--5" <?php if ($bakala_options['img_back_guarantee']['url'] != '') {
                                echo 'style="background-image:url(' . $bakala_options['img_back_guarantee']['url'] . ')"';
                            } ?>>
                                <?php echo $bakala_options['text_back_guarantee']; ?>
                            </div>
                        </<?= empty($bakala_options['back_guarantee']) ? 'div' : 'a' ?>>
                        <?php } ?>
                        <?php if ($bakala_options['switch_Guarantee_of_Origin'] == true) { ?>
                        <<?= empty($bakala_options['Guarantee_of_Origin']) ? 'div' : 'a' ?> class="c-footer__badge"
                        href="<?php if (isset($bakala_options['Guarantee_of_Origin']) && $bakala_options['Guarantee_of_Origin']) {
                            echo get_permalink($bakala_options['Guarantee_of_Origin']);
                        } ?>" target="_blank">
                        <div class="c-footer__feature-item c-footer__feature-item--6" <?php if ($bakala_options['img_Guarantee_of_Origin']['url'] != '') {
                            echo 'style="background-image:url(' . $bakala_options['img_Guarantee_of_Origin']['url'] . ')"';
                        } ?>>
                            <?php echo $bakala_options['text_Guarantee_of_Origin']; ?>
                        </div>
                    </<?= empty($bakala_options['Guarantee_of_Origin']) ? 'div' : 'a' ?>>
                    <?php } ?>
                    </nav>
                </div>

                <div class="col-md-9 no-padding">
                    <div class="row col-md-4">
                        <?php if (is_active_sidebar('subscribe-col-1')) {
                            dynamic_sidebar('subscribe-col-1');
                        } ?>
                    </div>
                    <div class="row col-md-4">
                        <?php if (is_active_sidebar('subscribe-col-2')) {
                            dynamic_sidebar('subscribe-col-2');
                        } ?>
                    </div>
                    <div class="row col-md-4">
                        <?php if (is_active_sidebar('subscribe-col-3')) {
                            dynamic_sidebar('subscribe-col-3');
                        } ?>
                    </div>
                </div>

                <div class="col-md-3 no-padding">
                    <div class="subscribe-social">
                        <div class="col-md-5 no-padding">
                            <?php if (isset($bakala_options['social_title']) && $bakala_options['social_title']) { ?>
                                <span class="widget-title"><?php echo $bakala_options['social_title']; ?></span>
                            <?php } ?>
                            <ul class="socials">
                                <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['facebook']; ?>"><i
                                                    class="icon icon-footer-facebook"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['twitter']; ?>"><i
                                                    class="icon icon-footer-twitter"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['googleplus']; ?>"><i
                                                    class="icon icon-footer-googleplus"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['instagram']; ?>"><i
                                                    class="icon icon-footer-instagram"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['youtube']; ?>"><i
                                                    class="icon icon-footer-aparat"></i></a>
                                    </li>
                                <?php } ?>
                                <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                    <li>
                                        <a target="_blank" rel="nofollow"
                                           href="<?php echo $bakala_options['vimeo']; ?>"><i
                                                    class="icon icon-footer-telegram"></i></a>
                                    </li>
                                <?php } ?>
                                <?php
                                if (is_array($bakala_options['other_socials'])) {
                                    foreach ($bakala_options['other_socials'] as $item) {
                                        if (!empty($item['image'])) {
                                            ?>
                                            <li>
                                                <a target="_blank" rel="nofollow" href="<?php echo $item['url']; ?>">
                                                    <img
                                                            src="<?php echo $item['image'] ?>"
                                                            class="other_socials_img"
                                                    >
                                                </a>
                                            </li>
                                        <?php }
                                    }
                                } ?>
                            </ul>
                        </div>
                    </div>
                    <?php if (isset($bakala_options['footersubscribe']) && $bakala_options['footersubscribe']) { ?>

                        <div class="subscribe-form-div">
                            <div class="widget-title"><?php echo __($bakala_options['footer_newsletter_title'],'bakala'); ?></div>
                            <div id="subscribe-form">
                                <?php echo do_shortcode($bakala_options["footer_newsletter_marketing_text"]); ?>
                            </div>
                        </div>
                    <?php } ?>

                </div>
            </div>
            </div>
            </div>

            <?php if (isset($bakala_options['footerinfobar']) && $bakala_options['footerinfobar']) { ?>
                <div class="row footerinfobar">
                    <div class="container-bakala">
                        <div class="container-bakala footer-div">
                            <?php if (isset($bakala_options['show-apps']) && $bakala_options['show-apps']) { ?>
                                <ul class="apps">

                                    <div class="c-new-footer__app-links-container"><a class="u-flex">
                                    <?php if(isset($bakala_options['app_img']) && !empty($bakala_options['app_img']['url'])){ ?>
                                            <div class="c-new-footer__app-links-logo">
                                                <img
                                                        src="<?php echo $bakala_options['app_img']['url']; ?>"
                                                >
                                            </div>
                                            <?php } ?>
                                            <div class="c-new-footer__app-links-label">
                                                <?php if (isset($bakala_options['app_title']) && $bakala_options['app_title']) { ?>
                                                    <?php echo $bakala_options['app_title']; ?>
                                                <?php } ?>
                                            </div>
                                        </a>
                                        <div class="c-new-footer__app-images-container">
                                            <?php if (isset($bakala_options['google_play']) && $bakala_options['google_play']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['google_play']; ?>"
                                                       class="google_play-icon"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/google_play.png'; ?>"
                                                                alt="google play icon"></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['soundcloud']) && $bakala_options['soundcloud']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['soundcloud']; ?>"
                                                       class="android-icon"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/android_app.png'; ?>"
                                                                alt="android app icon"></a>
                                                </li>
                                            <?php } ?>

                                            <?php if (isset($bakala_options['myket']) && $bakala_options['myket']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['myket']; ?>" class="myket"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/myket.png'; ?>"
                                                                alt="myket icon"></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['vine']) && $bakala_options['vine']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['vine']; ?>"
                                                       class="ios-icon"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/ios_app.png'; ?>"
                                                                alt="ios app icon"></a>
                                                </li>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </ul> <?php } ?>
                        </div>
                    </div>
                </div>
            <?php } ?>

            <?php if (isset($bakala_options['footermenu']) && $bakala_options['footermenu'] && class_exists('WooCommerce')) { ?>
                <div class="row footer-bottom-widgets">
                    <div class="container-bakala">
                        <div class="container-bakala footer-div">
                            <div class="row">
                                <?php
                                for ($i = 1; $i <= 6; $i++) {
                                    $optionname = 'footermenu_cat' . $i;
                                    if (isset($bakala_options[$optionname]) && $bakala_options[$optionname]) {
                                        $cat = get_term($bakala_options[$optionname], 'product_cat');
                                        if ($cat) : ?>
                                            <div class="col-md-2">
                                                <div class="widget-title">
                                                    <a href="<?php echo get_term_link($cat); ?>"><?php echo $cat->name; ?></a>
                                                </div>
                                                <ul>
                                                    <?php
                                                    $childs = get_term_children($cat->term_id, 'product_cat');
                                                    foreach ($childs as $child) {
                                                        $getchild = get_term($child, 'product_cat');
                                                        $childpar = $getchild->parent;
                                                        if ($childpar == $cat->term_id) {
                                                            echo '<li><a href="' . get_term_link($getchild) . '">' . $getchild->name . '</a></li>';
                                                        }
                                                    }
                                                    ?>
                                                </ul>
                                            </div>
                                        <?php endif;
                                    }
                                }

                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php } ?>


            <?php
            $display = true;
            if (!is_front_page()) {
                if (isset($bakala_options['footer-home']) && $bakala_options['footer-home']) {
                    $display = false;
                }
            }

            ?>
            <div class="row about-bar">
                <div class="container-bakala">
                    <div class="container-bakala footer-div">
                        <?php if ($display) { ?>
                            <div class="col-md-9 no-padding footer_description">
                                <?php if (isset($bakala_options['footer_credit']) && !empty($bakala_options['footer_credit'])) {
                                    echo '<div class="footer_description_inner">';
                                    echo $bakala_options['footer_credit'];
                                    echo '</div>';
                                    echo '<span class="footer_more" data-less="' . __('Less', 'bakala') . '" data-more="' . __('More', 'bakala') . '">' . __('More', 'bakala') . '</span>';
                                } ?>
                            </div>
                        <?php } ?>

                        <div class="col-md-3 no-padding">
                            <?php if (isset($bakala_options['footer_credit_left_html'])) {
                                echo $bakala_options['footer_credit_left_html'];
                            } ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row copyright-bar">
                <div class="container-bakala">
                    <div class="container-bakala footer-div">


                        <div class="copyright-bar-text">
                            <div class="no-padding section-one">
                                    <span><?php if (isset($bakala_options['copyright-one']) && $bakala_options['copyright-one']) {
echo $bakala_options['copyright-one'];
                                        } ?></span>
                            </div>
<div class="no-padding section-two">
    <?php 
  
            echo $bakala_options['copyright-two'];
    
    ?>
</div>


                        </div>
                    </div>
                </div>
            </div>
            </div>
        </footer>
        <?php
    } elseif ($bakala_options['footer_style'] == 'mobit') {
        ?>
        <footer class="bakala_mt_footer footer-container">
            <div class="d-flex justify-content-center w-100">
                <div class="bakala-jump-to-top" id="js-jump-to-top">
                    <span><?= __('Back to top', 'bakala') ?></span>
                    <span class="c-new-footer__jump-to-top-icon"></span>
                </div>
            </div>
            <div class="bakala_mt_prefooter bg-light rounded-3 d-lg-flex justify-content-between">
                <div class="d-none d-lg-flex flex-column bakala_footer_support">
                    <div class="bakala_footer_support_title">
                        <?= empty($bakala_options['support-label']) ? __('Support','bakala') : $bakala_options['support-label']; ?>
                    </div>
                    <div class="d-flex text-sm">
                        <span class="bakala_footer_support_label"><?= empty($bakala_options['footerinfobar_phone_label']) ? __('Phone', 'bakala') : __($bakala_options['footerinfobar_phone_label'],'bakala'); ?> :</span>
                        <div class="support bakala_footer_support_text">
                            <a href="tel:<?php echo $bakala_options['footerinfobar_phone']; ?>"><?php echo $bakala_options['footerinfobar_phone']; ?></a>
                            <span class="text-sm font-weight-bold">
                            <?php echo $bakala_options['footerinfobar_slogan']; ?>
                        </span>
                        </div>
                    </div>
                    <?php if(!empty($bakala_options['footer_location'])){ ?>
                    <div class="d-flex text-sm">
                        <div class="bakala_footer_support_text">
                            <i class="bakala-icon icon-map"></i>
                            <span><?php echo $bakala_options['footer_location']; ?></span>
                        </div>
                    </div>
                    <?php } ?>
                    <div class="d-flex font-weight-bold text-sm">
                        <span class="bakala_footer_support_label"><?= empty($bakala_options['footerinfobar_email_label']) ? __('Email', 'bakala') : $bakala_options['footerinfobar_email_label']; ?> :</span>
                        <a href="mailto:<?php echo $bakala_options['footerinfobar_email']; ?>"
                           class="text-dark font-medium bakala_footer_support_text">
                            <?php echo $bakala_options['footerinfobar_email']; ?>
                        </a>
                    </div>
                </div>
                <div class="align-items-center d-lg-flex lg:flex-row-reverse lg:space-x-2 row row-cols-2 row-cols-4 row-rows-2">
                    <?php if ($bakala_options['switch_Express_Shipping'] == true) { ?>
                    <div class="bakala_footer_feature">
                        <<?= empty($bakala_options['Express_Shipping']) ? 'div' : 'a' ?> class="h-20 col-center w-36"
                        href="<?php if (isset($bakala_options['Express_Shipping']) && $bakala_options['Express_Shipping']) {
                            echo get_permalink($bakala_options['Express_Shipping']);
                        } ?>" target="_blank">
                        <span class="w-14 h-14 lg:w-16 lg:h-16 block">
                                <img src="<?= $bakala_options['img_Express_Shipping']['url'] ?>" loading="lazy"
                                     width="64" height="64"
                                     alt="<?php echo $bakala_options['text_Express_Shipping']; ?>"
                                     class="bakala_footer_feature_icon">
                            </span>
                        <div class="bakala_footer_feature_title">
                            <?php echo $bakala_options['text_Express_Shipping']; ?>
                        </div>
                    </<?= empty($bakala_options['Express_Shipping']) ? 'div' : 'a' ?>>
                </div>
                <?php } ?>
                <?php if ($bakala_options['switch_Payment_at_the_place'] == true) { ?>
                    <div class="bakala_footer_feature">
                        <<?= empty($bakala_options['Payment_at_the_place']) ? 'div' : 'a' ?> class="h-20 col-center w-36"
                           href="<?php if (isset($bakala_options['Payment_at_the_place']) && $bakala_options['Payment_at_the_place']) {
                               echo get_permalink($bakala_options['Payment_at_the_place']);
                           } ?>" target="_blank">
                            <span class="w-14 h-14 lg:w-16 lg:h-16 block">
                                <img src="<?= $bakala_options['img_Payment_at_the_place']['url'] ?>" loading="lazy"
                                     width="64" height="64"
                                     alt="<?php echo $bakala_options['text_Payment_at_the_place']; ?>"
                                     class="bakala_footer_feature_icon">
                            </span>
                            <div class="bakala_footer_feature_title">
                                <?php echo $bakala_options['text_Payment_at_the_place']; ?>
                            </div>
                        </<?= empty($bakala_options['Payment_at_the_place']) ? 'div' : 'a' ?>>
                    </div>
                <?php } ?>
                <?php if ($bakala_options['switch_back_guarantee'] == true) { ?>
                <div class="bakala_footer_feature">
                    <<?= empty($bakala_options['back_guarantee']) ? 'div' : 'a' ?> class="h-20 col-center w-36"
                    href="<?php if (isset($bakala_options['back_guarantee']) && $bakala_options['back_guarantee']) {
                        echo get_permalink($bakala_options['back_guarantee']);
                    } ?>" target="_blank">
                    <span class="w-14 h-14 lg:w-16 lg:h-16 block">
                                <img src="<?= $bakala_options['img_back_guarantee']['url'] ?>" loading="lazy" width="64"
                                     height="64" alt="<?php echo $bakala_options['text_back_guarantee']; ?>"
                                     class="bakala_footer_feature_icon">
                            </span>
                    <div class="bakala_footer_feature_title">
                        <?php echo $bakala_options['text_back_guarantee']; ?>
                    </div>
                </<?= empty($bakala_options['back_guarantee']) ? 'div' : 'a' ?>>
            </div>
            <?php } ?>
            <?php if ($bakala_options['switch_Guarantee_of_Origin'] == true) { ?>
                <div class="bakala_footer_feature">
                <<?= empty($bakala_options['Guarantee_of_Origin']) ? 'div' : 'a' ?> class="h-20 col-center w-36"
                href="<?php if (isset($bakala_options['Guarantee_of_Origin']) && $bakala_options['Guarantee_of_Origin']) {
                    echo get_permalink($bakala_options['Guarantee_of_Origin']);
                } ?>" target="_blank">
                <span class="w-14 h-14 lg:w-16 lg:h-16 block">
                                <img src="<?= $bakala_options['img_Guarantee_of_Origin']['url'] ?>" loading="lazy"
                                     width="64" height="64"
                                     alt="<?php echo $bakala_options['text_Guarantee_of_Origin']; ?>"
                                     class="bakala_footer_feature_icon">
                            </span>
                <div class="bakala_footer_feature_title">
                    <?php echo $bakala_options['text_Guarantee_of_Origin']; ?>
                </div>

                </<?= empty($bakala_options['Guarantee_of_Origin']) ? 'div' : 'a' ?>>
                </div>
            <?php } ?>
           </div>
            </div>
            <div class="row footer-newsletter">
                <div class="container-bakala">
                    <div class="container-bakala footer-div">
                        <div class="footer-svg">
                            <nav class="c-footer__feature-innerbox">
                                <?php if ($bakala_options['switch_Express_Shipping'] == true) { ?>
                                <<?= empty($bakala_options['Express_Shipping']) ? 'div' : 'a' ?> class="c-footer__badge"
                                href="<?php if (isset($bakala_options['Express_Shipping']) && $bakala_options['Express_Shipping']) {
                                    echo get_permalink($bakala_options['Express_Shipping']);
                                } ?>" target="_blank">
                                <div class="c-footer__feature-item c-footer__feature-item--1" <?php if ($bakala_options['img_Express_Shipping']['url'] != '') {
                                    echo 'style="background-image:url(' . $bakala_options['img_Express_Shipping']['url'] . ')"';
                                } ?>>
                                    <?php echo $bakala_options['text_Express_Shipping']; ?>
                                </div>
                            </<?= empty($bakala_options['Express_Shipping']) ? 'div' : 'a' ?>>
                            <?php } ?>
                            <?php if ($bakala_options['switch_Payment_at_the_place'] == true) { ?>
                            <<?= empty($bakala_options['Payment_at_the_place']) ? 'div' : 'a' ?> class="c-footer__badge"
                            href="<?php if (isset($bakala_options['Payment_at_the_place']) && $bakala_options['Payment_at_the_place']) {
                                echo get_permalink($bakala_options['Payment_at_the_place']);
                            } ?>" target="_blank">
                            <div class="c-footer__feature-item c-footer__feature-item--4" <?php if ($bakala_options['img_Payment_at_the_place']['url'] != '') {
                                echo 'style="background-image:url(' . $bakala_options['img_Payment_at_the_place']['url'] . ')"';
                            } ?>>
                                <?php echo $bakala_options['text_Payment_at_the_place']; ?>
                            </div>
                        </<?= empty($bakala_options['Payment_at_the_place']) ? 'div' : 'a' ?>>
                        <?php } ?>
                        <?php if ($bakala_options['switch_back_guarantee'] == true) { ?>
                        <<?= empty($bakala_options['back_guarantee']) ? 'div' : 'a' ?> class="c-footer__badge"
                        href="<?php if (isset($bakala_options['back_guarantee']) && $bakala_options['back_guarantee']) {
                            echo get_permalink($bakala_options['back_guarantee']);
                        } ?>" target="_blank">
                        <div class="c-footer__feature-item c-footer__feature-item--5" <?php if ($bakala_options['img_back_guarantee']['url'] != '') {
                            echo 'style="background-image:url(' . $bakala_options['img_back_guarantee']['url'] . ')"';
                        } ?>>
                            <?php echo $bakala_options['text_back_guarantee']; ?>
                        </div>
                    </<?= empty($bakala_options['back_guarantee']) ? 'div' : 'a' ?>>
                    <?php } ?>
                    <?php if ($bakala_options['switch_Guarantee_of_Origin'] == true) { ?>
                    <<?= empty($bakala_options['Guarantee_of_Origin']) ? 'div' : 'a' ?> class="c-footer__badge"
                    href="<?php if (isset($bakala_options['Guarantee_of_Origin']) && $bakala_options['Guarantee_of_Origin']) {
                        echo get_permalink($bakala_options['Guarantee_of_Origin']);
                    } ?>" target="_blank">
                    <div class="c-footer__feature-item c-footer__feature-item--6" <?php if ($bakala_options['img_Guarantee_of_Origin']['url'] != '') {
                        echo 'style="background-image:url(' . $bakala_options['img_Guarantee_of_Origin']['url'] . ')"';
                    } ?>>
                        <?php echo $bakala_options['text_Guarantee_of_Origin']; ?>
                    </div>
                </<?= empty($bakala_options['Guarantee_of_Origin']) ? 'div' : 'a' ?>>
                <?php } ?>
                </nav>
            </div>

            <div class="col-md-9 no-padding">
                <div class="row col-md-4">
                    <?php if (is_active_sidebar('subscribe-col-1')) {
                        dynamic_sidebar('subscribe-col-1');
                    } ?>
                </div>
                <div class="row col-md-4">
                    <?php if (is_active_sidebar('subscribe-col-2')) {
                        dynamic_sidebar('subscribe-col-2');
                    } ?>
                </div>
                <div class="row col-md-4">
                    <?php if (is_active_sidebar('subscribe-col-3')) {
                        dynamic_sidebar('subscribe-col-3');
                    } ?>
                </div>
            </div>

            <div class="col-md-3 no-padding">
                <div class="subscribe-social">
                    <div class="col-md-5 no-padding">
                        <?php if (isset($bakala_options['social_title']) && $bakala_options['social_title']) { ?>
                            <span class="widget-title"><?php echo $bakala_options['social_title']; ?></span>
                        <?php } ?>
                        <ul class="socials">
                            <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['facebook']; ?>"><i
                                                class="icon icon-footer-facebook"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow"
                                       href="<?php echo $bakala_options['twitter']; ?>"><i
                                                class="icon icon-footer-twitter"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow"
                                       href="<?php echo $bakala_options['googleplus']; ?>"><i
                                                class="icon icon-footer-googleplus"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow"
                                       href="<?php echo $bakala_options['instagram']; ?>"><i
                                                class="icon icon-footer-instagram"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow"
                                       href="<?php echo $bakala_options['youtube']; ?>"><i
                                                class="icon icon-footer-aparat"></i></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['vimeo']; ?>"><i
                                                class="icon icon-footer-telegram"></i></a>
                                </li>
                            <?php } ?>
                            <?php
                            if (is_array($bakala_options['other_socials'])) {
                                foreach ($bakala_options['other_socials'] as $item) {
                                    if (!empty($item['image'])) {
                                        ?>
                                        <li>
                                            <a target="_blank" rel="nofollow" href="<?php echo $item['url']; ?>">
                                                <img src="<?php echo $item['image'] ?>" class="other_socials_img">
                                            </a>
                                        </li>
                                    <?php }
                                }
                            } ?>
                        </ul>
                    </div>
                </div>
                <?php if (isset($bakala_options['footersubscribe']) && $bakala_options['footersubscribe']) { ?>

                    <div class="subscribe-form-div">
                        <div class="widget-title"><?php echo __($bakala_options['footer_newsletter_title'],'bakala'); ?></div>
                        <div id="subscribe-form">
                            <?php echo do_shortcode($bakala_options["footer_newsletter_marketing_text"]); ?>
                        </div>
                    </div>
                <?php } ?>

            </div>
            </div>
            </div>
            </div>
            <?php if (isset($bakala_options['footerinfobar']) && $bakala_options['footerinfobar']) { ?>
                <div class="row footerinfobar">
                    <div class="container-bakala">
                        <div class="container-bakala footer-div">
                            <?php if (isset($bakala_options['show-apps']) && $bakala_options['show-apps']) { ?>
                                <ul class="apps">
                                    <div class="c-new-footer__app-links-container"><a class="u-flex">
                                            <div class="c-new-footer__app-links-logo">
                                                <img src="<?php echo $bakala_options['app_img']['url']; ?>">
                                            </div>
                                            <div class="c-new-footer__app-links-label">
                                                <?php if (isset($bakala_options['app_title']) && $bakala_options['app_title']) { ?>
                                                    <?php echo $bakala_options['app_title']; ?>
                                                <?php } ?>
                                            </div>
                                        </a>
                                        <div class="c-new-footer__app-images-container">
                                            <?php if (isset($bakala_options['google_play']) && $bakala_options['google_play']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['google_play']; ?>"
                                                       class="google_play-icon"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/google_play.png'; ?>"
                                                                alt="google play icon"></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['soundcloud']) && $bakala_options['soundcloud']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['soundcloud']; ?>"
                                                       class="android-icon"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/android_app.png'; ?>"
                                                                alt="android app icon"></a>
                                                </li>
                                            <?php } ?>

                                            <?php if (isset($bakala_options['myket']) && $bakala_options['myket']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['myket']; ?>" class="myket"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/myket.png'; ?>"
                                                                alt="myket icon"></a>
                                                </li>
                                            <?php } ?>
                                            <?php if (isset($bakala_options['vine']) && $bakala_options['vine']) { ?>
                                                <li>
                                                    <a target="_blank" rel="nofollow"
                                                       href="<?php echo $bakala_options['vine']; ?>"
                                                       class="ios-icon"><img
                                                                src="<?= get_template_directory_uri() . '/vendor/images/ios_app.png'; ?>"
                                                                alt="ios app icon"></a>
                                                </li>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </ul> <?php } ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
            <?php
            $display = true;
            if (!is_front_page()) {
                if (isset($bakala_options['footer-home']) && $bakala_options['footer-home']) {
                    $display = false;
                }
            }

            ?>
            <div class="row about-bar">
                <div class="container-bakala">
                    <div class="container-bakala footer-div">
                        <div class="col-md-9 no-padding footer_description">
                            <?php if (isset($bakala_options['footer_credit']) && !empty($bakala_options['footer_credit']) && $display) {
                                echo '<div class="footer_description_inner">';
                                echo $bakala_options['footer_credit'];
                                echo '</div>';
                                echo '<span class="footer_more" data-less="' . __('Less', 'bakala') . '" data-more="' . __('More', 'bakala') . '">' . __('More', 'bakala') . '</span>';
                            } ?>
                        </div>

                        <div class="col-md-3 no-padding">
                            <?php if (isset($bakala_options['footer_credit_left_html'])) {
                                echo $bakala_options['footer_credit_left_html'];
                            } ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row copyright-bar">
                <div class="container-bakala">
                    <div class="container-bakala footer-div">


                        <div class="copyright-bar-text">
                            <div class="no-padding section-one">
                            <span><?php if (isset($bakala_options['copyright-one']) && $bakala_options['copyright-one']) {
echo $bakala_options['copyright-one'];
                                } ?></span>
                            </div>
                            <div class="no-padding section-two">
                            <span><?php if (isset($bakala_options['copyright-two']) && $bakala_options['copyright-two']) {
                                    echo $bakala_options['copyright-two'];
                                } ?></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <?php
    } else {
        ?>
        <div class="footer">
            <div class="footer_container">
                <div class="information">
                    <?php if ($display) { ?>
                        <div class="description ellipsis-3">

                            <?php if (isset($bakala_options['footer_credit']) && !empty($bakala_options['footer_credit']) && $display) {
                                echo '<div class="footer_description_inner">';
                                echo $bakala_options['footer_credit'];
                                echo '</div>';
                                echo '<span class="footer_more" data-less="' . __('Less', 'bakala') . '" data-more="' . __('More', 'bakala') . '">' . __('More', 'bakala') . '</span>';
                            } ?>
                        </div>
                    <?php } ?>
                    <?php if($bakala_options['footer_logo'] != 0){ ?>
                        <div class="c-new-footer__logo"> <?php
                        if (isset($bakala_options['site_footer_logo']) && !empty($bakala_options['site_footer_logo']['url'])) {
                            $logo_href = $bakala_options['site_footer_logo']['url'];
                        } else {
                            $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                        }
                        ?>
                        <div property="name">
                            <div class="white-logo">
                                <img
                                        src="<?php echo $logo_href; ?>"
                                        alt="<?php echo get_bloginfo(); ?>"
                                >
                            </div>
                            <?php


                            ?>
                            <?php if (isset($bakala_options['dark_logo_mobile']) && strlen($bakala_options['dark_logo_mobile']['url']) > 0) {
                                $dark_logo = $bakala_options['dark_logo_mobile']['url']; ?>
                                <a class="dark-logo" href="<?php echo home_url('/'); ?>"
                                   title="<?php echo get_bloginfo(); ?>" target="_self">
                                    <img
                                            src="<?php echo $dark_logo; ?>"
                                            alt="<?php echo get_bloginfo(); ?>"
                                    >
                                </a>
                            <?php } ?>

                            <?php
                            ?>

                        </div>
                    </div>
                    <?php } ?>
                    <ul class="contact">
                        <?php if (!empty($bakala_options['footer_location'])) { ?>
                            <li dir="rtl">
                                <i class="bakala-icon icon-map"></i>
                                <span><?= $bakala_options['footer_location'] ?></span>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['footerinfobar_phone']) && $bakala_options['footerinfobar_phone']) { ?>
                            <li dir="rtl">
                                <span>تلفن :</span>
                                <a style="font-size: 15px;letter-spacing: 2pt"
                                   href="<?php echo get_permalink($bakala_options['footerinfobar_phone_p']); ?>"
                                   dir="ltr"><?php echo $bakala_options['footerinfobar_phone']; ?></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['footerinfobar_email']) && $bakala_options['footerinfobar_email']) { ?>
                            <li dir="rtl">
                                <!--<i class="material-icons">alternate_email</i>-->
                                <span>ایمیل :</span>
                                <a style="letter-spacing: 2pt"
                                   href="mailto:<?php echo $bakala_options['footerinfobar_email']; ?>"
                                   dir="ltr"><?php echo $bakala_options['footerinfobar_email']; ?></a>
                            </li>
                        <?php } ?>
                    </ul>

                </div>
                <div class="cols">
                    <?php if (is_active_sidebar('subscribe-col-1')) {
                        dynamic_sidebar('subscribe-col-1');
                    } ?>
                    <?php if (is_active_sidebar('subscribe-col-2')) {
                        dynamic_sidebar('subscribe-col-2');
                    } ?>
                    <?php if (is_active_sidebar('subscribe-col-3')) {
                        dynamic_sidebar('subscribe-col-3');
                    } ?>
                </div>
                <div class="social">
                <?php if (isset($bakala_options['social_title']) && $bakala_options['social_title']) { ?>
                    <div class="title"><?php echo $bakala_options['social_title']; ?> </div>
                    <?php } ?>
                    <ul class="socials">
                        <?php if (isset($bakala_options['facebook']) && $bakala_options['facebook']) { ?>
                            <li>
                                <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['facebook']; ?>"><i
                                            class="icon icon-footer-facebook"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['twitter']) && $bakala_options['twitter']) { ?>
                            <li>
                                <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['twitter']; ?>"><i
                                            class="icon icon-footer-twitter"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['googleplus']) && $bakala_options['googleplus']) { ?>
                            <li>
                                <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['googleplus']; ?>"><i
                                            class="icon icon-footer-googleplus"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['instagram']) && $bakala_options['instagram']) { ?>
                            <li>
                                <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['instagram']; ?>"><i
                                            class="icon icon-footer-instagram"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['youtube']) && $bakala_options['youtube']) { ?>
                            <li>
                                <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['youtube']; ?>"><i
                                            class="icon icon-footer-aparat"></i></a>
                            </li>
                        <?php } ?>
                        <?php if (isset($bakala_options['vimeo']) && $bakala_options['vimeo']) { ?>
                            <li>
                                <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['vimeo']; ?>"><i
                                            class="icon icon-footer-telegram"></i></a>
                            </li>
                        <?php } ?>
                        <?php
                        if (is_array($bakala_options['other_socials'])) {
                            foreach ($bakala_options['other_socials'] as $item) {
                                if (!empty($item['image'])) {
                                    ?>
                                    <li>
                                        <a target="_blank" rel="nofollow" href="<?php echo $item['url']; ?>">
                                            <img
                                                    src="<?php echo $item['image'] ?>"
                                                    class="other_socials_img"
                                            >
                                        </a>
                                    </li>
                                <?php }
                            }
                        } ?>
                    </ul>
                    <div class="newsletter">
                        <div class="container">
                            <p><?php echo $bakala_options['footer_newsletter_title']; ?> </p>
                            <?php echo do_shortcode($bakala_options["footer_newsletter_marketing_text"]); ?>

                        </div>
                    </div>
                    <div class="licences">
                        <div class="container">
                            <?php if (isset($bakala_options['footer_credit_left_html'])) {
                                echo $bakala_options['footer_credit_left_html'];
                            } ?>
                        </div>
                    </div>
                </div>

            </div>
            <?php if (isset($bakala_options['show-apps']) && $bakala_options['show-apps']) { ?>
                <ul class="apps">

                    <div class="c-new-footer__app-links-container"><a class="u-flex">
                            <div class="c-new-footer__app-links-logo">
                                <img
                                        src="<?php echo $bakala_options['app_img']['url']; ?>"
                                        class="other_socials_img"
                                >
                            </div>
                            <div class="c-new-footer__app-links-label">
                                <?php if (isset($bakala_options['app_title']) && $bakala_options['app_title']) { ?>
                                    <?php echo $bakala_options['app_title']; ?>
                                <?php } ?>
                            </div>
                        </a>
                        <div class="c-new-footer__app-images-container">
                            <?php if (isset($bakala_options['google_play']) && $bakala_options['google_play']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow"
                                       href="<?php echo $bakala_options['google_play']; ?>"
                                       class="google_play-icon"><img
                                                src="<?= get_template_directory_uri() . '/vendor/images/google_play.png'; ?>"
                                                alt="google play icon"></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['soundcloud']) && $bakala_options['soundcloud']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow"
                                       href="<?php echo $bakala_options['soundcloud']; ?>" class="android-icon"><img
                                                src="<?= get_template_directory_uri() . '/vendor/images/android_app.png'; ?>"
                                                alt="android app icon"></a>
                                </li>
                            <?php } ?>

                            <?php if (isset($bakala_options['myket']) && $bakala_options['myket']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['myket']; ?>"
                                       class="myket"><img
                                                src="<?= get_template_directory_uri() . '/vendor/images/myket.png'; ?>"
                                                alt="myket icon"></a>
                                </li>
                            <?php } ?>
                            <?php if (isset($bakala_options['vine']) && $bakala_options['vine']) { ?>
                                <li>
                                    <a target="_blank" rel="nofollow" href="<?php echo $bakala_options['vine']; ?>"
                                       class="ios-icon"><img
                                                src="<?= get_template_directory_uri() . '/vendor/images/ios_app.png'; ?>"
                                                alt="ios app icon"></a>
                                </li>
                            <?php } ?>
                        </div>
                    </div>
                </ul> <?php } ?>
            <div class="bakala_row">
                <div class="copyright"><?php if (isset($bakala_options['copyright-one']) && $bakala_options['copyright-one']) {
echo $bakala_options['copyright-one'];
                    } ?></div>
                <a href="#" id="scrollUp">
                    <div id="js-jump-to-top" class="c-new-footer__jump-to-top-container"><span
                                class="c-new-footer__jump-to-top-label"><?php echo _e('Back to Top', 'bakala'); ?></span>
                        <span class="c-new-footer__jump-to-top-icon"></span>
                    </div>
                </a>
            </div>


        </div>
    <?php } ?>
    <div class="dark-background"></div>
    <?php
    if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
        $logo_href = $bakala_options['site_header_logo']['url'];
    } else {
        $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
    }
    ?>
    <div class="page-modal lr-loader" style="display:none;">
        <div class="page-content" id="loader">
            <img
                    src="<?= $logo_href ?>"
                    alt="site-logo"
                    class="site-logo"
            >
            <div class="c-remodal-loader__bullets"><i
                        class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i
                        class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i
                        class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i
                        class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
        </div>
    </div>
    <?php
}
 if (!empty($bakala_options['custom_js'])) {
    echo '<script>' . $bakala_options['custom_js'] . ' </script>';
}
?>
<script>
   

        function skeletonLoader() {
                    document.querySelectorAll('.skeleton_loader_enable .pro_carousel_loading').forEach(function (element) {
    element.classList.remove('is_loading');
});

    document.querySelectorAll('.skeleton_loader_enable .bk_stories__elements__item').forEach(function (item) {
        item.querySelector('.bk_stories__skeleton--image').style.display = 'none';
        item.querySelector('.bk_stories__elements__item__picture--img').style.display = 'block';
        item.querySelector('.bk_stories__skeleton--title').style.display = 'none';
        item.querySelector('.bk_stories__elements__item__title').style.display = 'block';
        item.querySelector('.bk_stories__elements__item__picture svg').style.display = 'block';
    });

   var imgElement = document.querySelector('.bakala_picture_slider .swiper-slide img');
var swiperSkeletonLoader = document.querySelector('.bakala_picture_slider .swiper-skeleton-loader');

if (imgElement && swiperSkeletonLoader) {
    var imageHeight = imgElement.clientHeight;
    swiperSkeletonLoader.style.height = imageHeight + 'px';

    swiperSkeletonLoader.style.transition = 'opacity 0.3s';
    swiperSkeletonLoader.style.opacity = '0';

    setTimeout(function() {
        swiperSkeletonLoader.remove();
    }, 300);
}


    document.querySelectorAll('.skeleton_loader_enable .bakala_picture_slider .swiper').forEach(function (element) {
    element.style.visibility = 'visible';
});

document.querySelectorAll('.skeleton_loader_enable .product-box-inner').forEach(function (element) {
    element.style.visibility = 'visible';
});

document.querySelectorAll('.skeleton_loader_enable .product-skeleton-loader').forEach(function (element) {
    element.style.display = 'none';
});

document.querySelectorAll('.skeleton_loader_enable .bakala_pro_carousel').forEach(function (element) {
    element.classList.remove('pro_carousel_loading');
});
document.querySelectorAll(".bakala_banner_skeleton").forEach(function (banner) {
            banner.style.display = 'none';
        });
        document.querySelectorAll(".bakala_banner").forEach(function (banner) {
            banner.style.display = 'block';
        });
document.querySelectorAll('.skeleton_loader_enable .bakala_account_cart').forEach(function (element) {
    element.style.display = 'flex';
});

document.querySelectorAll('.skeleton_loader_enable .header-skeleton').forEach(function (element) {
    element.style.display = 'none';
});

			document.body.classList.remove('skeleton_loading');
            document.body.classList.remove('skeleton_loader_enable');
            document.body.classList.add('skeleton_loader_disable');

document.querySelectorAll('.skeleton_loader_enable .skeleton_loader').forEach(function (loader) {
    loader.style.transition = 'opacity 0.3s';
    loader.style.opacity = '0';
    setTimeout(function() {
        loader.style.display = 'none';
    }, 300);
});

document.querySelectorAll('.skeleton_loader_enable .product-info-box *:not(.skeleton_loader):not(.skeleton_loader_background):not(.skeleton_loader_background_masker)').forEach(function (element) {
    element.style.visibility = 'visible';
});

document.querySelectorAll('.woocommerce-variation, .woocommerce-variation *').forEach(function (element) {
    element.style.visibility = 'visible';
});

document.querySelectorAll('.skeleton_loader_enable .product-gallery-skeleton').forEach(function (element) {
    element.style.display = 'none';
});

document.querySelectorAll('.bakala-gallery-thumbnails-skeleton').forEach(function (element) {
    element.style.display = 'none';
});

document.querySelectorAll('.skeleton_loader_enable .woocommerce-product-gallery').forEach(function (element) {
    element.style.display = 'block';
});

document.querySelectorAll('.skeleton_loader_enable .related-products .scroller').forEach(function (element) {
    element.style.visibility = 'visible';
});

}

    setTimeout(function() {
        skeletonLoader();
    }, 500);
	</script>