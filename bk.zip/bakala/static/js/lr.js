
document.addEventListener('input', function (e) {
    if (e.target.classList.contains('token-input')) {
        var input = e.target;
        if (input.value.length > 1) {
            input.value = input.value.slice(0, 1); // محدود کردن به 1 کاراکتر
        }
    }
});
    // Update the count down every 1 second
    function bakalaCountdown() {
        console.log(lr_params.code_time)
        var countDownDate = new Date().getTime() + parseInt(lr_params.code_time+'000');

        var x = setInterval(function() {

            // Get today's date and time
            var now = new Date().getTime();

            // Find the distance between now and the count down date
            var distance = countDownDate - now;

            // Time calculations for days, hours, minutes and seconds
            var days = Math.floor(distance / (1000 * 60 * 60 * 24));
            var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            var seconds = Math.floor((distance % (1000 * 60)) / 1000);

            // Display the result in the element with id="demo"
            document.getElementById("lr-countdown").innerHTML = `<div class="otp-inputs__timer"><i class="bakala-icon icon-recode"></i>
                ${minutes}:${seconds}
            </div>`;

            // If the count down is finished, write some text
            if (distance < 0) {
                clearInterval(x);
                document.getElementById("lr-countdown").innerHTML = `<button id="otp-recode" type="button" onclick="resendCode()" class="otp-inputs__resend"><span class="otp-inputs__tooltip">
                        Get the code again
                    </span><i class="bakala-icon icon-recode"></i></button>`;
            }
        }, 1000);
    }

    function showPass() {
        jQuery('#show-pass').fadeOut();
        jQuery('#send').fadeOut();
        jQuery('#lr-btn').fadeIn();
        jQuery('.forget').fadeIn();
        jQuery('#show-code').fadeIn();
        jQuery('#lr-password-field').fadeIn();

    }

    function showCode() {
        jQuery('#show-code').fadeOut();
        jQuery('#send').fadeIn();
        jQuery('#lr-btn').fadeOut();
        jQuery('#show-pass').fadeIn();
        jQuery('.forget').fadeOut();
        jQuery('#lr-password-field').fadeOut();

    }
    jQuery('#show-pass').click(function() {
        showPass();
        jQuery('#pass').focus();
    });
    jQuery('#show-code').click(function() {
        showCode();
        jQuery('#phone').focus();
    });
    jQuery('#pass').focus(function() {
        jQuery(document).keypress(
            function(e) {
                if (e.which == '13') {
                    e.preventDefault();
                    jQuery('#lr-btn').click()
                }
            });
    })

    function getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    function getEmail(email) {
        jQuery('#lr-send-form').fadeOut();
        jQuery('#error-phone').fadeOut();
        jQuery('#lr-password-form').fadeIn();
        jQuery('#lr-submit-form').fadeOut();
        jQuery.ajax({
            url: lr_params.ajaxurl,
            type: 'GET',
            data: {
                action: 'get_latest_posts_by_category',
                email: email
            },
            beforeSend: function() {
                jQuery('.lr-loader').show()
            },

            success: function(data) {
                if (data == "yes") {
                    jQuery('.lr-loader').hide()
                    jQuery('.mobile-number').text(getCookie('phone'))
                } else {
                    jQuery('.lr-loader').hide()
                }
            }
        });
    }
    /////////////////////////////////
    function getphn() {
        jQuery('#lr-submit-form').show();
        jQuery('#lr-send-form').hide();
        jQuery('#error-phone').fadeOut();
        bakalaCountdown();
        jQuery('.lr_loader').remove()
        jQuery('#bakala_login .modal-content').removeClass('lr_loading')
        jQuery('span.lr-phone-number').text(getCookie('phone'))
        jQuery('input.lr-phone-number').val(getCookie('phone'))
    }
    var digit1 = jQuery('input#digit-1').val();
    var digit2 = jQuery('input#digit-2').val();
    var digit3 = jQuery('input#digit-3').val();
    var digit4 = jQuery('input#digit-4').val();
    var digits = digit1.concat(digit2, digit3, digit4);
    var codeCookie = getCookie('opt_code');
    // var clock = jQuery('#lr-countdown').FlipClock({
    //     autoStart: false,
    //     callbacks: {
    //         start: function() {
    //             jQuery('#otp-recode').attr('disabled', 'disabled');
    //             jQuery('.mobile-number').text(getCookie('phone'))

    //         },
    //         stop: function() {
    //             jQuery('#lr-submit').fadeOut();
    //             jQuery('#otp-recode').fadeIn();

    //             jQuery('#otp-recode').removeAttr('disabled');
    //         }
    //     }
    // });

    jQuery('#lr-send-form').on('submit', function(e) {
        e.preventDefault();
        var nonce = jQuery('meta[name="csrf-token"]').attr('content');
        jQuery.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': nonce
            }
        });
        var loaderTimeout;
        if (jQuery('#pass').length < 1) {
            if (jQuery('#phone').val().length > 0) {
                jQuery.ajax({
                    url: lr_params.ajaxurl,
                    type: 'POST',
                    dataType: "json",
                    data: {
                        action: "bakala_send_code",
                        phone_email: jQuery('#phone').val(),
                    },
                    beforeSend: function() {
                        jQuery('#bakala_login .modal-content').append('<div class="lr_loader"></div>');
                        jQuery('#bakala_login .modal-content').addClass('lr_loading')
                        
                        loaderTimeout = setTimeout(function() {
                            jQuery('.lr_loader').remove();
                            jQuery('#bakala_login .modal-content').removeClass('lr_loading');
                        }, 10000);
                    },
                    
                    success: function(response) {
                        if (response.status_code == 500) {
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'center',
                                showConfirmButton: false,
                                timer: 1000,
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.addEventListener('mouseenter', Swal.stopTimer)
                                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                                }
                            })
                            Toast.fire({
                                title: response.message,
                                icon: 'error',
                            })
                        } else {
                            if (phone_pattern.test(jQuery('#phone').val())) {
                                getphn();

                                jQuery('#digit-1').focus();
                                jQuery('#digit-4').keyup(function() {
                                    jQuery('#lr-submit').trigger("click");
                                    jQuery('#bakala_login .modal-content').append('<div class="lr_loader"></div>');
                                    jQuery('#bakala_login .modal-content').addClass('lr_loading')
                                });
                            } else if (validateEmail(jQuery('#phone').val())) {
                                jQuery('.lr_loader').remove()
                                jQuery('#bakala_login .modal-content').removeClass('lr_loading')
                                getEmail(jQuery('#phone').val())
                            } else {
                                jQuery('#error-phone').fadeIn();
                            }
                        }
                    },
                    complete: function() {
                        jQuery('.lr_loader').remove()
                        jQuery('#bakala_login .modal-content').removeClass('lr_loading')
                    },
                });
            } else {
                jQuery('#error-phone').text('Enter mobile number or email!');
                jQuery('#error-phone').fadeIn();
            }
        } else {
            if (phone_pattern.test(jQuery('#phone').val())) {
                jQuery.ajax({
                    url: lr_params.ajaxurl,
                    type: 'POST',
                    dataType: "json",
                    data: {
                        action: "bakala_send_code",
                        phone_email: jQuery('#phone').val(),
                    },
                    beforeSend: function() {
                        jQuery('#bakala_login .modal-content').append('<div class="lr_loader"></div>');
                        jQuery('#bakala_login .modal-content').addClass('lr_loading')
                        loaderTimeout = setTimeout(function() {
                            jQuery('.lr_loader').remove();
                            jQuery('#bakala_login .modal-content').removeClass('lr_loading');
                        }, 10000);
                    },
                    success: function(response) {
                        if (response.status_code == 500) {
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'center',
                                showConfirmButton: false,
                                timer: 1000,
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.addEventListener('mouseenter', Swal.stopTimer)
                                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                                }
                            })
                            Toast.fire({
                                title: response.message,
                                icon: 'error',
                            })
                        } else {
                            if (phone_pattern.test(jQuery('#phone').val())) {
                                getphn();

                                jQuery('#digit-4').keyup(function() {
                                    jQuery('#lr-submit').trigger("click");
                                    jQuery('#bakala_login .modal-content').append('<div class="lr_loader"></div>');
                                    jQuery('#bakala_login .modal-content').addClass('lr_loading')
                                });
                            } else if (validateEmail(jQuery('#phone').val())) {
                                jQuery('.lr_loader').remove()
                                jQuery('#bakala_login .modal-content').removeClass('lr_loading')
                                getEmail(jQuery('#phone').val())
                            } else {
                                jQuery('#error-phone').fadeIn();
                            }
                        }
                    },
                    complete: function() {
                        jQuery('.lr_loader').remove()
                        jQuery('#bakala_login .modal-content').removeClass('lr_loading')
                        jQuery('#digit-1').focus();
                    },
                });
            } else {
                jQuery('#error-phone').text('Enter the mobile number!');
                jQuery('#error-phone').fadeIn();
            }
        }
        return false;
    })
    jQuery('#lr-btn').on('click', function() {
        var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
        var email_pattern = /^[a-zA-Z-' ]*$/;

        if (jQuery('#phone').val().length > 0 && jQuery('#pass').val().length > 1 && (phone_pattern.test(jQuery('#phone').val()) || validateEmail(jQuery('#phone').val()))) {
            jQuery.ajax({
                url: lr_params.ajaxurl,
                type: 'POST',
                dataType: "json",
                data: {
                    action: "bakala_lr_submit",
                    phone_email: jQuery('#phone').val(),
                    password: jQuery('#pass').val()
                },
                beforeSend: function() {
                    jQuery('#bakala_login .modal-content').append('<div class="lr_loader"></div>');
                    jQuery('#bakala_login .modal-content').addClass('lr_loading')
                },
                success: function(response) {
                    jQuery('.lr_loader').remove()
                    jQuery('#bakala_login .modal-content').removeClass('lr_loading')
                    if (response.status_code == 500) {
                        jQuery('#pass').css('borderColor', '#ee5a66')
                        jQuery('#error-pass').text(response.message)
                        jQuery('#error-pass').fadeIn()
                    } else {
                        const Toast = Swal.mixin({
                            toast: true,
                            position: 'center',
                            showConfirmButton: false,
                            timer: 1000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal.stopTimer)
                                toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        })
                        Toast.fire({
                            title: response.message,
                            icon: 'success',
                        }).then((result) => {
                            location.reload();
                        })
                    }
                }
            });
        }
    })
    var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
    var email_pattern = /^[a-zA-Z-' ]*$/;
    
    
    
    jQuery('#phone').keyup(function() {
        if (phone_pattern.test(jQuery(this).val()) == false && !Array.isArray(validateEmail(jQuery(this).val()))) {
            jQuery(this).parent().css('height', 'auto');
            jQuery('#send').attr('disabled','disabled');
            
            jQuery(this).css('borderColor', '#ee5a66')
        } else {
            jQuery(this).parent().css('height', '65px');
            jQuery('#send').removeAttr('disabled');
            jQuery(this).css('borderColor', 'green')
            if (phone_pattern.test(jQuery(this).val())) {
                showCode()
            } else {
                showPass()
            }
        }
    });

    jQuery('#lr-submit-form').on('submit', function(e) {
        e.preventDefault();
        var digit1 = jQuery('input#digit-1').val();
        var digit2 = jQuery('input#digit-2').val();
        var digit3 = jQuery('input#digit-3').val();
        var digit4 = jQuery('input#digit-4').val();
        var digits = digit1.concat(digit2, digit3, digit4);
        jQuery.ajax({
            url: lr_params.ajaxurl,
            type: 'POST',
            dataType: "json",
            data: {
                action: "bakala_submit_code",
                token: digits,
            },
            beforeSend: function() {
                jQuery('#bakala_login .modal-content').append('<div class="lr_loader"></div>');
                jQuery('#bakala_login .modal-content').addClass('lr_loading')
            },
            success: function(response) {
                jQuery('.lr_loader').remove()
                jQuery('#bakala_login .modal-content').removeClass('lr_loading')
                if (response.status_code == 500) {
                    jQuery('#lr-token input').css('borderColor', '#ee5a66')
                    jQuery('.token-error').text(response.message)
                } else {
                    jQuery('#bakala_login').modal('toggle');
                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'center',
                        showConfirmButton: false,
                        timer: 1000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                            toast.addEventListener('mouseenter', Swal.stopTimer)
                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    })
                    Toast.fire({
                        title: response.message,
                        icon: 'success',
                    }).then((result) => {
                        location.reload();
                    })
                }
            }
        });

        return false;
    })

    jQuery('#lr-password-form').on('submit', function(e) {
        e.preventDefault();
        var password = jQuery('input#password').val();
        jQuery.ajax({
            url: lr_params.ajaxurl,
            type: 'POST',
            dataType: "json",
            data: {
                action: "bakala_submit_password",
                password: password,
            },
            beforeSend: function() {
                jQuery('#bakala_login .modal-content').append('<div class="lr_loader"></div>');
                jQuery('#bakala_login .modal-content').addClass('lr_loading')
            },
            success: function(response) {
                jQuery('.lr_loader').remove()
                jQuery('#bakala_login .modal-content').removeClass('lr_loading')
                if (response.status_code == 500) {
                    jQuery('#password').css('borderColor', '#ee5a66')
                    jQuery('.password-error').text(response.message)
                } else {
                    jQuery('#bakala_login').modal('toggle');
                    const Toast = Swal.mixin({
                        toast: true,
                        position: 'center',
                        showConfirmButton: false,
                        timer: 1000,
                        timerProgressBar: true,
                        didOpen: (toast) => {
                            toast.addEventListener('mouseenter', Swal.stopTimer)
                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                        }
                    })
                    Toast.fire({
                        title: response.message,
                        icon: 'success',
                    }).then((result) => {
                        location.reload();
                    })
                }
            }
        });

        return false;
    })
    ////////////////////

    //////////////////////
    function resendCode() {
        jQuery.ajax({
            url: lr_params.ajaxurl,
            type: 'POST',
            data: {
                action: "bakala_send_code",
                phone_email: jQuery('#phone').val(),
            },
            beforeSend: function() {
                jQuery('.lr-loader').show()
            },
            complete: function() {
                jQuery('.lr-loader').hide()
            },
            success: function(data) {

                var pattern = /^(\+98|0098|98|0)?9\d{9}$/;
                if (pattern.test(jQuery('#phone').val())) {
                    bakalaCountdown();
                    jQuery('#lr-submit-form').fadeIn();
                    jQuery('#lr-send-form').fadeOut();
                    jQuery('#error-phone').fadeOut();

                } else {
                    jQuery('#error-phone').fadeIn();
                }
            }
        });
    }
   

    jQuery('#edit-phone-number,button.header__button.back-icon').click(function(e) {
        e.preventDefault();
        jQuery('#lr-submit-form').fadeOut();
        jQuery('#lr-send-form').fadeIn();
    })


    String.prototype.toEnglishDigit = function() {
        var find = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        var replace = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        var replaceString = this;
        var regex;
        for (var i = 0; i < find.length; i++) {
            regex = new RegExp(find[i], "g");
            replaceString = replaceString.replace(regex, replace[i]);
        }
        return replaceString;
    };

    document.querySelectorAll('input').forEach(x => {
        x.oninput = function() {
            x.value = x.value.toEnglishDigit()
        }
    });
    jQuery('#lr-token').find('input').each(function() {
        jQuery(this).attr('maxlength', 1);
        jQuery(this).on('keyup', function(e) {
            e.preventDefault();
            var parent = jQuery(jQuery(this).parent());

            inputCharacter = String.fromCharCode(e.which);

            acceptableNumbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];


            if (e.keyCode == 8 || e.keyCode == 37) {
                var prev = parent.find('input#' + jQuery(this).data('previous'));


                if (prev.length != undefined) {
                    jQuery(prev).select();
                }


            } else if (e.which == 229 || (e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
                //} else if( checkIsInArray( inputCharacter , acceptableNumbers ) ) {
                var next = parent.find('input#' + jQuery(this).data('next'));

                if (next.length != undefined) {
                    jQuery(next).select();
                } else {
                    if (parent.data('autosubmit')) {
                        parent.submit();
                    }
                }
            }
        });
    });
