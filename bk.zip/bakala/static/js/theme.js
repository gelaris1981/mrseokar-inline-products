jQuery(document).ready(function ($) {
    
    /**
     * Sticky Tabs
     */
    if ( jQuery("ul.wc-tabs").length ) {
        jQuery(window).scroll(function (e) {
            
            if ( jQuery(".mt-sticky-header").length ) {
                if ( jQuery("#navbar-primary-fixed").length ) {
                    var headerHeight = jQuery(".mt-sticky-header").height() ;
                    jQuery("ul.wc-tabs").css("top", headerHeight + "px");
                    if($('.bakala_product_float_box .product-info-box').length){
                        $('.bakala_product_float_box .product-info-box').css("top", headerHeight + jQuery('ul.tabs.wc-tabs.sticky').height() + "px");
                    }
                } else {
                    jQuery("ul.wc-tabs").css("top", "0");
                    if($('.bakala_product_float_box .product-info-box').length){
                        $('.bakala_product_float_box .product-info-box').css("top", "0");
                    }
                }
            } else {
                if ( !jQuery(".site-header").hasClass("sticky-header") ) {
                    jQuery("ul.wc-tabs").css("top", "0");
                } else {
                    if($('body').hasClass('bakala_product_tabs_scrollable')){
                        var headerHeight = $(".sticky-header").height();
                        
                    }else{
                        var headerHeight = $(".sticky-header .row.header").height();
                    }
                    jQuery("ul.wc-tabs").css("top", headerHeight + "px");
                    if($('.bakala_product_float_box .product-info-box').length){
                        $('.bakala_product_float_box .product-info-box').css("top", headerHeight + jQuery('ul.tabs.wc-tabs.sticky').height());
                    }
                }
            }
            
            jQuery(".products-tabs").offset().top - 55;
            
            if ( jQuery(".upsell-carousel").length ) {
                jQuery(".upsell-carousel").offset().top - 55;
            } else if ( jQuery(".smart-similar-products").length ) {
                jQuery(".smart-similar-products").offset().top - 55;
            } else if ( jQuery(".footer").length ) {
                jQuery(".footer").offset().top - 55;
            }else if(jQuery('.elementor-location-footer').length){
                jQuery('.elementor-location-footer').top - 55;
            } else {
                jQuery("footer").offset().top - 55;
            }
            if(jQuery('.elementor-location-footer').length){
                jQuery(this).scrollTop() + jQuery('.elementor-location-footer').height();
            }else{
                jQuery(this).scrollTop() + jQuery(".footer").height();
            }
            
            jQuery("ul.wc-tabs").addClass("sticky");
        });
    }
    
});