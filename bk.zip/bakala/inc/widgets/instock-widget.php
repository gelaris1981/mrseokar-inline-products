<?php

// Register and load the widget

function wpb_load_widget()
{
	register_widget('WC_Available_Product_Widget');
}

add_action('widgets_init', 'wpb_load_widget');

// Creating the widget

class WC_Available_Product_Widget extends WP_Widget

{
	function __construct()
	{
		parent::__construct(

		// Base ID of your widget

		'wcavp_widget',

		// Widget name will appear in UI

		__('Instock Product', 'bakala') ,

		// Widget description

		array(
			'description' => __('Checkbox for instock product filter', 'bakala') ,
		));
	}

	// Creating widget front-end

// Creating widget front-end
public function widget($args, $instance)
{
    global $wp;

    $title = $instance['title'];
    $current_url = add_query_arg($_SERVER['QUERY_STRING'], '', home_url($wp->request) . '/');

    // Default instock URL
    $oinstock_url = bakala_merge_querystring($current_url, '?oinstock=true');

    // Check if 'oinstock' is active
    if (!empty(get_query_var('oinstock'))) {
        $active = true;
        $url = esc_url(remove_query_arg('oinstock', $current_url));
    } else {
        $active = false;
        $url = $oinstock_url;
    }

    // Only check the HTTP response code if the option is active
    if ($active && ini_get('allow_url_fopen')) {
        $response_code = $this->get_http_response_code($oinstock_url);

        if ($response_code == 404) {
            // Replace any page number with 1 if the URL returns a 404
            $current_url = preg_replace('/\/page\/\d+\//', '/page/1/', $current_url);
        }
    }

    echo "<div class=\"clearfix\"></div><div class=\"available_widget\"><ul><li class=\"woocommerce-widget-layered-nav-list__item " . (!empty(get_query_var('oinstock')) ? 'chosen' : '') . " wc-layered-nav-term\">
    <a href='" . $url . "' class=\"instock_product" . (!empty(get_query_var('oinstock')) ? ' checked' : '') . "\">" . __("Only instock products", "bakala") . "</a>
    </li></ul></div>";
}


// Function to get HTTP response code using wp_remote_head
private function get_http_response_code($url)
{
    $response = wp_remote_head($url);
    $response_code = wp_remote_retrieve_response_code($response);
    return $response_code;
}


	// Widget Backend

	public function form($instance)
	{
		if (isset($instance['title'])) {
			$title = $instance['title'];
		}
		else {
			$title = __('New title', 'bigkala');
		}

		// Widget admin form

?>
<p>
<label for="<?php
		echo $this->get_field_id('title'); ?>"><?php
		_e('Title:'); ?></label> 
<input class="widefat" id="<?php
		echo $this->get_field_id('title'); ?>" name="<?php
		echo $this->get_field_name('title'); ?>" type="text" value="<?php
		echo esc_attr($title); ?>" />
</p>
<?php
	}

	// Updating widget replacing old instances with new

	public function update($new_instance, $old_instance)
	{
		$instance = array();
		$instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
		return $instance;
	}
}