<?php
// require_once dirname(__FILE__) . '/torob.php';
if (!function_exists('bakala_get_product_attr_taxonomies')) {
    /**
     * Get All Product Attribute Taxonomies
     *
     * @return array
     */
    function bakala_get_product_attr_taxonomies()
    {

        $product_taxonomies = array();
        $attribute_taxonomies = wc_get_attribute_taxonomies();

        if ($attribute_taxonomies) {
            foreach ($attribute_taxonomies as $tax) {
                $product_taxonomies[wc_attribute_taxonomy_name($tax->attribute_name)] = $tax->attribute_label;
            }
        }

        return $product_taxonomies;
    }
}

if (!class_exists('Redux')) {
    return;
}

$opt_name = "bakala_options";

$theme = wp_get_theme(); // For use with some settings. Not necessary.
// define('CNKT_INSTALLER_PATH', get_template_directory_uri() . '/inc/redux-framework/sample/extension/wbc_importer/wbc_importer/connekt-plugin-installer/');

if (bakala_license_is_activated() === false) {
    $import = false;
} else {
    $import = true;
}

$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name' => $opt_name,
    'search' => true,
    // This is where your data is stored in the database and also becomes your global variable name.
    'display_name' => $theme->get('Name'),
    // Name that appears at the top of your panel
    'display_version' => $theme->get('Version'),
    // Version that appears at the top of your panel
    'menu_type' => 'menu',
    //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu' => true,
    // Show the sections below the admin menu item or not
    'menu_title' => __('Theme Options', 'bakala'),
    'page_title' => __('Theme Options', 'bakala'),
    // You will need to generate a Google API key to use this feature.
    // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
    'google_api_key' => '',
    // Set it you want google fonts to update weekly. A google_api_key value is required.
    'google_update_weekly' => false,
    // Must be defined to add google fonts to the typography module
    'async_typography' => false,
    // Use a asynchronous font on the front end or font string
    'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
    'admin_bar' => true,
    // Show the panel pages on the admin bar
    'admin_bar_icon' => 'dashicons-admin-settings',
    // Choose an icon for the admin bar menu
    'admin_bar_priority' => 50,
    // Choose an priority for the admin bar menu
    'global_variable' => 'bakala',
    // Set a different name for your global variable other than the opt_name
    'dev_mode' => false,
    // Show the time the page took to load, etc
    'update_notice' => false,
    // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
    'customizer' => false,
    // Enable basic customizer support
    //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
    //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

    // OPTIONAL -> Give you extra features
    'page_priority' => null,
    // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_parent' => 'bakala_theme',
    // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
    'page_permissions' => 'manage_options',
    // Permissions needed to access the options panel.
    'menu_icon' => '',
    // Specify a custom URL to an icon
    'last_tab' => '',
    // Force your panel to always open to a specific tab (by id)
    'page_icon' => 'icon-themes',
    // Icon displayed in the admin panel next to your menu_title
    'page_slug' => 'bakala_options',
    // Page slug used to denote the panel
    'save_defaults' => true,
    // On load save the defaults to DB before user clicks save or not
    'default_show' => false,
    // If true, shows the default value next to each field that is not the default value.
    'default_mark' => '',
    // What to print by the field's title if the value shown is default. Suggested: *
    'show_import_export' => $import,
    // Shows the Import/Export panel when not used as a field.

    // CAREFUL -> These options are for advanced use only
    'transient_time' => 60 * MINUTE_IN_SECONDS,
    'output' => true,
    // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag' => true,
    // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
    'footer_credit' => false,                   // Disable the footer credit of Redux. Please leave if you can help it.

    // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
    'database' => '',
    // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!

    'use_cdn' => true,
    // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

    'compiler' => true,

    // HINTS
    'hints' => array(
        'icon' => 'el el-question-sign',
        'icon_position' => 'right',
        'icon_color' => 'lightgray',
        'icon_size' => 'normal',
        'tip_style' => array(
            'color' => 'light',
            'shadow' => true,
            'rounded' => false,
            'style' => '',
        ),
        'tip_position' => array(
            'my' => 'top left',
            'at' => 'bottom right',
        ),
        'tip_effect' => array(
            'show' => array(
                'effect' => 'slide',
                'duration' => '1000',
                'event' => 'mouseover',
            ),
            'hide' => array(
                'effect' => 'slide',
                'duration' => '1000',
                'event' => 'click mouseleave',
            ),
        ),
    )
);


Redux::set_args($opt_name, $args);


$order_statuses_posts = bk_wc_order_status_manager_get_order_status_posts();
if (is_array($order_statuses_posts)) {
    $order_statuses_posts = $order_statuses_posts;
} else {
    $order_statuses_posts = [];
}
// ایجاد یک آرایه خالی
$order_statuses_array = array();

// پر کردن آرایه با post_name به عنوان کلید و post_title به عنوان مقدار
foreach ($order_statuses_posts as $status) {
    // اطمینان از وجود هر دو میدان قبل از اضافه کردن به آرایه
    if (isset($status->post_name) && isset($status->post_title)) {
        $order_statuses_array['wc-' . $status->post_name] = $status->post_title;
    }
}


if (bakala_license_is_activated() === false) :
    Redux::set_section($opt_name, array(
        'title' => __('General', 'bakala'),
        'id' => 'parent_general_section',
        'icon' => 'dashicons dashicons-admin-settings',
        'fields' => array(
            array(
                'id' => 'opt-info-critical',
                'type' => 'info',
                'style' => 'critical',
                'icon' => 'el el-info-circle',
                'title' => __('هشدار', 'bakala'),
                'desc' => __('جهت دسترسی به تمامی امکانات <b>قالب باکالا</b>, لطفا آن را فعال کنید', 'bakala')
            ),
        )
    ));
else :

    // -> START Fields
    Redux::set_section($opt_name, array(
        'title' => __('General', 'bakala'),
        'id' => 'parent_general_section',
        'icon' => 'dashicons dashicons-admin-settings',
    ));
    Redux::set_section($opt_name, array(
        'title' => __('Brand', 'bakala'),
        'id' => 'Brand_section',
        'subsection' => true,
        'icon' => 'dashicons dashicons-format-image',
        'fields' => array(
            array(
                'id' => 'site_header_logo',
                'type' => 'media',
                'title' => __('Your Logo', 'bakala'),
                'default' => array('url' => get_template_directory_uri() . '/vendor/images/logo-header.png'),
                'desc' => __('Choose your logo to show on header', 'bakala'),
            ),
            array(
                'id' => 'logo_size_desk',
                'type' => 'dimensions',
                'units' => false,
                'title' => esc_html__('سایز لوگو دسکتاپ', 'bakala'),
                'default' => array(
                    'Width' => 'auto',
                    'Height' => 'auto'
                ),
            ),
            array(
                'id' => 'logo-white',
                'type' => 'media',
                'title' => __('Your Logo For Mobile Menu', 'bakala'),
                'default' => array('url' => get_template_directory_uri() . '/vendor/images/logo-white.png'),
                'desc' => __('Choose your logo to show on mobile menu area.', 'bakala'),
            ),
            array(
                'id' => 'logo_size_mob',
                'type' => 'dimensions',
                'units' => false,
                'title' => esc_html__('سایز لوگو موبایل', 'bakala'),
                'default' => array(
                    'Width' => 'auto',
                    'Height' => 'auto'
                ),
            ),
            array(
                'id' => 'logo_size_mob_product',
                'type' => 'dimensions',
                'units' => false,
                'title' => esc_html__('سایز لوگو موبایل محصول', 'bakala'),
                'default' => array(
                    'Width' => 70,
                    'Height' => 'auto'
                ),
            ),
            array(
                'id' => 'logo_amination',
                'type' => 'switch',
                'title' => __('انیمشن لوگو', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه، لوگوی سایت دارای انیمیشن خواهد شد.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'image_hover_tilt',
                'type' => 'switch',
                'title' => __('انیمیشن هاور تصاویر', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه، انیمیشن به هاور تصاویر اضافه می شود.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'bakala_favicon',
                'type' => 'media',
                'title' => __('Your Favicon', 'bakala'),
                'default' => array('url' => get_template_directory_uri() . '/vendor/images/favicon.png'),
                'desc' => __('Choose your favicon to show on browser.', 'bakala'),
            ),
            array(
                'id' => 'site_footer_logo',
                'type' => 'media',
                'title' => __('Your Footer Logo', 'bakala'),
                'default' => array('url' => get_template_directory_uri() . '/vendor/images/logo-footer.png'),
                'desc' => __('Choose your logo to show on header', 'bakala'),
            ),

            array(
                'id' => 'elementor_width',
                'subtitle' => esc_html(__('با فعالسازی این گزینه عرض صفحه و سکشن های المنتور در المنتور تعیین می شوند.', 'bakala')),
                'title' => esc_html(__('عرض دلخواه المنتور', 'bakala')),
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 0,
            ),
            array(
                'id' => 'sender_email',
                'subtitle' => esc_html(__('آدرس ایمیل های ارسالی را می توانید تغییر دهید.', 'bakala')),
                'title' => esc_html(__('آدرس ایمیل های ارسالی', 'bakala')),
                'type' => 'text',
                'placeholder' => esc_html(__('test@test.com', 'bakala')),
            ),
            array(
                'id' => 'sender_email_name',
                'subtitle' => esc_html(__('نام ارسال کننده ایمیل ها را می توانید تغییر دهید.', 'bakala')),
                'title' => esc_html(__('نام ارسال کننده ایمیل ها', 'bakala')),
                'type' => 'text',
                'placeholder' => esc_html(__('باکالا', 'bakala')),
            ),
            array(
                'id' => 'full_width_images',
                'subtitle' => esc_html(__('با فعالسازی این گزینه، تمامی تصاویر وبسایت تمام عرض می شوند', 'bakala')),
                'title' => esc_html(__('تصاویر تمام عرض', 'bakala')),
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 0,
            ),
            array(
                'id' => 'layout_pages',
                'title' => esc_html(__('حالت نمایش سایت', 'bakala')),
                'type' => 'button_set',
                'options' => array(
                    'full' => __('تمام عرض', 'bakala'),
                    'box' => __('جعبه ای', 'bakala'),
                ),
                'default' => 'full',
            ),

        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('SVG Icons', 'bakala'),
        'id' => 'svg_section',
        'subsection' => true,
        'icon' => 'dashicons dashicons-heart',
        'fields' => array(
            array(
                'title' => esc_html(__('Enabale express shipping icon', 'bakala')),
                'id' => 'switch_Express_Shipping',
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 1,
            ),
            array(
                'id' => 'text_Express_Shipping',
                'type' => 'text',
                'title' => __("Express Shipping Title", "bakala"),
                'default' => __("Express Shipping", "bakala"),
                'required' => array('switch_Express_Shipping', '=', true)
            ),
            array(
                'id' => 'img_Express_Shipping',
                'type' => 'media',
                'title' => __("Express icon image", "bakala"),
                'required' => array('switch_Express_Shipping', '=', true)
            ),
            array(
                'id' => 'Express_Shipping',
                'type' => 'select',
                'data' => 'pages',
                'title' => __('Select Express Shipping Page', 'bakala'),
                'desc' => __('Select page that has Express Shipping template.', 'bakala'),
                'required' => array('switch_Express_Shipping', '=', true)
            ),
            array(
                'title' => esc_html(__('Enabale Payment at the place icon', 'bakala')),
                'id' => 'switch_Payment_at_the_place',
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 1,
            ),
            array(
                'id' => 'text_Payment_at_the_place',
                'type' => 'text',
                'title' => __("Payment at the place Title", "bakala"),
                'default' => __("Payment at the place", "bakala"),
                'required' => array('switch_Payment_at_the_place', '=', true)
            ),
            array(
                'id' => 'img_Payment_at_the_place',
                'type' => 'media',
                'title' => __("Payment at the place icon image", "bakala"),
                'required' => array('switch_Payment_at_the_place', '=', true)
            ),
            array(
                'id' => 'Payment_at_the_place',
                'type' => 'select',
                'data' => 'pages',
                'title' => __('Select Payment at the place Page', 'bakala'),
                'desc' => __('Select page that has Payment at the place template.', 'bakala'),
                'required' => array('switch_Payment_at_the_place', '=', true)
            ),
            array(
                'title' => esc_html(__('Enabale money Back guarantee icon', 'bakala')),
                'id' => 'switch_back_guarantee',
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 1,
            ),
            array(
                'id' => 'text_back_guarantee',
                'type' => 'text',
                'title' => __("Money back guarantee Title", "bakala"),
                'default' => __("7 dayes money back guarantee", "bakala"),
                'required' => array('switch_back_guarantee', '=', true)
            ),
            array(
                'id' => 'img_back_guarantee',
                'type' => 'media',
                'title' => __("Money back guarantee icon image", "bakala"),
                'required' => array('switch_back_guarantee', '=', true)
            ),
            array(
                'id' => 'back_guarantee',
                'type' => 'select',
                'data' => 'pages',
                'title' => __('Select 7 days money back guarantee Page', 'bakala'),
                'desc' => __('Select page that has 7 days money back guarantee template.', 'bakala'),
                'required' => array('switch_back_guarantee', '=', true)
            ),
            array(
                'title' => esc_html(__('Enabale Guarantee of Origin icon', 'bakala')),
                'id' => 'switch_Guarantee_of_Origin',
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 1,
            ),
            array(
                'id' => 'text_Guarantee_of_Origin',
                'type' => 'text',
                'title' => __("Guarantee of Origin Title", "bakala"),
                'default' => __("Guarantee of Origin products", "bakala"),
                'required' => array('switch_Guarantee_of_Origin', '=', true)
            ),
            array(
                'id' => 'img_Guarantee_of_Origin',
                'type' => 'media',
                'title' => __("Guarantee of Origin icon image", "bakala"),
                'required' => array('switch_Guarantee_of_Origin', '=', true)
            ),
            array(
                'id' => 'Guarantee_of_Origin',
                'type' => 'select',
                'data' => 'pages',
                'title' => __('Select Guarantee of Origin Page', 'bakala'),
                'desc' => __('Select page that has Guarantee of Origin template.', 'bakala'),
                'required' => array('switch_Guarantee_of_Origin', '=', true)
            ),
        )
    ));
    Redux::set_section(
        $opt_name,
        array(
            'title' => __('پنل پیامک', 'bakala'),
            'id' => 'sms_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-format-chat',
            'fields' => array(
                array(
                    'title' => esc_html(__('انتخاب سرویس دهنده پیامک', 'bakala')),
                    'id' => 'sp_sms',
                    'type' => 'select',
                    'options' => array(
                        'ippanel' => 'ippanel(تمامی شرکت های زیر مجموعه)',
                        'meli' => 'ملی پیامک',
                        'smsir_simple' => 'sms.ir ساده',
                        'smsir_fast' => 'sms.ir ارسال سریع',
                        'kavenegar' => 'کاوه نگار',
                        'parsgreen' => 'پارس گرین',
                        'segalnet' => 'سگال نت',
                        'msgway' => 'راه پیام',
                        'farapayamak' => 'فراپیامک',
                        'rahyab' => 'رهیاب رایانه گستر',
                        'isms' => 'isms.ir',
                    ),
                    'default' => 'ippanel',
                    'subtitle' => __('سرویس دهنده پیامکی خود را انتخاب کنید.', 'bakala'),
                ),

                array(
                    'title' => esc_html(__('نام کاربری پنل پیامکی', 'bakala')),
                    'id' => 'ippanel_username',
                    'type' => 'text',
                    'desc' => __('نام کاربری پنل پیامکی را وارد کنید.', 'bakala'),
                    'required' => array(
                        array('sp_sms', '=', array('ippanel', 'meli', 'segalnet', 'farapayamak','rahyab','isms')),
                    )
                ),
                array(
                    'title' => esc_html(__('نام کاربری دریافت توکن', 'bakala')),
                    'id' => 'rahyab_token_username',
                    'type' => 'text',
                    'desc' => __('نام کاربری دریافت توکن را وارد کنید.', 'bakala'),
                    'required' => array(
                        array('sp_sms', '=', 'rahyab'),
                    )
                ),
            

                array(
                    'title' => esc_html(__('رمز عبور پنل پیامکی', 'bakala')),
                    'id' => 'ippanel_password',
                    'type' => 'password',
                    'desc' => __('رمز عبور پنل پیامکی را وارد کنید.', 'bakala'),
                    'required' => array(
                        array('sp_sms', '=', array('ippanel', 'meli', 'segalnet', 'farapayamak','rahyab','isms')),
                    )
                ),
                array(
                    'title' => esc_html(__('نام شرکت', 'bakala')),
                    'id' => 'rahyab_company',
                    'type' => 'text',
                    'desc' => __('نام شرکت را وارد کنید.', 'bakala'),
                    'required' => array(
                        array('sp_sms', '=', 'rahyab'),
                    )
                ),
                array(
                    'title' => esc_html(__('شماره فرستنده پنل پیامکی', 'bakala')),
                    'id' => 'ippanel_sender',
                    'type' => 'text',
                    'desc' => __('شماره فرستنده پنل پیامکی را وارد کنید.', 'bakala'),
                    'required' => array(
                        array('sp_sms', '=', array('ippanel', 'smsir_fast', 'smsir_simple', 'meli', 'parsgreen', 'segalnet','rahyab','isms')),
                    )
                ),
                array(
                    'title' => esc_html(__('متن پیامک', 'bakala')),
                    'id' => 'lr_sms_text',
                    'type' => 'text',
                    'desc' => __('مقدار کد تایید را با %code% مشخص کنید.', 'bakala.'),
                    'placeholder' => __('فروشگاه اینترنتی باکالا، کد تایید شما %code% می باشد.', 'bakala'),
                    'required' => array(
                        array('sp_sms', '=', array('smsir_simple', 'parsgreen', 'segalnet','rahyab','isms')),
                    )
                ),

                array(
                    'title' => esc_html(__('کلید دسترسی', 'bakala')),
                    'id' => 'ippanel_accesskey',
                    'type' => 'text',
                    'desc' => __('از پنل پیامکی بخش خدمات وب سرویس/کلیدهای دسترسی ایجاد و در این قسمت درج کنید.', 'bakala'),
                    'required' => array(
                        array('sp_sms', '=', array('ippanel', 'smsir_fast', 'parsgreen', 'kavenegar', 'msgway')),
                    )

                ),


            )

        )
    );


    Redux::set_section(
        $opt_name,
        array(
            'title' => __('login', 'bakala'),
            'id' => 'login_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-admin-network',
            'fields' => array(
                array(
                    'title' => esc_html(__('Pop-up login', 'bakala')),
                    'id' => 'popup_login',
                    'type' => 'switch',
                    'on' => esc_html(__('Enabled', 'bakala')),
                    'off' => esc_html(__('Disabled', 'bakala')),
                    'default' => 0,
                    'desc' => __('Show login form in pop-up instead of woocommerce login page.', 'bakala'),
                ),

                array(
                    'title' => esc_html(__('پاپ آپ دیجیتس', 'bakala')),
                    'id' => 'digits',
                    'type' => 'switch',
                    'on' => esc_html(__('Enabled', 'bakala')),
                    'off' => esc_html(__('Disabled', 'bakala')),
                    'default' => 0,
                    'desc' => __('از پاپ آپ دیجیتس برای ورود استفاده کنید!', 'bakala'),
                    'required' => array('popup_login', '=', 1),
                ),


                array(
                    'title' => esc_html(__('ورود/ثبت نام باکالا', 'bakala')),
                    'id' => 'lr_bakala',
                    'type' => 'switch',
                    'on' => esc_html(__('Enabled', 'bakala')),
                    'off' => esc_html(__('Disabled', 'bakala')),
                    'default' => 0,
                    'desc' => __('فعالسازی ورود/ثبت نام با شماره همراه', 'bakala'),
                ),
                array(
                    'title' => esc_html(__('تعداد کاراکتر کد تایید', 'bakala')),
                    'id' => 'lr_code_count',
                    'type' => 'slider',
                    'subtitle' => __('تعداد کاراکتر کد تایید را تعیین کنید.', 'bakala'),
                    "default" => 4,
                    "min" => 4,
                    "step" => 1,
                    "max" => 10,
                    'display_value' => 'text',
                    'required' => array('lr_bakala', '=', 1),
                ),
                array(
                    'title' => esc_html(__('کد پترن', 'bakala')),
                    'id' => 'ippanel_pattern',
                    'type' => 'text',
                    'desc' => __('کد پترن پنل پیامکی را وارد کنید.', 'bakala'),
                    'required' => array('lr_bakala', '=', 1),
                ),
                array(
                    'id' => 'lr_info_meli',
                    'type' => 'raw',
                    'title' => __('<div class="balala_alert"><div>متن پترن خود را طوری تنظیم کنید که دارای یک متغیر به صورت زیر باشد:</div><div style="font-weight:bold;margin-top:10px !important;color: #FDB910;">کد تایید</div><hr><p><strong>متن پیشنهادی:</strong> .کد تائید شما برای ورود/ثبت نام: {0}.</p> </div>', 'bakala'),
                    'required' => array(
                        array('review_reminder_sms', '=', 1),
                        array('sp_sms', '=', 'meli')
                    )
                ),
                array(
                    'id' => 'lr_info_ippanel',
                    'type' => 'raw',
                    'title' => __('<div class="balala_alert"><p><strong>متن پیشنهادی:</strong> کد تأیید ورود شما: %code%</p> </div>', 'bakala'),
                    'required' => array(
                        array('review_reminder_sms', '=', 1),
                        array('sp_sms', '=', 'ippanel')
                    )
                ),
                array(
                    'title' => esc_html(__('متغیر ورودی پترن', 'bakala')),
                    'id' => 'sms_pattern_var',
                    'type' => 'text',
                    'desc' => __('متغیر ورودی کد پترن پنل پیامکی را وارد کنید.', 'bakala'),
                    'required' => array(
                        array('lr_bakala', '=', 1),
                        array('sp_sms', '=', array('ippanel', 'smsir_fast'))
                    )
                ),
                array(
                    'id' => 'bakala_lr_logo',
                    'type' => 'media',
                    'title' => __('لوگو فرم ورود', 'bakala'),
                    'subtitle' => __('لوگو فرم ورود را آپلود کنید.', 'bakala'),
                    'required' => array('lr_bakala', '=', 1)
                ),
                array(
                    'id' => 'lr_bg',
                    'type' => 'color_gradient',
                    'title' => __('پس زمینه فرم ورود دسکتاپ', 'bakala'),
                    'subtitle' => __('پس زمینه فرم را تعیین کنید', 'bakala'),
                    'desc' => __('درصورتیکه می خواهید پس زمینه تک رنگ باشد؛ هر دو رنگ را یکی انتخاب کنید.', 'bakala'),
                    'validate' => 'color',
                    'required' => array('lr_bakala', '=', 1)
                ),
                array(
                    'id' => 'lr_bg_mobile',
                    'type' => 'color_gradient',
                    'title' => __('پس زمینه فرم ورود موبایل', 'bakala'),
                    'subtitle' => __('پس زمینه فرم را تعیین کنید', 'bakala'),
                    'desc' => __('درصورتیکه می خواهید پس زمینه تک رنگ باشد؛ هر دو رنگ را یکی انتخاب کنید.', 'bakala'),
                    'validate' => 'color',
                    'required' => array('lr_bakala', '=', 1)
                ),

                array(
                    'title' => esc_html(__('ورود/ثبت نام با ایمیل', 'bakala')),
                    'id' => 'lr_email_enable',
                    'type' => 'switch',
                    'on' => esc_html(__('Enabled', 'bakala')),
                    'off' => esc_html(__('Disabled', 'bakala')),
                    'default' => 1,
                    'subtitle' => __('جهت غیرفعالسازی ورود/ثبت نام با ایمیل این گزینه را غیرفعال کنید.', 'bakala'),
                    'required' => array('lr_bakala', '=', 1),
                ),
                array(
                    'title' => esc_html(__('ورود/ثبت نام با رمز عبور', 'bakala')),
                    'id' => 'lr_password_enable',
                    'type' => 'switch',
                    'on' => esc_html(__('Enabled', 'bakala')),
                    'off' => esc_html(__('Disabled', 'bakala')),
                    'default' => 0,
                    'subtitle' => __('با فعالسازی این گزینه، کاربر امکان تعیین رمز عبور و ورود با رمز عبور را دارد.', 'bakala'),
                    'required' => array('lr_bakala', '=', 1),
                ),
                array(
                    'title' => esc_html(__('شرایط و قوانین', 'bakala')),
                    'id' => 'lr_privacy_policy',
                    'type' => 'switch',
                    'on' => esc_html(__('Enabled', 'bakala')),
                    'off' => esc_html(__('Disabled', 'bakala')),
                    'default' => 1,
                    'subtitle' => __('با فعالسازی این گزینه، پذیرش قوانین و شرایط از ورود و ثبت نام حذف می شود.', 'bakala'),
                    'required' => array('lr_bakala', '=', 1),
                ),
                array(
                    'title' => esc_html(__('فراموشی رمز عبور', 'bakala')),
                    'id' => 'lr_forget_password',
                    'type' => 'switch',
                    'on' => esc_html(__('Enabled', 'bakala')),
                    'off' => esc_html(__('Disabled', 'bakala')),
                    'default' => 1,
                    'subtitle' => __('با فعالسازی این گزینه، فراموشی رمز عبور از ورود و ثبت نام حذف می شود.', 'bakala'),
                    'required' => array('lr_bakala', '=', 1),
                ),

                array(
                    'title' => esc_html(__('زمان انقاضای کد تایید (ثانیه)', 'bakala')),
                    'id' => 'ippanel_time',
                    'type' => 'text',
                    'desc' => __('زمان انقضای کد تایید را به ثانیه وارد کنید', 'bakala'),
                    'default' => '120',
                    'required' => array('lr_bakala', '=', 1),
                ),

                array(
                    'title' => esc_html(__('نمونه شماره ثبت شده', 'bakala')),
                    'id' => 'phone_number_example',
                    'type' => 'text',
                    'subtitle' => __('اگر قبلا از افزونه ای برای ثبت نام با موبایل استفاده کرده اید یک نمونه از نام کاربری را وارد کنید.', 'bakala'),
                    'placeholder' => 'به عنوان مثال: 091212345678',
                    'required' => array('lr_bakala', '=', 1),
                ),
                array(
                    'id' => 'info_warning_phone',
                    'type' => 'info',
                    'title' => esc_html__('اخطار!', 'bakala'),
                    'style' => 'warning',
                    'desc' => esc_html__('اگر قبلا از افزونه ای مانند دیجیتس برای ثبت نام استفاده کرده اید، وارد کاربران در پیشخوان ورردپرس شوید و نام کاربری یکی از کاربرانی که اخیرا ثبت نام شده است را در فیلد بالا قرار دهید. ', 'bakala'),
                    'required' => array('lr_bakala', '=', 1),
                ),
                array(
                    'title' => esc_html(__('تعداد دفعات تلاش مجاز', 'bakala')),
                    'id' => 'lr_limit_count',
                    'type' => 'slider',
                    'subtitle' => __('تعداد دفعاتی که کاربر مجاز است تا اتمام زمان انقضای کد، برای ارسال کد تایید تلاش کند را تعیین کنید.', 'bakala'),
                    "default" => 2,
                    "min" => 2,
                    "step" => 1,
                    "max" => 10,
                    'display_value' => 'text',
                    'required' => array('lr_bakala', '=', 1),
                ),
                array(
                    'title' => esc_html(__('ورود با شماره موبایل سفارش ووکامرس', 'bakala')),
                    'id' => 'lr_billing_phone',
                    'type' => 'switch',
                    'on' => esc_html(__('Enabled', 'bakala')),
                    'off' => esc_html(__('Disabled', 'bakala')),
                    'default' => 0,
                    'subtitle' => __('با فعالسازی این گزینه، مشتریانی که قبلا بصورت مهمان خرید کرده اند با شماره موبایل ثبت شده در سفارش می توانند وارد حساب کاربری شوند.', 'bakala'),
                    'required' => array('lr_bakala', '=', 1),
                ),
                array(
                    'id' => 'alert_lr_billing_phone',
                    'type' => 'info',
                    'title' => esc_html__('اخطار!', 'bakala'),
                    'style' => 'critical',
                    'icon' => 'el-icon-info-sign',
                    'desc' => 'اگر قصد استفاده از این امکان را دارید؛ به این نکته توجه کنید که هرگز با اکانت خود برای مشتری سفارش درج نکنید چراکه به مشتری اجازه ورود به اکانتتان را می دهید',
                    'required' => array('lr_billing_phone', '=', 1),
                ),
                array(
                    'id' => 'lr_style',
                    'type' => 'button_set',
                    'title' => __('استایل فرم ورود/ثبت نام دسکتاپ', 'bakala'),
                    'subtitle' => __('استایل فرم ورود/ثبت نام در دسکتاپ را تعیین کنید.', 'bakala'),
                    'options' => array(
                        'one' => __('استایل اول', 'bakala'),
                        'two' => __('استایل دوم', 'bakala'),
                    ),
                    'default' => 'one',
                    'required' => array('lr_bakala', '=', true)
                ),
                array(
                    'id' => 'update_display_name',
                    'type' => 'raw',
                    'content' => '<div class="balala_alert" style="background:#000;"><h3 style="color:#FDB910">به‌روزرسانی نام نمایشی کاربران</h3><div style="color:#fff;margin-bottom:20px">(فقط کاربرانی که نام نمایشی آن ها "کاربر گرامی" می باشد.)</div><div class="lr_testing"><button id="update_users_display_name" type="button">به‌روزرسانی</button></div></div>',
                ),
                array(
                    'id' => 'lr_testing',
                    'type' => 'raw',
                    'content' => '<div class="balala_alert" style="background:#000;"><h3 style="color:#FDB910">تست پنل پیامکی</h3><div class="lr_testing"><input type="text" id="lr_testing_phone" placeholder="شماره موبایل شما"><button id="lr_testing_btn" type="button">تست</button></div></div>',

                ),
            )

        )
    );

    Redux::set_section($opt_name, array(
        'title' => __('typography', 'bakala'),
        'id' => 'typo',
        'subsection' => true,
        'icon' => 'dashicons dashicons-editor-spellcheck',
        'fields' => array(

            array(
                'id' => 'body-typography',
                'type' => 'typography',
                'title' => __('Body Typography', 'bakala'),
                'subtitle' => __('You Can Choose Your Custom Body Typography', 'bakala'),
                'google' => false,
                'font-backup' => false,
                'output' => '.a,body,label,li,p,span,ul,body a',
                'color' => false,
                'font-weight' => false,
                'font-size' => true,
                'line-height' => false,
                'text-align' => false,
                'fonts' => array(
                    'iransans' => 'iransans',
                    'iranyekanx' => 'iranyekanx',
                    'kalameh' => 'kalameh',
                    'dana' => 'dana',
                    'mania' => 'mania',
                    'bakh' => 'bakh',
                    'rokh' => 'rokh',
                ),
            ),
            array(
                'id' => 'menu-typography',
                'type' => 'typography',
                'title' => __('Menu Typography', 'bakala'),
                'subtitle' => __('You Can Choose Your Custom Menu Typography', 'bakala'),
                'google' => false,
                'font-backup' => false,
                'output' => '.main-menu-div p, .main-menu-div a, .main-menu-div span, .main-menu-div li, .main-menu-div ul, .off-canvas-panel-wrapper_mo ul, .navbar-primary .promotion-badge ul li a,
                .off-canvas-panel-wrapper_mo li, .off-canvas-panel-wrapper_mo span, .off-canvas-panel-wrapper_mo a,.bk_menu.bk_new_menu .bakala > ul > li > span.title a',
                'color' => true,
                'font-weight' => true,
                'font-size' => true,
                'line-height' => true,
                'text-align' => false,
                'fonts' => array(
                    'iransans' => 'iransans',
                    'iranyekanx' => 'iranyekanx',
                    'kalameh' => 'kalameh',
                    'dana' => 'dana',
                    'mania' => 'mania',
                    'bakh' => 'bakh',
                    'rokh' => 'rokh',
                ),
            ),
            array(
                'title' => esc_html(__('فونت های المنتور', 'bakala')),
                'id' => 'elementor_fonts',
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 0,
                'description' => 'درصورتی که میخواهید فونت های پیشفرض المنتور غیرفعال شود از تنظیمات المنتور، تیک گزینه "غیرفعال کردن فونت های پیشفرض" را بزنید.',
                'subtitle' => __('اگر از فونت های المنتور استفاده می کنید، این گزینه را فعال کنید تا فونت های المنتور اعمال شوند.', 'bakala'),
            ),

        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('General Colors', 'bakala'),
        'id' => 'general_color_section',
        'subsection' => true,
        'icon' => 'dashicons dashicons-admin-customizer',
        'fields' => array(
            array(
                'id' => 'body_bg_color',
                'type' => 'color',
                'title' => __('Body Background Color', 'bakala'),
                'subtitle' => __('Pick a background color for the body (default: #f5f5f5).', 'bakala'),
                'default' => '#f5f5f5',
                'validate' => 'color',
            ),
            array(
                'id' => 'body_bg_image',
                'type' => 'media',
                'title' => __('Background Image', 'bakala'),
                'compiler' => '1',
                'desc' => __('Choose your image to show on body background', 'bakala'),
            ),
            array(
                'id' => 'accent_color1',
                'type' => 'color',
                'title' => __("Accent color #1", "bakala")
            ),
            array(
                'id' => 'accent_color2',
                'type' => 'color',
                'title' => __("Accent color #2", "bakala")
            ),
            array(
                'id' => 'accent-gradient',
                'type' => 'color_gradient',
                'title' => __('Gradient Color', 'bakala'),
                'subtitle' => __('The Gradient Colors Can Change from here', 'bakala'),
                'desc' => __('Gradient Colors must Set Here', 'bakala'),
                'validate' => 'color',
            ),
            array(
                'id' => 'color_type',
                'type' => 'switch',
                'title' => __('نمایش نوین رنگ ها', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه،رنگ ها در برگه محصول به صورت نوین نمایش داده خواهد شد.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'color_compability',
                'type' => 'info',
                'desc' => sprintf(__('For use swatch for all products click below button.<br><b>Important:</b> This option clear all other swatch settings for all products<br><a class="btn btn-torob btn-update-products" href="%1s">Update all products<a>', 'bakala'), home_url('wp-admin/admin-post.php?action=update_product_color')),
            )
        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('Mobile Colors', 'bakala'),
        'id' => 'mobile_section',
        'subsection' => true,
        'icon' => 'dashicons dashicons-smartphone',
        'fields' => array(
            array(
                'id' => 'theme-color',
                'type' => 'color',
                'title' => __("Mobile Address Bar Color", "bakala"),
                'subtitle' => __('Pick a background color for the body (default: #ef3743).', 'bakala'),
                'default' => '#ef3743',
                'validate' => 'color',
            ),
            array(
                'id' => 'm_accent_color1',
                'type' => 'color',
                'title' => __("Mobile Accent color #1", "bakala"),
                'default' => '#5c677d',
                'validate' => 'color',
            ),
            array(
                'id' => 'm_accent_color2',
                'type' => 'color',
                'title' => __("Mobile Accent color #2", "bakala"),
                'default' => '#ef3743',
                'validate' => 'color',
            ),
            array(
                'id' => 'm-accent-gradient',
                'type' => 'color_gradient',
                'title' => __('Mobile Gradient Color', 'bakala'),
                'subtitle' => __('The Gradient Colors Can Change from here', 'bakala'),
                'desc' => __('Gradient Colors must Set Here', 'bakala'),
                'validate' => 'color',
                'default' => array(
                    'from' => '#5C677D',
                    'to' => '#475062',
                ),
                array(
                    'id' => 'pannel-color',
                    'type' => 'color',
                    'title' => __("Mobile Right Panel Color", "bakala"),
                    'subtitle' => __('Pick a background color (default: #ef3743).', 'bakala'),
                    'default' => '#ef3743',
                    'validate' => 'color',
                ),
                array(
                    'id' => 'mobile-menu-color',
                    'type' => 'color',
                    'title' => __("Mobile Menu Color", "bakala"),
                    'subtitle' => __('Pick a background color (default: #fff).', 'bakala'),
                    'default' => '#ffffff',
                    'validate' => 'color',
                ),
                array(
                    'id' => 'mobile-submenu-color',
                    'type' => 'color',
                    'title' => __("Mobile Submenu Color", "bakala"),
                    'subtitle' => __('Pick a background color (default: #ededed).', 'bakala'),
                    'default' => '#ededed',
                    'validate' => 'color',
                ),
                array(
                    'id' => 'mobile-icon-color',
                    'type' => 'color',
                    'title' => __("Mobile Icon Color", "bakala"),
                    'subtitle' => __('Pick a background color (default: #8b8c8f).', 'bakala'),
                    'default' => '#8b8c8f',
                    'validate' => 'color',
                ),
                array(
                    'id' => 'mobile-count-background',
                    'type' => 'color',
                    'title' => __("Mobile Count Background", "bakala"),
                    'subtitle' => __('Pick a background color (default: ef394e).', 'bakala'),
                    'default' => 'ef394e',
                    'validate' => 'color',
                ),
                array(
                    'id' => 'mobile-account-background',
                    'type' => 'color',
                    'title' => __("Mobile account Background", "bakala"),
                    'subtitle' => __('Pick a background color (default: #64d979).', 'bakala'),
                    'default' => '#64d979',
                    'validate' => 'color',
                ),
            )
        )
    ));
    Redux::setSection($opt_name, array(
        'title' => esc_html__('bakala miracle', 'bakala'),
        'icon' => 'dashicons dashicons-awards',
        'fields' => array(
            array(
                'id' => 'styling_general_info_start',
                'type' => 'section',
                'title' => esc_html__('General', 'bakala'),
                'subtitle' => esc_html__('General Theme Style Settings', 'bakala'),
                'indent' => TRUE,
            ),
            array(
                'id' => 'darkmode',
                'title' => esc_html(__('استایل تیره', 'bakala')),
                'subtitle' => esc_html(__('با فعالسازی این گزینه ظاهر قالب تیره خواهد شد.', 'bakala')),
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 0,
            ),
            array(
                'id' => 'darkmode_background_color',
                'title' => esc_html(__('رنگ پس زمینه استایل تیره', 'bakala')),
                'subtitle' => esc_html(__('رنگ پس زمینه استایل تیره را انتخاب کنید.', 'bakala')),
                'type' => 'color',
                'default' => '#262626',
                'validate' => 'color',
                'required' => array('darkmode', '=', 1)
            ),
            array(
                'id' => 'darkmode_text_color',
                'title' => esc_html(__('رنگ متن استایل تیره', 'bakala')),
                'subtitle' => esc_html(__('رنگ متن ها در استایل تیره را انتخاب کنید.', 'bakala')),
                'type' => 'color',
                'default' => '#FFFFFF',
                'validate' => 'color',
                'required' => array('darkmode', '=', 1)
            ),

            // 		array(
            // 			'title'		=> esc_html__( 'Chose your Color template', 'bakala' ),
            // 			'subtitle'	=> esc_html__( 'Choose your template', 'bakala' ),
            // 			'id'		=> 'main_color',
            // 			'type'		=> 'select',
            // 			'options'	=> array(
            // 				'light'		=> esc_html__( 'bakala Light', 'bakala' ),
            // 			),
            // 			'default'	=> 'light'
            // 		),
        )
    ));

    Redux::set_section($opt_name, array(
        'title' => __('پیش بارگذاری', 'bakala'),
        'id' => 'preloading',
        'subsection' => false,
        'icon' => 'dashicons dashicons-image-rotate',
        'fields' => array(
            array(
                'id' => 'bakala_preload',
                'title' => esc_html(__('پیش بارگذاری', 'bakala')),
                'subtitle' => esc_html(__('انیمیشن پیش بارگذاری را هنگام بارگیری محتوای وب سایت خود فعال کنید.', 'bakala')),
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 0,
            ),
            array(
                'id' => 'bakala_preload_css',
                'type' => 'image_select',
                'title' => __('انتخاب لودر', 'bakala'),
                'subtitle' => __('لودر پیش بارگذاری را انتخاب کنید.', 'bakala'),
                'required' => array('bakala_preload', '=', 1),
                'options' => array(
                    'spinner' => array(
                        'alt' => 'spinner',
                        'img' => get_template_directory_uri() . '/vendor/images/loading/spinner.jpg'
                    ),
                    'default' => array(
                        'alt' => 'default',
                        'img' => get_template_directory_uri() . '/vendor/images/loading/default.jpg'
                    ),
                    'grid' => array(
                        'alt' => 'grid',
                        'img' => get_template_directory_uri() . '/vendor/images/loading/grid.jpg'
                    ),
                    'roller' => array(
                        'alt' => 'roller',
                        'img' => get_template_directory_uri() . '/vendor/images/loading/roller.jpg'
                    ),
                    'ellipsis' => array(
                        'alt' => 'ellipsis',
                        'img' => get_template_directory_uri() . '/vendor/images/loading/ellipsis.jpg'
                    ),
                    'ring' => array(
                        'alt' => 'ring',
                        'img' => get_template_directory_uri() . '/vendor/images/loading/ring.jpg'
                    ),
                ),
                'default' => 'spinner'
            ),
            array(
                'id' => 'bakala_preload_css_color',
                'type' => 'color',
                'title' => __('رنگ لودر پیش بارگذاری', 'bakala'),
                'title' => __('رنگ لودر پیش بارگذاری را انتخاب کنید.', 'bakala'),
                'default' => '#000',
                'validate' => 'color',
                'required' => array('bakala_preload', '=', 1)
            ),
            array(
                'id' => 'bakala_preload_gif',
                'type' => 'media',
                'title' => __('تصویر متحرک', 'bakala'),
                'subtitle' => __('تصویر متحرک پیش بارگذاری را آپلود کنید.', 'bakala'),
                'required' => array('bakala_preload', '=', 1)
            ),
            array(
                'id' => 'info_warning_preload',
                'type' => 'info',
                'title' => esc_html__('اخطار!', 'bakala'),
                'style' => 'warning',
                'required' => array('bakala_preload', '=', 1),
                'desc' => esc_html__('استفاده از تصویر متحرک (gif) ممکن است باعث افت رتبه در جی تی متریکس شود؛ لذا توصیه نمی شود. ', 'bakala')
            ),
            array(
                'id' => 'bakala_preload_logo',
                'type' => 'media',
                'title' => __('لوگو پیش بارگذاری', 'bakala'),
                'subtitle' => __('لوگو پیش بارگذاری را آپلود کنید.', 'bakala'),
                'required' => array('bakala_preload', '=', 1)
            ),
            array(
                'id' => 'bakala_preload_color',
                'type' => 'color',
                'title' => __('پس زمینه سایت در هنگام پیش بارگذاری', 'bakala'),
                'subtitle' => __('رنگ پس زمینه سایت در هنگام پیش بارگذاری را انتخاب کنید.', 'bakala'),
                'default' => '#FFFFFF',
                'validate' => 'color',
                'required' => array('bakala_preload', '=', 1)

            ),
        )
    ));

    Redux::set_section($opt_name, array(
        'title' => __('دکمه شناور واتس اپ', 'bakala'),
        'id' => 'bakala_whatsapp',
        'icon' => 'dashicons dashicons-whatsapp',
        'fields' => array(
            array(
                'id' => 'whatsapp_chat',
                'title' => esc_html(__('دکمه شناور چت واتس اپ', 'bakala')),
                'subtitle' => esc_html(__('با فعالسازی این گزینه دکمه شناور چت واتس اپ در سایت فعال می شود.', 'bakala')),
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 0,
            ),
            array(
                'id' => 'whatsapp_chat_mobile',
                'title' => esc_html(__('فعالسازی دکمه شناور چت واتس اپ در موبایل', 'bakala')),
                'subtitle' => esc_html(__('با فعالسازی این گزینه دکمه شناور چت واتس اپ در موبایل فعال می شود.', 'bakala')),
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 1,
                'required' => array('whatsapp_chat', '=', 1),
            ),
            array(
                'id' => 'whatsapp_chat_phone_number',
                'type' => 'text',
                'title' => __("شماره واتس اپ", "bakala"),
                'subtitle' => __("همراه با کد کشور", "bakala"),
                'placeholder' => __("989120123456", "bakala"),
                'required' => array('whatsapp_chat', '=', 1)
            ),
            array(
                'id' => 'whatsapp_chat_text',
                'type' => 'text',
                'title' => __("متن چت واتس اپ", "bakala"),
                'placeholder' => __("پشتیبانی واتس اپ", "bakala"),
                'required' => array('whatsapp_chat', '=', 1)
            ),
            array(
                'id' => 'whatsapp_chat_position_pc',
                'type' => 'switch',
                'title' => esc_html(__('موقعیت دکمه واتس اپ در دسکتاپ', 'bakala')),
                'on' => 'راست',
                'off' => 'چپ',
                'default' => '1',
                'required' => array('whatsapp_chat', '=', 1),
            ),
            array(
                'id' => 'whatsapp_chat_position_x_pc',
                'type' => 'slider',
                'title' => __('فاصله از محور X در دسکتاپ', 'bakala'),
                'subtitle' => __('به px', 'bakala'),
                "default" => 20,
                "min" => 1,
                "step" => 1,
                "max" => 1900,
                'display_value' => 'text',
                'required' => array('whatsapp_chat', '=', 1),

            ),
            array(
                'id' => 'whatsapp_chat_position_y_pc',
                'type' => 'slider',
                'title' => __('فاصله از محور Y در دسکتاپ', 'bakala'),
                'subtitle' => __('به px', 'bakala'),
                "default" => 20,
                "min" => 1,
                "step" => 1,
                "max" => 1900,
                'display_value' => 'text',
                'required' => array('whatsapp_chat', '=', 1),
            ),
            array(
                'id' => 'whatsapp_chat_position_mobile',
                'type' => 'switch',
                'title' => esc_html(__('موقعیت دکمه واتس اپ در موبایل', 'bakala')),
                'on' => 'راست',
                'off' => 'چپ',
                'default' => '1',
                'required' => array('whatsapp_chat_mobile', '=', 1),
            ),
            array(
                'id' => 'whatsapp_chat_position_x_mobile',
                'type' => 'slider',
                'title' => __('فاصله از محور X در موبایل', 'bakala'),
                'subtitle' => __('به px', 'bakala'),
                "default" => 20,
                "min" => 1,
                "step" => 1,
                "max" => 1900,
                'display_value' => 'text',
                'required' => array('whatsapp_chat_mobile', '=', 1),
            ),
            array(
                'id' => 'whatsapp_chat_position_y_mobile',
                'type' => 'slider',
                'title' => __('فاصله از محور Y در موبایل', 'bakala'),
                'subtitle' => __('به px', 'bakala'),
                "default" => 20,
                "min" => 1,
                "step" => 1,
                "max" => 1900,
                'display_value' => 'text',
                'required' => array('whatsapp_chat_mobile', '=', 1),
            ),
        )
    ));


    Redux::set_section($opt_name, array(
        'title' => __('دکمه شناور تماس', 'bakala'),
        'id' => 'float_call',
        'icon' => 'dashicons dashicons-phone',
        'fields' => array(
            array(
                'id' => 'float_call_enable',
                'title' => esc_html(__('فعالسازی دکمه شناور تماس', 'bakala')),
                'subtitle' => esc_html(__('با فعالسازی این گزینه دکمه شناور تماس در سایت فعال می شود.', 'bakala')),
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 0,
            ),
            array(
                'id' => 'float_call_enable_mobile',
                'title' => esc_html(__('فعالسازی دکمه شناور تماس در موبایل', 'bakala')),
                'subtitle' => esc_html(__('با فعالسازی این گزینه دکمه شناور تماس در موبایل فعال می شود.', 'bakala')),
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 1,
                'required' => array('float_call_enable', '=', 1),
            ),
        )
    ));

    Redux::set_section($opt_name, array(
        'title' => __('تنظیمات دکمه', 'bakala'),
        'id' => 'float_call_btn',
        'subsection' => true,
        'icon' => 'dashicons dashicons-button',
        'fields' => array(
            array(
                'id' => 'float_call_color',
                'type' => 'color_gradient',
                'title' => __('رنگ دکمه شناور تماس را تعیین کنید', 'bakala'),
                'required' => array('float_call_enable', '=', 1),
                'validate' => 'color',
            ),
            array(
                'id' => 'float_call_position_pc',
                'type' => 'switch',
                'title' => esc_html(__('موقعیت دکمه تماس در دسکتاپ', 'bakala')),
                'on' => 'راست',
                'off' => 'چپ',
                'default' => '1'
            ),
            array(
                'id' => 'float_call_position_x_pc',
                'type' => 'slider',
                'title' => __('فاصله از محور X در دسکتاپ', 'bakala'),
                'subtitle' => __('به px', 'bakala'),
                "default" => 20,
                "min" => 1,
                "step" => 1,
                "max" => 1900,
                'display_value' => 'text'
            ),
            array(
                'id' => 'float_call_position_y_pc',
                'type' => 'slider',
                'title' => __('فاصله از محور Y در دسکتاپ', 'bakala'),
                'subtitle' => __('به px', 'bakala'),
                "default" => 20,
                "min" => 1,
                "step" => 1,
                "max" => 1900,
                'display_value' => 'text'
            ),
            array(
                'id' => 'float_call_position_mobile',
                'type' => 'switch',
                'title' => esc_html(__('موقعیت دکمه تماس در موبایل', 'bakala')),
                'on' => 'راست',
                'off' => 'چپ',
                'default' => '1',
                'required' => array('float_call_enable_mobile', '=', 1),

            ),
            array(
                'id' => 'float_call_position_x_mobile',
                'type' => 'slider',
                'title' => __('فاصله از محور X در موبایل', 'bakala'),
                'subtitle' => __('به px', 'bakala'),
                "default" => 20,
                "min" => 1,
                "step" => 1,
                "max" => 1900,
                'display_value' => 'text',
                'required' => array('float_call_enable_mobile', '=', 1),
            ),
            array(
                'id' => 'float_call_position_y_mobile',
                'type' => 'slider',
                'title' => __('فاصله از محور Y در موبایل', 'bakala'),
                'subtitle' => __('به px', 'bakala'),
                "default" => 20,
                "min" => 1,
                "step" => 1,
                "max" => 1900,
                'display_value' => 'text',
                'required' => array('float_call_enable_mobile', '=', 1),
            ),
            array(
                'id' => 'float_call_text',
                'type' => 'text',
                'title' => __("متن دکمه تماس", "bakala"),
                'default' => __('تماس با ما', 'bakala')
            ),

        ),
    ));
    Redux::set_section($opt_name, array(
        'title' => __('آیتم های تماس', 'bakala'),
        'id' => 'float_call_items',
        'subsection' => true,
        'icon' => 'dashicons dashicons-menu',
        'fields' => array(
            array(
                'id' => 'phone_start',
                'type' => 'section',
                'title' => esc_html__('شماره ثابت', 'bakala'),
                'indent' => true,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'phone_number',
                'type' => 'text',
                'title' => __("شماره تلفن ثابت را وارد کنید.", "bakala"),
                'placeholder' => __('02112345678', 'bakala')
            ),
            array(
                'id' => 'phone_text',
                'type' => 'text',
                'title' => __("متن تلفن ثابت را وارد کنید.", "bakala"),
                'placeholder' => __('تماس با فروشگاه', 'bakala')
            ),
            array(
                'id' => 'phone_icon_color',
                'type' => 'color',
                'title' => __('رنگ آیکون تلفن ثابت را تعیین کنید', 'bakala'),
                'default' => '#228b22',
                'validate' => 'color',
                'transparent' => false
            ),
            array(
                'id' => 'phone_end',
                'type' => 'section',
                'indent' => false,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'mobile_start',
                'type' => 'section',
                'title' => esc_html__('شماره موبایل', 'bakala'),
                'subtitle' => esc_html__('جهت افزودن شماره موبایل به لیست تماس اطلاعات این بخش را وارد کنید در غیراینصورت خالی رها کنید.', 'bakala'),
                'indent' => true,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'mobile_number',
                'type' => 'text',
                'title' => __("شماره موبایل را وارد کنید.", "bakala"),
                'placeholder' => __('09120123456', 'bakala')
            ),
            array(
                'id' => 'mobile_text',
                'type' => 'text',
                'title' => __("متن موبایل را وارد کنید.", "bakala"),
                'placeholder' => __('تماس با پشتیبان فروشگاه', 'bakala')
            ),
            array(
                'id' => 'mobile_icon_color',
                'type' => 'color',
                'title' => __('رنگ آیکون موبایل را تعیین کنید', 'bakala'),
                'default' => '#ffa500',
                'validate' => 'color',
                'transparent' => false
            ),
            array(
                'id' => 'mobile_end',
                'type' => 'section',
                'indent' => false,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'whatsapp_start',
                'type' => 'section',
                'title' => esc_html__('واتس اپ', 'bakala'),
                'subtitle' => esc_html__('جهت افزودن واتس اپ به لیست تماس اطلاعات این بخش را وارد کنید در غیراینصورت خالی رها کنید.', 'bakala'),
                'indent' => true,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'whatsapp_number',
                'type' => 'text',
                'title' => __("شماره واتس اپ را وارد کنید.", "bakala"),
                'placeholder' => __('9120123456', 'bakala')
            ),
            array(
                'id' => 'whatsapp_text',
                'type' => 'text',
                'title' => __("متن واتس اپ را وارد کنید.", "bakala"),
                'placeholder' => __('ارتباط از طریق واتس اپ', 'bakala')
            ),
            array(
                'id' => 'whatsapp_icon_color',
                'type' => 'color',
                'title' => __('رنگ آیکون واتس اپ را تعیین کنید', 'bakala'),
                'default' => '#25D366',
                'validate' => 'color',
                'transparent' => false
            ),
            array(
                'id' => 'whatsapp_end',
                'type' => 'section',
                'indent' => false,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'telegram_start',
                'type' => 'section',
                'title' => esc_html__('تلگرام', 'bakala'),
                'subtitle' => esc_html__('جهت افزودن تلگرام به لیست تماس اطلاعات این بخش را وارد کنید در غیراینصورت خالی رها کنید.', 'bakala'),
                'indent' => true,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'telegram_username',
                'type' => 'text',
                'title' => __("یوزر نیم گروه ، کانال یا اکانت تلگرام را وارد کنید.", "bakala"),
                'subtitle' => __("بدون @", "bakala"),
                'placeholder' => __('testaccount', 'bakala')
            ),
            array(
                'id' => 'telegram_text',
                'type' => 'text',
                'title' => __("متن تلگرام را وارد کنید.", "bakala"),
                'placeholder' => __('ارتباط از طریق تلگرام', 'bakala')
            ),
            array(
                'id' => 'telegram_icon_color',
                'type' => 'color',
                'title' => __('رنگ آیکون تلگرام را تعیین کنید', 'bakala'),
                'default' => '#20AFDE',
                'validate' => 'color',
                'transparent' => false
            ),
            array(
                'id' => 'telegram_end',
                'type' => 'section',
                'indent' => false,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'instagram_start',
                'type' => 'section',
                'title' => esc_html__('اینستاگرام', 'bakala'),
                'subtitle' => esc_html__('جهت افزودن اینستاگرام به لیست تماس اطلاعات این بخش را وارد کنید در غیراینصورت خالی رها کنید.', 'bakala'),
                'indent' => true,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'instagram_username',
                'type' => 'text',
                'title' => __("آدرس پیج اینستاگرام را وارد کنید.", "bakala"),
                'subtitle' => __("بدون @", "bakala"),
                'placeholder' => __('testaccount', 'bakala')
            ),
            array(
                'id' => 'instagram_text',
                'type' => 'text',
                'title' => __("متن اینستاگرام را وارد کنید.", "bakala"),
                'placeholder' => __('پیج اینستاگرام', 'bakala')
            ),
            array(
                'id' => 'instagram_icon_color',
                'type' => 'color_gradient',
                'title' => __('رنگ آیکون اینستاگرام را تعیین کنید', 'bakala'),
                'validate' => 'color',
                'output' => '.bakala-messanger.msg-item-instagram span',
            ),
            array(
                'id' => 'instagram_end',
                'type' => 'section',
                'indent' => false,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'goftino_start',
                'type' => 'section',
                'title' => esc_html__('گفتینو', 'bakala'),
                'subtitle' => esc_html__('جهت افزودن گفتینو به لیست تماس، پس نصب و فعالسازی افزونه گفتینو این گزینه را فعال کنید.', 'bakala'),
                'indent' => true,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'float_call_goftino',
                'title' => esc_html(__('افزودن گفتینو به دکمه شناور تماس', 'bakala')),
                'subtitle' => esc_html(__('با فعالسازی این گزینه، گفتینو به دکمه شناور تماس افزوده می شود.', 'bakala')),
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 0,
                'required' => array('float_call_enable', '=', 1),
            ),
            array(
                'id' => 'float_call_goftino_title',
                'type' => 'text',
                'title' => __("عنوان آیتم وارد کنید.", "bakala"),
                'placeholder' => __('چت آنلاین گفتینو', 'bakala')
            ),
            array(
                'id' => 'goftino_end',
                'type' => 'section',
                'indent' => false,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'other_float_start',
                'type' => 'section',
                'title' => esc_html__('آیتم های دیگر', 'bakala'),
                'indent' => true,
                'required' => array('float_call_enable', '=', 1)
            ),
            array(
                'id' => 'other_items_float',
                'type' => 'slides',
                'title' => __('آیتم های دیگر', 'bakala'),
                'subtitle' => __('آیتم های دیگری که در موارد فوق وجود ندارد را بصورت سفارشی اضافه کنید.', 'bakala'),
            ),
        ),
    ));


    Redux::setSection($opt_name, array(
        'title' => __('adsense', 'bakala'),
        'id' => 'adsense_section',
        'icon' => 'dashicons dashicons-tickets-alt',
        'subsection' => false,
        'fields' => array(
            array(
                'id' => 'top_bar',
                'type' => 'switch',
                'title' => __('Enable top bar', 'bakala'),
                'subtitle' => __('Enable top bar for display custom offers', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'top_bar_type',
                'type' => 'button_set',
                'title' => __('Top Bar Type', 'bakala'),
                'subtitle' => __('Select type of top bar.', 'bakala'),
                'options' => array(
                    'bgtext' => __('Background and text', 'bakala'),
                    'image' => __('Use Image', 'bakala'),
                ),
                'default' => 'bgtext',
                'required' => array('top_bar', '=', true)
            ),
            array(
                'id' => 'top_bar_bgtext_bg',
                'type' => 'color',
                'title' => __('Background Color', 'bakala'),
                'subtitle' => __('Pick a background color for the top bar (default: #00000).', 'bakala'),
                'default' => '#000000',
                'validate' => 'color',
                'required' => array('top_bar_type', '=', 'bgtext')
            ),
            array(
                'id' => 'top_bar_bgtext_color',
                'type' => 'color',
                'title' => __('Text Color', 'bakala'),
                'subtitle' => __('Pick a color for the top bar text (default: #FFFFFF).', 'bakala'),
                'default' => '#ffffff',
                'validate' => 'color',
                'required' => array('top_bar_type', '=', 'bgtext')
            ),
            array(
                'id' => 'top_bar_bgtext_text',
                'type' => 'editor',
                'title' => __('Your Text', 'bakala'),
                'args' => array(
                    'wpautop' => false,
                    'teeny' => true
                ),
                'required' => array('top_bar_type', '=', 'bgtext')
            ),
            array(
                'id' => 'top_bar_image',
                'type' => 'media',
                'title' => __('Your image', 'bakala'),
                'compiler' => '1',
                'desc' => __('Choose your image to show on top bar', 'bakala'),
                'required' => array('top_bar_type', '=', 'image')
            ),
            array(
                'id' => 'top_bar_link',
                'type' => 'text',
                'title' => __('Top Bar Link', 'bakala'),
                'subtitle' => __('Insert your link for top bar', 'bakala'),
                'required' => array('top_bar', '=', true)
            ),

            array(
                'id' => 'top_bar_link_type',
                'type' => 'button_set',
                'title' => __('نوع لینک بنر', 'bakala'),
                'options' => array(
                    'text' => __('لینک دار شدن متن', 'bakala'),
                    'btn' => __('لینک با دکمه', 'bakala'),
                ),
                'default' => 'text',
                'required' => array('top_bar_type', '=', 'bgtext')
            ),
            array(
                'id' => 'top_bar_btn_text',
                'type' => 'text',
                'title' => __('متن دکمه لینک', 'bakala'),
                'subtitle' => __('متن دکمه لینک بنر را بنویسید.', 'bakala'),
                'placeholder' => 'مشاهده',
                'required' => array('top_bar_link_type', '=', 'btn')
            ),
            array(
                'id' => 'top_bar_btn_color',
                'type' => 'color',
                'title' => __('رنگ متن دکمه لینک', 'bakala'),
                'default' => '#000000',
                'validate' => 'color',
                'required' => array('top_bar_link_type', '=', 'btn')
            ),
            array(
                'id' => 'top_bar_btn_bg',
                'type' => 'color',
                'title' => __('رنگ پس زمینه دکمه لینک', 'bakala'),
                'default' => '#ffffff',
                'validate' => 'color',
                'required' => array('top_bar_link_type', '=', 'btn')
            ),
            //mobile adsense
            array(
                'id' => 'top_bar_mobile',
                'type' => 'switch',
                'title' => __('Enable mobile top bar', 'bakala'),
                'subtitle' => __('Enable mobile top bar for display custom offers', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'top_bar_type_mobile',
                'type' => 'button_set',
                'title' => __('Top Bar Type', 'bakala'),
                'subtitle' => __('Select type of top bar.', 'bakala'),
                'options' => array(
                    'bgtext' => __('Background and text', 'bakala'),
                    'image' => __('Use Image', 'bakala'),
                ),
                'default' => 'bgtext',
                'required' => array('top_bar_mobile', '=', true)
            ),
            array(
                'id' => 'top_bar_bgtext_bg_mobile',
                'type' => 'color',
                'title' => __('Background Color', 'bakala'),
                'subtitle' => __('Pick a background color for the top bar (default: #00000).', 'bakala'),
                'default' => '#000000',
                'validate' => 'color',
                'required' => array('top_bar_type_mobile', '=', 'bgtext')
            ),
            array(
                'id' => 'top_bar_bgtext_color_mobile',
                'type' => 'color',
                'title' => __('Text Color', 'bakala'),
                'subtitle' => __('Pick a color for the top bar text (default: #FFFFFF).', 'bakala'),
                'default' => '#ffffff',
                'validate' => 'color',
                'required' => array('top_bar_type_mobile', '=', 'bgtext')
            ),
            array(
                'id' => 'top_bar_bgtext_text_mobile',
                'type' => 'editor',
                'title' => __('Your Text', 'bakala'),
                'args' => array(
                    'wpautop' => false,
                    'teeny' => true
                ),
                'required' => array('top_bar_type_mobile', '=', 'bgtext')
            ),
            array(
                'id' => 'top_bar_image_mobile',
                'type' => 'media',
                'title' => __('Your image', 'bakala'),
                'compiler' => '1',
                'desc' => __('Choose your image to show on top bar', 'bakala'),
                'required' => array('top_bar_type_mobile', '=', 'image')
            ),
            array(
                'id' => 'top_bar_link_mobile',
                'type' => 'text',
                'title' => __('Top Bar Link', 'bakala'),
                'subtitle' => __('Insert your link for top bar', 'bakala'),
                'required' => array('top_bar_mobile', '=', true)
            ),
            array(
                'id' => 'top_bar_link_type_mobile',
                'type' => 'button_set',
                'title' => __('نوع لینک بنر', 'bakala'),
                'options' => array(
                    'text' => __('لینک دار شدن متن', 'bakala'),
                    'btn' => __('لینک با دکمه', 'bakala'),
                ),
                'default' => 'text',
                'required' => array('top_bar_type_mobile', '=', 'bgtext')
            ),
            array(
                'id' => 'top_bar_btn_text_mobile',
                'type' => 'text',
                'title' => __('متن دکمه لینک', 'bakala'),
                'subtitle' => __('متن دکمه لینک بنر را بنویسید.', 'bakala'),
                'placeholder' => 'مشاهده',
                'required' => array('top_bar_link_type_mobile', '=', 'btn')
            ),
            array(
                'id' => 'top_bar_btn_color_mobile',
                'type' => 'color',
                'title' => __('رنگ متن دکمه لینک', 'bakala'),
                'default' => '#000000',
                'validate' => 'color',
                'required' => array('top_bar_link_type_mobile', '=', 'btn')
            ),
            array(
                'id' => 'top_bar_btn_bg_mobile',
                'type' => 'color',
                'title' => __('رنگ پس زمینه دکمه لینک', 'bakala'),
                'default' => '#ffffff',
                'validate' => 'color',
                'required' => array('top_bar_link_type_mobile', '=', 'btn')
            ),
        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('Header', 'bakala'),
        'id' => 'header_section',
        'icon' => 'dashicons dashicons-welcome-write-blog',
        'fields' => array(


            array(
                'title' => esc_html__('مکان محصول', 'bakala'),
                'subtitle' => esc_html__('با استفاده از این امکان می توانید به محصولات خود مکان اضافه کنید.', 'bakala'),
                'id' => 'enable_location',
                'type' => 'switch',
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),

            array(
                'id' => 'show_cart',
                'type' => 'switch',
                'title' => __('Dispaly cart box', 'bakala'),
                'subtitle' => __('Dispaly cart box in header or not', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),

            array(
                'id' => 'top_bar_trackorder',
                'type' => 'select',
                'data' => 'pages',
                'title' => __('Select Order Tracking Page', 'bakala'),
                'desc' => __('برگه ای که شامل کد کوتاه [bakala_order_tracking] یا المان المنتور "پیگیری سفارش" می باشد را انتخاب کنید.
        ', 'bakala'),
            ),

            array(
                'id' => 'offer_menu_cat',
                'type' => 'select',
                'data' => 'terms',
                'args' => array('taxonomies' => 'product_cat'),
                'title' => __('Wonder category', 'bakala'),
                'desc' => __('Select wonder peoducts category.', 'bakala'),
            ),


            array(
                'id' => 'header_tell',
                'type' => 'switch',
                'title' => __('Add a Contact link in header', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'headerinfobar_tell_page',
                'type' => 'select',
                'data' => 'pages',
                'title' => __('Select Contact Page', 'bakala'),
                'desc' => __('Select page that has Contact.', 'bakala'),
                'required' => array('header_tell', '=', true),
            ),
            array(
                'id' => 'headerinfobar_tell_phone',
                'type' => 'text',
                'title' => __('شماره تماس', 'bakala'),
                'subtitle' => __('درصورتیکه میخواهید در موبایل بجای لینک صفحه تماس با ما، مستقیم به شماره تماس متصل شود؛ شماره تماس خود را وارد کنید.', 'bakala'),
                'placeholder' => '02112345678',
                'required' => array('header_tell', '=', true),
            ),

            array(
                'id' => 'header_categories_enable_pc',
                'type' => 'switch',
                'title' => __('نمایش دسته بندی های محصولات در هدر دسکتاپ', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'header_categories_enable_mobile',
                'type' => 'switch',
                'title' => __('نمایش دسته بندی های محصولات در هدر موبایل', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'header_categories',
                'type' => 'select',
                'multi' => true,
                'data' => 'terms',
                'args' => array('taxonomies' => 'product_cat'),
                'title' => __('انتخاب دسته بندی های هدر', 'bakala'),
                'subtitle' => __('انتخاب کنید کدام دسته بندی ها در هدر نمایش داده شود.', 'bakala'),

            ),
            array(
                'id' => 'popular_searches',
                'type' => 'switch',
                'title' => __('افزودن جستجوهای پرطرفدار به جستجوی محصولات', 'bakala'),
                'subtitle' => __('برای استفاده از این قابلیت باید حتما افزونه "فیبو سرچ" و گزینه تجزیه و تحلیل در افزونه مذکور فعال باشد.', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'popular_searches_number',
                'type' => 'slider',
                'title' => __('تعداد جستجوهای پرطرفدار', 'bakala'),
                "default" => 5,
                "min" => 1,
                "step" => 1,
                "max" => 20,
                'display_value' => 'text',
                'required' => array('popular_searches', '=', true)

            ),
            array(
                'id' => 'popular_searches_banner',
                'type' => 'switch',
                'title' => __('افزودن بنر به جستجوی پرطرفدار', 'bakala'),
                'subtitle' => __('تصویری را به باکس جستجوی پرطرفدار اضافه کنید.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'popular_searches_banner_image',
                'type' => 'media',
                'title' => __('تصویر بنر جستجوی پرطرفدار', 'bakala'),
                'required' => array('popular_searches_banner', '=', 1),
            ),
            array(
                'id' => 'popular_searches_banner_link',
                'type' => 'text',
                'title' => __('لینک بنر جستجوی پرطرفدار', 'bakala'),
                'required' => array('popular_searches_banner', '=', 1),
            ),
            array(
                'id' => 'info_warning_popular_searches',
                'type' => 'info',
                'title' => esc_html__('نکته مهم!', 'bakala'),
                'style' => 'critical',
                'desc' => esc_html__('برای فیلتر کردن عبارت های جستجو به  "تنظیمات قالب/تجزیه و تحلیل جستجو" مراجعه کنید و هر عبارتی که قصد عدم نمایش آن را دارید را غیرفعال کنید. ', 'bakala'),
                'required' => array('popular_searches', '=', 1),
            ),


            array(
                'id' => 'search_shortcode',
                'type' => 'text',
                'title' => __('شورت کد جستجو', 'bakala'),
                'subtitle' => __('اگر از فیبوسرچ استفاده نمیکنید شورت کد مدنظر را وارد کنید. مثال: [wcas-search-form]', 'bakala'),
            ),
            /*array(
                'id'         => 'modern_header_mobile_logo',
                'type'         => 'switch',
                'title'     => __('لوگو در صفحه محصول هدر نوین موبایل', 'bakala'),
                'subtitle'    => __('با فعالسازی این گزینه، در صفحه محصول در هدر نوین موبایل، لوگو اضافه می شود.', 'bakala'),
                'default'    => 1,
                'on'         => __('Enable', 'bakala'),
                'off'         => __('Disable', 'bakala'),
                'required' => array('modern_header_mobile', '=', true),
            ),*/
        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('هدر دسکتاپ', 'bakala'),
        'id' => 'header_pc',
        'subsection' => true,
        'icon' => 'dashicons dashicons-desktop',
        'fields' => array(
            array(
                'title' => esc_html__('سربرگ چسبان', 'bakala'),
                'subtitle' => __('با فعال کردن این گزینه سربرگ وبسایت در دسکتاپ با اسکرول ثابت میماند', 'bakala'),
                'id' => 'sticky_header_desk',
                'type' => 'switch',
                'on' => esc_html__('Enabled', 'bakala'),
                'off' => esc_html__('Disabled', 'bakala'),
                'default' => 0,
            ),
            array(
                'title' => esc_html__('Menu type', 'bakala'),
                'subtitle' => esc_html__('Choose menu type.', 'bakala'),
                'id' => 'menu_type',
                'type' => 'button_set',
                'options' => array(
                    'type1' => __('Type 1', 'bakala'),
                    'type2' => __('Type 2', 'bakala'),
                    'type3' => __('Type 3', 'bakala'),
                ),
                'default' => 'type2',
            ),
            array(
                'id' => 'menu_level',
                'type' => 'button_set',
                'title' => __('Menu layout', 'bakala'),
                'subtitle' => __('Select menu layout.', 'bakala'),
                'options' => array(
                    'four' => __('4 Level', 'bakala'),
                    'three' => __('3 Level', 'bakala'),
                ),
                'default' => 'four',
				'required' => array( 
        array('menu_type', '!=', 'type3')  
    ),
            ),
            array(
                'id' => 'show_search',
                'type' => 'switch',
                'title' => __('Dispaly search box', 'bakala'),
                'subtitle' => __('Dispaly search box in header or not', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'header_type',
                'type' => 'button_set',
                'title' => __('استایل هدر', 'bakala'),
                'subtitle' => __('استایل هدر را تعیین کنید', 'bakala'),
                'options' => array(
                    'main' => __('هدر اول', 'bakala'),
                    'mobit' => __('هدر دوم', 'bakala'),
                ),
                'default' => 'main',
            ),
        ),
    ));
    Redux::set_section($opt_name, array(
        'title' => __('هدر موبایل', 'bakala'),
        'id' => 'header_mobile',
        'subsection' => true,
        'icon' => 'dashicons dashicons-smartphone',
        'fields' => array(
            array(
                'title' => esc_html__('سربرگ چسبان', 'bakala'),
                'subtitle' => __('با فعال کردن این گزینه سربرگ وبسایت در موبایل با اسکرول ثابت میماند', 'bakala'),
                'id' => 'sticky_header_mob',
                'type' => 'switch',
                'on' => esc_html__('Enabled', 'bakala'),
                'off' => esc_html__('Disabled', 'bakala'),
                'default' => 0,
            ),
            array(
                'id' => 'mobile_menu',
                'type' => 'switch',
                'title' => __('Using Different Menu On Mobile Theme', 'bakala'),
                'subtitle' => __('If enable this option, menu mobile location add to nav and you can choose different menu.', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'modern_header_mobile',
                'type' => 'switch',
                'title' => __('هدر نوین موبایل', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه هدر در موبایل ظاهر و ساختار نوین میگیرد', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'modern_header_mobile_style',
                'type' => 'button_set',
                'title' => __('استایل هدر نوین', 'bakala'),
                'subtitle' => __('استایل هدر نوین را تعیین کنید', 'bakala'),
                'options' => array(
                    'one' => __('استایل اول', 'bakala'),
                    'two' => __('استایل دوم', 'bakala'),
                ),
                'default' => 'one',
            ),
            array(
                'id' => 'modern_header_mobile_search',
                'type' => 'switch',
                'title' => __('فیلد جستجو در هدر نوین موبایل', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه، فیلد جستجو به هدر نوین موبایل اضافه می شود.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'home_button',
                'type' => 'switch',
                'title' => __('نمایش دکمه خانه در هدر نوین محصول', 'bakala'),
                'subtitle' => __('نمایش/عدم نمایش دکمه خانه در هدر موبایل محصول را تعیین کنید.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'home_button_type',
                'type' => 'button_set',
                'title' => __('نوع دکمه خانه در هدر نوین محصول', 'bakala'),
                'subtitle' => __('نوع دکمه خانه در هدر موبایل محصول را تعیین کنید.', 'bakala'),
                'options' => array(
                    'icon' => __('ایکن', 'bakala'),
                    'logo' => __('لوگو', 'bakala'),
                ),
                'default' => 'logo',
                'required' => array('home_button', '=', 1),
            ),
        ),
    ));
    Redux::set_section($opt_name, array(
        'title' => __('منوی پایین موبایل', 'bakala'),
        'id' => 'bottom_navbar',
        'icon' => 'dashicons dashicons-pressthis',
        'fields' => array(
            array(
                'title' => esc_html__('فعالسازی منوی پایینی موبایل', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه منوی پایینی موبایل نمایش داده خواهد شد.', 'bakala'),
                'id' => 'bottom_navbar_enable',
                'type' => 'switch',
                'on' => esc_html__('Enabled', 'bakala'),
                'off' => esc_html__('Disabled', 'bakala'),
                'default' => 1,
            ),
            array(
                'title' => esc_html__('نوع نمایش منوی پایینی موبایل', 'bakala'),
                'subtitle' => __('نوع نمایش منوی پایینی موبایل را تعیین کنید.', 'bakala'),
                'id' => 'bottom_navbar_type',
                'type' => 'switch',
                'on' => esc_html__('عنوان + آیکون', 'bakala'),
                'off' => esc_html__('فقط آیکون', 'bakala'),
                'default' => 1,
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'id' => 'bottom_navbar_items_section-start',
                'type' => 'section',
                'title' => esc_html__('آیتم های نوار پایینی', 'bakala'),
                'indent' => true,
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'title' => esc_html__('خانه', 'bakala'),
                'id' => 'bottom_navbar_home',
                'type' => 'switch',
                'on' => esc_html__('Enabled', 'bakala'),
                'off' => esc_html__('Disabled', 'bakala'),
                'default' => 1,
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'title' => esc_html__('دسته بندی ها', 'bakala'),
                'id' => 'bottom_navbar_categories',
                'type' => 'switch',
                'on' => esc_html__('Enabled', 'bakala'),
                'off' => esc_html__('Disabled', 'bakala'),
                'default' => 1,
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'id' => 'categories_page',
                'type' => 'select',
                'data' => 'pages',
                'title' => __('انتخاب برگه دسته بندی محصولات', 'bakala'),
                'subtitle' => __('درصورتیکه برگه ای انتخاب نکنید بطور پیشفرض برگه فروشگاه انتخاب می شود.', 'bakala'),
                'required' => array('bottom_navbar_categories', '=', true),
            ),
            array(
                'title' => esc_html__('علاقه مندی', 'bakala'),
                'id' => 'bottom_navbar_favorites',
                'type' => 'switch',
                'on' => esc_html__('Enabled', 'bakala'),
                'off' => esc_html__('Disabled', 'bakala'),
                'default' => 1,
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'title' => esc_html__('سفارشات', 'bakala'),
                'id' => 'bottom_navbar_orders',
                'type' => 'switch',
                'on' => esc_html__('Enabled', 'bakala'),
                'off' => esc_html__('Disabled', 'bakala'),
                'default' => 1,
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'id' => 'bottom_navbar_items_section-end',
                'type' => 'section',
                'indent' => false,
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'id' => 'bottom_navbar_style_section-start',
                'type' => 'section',
                'title' => esc_html__('تنظیمات ظاهری', 'bakala'),
                'indent' => true,
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'id' => 'bottom_navbar_bg',
                'type' => 'color',
                'title' => __('رنگ نوار', 'bakala'),
                'subtitle' => __('رنگ نوار پایینی را تعیین کنید.', 'bakala'),
                'default' => '#ffffff',
                'validate' => 'color',
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'id' => 'bottom_navbar_icon_color',
                'type' => 'color',
                'title' => __('رنگ آیکون ها', 'bakala'),
                'subtitle' => __('رنگ آیکون ها را تعیین کنید.', 'bakala'),
                'default' => '#666666',
                'validate' => 'color',
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'id' => 'bottom_navbar_icon_active_color',
                'type' => 'color',
                'title' => __('رنگ آیکون فعال', 'bakala'),
                'subtitle' => __('رنگ آیکون فعال را تعیین کنید.', 'bakala'),
                'default' => '#000000',
                'validate' => 'color',
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'id' => 'bottom_navbar_label_color',
                'type' => 'color',
                'title' => __('رنگ عنوان ها', 'bakala'),
                'subtitle' => __('رنگ آیکون ها را تعیین کنید.', 'bakala'),
                'default' => '#666666',
                'validate' => 'color',
                'required' => array('bottom_navbar_enable', '=', true),
            ),
            array(
                'id' => 'bottom_navbar_label_active_color',
                'type' => 'color',
                'title' => __('رنگ عنوان فعال', 'bakala'),
                'subtitle' => __('رنگ متن فعال را تعیین کنید.', 'bakala'),
                'default' => '#000000',
                'validate' => 'color',
                'required' => array('bottom_navbar_enable', '=', true),
            ),
        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('Footer', 'bakala'),
        'id' => 'footer_section',
        'icon' => 'dashicons dashicons-schedule',
        'fields' => array(
            array(
                'id' => 'footerproducts',
                'type' => 'switch',
                'title' => __('Enable Recently Viewed Products', 'bakala'),
                'subtitle' => __('Enable Recently Viewed Products In Footer Area', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'footer_logo',
                'type' => 'switch',
                'title' => __('نمایش لوگو در فوتر', 'bakala'),
                'subtitle' => __('می توانید نمایش لوگو در فوتر را پنهان کنید.', 'bakala'),
                'default' => 1,
                'on' => __('نمایش', 'bakala'),
                'off' => __('پنهان', 'bakala'),
            ),
            array(
                'title' => esc_html(__('Scroll To Top', 'bakala')),
                'id' => 'scrollup',
                'type' => 'switch',
                'on' => esc_html(__('Enabled', 'bakala')),
                'off' => esc_html(__('Disabled', 'bakala')),
                'default' => 1,
            ),
            array(
                'id' => 'footerinfobar',
                'type' => 'switch',
                'title' => __('Enable footer info bar', 'bakala'),
                'subtitle' => __('Enable footer info bar for display support info', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'footerinfobar_slogan',
                'type' => 'text',
                'title' => __('Footer Info Bar Slogan', 'bakala'),
                'subtitle' => __('Insert your footer info bar slogan', 'bakala'),
                'required' => array('footerinfobar', '=', true)
            ),
            array(
                'id' => 'footerinfobar_email',
                'type' => 'text',
                'title' => __('Footer Info Bar Email Address', 'bakala'),
                'subtitle' => __('Insert your footer info bar email address', 'bakala'),
                'required' => array('footerinfobar', '=', true)
            ),
            array(
                'id' => 'footerinfobar_email_label',
                'type' => 'text',
                'title' => __('برچسب آدرس پست الکترونیک', 'bakala'),
                'default' => __('آدرس ایمیل', 'bakala'),
                'subtitle' => __('می توانید این برچسب را تغییر دهید.', 'bakala'),
                'required' => array('footerinfobar', '=', true)
            ),
            array(
                'id' => 'footerinfobar_phone',
                'type' => 'text',
                'title' => __('Footer Info Bar Phone Number', 'bakala'),
                'subtitle' => __('Insert your footer info bar phone number', 'bakala'),
                'required' => array('footerinfobar', '=', true)
            ),
            array(
                'id' => 'footerinfobar_phone_label',
                'type' => 'text',
                'title' => __('برچسب شماره تماس', 'bakala'),
                'default' => __('شماره تماس', 'bakala'),
                'subtitle' => __('می توانید این برچسب را تغییر دهید.', 'bakala'),
                'required' => array('footerinfobar', '=', true)
            ),
            array(
                'id' => 'footerinfobar_phone_p',
                'type' => 'select',
                'data' => 'pages',
                'title' => __('Select Contact Page', 'bakala'),
                'desc' => __('Select page that has contact information.', 'bakala'),
            ),
            array(
                'id' => 'footer_location',
                'type' => 'text',
                'title' => __('آدرس فروشگاه', 'bakala'),
                'subtitle' => __('آدرس فروشگاه خود را وارد کنید!', 'bakala'),
            ),
            array(
                'id' => 'footersubscribe',
                'type' => 'switch',
                'title' => __('Enable footer Subscribe Bar', 'bakala'),
                'subtitle' => __('Enable footer subscribe bar.', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'footer_newsletter_title',
                'type' => 'text',
                'title' => __('Footer Subscribe Form Title', 'bakala'),
                'subtitle' => __('Insert your footer subscribe form title', 'bakala'),
            ),
            array(
                'id' => 'footer_newsletter_marketing_text',
                'type' => 'text',
                'title' => __('Footer Subscribe Form Shortcode', 'bakala'),
                'subtitle' => __('Insert your footer subscribe form shortcode (use contact form 7 plugin)', 'bakala'),
            ),
            array(
                'id' => 'copyright-one',
                'type' => 'text',
                'title' => __('CopyRight Text', 'bakala'),
                'subtitle' => __('Insert your copyright text', 'bakala'),
            ),
            array(
                'id' => 'copyright-two',
                'type' => 'text',
                'title' => __('CopyRight Text Two', 'bakala'),
                'subtitle' => __('Insert your copyright text', 'bakala'),
            ),
            array(
                'id' => 'footer-home',
                'type' => 'switch',
                'title' => __('Hide footer about section except homepage', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'footer_credit_left_html',
                'type' => 'textarea',
                'title' => __('Enamad And Other Scripts', 'bakala'),
                'desc' => __('Insert your Enamad or other scripts code', 'bakala'),
            ),
            array(
                'id' => 'footer_credit',
                'type' => 'editor',
                'title' => __('Your Text About Website', 'bakala'),
                'args' => array(
                    'wpautop' => false,
                    'teeny' => true
                ),
            ),
            array(
                'id' => 'mobile-footer-text',
                'type' => 'textarea',
                'title' => __('Your Text Or Enamad Code To Show On Mobile Footer', 'bakala'),
                'args' => array(
                    'wpautop' => false,
                    'teeny' => true
                ),
            ),
            array(
                'id' => 'footer_fixed_box',
                'type' => 'switch',
                'title' => __('Show fixed box in adoptive', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),

            array(
                'id' => 'fixed_box_title',
                'type' => 'text',
                'title' => __('Title', 'bakala'),
                'required' => array('footer_fixed_box', '=', 1),
            ),
            array(
                'id' => 'fixed_box_img',
                'type' => 'media',
                'title' => __('Image', 'bakala'),
                'required' => array('footer_fixed_box', '=', 1),
            ),
            array(
                'id' => 'fixed_box_link',
                'type' => 'text',
                'title' => __('link', 'bakala'),
                'required' => array('footer_fixed_box', '=', 1),
            ),
            array(
                'id' => 'fixed_box_btntxt',
                'type' => 'text',
                'title' => __('Button text ', 'bakala'),
                'required' => array('footer_fixed_box', '=', 1),
            ),
            array(
                'id' => 'footer_style',
                'type' => 'button_set',
                'title' => __('استایل فوتر', 'bakala'),
                'subtitle' => __('نوع نمایش فوتر را انتخاب کنید.', 'bakala'),
                'options' => array(
                    'old' => __('قدیمی', 'bakala'),
                    'new' => __('جدید', 'bakala'),
                    'mobit' => __('استایل سوم', 'bakala'),
                ),
                'default' => 'old',
            ),
            array(
                'id' => 'jump_style',
                'type' => 'button_set',
                'title' => __('استایل دکمه بازگشت به بالا', 'bakala'),
                'subtitle' => __('نوع نمایش دکمه بازگشت به بالا را انتخاب کنید.', 'bakala'),
                'options' => array(
                    'static' => __('ثابت (استایل قبلی)', 'bakala'),
                    'fixed' => __('شناور', 'bakala'),
                ),
                'default' => 'static',
            ),
        )


    ));
    if (class_exists('WooCommerce')) {

        Redux::set_section($opt_name, array(
            'title' => __('Woocommerce', 'bakala'),
            'id' => 'parent_shop_section',
            'icon' => 'dashicons dashicons-cart',
        ));

        Redux::set_section($opt_name, array(
            'title' => __('Shop', 'bakala'),
            'id' => 'shop_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-store',
            'fields' => array(
                array(
                    'title' => esc_html__('General', 'bakala'),
                    'id' => 'shop_general_info_start',
                    'type' => 'section',
                    'indent' => true
                ),
                array(
                    'title' => esc_html__('Referer', 'bakala'),
                    'subtitle' => esc_html__('Redirect customerts to referer page after login & register.', 'bakala'),
                    'id' => 'referer',
                    'type' => 'switch',
                    'on' => esc_html__('Enabled', 'bakala'),
                    'off' => esc_html__('Disabled', 'bakala'),
                    'default' => 1,
                ),
                array(
                    'title' => esc_html__('Password strength', 'bakala'),
                    'subtitle' => esc_html__('Disable password strength is registration form.', 'bakala'),
                    'id' => 'password_strength',
                    'type' => 'switch',
                    'on' => esc_html__('Enabled', 'bakala'),
                    'off' => esc_html__('Disabled', 'bakala'),
                    'default' => 0,
                ),
                array(
                    'title' => esc_html__('Ajax Mode', 'bakala'),
                    'subtitle' => esc_html__('Enable / Disable the Ajax Mode.', 'bakala'),
                    'id' => 'ajax_mode',
                    'type' => 'switch',
                    'on' => esc_html__('Enabled', 'bakala'),
                    'off' => esc_html__('Disabled', 'bakala'),
                    'default' => 1,
                ),
                array(
                    'id' => 'pagination_type',
                    'type' => 'button_set',
                    'title' => __('نوع صفحه بندی', 'bakala'),
                    'subtitle' => __('نوع صفحه بندی ایجکسی را مشخص کنید.', 'bakala'),
                    'options' => array(
                        'numeric' => __('عددی', 'bakala'),
                        'load_more' => __('دکمه بارگزاری بیشتر', 'bakala'),
                        'infinite_scroll' => __('اسکرول بینهایت', 'bakala'),
                    ),
                    'default' => 'numeric',
                ),
                array(
                    'title' => esc_html__('New tab', 'bakala'),
                    'subtitle' => esc_html__('Open products in new tab.', 'bakala'),
                    'id' => 'new_tab',
                    'type' => 'switch',
                    'on' => esc_html__('Enabled', 'bakala'),
                    'off' => esc_html__('Disabled', 'bakala'),
                    'default' => 1,
                ),
                array(
                    'title' => esc_html__('New tab in carousels', 'bakala'),
                    'subtitle' => esc_html__('Open products in new tab.', 'bakala'),
                    'id' => 'cnew_tab',
                    'type' => 'switch',
                    'on' => esc_html__('Enabled', 'bakala'),
                    'off' => esc_html__('Disabled', 'bakala'),
                    'default' => 0,
                ),
                array(
                    'id' => 'archive_style',
                    'type' => 'button_set',
                    'title' => __('Products layout', 'bakala'),
                    'subtitle' => __('Select Products layout in archive page.', 'bakala'),
                    'options' => array(
                        'grid' => __('Grid', 'bakala'),
                        'listing' => __('Listing', 'bakala'),
                    ),
                    'default' => 'grid',
                ),
                array(
                    'title' => esc_html__('Catalog Mode', 'bakala'),
                    'subtitle' => esc_html__('Enable / Disable the Catalog Mode.', 'bakala'),
                    'id' => 'catalog_mode',
                    'type' => 'switch',
                    'on' => esc_html__('Enabled', 'bakala'),
                    'off' => esc_html__('Disabled', 'bakala'),
                    'default' => 0,
                ),
                array(
                    'title' => esc_html__('Products count', 'bakala'),
                    'subtitle' => esc_html__('Number of products that show in shop page', 'bakala'),
                    'id' => 'product_no',
                    'type' => 'slider',
                    "default" => 12,
                    "min" => 1,
                    "step" => 1,
                    "max" => 200,
                    'display_value' => 'text',
                ),


                array(
                    'id' => 'product_placeholder',
                    'type' => 'media',
                    'title' => __('Product Placeholder', 'bakala'),
                    'default' => array('url' => get_template_directory_uri() . '/vendor/images/product-placeholder.png'),
                    'desc' => __('Choose your images to show for products that has no images.', 'bakala'),
                ),
                array(
                    'title' => esc_html__('Show last price change', 'bakala'),
                    'subtitle' => esc_html__('Show last price change and modified date in loop', 'bakala'),
                    'id' => 'show_modified_price_change',
                    'type' => 'switch',
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'title' => esc_html__('درصد تخفیف رند', 'bakala'),
                    'subtitle' => esc_html__('اگر این گزینه را فعال کنید درصد تخفیف در سایت بدون اعشار و رند شده نمایش داده می شود.', 'bakala'),
                    'id' => 'sale_perc_rond',
                    'type' => 'switch',
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'title' => esc_html__('قیمت بازه ای محصولات متغیر', 'bakala'),
                    'subtitle' => esc_html__('اگر این گزینه را فعال کنید قیمت محصولات متغیر بصورت بازه نمایش داده می شود.', 'bakala'),
                    'id' => 'range_price',
                    'type' => 'switch',
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'force_login_cart',
                    'title' => esc_html__('لاگین اجباری برای خرید', 'bakala'),
                    'subtitle' => esc_html__('با فعالسازی این گزینه، مشتریان برای خرید از سایت باید لاگین شوند.', 'bakala'),
                    'type' => 'switch',
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'hide_price',
                    'title' => esc_html__('پنهان کردن قیمت', 'bakala'),
                    'subtitle' => esc_html__('با فعالسازی این گزینه، مشتریان برای دیدن قیمت محصولات باید لاگین شوند.', 'bakala'),
                    'type' => 'switch',
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'show_category_count',
                    'title' => esc_html__('نمایش تعداد محصولات دسته بندی', 'bakala'),
                    'subtitle' => esc_html__('با فعالسازی این گزینه، تعداد هر دسته بندی نمایش داده می شود.', 'bakala'),
                    'type' => 'switch',
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'loop-cart',
                    'type' => 'switch',
                    'title' => __('Display Add To Cart Button', 'bakala'),
                    'subtitle' => __('Display add to cart button on shop loop and category page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'quantity_content_product',
                    'type' => 'switch',
                    'title' => __('نمایش تعداد در فروشگاه', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، در برگه فروشگاه و دسته بندی ها، تعداد در کنار دکمه افزودن به سبد خرید اضافه می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'subcategories_type',
                    'type' => 'switch',
                    'title' => __('نحوه نمایش زیردسته ها', 'bakala'),
                    'subtitle' => __('نحوه نمایش زیر دسته ها در دسته بندی های محصولات را تعیین کنید.', 'bakala'),
                    'default' => 1,
                    'on' => __('نوین', 'bakala'),
                    'off' => __('قدیمی', 'bakala'),
                ),
                array(
                    'id' => 'category_panel_type',
                    'type' => 'switch',
                    'title' => __('نحوه نمایش مرتب سازی و فیلترها در موبایل', 'bakala'),
                    'subtitle' => __('نحوه نمایش مرتب سازی و فیلترها در موبایل را تعیین کنید.', 'bakala'),
                    'default' => 1,
                    'on' => __('چسبیده به پایین', 'bakala'),
                    'off' => __('چسبیده به بالا', 'bakala'),
                ),
                array(
                    'id' => 'show_variables_shop',
                    'type' => 'switch',
                    'title' => __('نمایش متغیرها در دسته بندی ها و فروشگاه', 'bakala'),
                    'subtitle' => __('نمایش متغیرها و افزودن به سبد خرید در باکس محصول در دسته بندی ها و فروشگاه', 'bakala'),
                    'default' => 0,
                    'on' => __('نمایش', 'bakala'),
                    'off' => __('پنهان', 'bakala'),
                ),
                array(
                    'id' => 'product_hover_image',
                    'type' => 'switch',
                    'title' => __('نمایش تصویر دوم محصول در هاور', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، تصویر دوم محصول هنگام هاور نمایش داده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('نمایش', 'bakala'),
                    'off' => __('پنهان', 'bakala'),
                ),
                array(
                    'id' => 'post_status_order',
                    'type' => 'switch',
                    'title' => __('افزودن وضعیت سفارش تحویل به پست', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، وضعیت تحویل به پست به سفارشات افزوده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'tipax_status_order',
                    'type' => 'switch',
                    'title' => __('افزودن وضعیت سفارش تحویل به تیپاکس', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، وضعیت تحویل به تیپاکس به سفارشات افزوده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'home_breadcrumb_text',
                    'type' => 'text',
                    'title' => __('عنوان جایگزین خانه در مسیر راهنما', 'bakala'),
                    'subtitle' => __('عنوان خانه را در مسیر راهما(بردکرامب) می توانید تغییر دهید.', 'bakala'),
                ),

                array(
                    'title' => esc_html__('تگ عنوان دسته بندی محصولات', 'bakala'),
                    'subtitle' => esc_html__('تگ عنوان دسته بندی محصولات را انتخاب کنید', 'bakala'),
                    'id' => 'product_archive_title',
                    'type' => 'select',
                    'options' => array(
                        'h1' => 'h1',
                        'h2' => 'h2',
                        'h3' => 'h3',
                        'h4' => 'h4',
                        'h5' => 'h5',
                        'h6' => 'h6',
                        'p' => 'p',
                        'span' => 'span',
                        'div' => 'div',
                    ),
                    'default' => 'h1',
                ),
                array(
                    'id' => 'last_no_price',
                    'type' => 'switch',
                    'title' => __('انتقال محصولات بدون قیمت به انتها', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، محصولاتی که بدون قیمت هستند به انتهای لیست محصولات منتقل می شوند.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'price_symbol_type',
                    'type' => 'switch',
                    'title' => __('استفاده از فونت بجای تومان', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه،رنگ ها در برگه محصول به صورت نوین نمایش داده خواهد شد.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'archive_description_position',
                    'type' => 'button_set',
                    'title' => __('جایگاه توضیحات دسته بندی محصولات', 'bakala'),
                    'subtitle' => __('جایگاه توضیحات دسته بندی محصولات را تعیین کنید.', 'bakala'),
                    'options' => array(
                        'before' => __('قبل از محصولات', 'bakala'),
                        'after' => __('بعد از محصولات', 'bakala'),
                    ),
                    'default' => 'after',
                ),
                array(
                    'id' => 'archive_description_style',
                    'type' => 'button_set',
                    'title' => __('نحوه نمایش توضیحات دسته بندی محصولات', 'bakala'),
                    'subtitle' => __('نحوه نمایش توضیحات دسته بندی محصولات را تعیین کنید.', 'bakala'),
                    'options' => array(
                        'normal' => __('معمولی', 'bakala'),
                        'accordion' => __('آکاردئونی', 'bakala'),
                    ),
                    'default' => 'normal',
                ),
                array(
                    'id' => 'cart_icon',
                    'type' => 'button_set',
                    'title' => __('ایکن سبد خرید', 'bakala'),
                    'subtitle' => __('می توانید ایکن سبد خرید را تغییر دهید.', 'bakala'),
                    'options' => array(
                        'one' => __('ایکن اول', 'bakala'),
                        'two' => __('ایکن دوم', 'bakala'),
                        'three' => __('ایکن سوم', 'bakala'),
                        'four' => __('ایکن چهارم', 'bakala'),
                        'five' => __('ایکن پنجم', 'bakala'),
                    ),
                    'default' => 'one',
                ),

                array(
                    'id' => 'best_sellers_sort',
                    'type' => 'switch',
                    'title' => __('افزودن گزینه "پرفروش ترین" به مرتب سازی محصولات', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، گزینه پرفروشترین به مرتب سازی محصولات ووکامرس اضافه می شود.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'mobile_cats_page',
                    'type' => 'section',
                    'title' => esc_html__('صفحه دسته بندی محصولات موبایل', 'bakala'),
                    'indent' => true,
                ),
                array(
                    'id' => 'exclude_cats_page',
                    'type' => 'select',
                    'data' => 'terms',
                    'args' => array('taxonomies' => 'product_cat'),
                    'title' => __('دسته های استثنا در صفحه دسته بندی محصولات موبایل', 'bakala'),
                    'desc' => __('دسته هایی که نمیخواهید در صفحه دسته بندی محصولات موبایل نمایش داده نشوند را انتخاب کنید.', 'bakala'),
                ),
                array(
                    'id' => 'hide_empty_cats',
                    'type' => 'switch',
                    'title' => __('نمایش دسته بندی های خالی', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، دسته بندی های خالی (بدون محصول) نیز نمایش داده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('Cart & Shipping', 'bakala'),
            'id' => 'shipping_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-location',
            'fields' => array(

                array(
                    'id' => 'floating-cart',
                    'type' => 'switch',
                    'title' => __('Floating shopping cart', 'bakala'),
                    'subtitle' => __('When you add to cart, the cart list opens from the side.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'add_to_cart_action',
                    'title' => __('اقدام پس از افزودن به سبد خرید', 'bakala'),
                    'subtitle' => __('انتخاب کنید که پس از افزودن به سبد خرید چه اقدامی صورت گیرد.', 'bakala'),
                    'type' => 'button_set',
                    'options' => array(
                        'popup' => __('نمایش پاپ اپ', 'bakala'),
                        'widget' => __('نمایش ابزارک', 'bakala'),
                        'none' => __('بدون اقدام', 'bakala'),
                    ),
                    'default' => 'popup',
                    'required' => array('floating-cart', '=', 1),
                ),
                
                array(
                    'id' => 'adding_to_cart_type',
                    'type' => 'button_set',
                    'title' => __('استایل پاپ اپ افزودن به سبد خرید', 'bakala'),
                    'subtitle' => __('استایل پاپ اپ اضافه شدن به سبد خرید محصول را انتخاب کنید.', 'bakala'),
                    // 'description' => __('اگر میخواهید هنگام اسکرول به تب بعدی هدایت شوید، حالت اسکرول و در غیراینصورت کلیک را انتخاب کنید!', 'bakala'),
                    'options' => array(
                        'one' => __('استایل اول', 'bakala'),
                        'two' => __('استایل دوم', 'bakala'),
                    ),
                    'default' => 'two',
                    'required' => array('add_to_cart_action', '=', 'popup'),
                ),
                array(
                    'id' => 'save_for_later',
                    'type' => 'switch',
                    'title' => __('لیست خرید بعدی', 'bakala'),
                    'subtitle' => __('به مشتری امکان ذخیره کردن محصول در لیست خرید بعدی را می دهد.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'checkout_header',
                    'type' => 'switch',
                    'title' => __('Enable minimal checkout header', 'bakala'),
                    'subtitle' => __('Enable or disable minimal checkout header in checkout page.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'checkout_footer',
                    'type' => 'switch',
                    'title' => __('فعالسازی فوتر مینیمال در برگه پرداخت ', 'bakala'),
                    'subtitle' => __('فعالسازی یا غیرفعالسازی فوتر مینیمال در برگه پرداخت. ', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'cart_count',
                    'type' => 'button_set',
                    'title' => __('Cart count', 'bakala'),
                    'subtitle' => __('Select cart count method.', 'bakala'),
                    'options' => array(
                        'rows' => __('cart rows', 'bakala'),
                        'items' => __('cart items', 'bakala'),
                    ),
                    'default' => 'items',
                ),
                array(
                    'title' => esc_html(__('show Map', 'bakala')),
                    'id' => 'show_map',
                    'type' => 'switch',
                    'on' => esc_html(__('Enabled', 'bakala')),
                    'off' => esc_html(__('Disabled', 'bakala')),
                    'default' => 0,
                ),
                array(
                    'id' => 'map_type',
                    'type' => 'button_set',
                    'title' => __('Choose your map type', 'bakala'),
                    'options' => array(
                        'google' => __('Google', 'bakala'),
                        'parsimap' => __('Parsimap', 'bakala'),
                    ),
                    'default' => 'google',
                    'required' => array('show_map', '=', true),
                ),
                array(
                    'id' => 'google_map_api',
                    'type' => 'text',
                    'title' => __('Google Map API', 'bakala'),
                    'subtitle' => __('Insert your google map api', 'bakala'),
                    'required' => array('map_type', '=', 'google'),
                ),
                array(
                    'id' => 'shipping-form',
                    'type' => 'switch',
                    'title' => __('Enable chipping other address', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'ed-name',
                    'type' => 'switch',
                    'title' => __('Enable name in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable name field in checkout page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-name',
                    'type' => 'switch',
                    'title' => __('Name required', 'bakala'),
                    'subtitle' => __('If you want required name in checkout, enable this option.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-name', '=', true),
                ),
                array(
                    'id' => 'ed-family',
                    'type' => 'switch',
                    'title' => __('Enable last name in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable last name field in checkout page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-family',
                    'type' => 'switch',
                    'title' => __('Last Name required', 'bakala'),
                    'subtitle' => __('If you want required last name in checkout, enable this option.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-family', '=', true),
                ),
                array(
                    'id' => 'ed-email',
                    'type' => 'switch',
                    'title' => __('Enable email in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable email field in checkout page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-email',
                    'type' => 'switch',
                    'title' => __('Email required', 'bakala'),
                    'subtitle' => __('If you want required email in checkout, enable this option.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-email', '=', true),
                ),
                array(
                    'id' => 'warning_checkout_email',
                    'type' => 'info',
                    'title' => esc_html__('هشدار!', 'bakala'),
                    'style' => 'warning',
                    'desc' => esc_html__('برای حذف یا اختیاری کردن ایمیل در صورتحساب، در تنظیمات پیکربندی ووکامرس/حساب کاربری و حریم خصوصی دقت کنید تا تیک گزینه "اجازه به مشتریان برای ثبت سفارش بدون نیاز به نام نویسی." فعال باشد!', 'bakala'),
                ),
                array(
                    'id' => 'ed-phone',
                    'type' => 'switch',
                    'title' => __('Enable phone in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable phone field in checkout page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-phone',
                    'type' => 'switch',
                    'title' => __('Phone required', 'bakala'),
                    'subtitle' => __('If you want required phone in checkout, enable this option.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-phone', '=', true),
                ),
                array(
                    'id' => 'ch-phone',
                    'type' => 'switch',
                    'title' => __('Enable phone validate in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable phone validate in checkout page. if you use digits in checkout page, disable this option', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'ed-country',
                    'type' => 'switch',
                    'title' => __('Enable country in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable country field in checkout page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-country',
                    'type' => 'switch',
                    'title' => __('Country required', 'bakala'),
                    'subtitle' => __('If you want required country in checkout, enable this option.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-country', '=', true),
                ),
                array(
                    'id' => 'ed-state',
                    'type' => 'switch',
                    'title' => __('Enable state in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable state field in checkout page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-state',
                    'type' => 'switch',
                    'title' => __('State required', 'bakala'),
                    'subtitle' => __('If you want required state in checkout, enable this option.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-state', '=', true),
                ),
                array(
                    'id' => 'ed-city',
                    'type' => 'switch',
                    'title' => __('Enable city in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable city field in checkout page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-city',
                    'type' => 'switch',
                    'title' => __('City required', 'bakala'),
                    'subtitle' => __('If you want required city in checkout, enable this option.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-city', '=', true),
                ),
                array(
                    'id' => 'ed-address',
                    'type' => 'switch',
                    'title' => __('Enable address in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable address field in checkout page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-address',
                    'type' => 'switch',
                    'title' => __('Address required', 'bakala'),
                    'subtitle' => __('If you want required address in checkout, enable this option.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-address', '=', true),
                ),
                array(
                    'id' => 'ed-postcode',
                    'type' => 'switch',
                    'title' => __('Enable post-code in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable post-code field in checkout page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-postcode',
                    'type' => 'switch',
                    'title' => __('Post-code required', 'bakala'),
                    'subtitle' => __('If you want required post-code in checkout, enable this option.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-postcode', '=', true),
                ),
                array(
                    'id' => 'ed-nationalcode',
                    'type' => 'switch',
                    'title' => __('Enable national code in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable national code field in checkout page.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-nationalcode',
                    'type' => 'switch',
                    'title' => __('National code required', 'bakala'),
                    'subtitle' => __('If you want required national code in checkout, enable this option.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-nationalcode', '=', true),
                ),
                array(
                    'id' => 'validate-nationalcode',
                    'type' => 'switch',
                    'title' => __('احراز کد ملی', 'bakala'),
                    'subtitle' => __('اگر این گزینه را فعال کنید، کد ملی احراز خواهد شد.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-nationalcode', '=', true),
                ),
                array(
                    'id' => 'ed-bankcard',
                    'type' => 'switch',
                    'title' => __('Enable bank card in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable bank card field in checkout page.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required-bankcard',
                    'type' => 'switch',
                    'title' => __('Bank card required', 'bakala'),
                    'subtitle' => __('If you want required bank card in checkout, enable this option.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('ed-bankcard', '=', true),
                ),
                array(
                    'id' => 'ed-notes',
                    'type' => 'switch',
                    'title' => __('Enable customer notes in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable customer notes section in checkout page.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'ed-invoice',
                    'type' => 'switch',
                    'title' => __('Enable invoice in checkout', 'bakala'),
                    'subtitle' => __('Enable or disable invoice section in checkout page.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'force_login_in_cart',
                    'type' => 'switch',
                    'title' => __('ورود اجباری در سبد خرید', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، دکمه ادامه جهت تسویه حساب به دکمه ورود و ثبت نام تبدیل می شود. ', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'delivery_time',
                    'type' => 'switch',
                    'title' => __('افزودن فیلد تاریخ ارسال سفارشی', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، فیلد تاریخ ارسال سفارشی به صورتحساب اضافه می شود. ', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'customer_type',
                    'type' => 'switch',
                    'title' => __('افزودن فیلد حقیقی/حقوقی', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، فیلد مشتری حقیقی/حقوقی به صورتحساب اضافه می شود. ', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'customer_type_info',
                    'type' => 'info',
                    'title' => esc_html__('هشدار!', 'bakala'),
                    'style' => 'warning',
                    'desc' => esc_html__('امکان "فیلد حقیقی/حقوقی" با افزونه "مالتی ادرس" سازگاری ندارد و درصورت استفاده از مالتی ادرس این امکان را غیرفعال کنید!', 'bakala'),
                    'required' => array('customer_type', '=', 1),
                ),

                array(
                    'id' => 'billing_company',
                    'type' => 'switch',
                    'title' => __('نام شرکت در برگه پرداخت', 'bakala'),
                    'subtitle' => __('فعالسازی/غیرفعالسازی نام شرکت در برگه پرداخت.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('customer_type', '=', true),
                ),
                array(
                    'id' => 'required_billing_company',
                    'type' => 'switch',
                    'title' => __('اجباری کردن فیلد نام شرکت', 'bakala'),
                    'subtitle' => __('در صورتی که تمایل دارید نام شرکت در برگه پرداخت اجباری باشد، این گزینه را فعال کنید.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('billing_company', '=', true),
                ),
                array(
                    'id' => 'billing_company_id',
                    'type' => 'switch',
                    'title' => __('شناسه ملی شرکت در برگه پرداخت', 'bakala'),
                    'subtitle' => __('فعالسازی/غیرفعالسازی شناسه ملی شرکت در برگه پرداخت.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('customer_type', '=', true),
                ),
                array(
                    'id' => 'required_billing_company_id',
                    'type' => 'switch',
                    'title' => __('اجباری کردن فیلد شناسه ملی شرکت', 'bakala'),
                    'subtitle' => __('در صورتی که تمایل دارید شناسه ملی شرکت در برگه پرداخت اجباری باشد، این گزینه را فعال کنید.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('billing_company_id', '=', true),
                ),
                array(
                    'id' => 'billing_company_economic_code',
                    'type' => 'switch',
                    'title' => __('کد اقتصادی شرکت در برگه پرداخت', 'bakala'),
                    'subtitle' => __('فعالسازی/غیرفعالسازی کد اقتصادی شرکت در برگه پرداخت.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('customer_type', '=', true),
                ),
                array(
                    'id' => 'required_billing_company_economic_code',
                    'type' => 'switch',
                    'title' => __('اجباری کردن فیلد کد اقتصادی شرکت', 'bakala'),
                    'subtitle' => __('در صورتی که تمایل دارید کد اقتصادی شرکت در برگه پرداخت اجباری باشد، این گزینه را فعال کنید.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('billing_company_economic_code', '=', true),
                ),
                array(
                    'id' => 'billing_company_registration_number',
                    'type' => 'switch',
                    'title' => __('شماره ثبت شرکت در برگه پرداخت', 'bakala'),
                    'subtitle' => __('فعالسازی/غیرفعالسازی شماره ثبت شرکت در برگه پرداخت.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('customer_type', '=', true),
                ),
                array(
                    'id' => 'required_billing_company_registration_number',
                    'type' => 'switch',
                    'title' => __('اجباری کردن فیلد شماره ثبت شرکت', 'bakala'),
                    'subtitle' => __('در صورتی که تمایل دارید شماره ثبت شرکت در برگه پرداخت اجباری باشد، این گزینه را فعال کنید.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('billing_company_registration_number', '=', true),
                ),
                array(
                    'id' => 'cart_continue_buy',
                    'type' => 'switch',
                    'title' => __('دکمه ادامه خرید در سبد خرید', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، دکمه ادامه خرید به سبد خرید اضافه می شود. ', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'delivery_time_section',
                    'type' => 'section',
                    'title' => esc_html__('زمان تحویل', 'bakala'),
                    'indent' => true,
                ),

                array(
                    'id' => 'delivery_time_enable',
                    'type' => 'switch',
                    'title' => 'نمایش زمان‌ تحویل سفارش',
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required_delivery_time',
                    'type' => 'switch',
                    'title' => 'ضروری کرن انتخاب تاریخ تحویل',
                    'default' => true,
                    'required' => array(
                        array('delivery_time_enable', '=', '1'),
                    ),
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                /*array(
                    'id'         => 'mobile_popup_delivery_time',
                    'type'       => 'switch',
                    'title'      => 'نمایش پاپ آپ فیلد تحویل سفارش در موبایل',
                    'default'    => true,
                    'required' => array(
                        array('delivery_time_enable', '=', '1'),
                    ),
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),*/


                array(
                    'id' => 'delivery_time_label',
                    'type' => 'text',
                    'title' => 'لیبل فیلد انتخاب تحویل',
                    'default' => 'انتخاب زمان تحویل',
                    'required' => array(
                        array('delivery_time_enable', '=', '1'),
                    ),
                ),
                array(
                    'id' => 'delivery_dates',
                    'type' => 'select',
                    'title' => __('روز های تحویل'),
                    'multi' => true,
                    'placeholder' => __('انتخاب'),
                    'options' => array(
                        'saturday' => __('شنبه'),
                        'sunday' => __('یکشنبه'),
                        'monday' => __('دوشنبه'),
                        'tuesday' => __('سه شنبه'),
                        'wednesday' => __('چهارشنبه'),
                        'thursday' => __('پنجشنبه'),
                        'friday' => __('جمعه'),
                    ),
                    'default' => array('saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday'),
                    'required' => array('delivery_time_enable', '=', '1'),
                ),

                array(
                    'id' => 'delivery_min_time',
                    'type' => 'slider',
                    'title' => __('حداقل زمان تحویل'),
                    'min' => 0,
                    'max' => 60,
                    'step' => 1,
                    'default' => 0,
                    'required' => array('delivery_time_enable', '=', '1'),
                ),
                /*array(
                    'id'         => 'delivery_times_count',
                    'type'       => 'slider',
                    'title'      => __('شمارش پیشنهاد زمان تحویل'),
                    'min'        => 1,
                    'max'        => 8,
                    'step'       => 1,
                    'default'    => 5,
                    'required' => array('delivery_time_enable', '=', '1'),
                ),*/
                // array(
                //     'type'    => 'heading',
                //     'content' => 'ساعت های تحویل سفارش',
                //     'required' => array(
                //         array('delivery_time_enable', '=', '1'),
                //     ),
                // ),
                array(
                    'id' => 'show_timer_send',
                    'type' => 'switch',
                    'title' => 'افزودن ساعت تحویل',
                    'default' => true,
                    'required' => array(
                        array('delivery_time_enable', '=', '1'),
                    ),
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required_timer_send',
                    'type' => 'switch',
                    'title' => 'ضروری کرن انتخاب ساعت تحویل',
                    'default' => true,
                    'required' => array(
                        array('delivery_time_enable', '=', '1'),
                        array('show_timer_send', '=', '1'),
                    ),
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'list_send_time_order',
                    'type' => 'multi_text',
                    'title' => __('ساعت های تحویل', 'bakala'),
                    // 'subtitle' => __('If you enter an invalid color it will be removed. Try using the text "blue" as a color.  ;)', 'bakala'),
                    'desc' => __('ساعت های تحویل را ایجاد کنید', 'bakala'),
                    'add_text' => __('افزودن ساعت', 'bakala'),
                    'required' => array(
                        array('delivery_time_enable', '=', '1'),
                        array('show_timer_send', '=', '1'),
                    ),
                ),
                array(
                    'id' => 'delivery_time_section_end',
                    'type' => 'section',
                    'indent' => false,
                ),
                array(
                    'id' => 'birthday_date',
                    'type' => 'switch',
                    'title' => __('فیلد تاریخ تولد', 'bakala'),
                    'subtitle' => __('فعالسازی/غیرفعالسازی تاریخ تولد در صفحه پرداخت.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'required_birthday_date',
                    'type' => 'switch',
                    'title' => __('اجباری کردن فیلد تاریخ تولد', 'bakala'),
                    'subtitle' => __('در صورتی که تمایل دارید فیلد تاریخ تولد در برگه پرداخت اجباری باشد، این گزینه را فعال کنید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('birthday_date', '=', true),
                ),
                array(
                    'id' => 'free_shipping_proccess',
                    'type' => 'switch',
                    'title' => 'درصد باقی مانده تا ارسال رایگان',
                    'subtitle' => __('نمایش درصد باقی مانده تا ارسال رایگان', 'bakala'),
                    'desc' => __('قبل از فعالسازی این گزینه اطمینان حاصل کنید که روش حمل و نقل رایگان اضافه کرده اید و مبلغ حداقل سفارش را وارد کرده اید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'free_shipping_proccess_price',
                    'type' => 'text',
                    'title' => 'مبلغ حداقل سفارش رایگان',
                    'desc' => __('فقط از عدد استفاده کنید و از گذاشتن واحد پول خودداری کنید', 'bakala'),
                    'placeholder' => '500000',
                    'required' => array(
                        array('free_shipping_proccess', '=', '1'),
                    ),
                ),
                array(
                    'id' => 'free_shipping_proccess_alert',
                    'type' => 'raw',
                    'title' => __('<div class="balala_alert"><div>جهت تنظیم حداقل قیمت ارسال رایگان در قسمت <a href="' . get_site_url() . '/wp-admin/admin.php?page=wc-settings&tab=shipping" style="color:#000;font-weight:600">پیکربندی ووکامرس/حمل و نقل</a> حداقل ارسال رایگان را تعیین کنید.</div>', 'bakala'),
                    'required' => array(
                        array('free_shipping_proccess', '=', 1),
                    )
                ),
                array(
                    'id' => 'gift',
                    'type' => 'switch',
                    'title' => 'هدایا',
                    'subtitle' => __('با این امکان می توانید تعیین کنید که اگر مشتری از مبلغی بیشتر خرید کرد؛ محصولاتی به عنوان هدیه به سبد خریدش اضافه شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'gift_price',
                    'type' => 'text',
                    'title' => 'مبلغ حداقل سفارش برای هدیه',
                    'desc' => __('فقط از عدد استفاده کنید و از گذاشتن واحد پول خودداری کنید', 'bakala'),
                    'placeholder' => '500000',
                    'required' => array(
                        array('gift', '=', '1'),
                    ),
                ),
                array(
                    'id' => 'gift_product',
                    'type' => 'text',
                    'title' => __('ایدی محصول هدیه را وارد کنید', 'bakala'),
                    'desc' => __('ایدی محصولی که می خواهید به عنوان هدیه به سبد خرید مشتری اضافه شود را انتخاب کنید.', 'bakala'),
                    'placeholder' => __('256', 'bakala'),
                    'required' => array('gift', '=', true)
                ),
                array(
                    'id' => 'free_shipping_label',
                    'type' => 'text',
                    'title' => __('برچسب ارسال رایگان', 'bakala'),
                    'desc' => __('می توانید برچسب ارسال رایگان را تغییر دهید.', 'bakala'),
                    'placeholder' => __('ارسال رایگان', 'bakala'),
                    'required' => array('gift', '=', true)
                ),
                array(
                    'id' => 'gift_label',
                    'type' => 'text',
                    'title' => __('برچسب هدیه', 'bakala'),
                    'desc' => __('می توانید برچسب هدیه را تغییر دهید.', 'bakala'),
                    'placeholder' => __('هدیه', 'bakala'),
                    'required' => array('gift', '=', true)
                ),
                array(
                    'id' => 'free_shipping_gift_label',
                    'type' => 'text',
                    'title' => __('برچسب هدیه+ارسال رایگان', 'bakala'),
                    'desc' => __('می توانید برچسب هدیه+ارسال رایگان را تغییر دهید.', 'bakala'),
                    'placeholder' => __('هدیه+ارسال رایگان', 'bakala'),
                    'required' => array('gift', '=', true)
                ),
                array(
                    'id' => 'remove_shipping_cost',
                    'type' => 'switch',
                    'title' => 'حذف هزینه ارسال در صورتحساب',
                    'subtitle' => __('با فعالسازی این گزینه، هزینه ارسال از صورتحساب حذف می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'force_persian_name',
                    'type' => 'switch',
                    'title' => 'اجبار به فارسی نام و نام خانوادگی',
                    'subtitle' => __('با فعالسازی این گزینه، نام و نام خانوادگی در صورتحساب حتما باید فارسی پر شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'empty_cart_icon',
                    'type' => 'media',
                    'title' => __('تصویر آیکن سبد خرید خالی', 'bakala'),
                    'subtitle' => __('می توانید تصویر آیکن سبد خرید در حالیتکه خالی است را تعیین کنید.', 'bakala'),
                ),

            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('صفحه تشکر', 'bakala'),
            'id' => 'thankyou_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-smiley',
            'fields' => array(
                array(
                    'id' => 'extra_thankyou',
                    'type' => 'editor',
                    'title' => __('محتوای اضافی صفحه تشکر', 'bakala'),
                    'subtitle' => __('این محتوا به ابتدای صفحه تشکر اضافه می شود.', 'bakala'),
                    'args' => array(
                        'teeny' => true,
                        'textarea_rows' => 10
                    )
                ),
                array(
                    'id' => 'thankyou_style',
                    'type' => 'button_set',
                    'title' => __('استایل صفحه تشکر', 'bakala'),
                    'options' => array(
                        'one' => __('استایل اول', 'bakala'),
                        'two' => __('استایل دوم', 'bakala'),
                    ),
                    'default' => 'one'
                ),
            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('Product Page', 'bakala'),
            'id' => 'product_page_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-nametag',
            'fields' => array(
                array(
                    'title' => esc_html__('Color Attribute', 'bakala'),
                    'subtitle' => esc_html__('Choose a product attribute that will be used as color', 'bakala'),
                    'id' => 'product_color_taxonomy',
                    'type' => 'select',
                    'options' => bakala_get_product_attr_taxonomies()
                ),
                array(
                    'title' => esc_html__('Warranty Attribute', 'bakala'),
                    'subtitle' => esc_html__('Choose a product attribute that will be used as warranty', 'bakala'),
                    'id' => 'product_warranty_taxonomy',
                    'type' => 'select',
                    'options' => bakala_get_product_attr_taxonomies()
                ),
                array(
                    'id' => 'product_brand_taxonomy_enable',
                    'type' => 'switch',
                    'title' => __('فعالسازی ویژگی برند (سازنده)', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، نمایش برند در محصول فعال می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'woocommerce_brand',
                    'type' => 'switch',
                    'title' => __('استفاده از برند ووکامرس', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، از تکسنومی برند ووکامرس بجای ویژگی استفاده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('product_brand_taxonomy_enable', '=', true)
                ),
                array(
                    'id' => 'show_brand_category',
                    'type' => 'switch',
                    'title' => __('نمایش برند و دسته بندی برند بالای عنوان محصول', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، برند و دسته بندی برند بالای عنوان محصول نمایش می دهد.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('product_brand_taxonomy_enable', '=', true)
                ),
                array(
                    'title' => esc_html__('Brand Attribute', 'bakala'),
                    'subtitle' => esc_html__('Choose a product attribute that will be used as brands', 'bakala'),
                    'desc' => esc_html__('Once you choose a brand attribute, you will be able to add brand images to the attributes', 'bakala'),
                    'id' => 'product_brand_taxonomy',
                    'type' => 'select',
                    'options' => bakala_get_product_attr_taxonomies(),
                    'required' => array(
                        ['product_brand_taxonomy_enable', '=', true],
                        ['woocommerce_brand', '=', false]
                    )
                ),
                array(
                    'id' => 'product_brand_taxonomy_img',
                    'type' => 'switch',
                    'title' => __('نمایش تصویر برند', 'bakala'),
                    'subtitle' => __('نمایش تصویر برند در کنار عنوان، در حالت جعبه ای', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('product_brand_taxonomy_enable', '=', true)
                ),
                array(
                    'id' => 'oos_price',
                    'type' => 'switch',
                    'title' => __('Out of stock price', 'bakala'),
                    'subtitle' => __('Dont show product price if its out of stock', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'stock_qauntity',
                    'type' => 'switch',
                    'title' => __('نمایش تعداد موجودی', 'bakala'),
                    'subtitle' => __('برای عدم نمایش تعداد موجودی غیرفعال کنید.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'low_stock_notice',
                    'type' => 'switch',
                    'title' => __('low stock notice', 'bakala'),
                    'subtitle' => __('Show notice if stock quantity is low', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'popup_desc',
                    'type' => 'switch',
                    'title' => __('Pop-up description', 'bakala'),
                    'subtitle' => __('Show product description as a pop-up in mobile theme', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'zoom_pic',
                    'type' => 'switch',
                    'title' => __('Enable zoom for thumbnails', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'product_response',
                    'type' => 'switch',
                    'title' => __('Enable response for products', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'better_price',
                    'type' => 'switch',
                    'title' => __('Enable price vote for products', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'better_price_notif',
                    'type' => 'switch',
                    'title' => __('Enable Email notification after better price submitted', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('better_price', '=', true)
                ),
                array(
                    'id' => 'single_product_style',
                    'type' => 'button_set',
                    'title' => __('Choose single product style', 'bakala'),
                    'options' => array(
                        'bakala' => __('bakala', 'bakala'),
                        'boxed' => __('Boxed', 'bakala'),
                    ),
                    'default' => 'boxed'
                ),
                array(
                    'id' => 'show_price_change',
                    'type' => 'switch',
                    'title' => __('Dispaly Product Price Changes', 'bakala'),
                    'subtitle' => __('Dispaly product price changes on product page', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'auto_price_change',
                    'type' => 'switch',
                    'title' => __('Enable Auto Product Price Changes', 'bakala'),
                    'subtitle' => __('Enable this option to record product price changes automatically. Disable if you want add price on product page.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'show_sku',
                    'type' => 'switch',
                    'title' => __('Dispaly Product SKU', 'bakala'),
                    'subtitle' => __('Dispaly product SKU in product page', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'show_category',
                    'type' => 'switch',
                    'title' => __('Dispaly Product Category', 'bakala'),
                    'subtitle' => __('Dispaly product category in product page', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'category_style',
                    'type' => 'button_set',
                    'title' => __('نوع دسته بندی ها', 'bakala'),
                    'subtitle' => __('نوع نمایش دسته بندی ها در صفحه محصول را تعیین کنید.', 'bakala'),
                    'options' => array(
                        'all' => __('همه دسته بندی ها', 'bakala'),
                        'main' => __('فقط دسته بندی اصلی', 'bakala'),
                        'deepest' => __('فقط آخرین دسته بندی', 'bakala'),
                    ),
                    'default' => 'all',
                    'required' => array('show_category', '=', true)
                ),
                array(
                    'id' => 'show_tag',
                    'type' => 'switch',
                    'title' => __('Dispaly Product Tag', 'bakala'),
                    'subtitle' => __('Dispaly product tag in product page', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'show_share',
                    'type' => 'switch',
                    'title' => __('Dispaly Product Share Section', 'bakala'),
                    'subtitle' => __('Dispaly product share section in product page', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'sendtofriend_sub',
                    'type' => 'text',
                    'title' => __('Send To Friend Email Subject', 'bakala'),
                    'desc' => __('Insert your email subject sending on send to friend section.', 'bakala'),
                    'required' => array('show_share', '=', true)
                ),
                array(
                    'id' => 'sendtofriend_text',
                    'type' => 'textarea',
                    'title' => __('Send To Friend Email Body', 'bakala'),
                    'desc' => __('Insert your message text for sending on send to friend section. Product link placed at the end of email.', 'bakala'),
                    'required' => array('show_share', '=', true)
                ),
                array(
                    'id' => 'show_related',
                    'type' => 'switch',
                    'title' => __('Dispaly Related Products', 'bakala'),
                    'subtitle' => __('Dispaly related products on product page', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'related_products_position',
                    'type' => 'button_set',
                    'title' => __('جایگاه نمایش محصولات مرتبط در محصول', 'bakala'),
                    'subtitle' => __('تعیین کنید که محصولات مرتبط در صفحه محصول کجا نمایش دهد.', 'bakala'),
                    'options' => array(
                        'before' => __('قبل از تب ها', 'bakala'),
                        'after' => __('بعد از تب ها', 'bakala'),
                    ),
                    'default' => 'before',
                    'required' => array('show_related', '=', '1')
                ),
                array(
                    'id' => 'bakala_related_products',
                    'type' => 'switch',
                    'title' => __('Related products type', 'bakala'),
                    'subtitle' => __('Show related product just from latest category', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'related_posts_per_page',
                    'type' => 'slider',
                    'title' => __('تعداد نمایش محصولات مرتبط', 'bakala'),
                    "default" => 20,
                    "min" => 1,
                    "step" => 1,
                    "max" => 50,
                    'display_value' => 'text',
                    'required' => array('show_related', '=', true)

                ),
                array(
                    'id' => 'custom_related_posts_per_page',
                    'type' => 'slider',
                    'title' => __('تعداد نمایش محصولات مرتبط سفارشی', 'bakala'),
                    'subtitle' => __('تعداد نمایش محصولات مرتبط سفارشی درصورتیکه در ویرایش محصول دسته ای انتخاب شده باشد.', 'bakala'),

                    "default" => 20,
                    "min" => 1,
                    "step" => 1,
                    "max" => 50,
                    'display_value' => 'text'
                ),
                array(
                    'id' => 'show_outofstock_related',
                    'type' => 'switch',
                    'title' => __('نمایش محصولات ناموجود در محصولات مرتبط', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه محصولات ناموجود نیز در محصولات مرتبط نمایش داده می شوند.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('show_related', '=', true)

                ),
                array(
                    'id' => 'orderby_related_products',
                    'type' => 'select',
                    'title' => __('مرتب سازی محصولات مرتبط بر اساس', 'bakala'),
                    'subtitle' => __('نحوه مرتب سازی محصولات مرتبط را انتخاب کنید.', 'bakala'),
                    'options' => array(
                        'date' => esc_html__('date', 'bakala'),
                        'price' => esc_html__('Price', 'bakala'),
                        'id' => esc_html__('id', 'bakala'),
                        'title' => esc_html__('title', 'bakala'),
                        'stock' => esc_html__('موجودی', 'bakala'),
                        'rand' => esc_html__('by accident', 'bakala'),
                    ),
                    'default' => 'rand',
                ),
                array(
                    'id' => 'order_related_products',
                    'type' => 'select',
                    'title' => __('مرتب سازی محصولات مرتبط', 'bakala'),
                    'subtitle' => __('صعودی/نزولی بودن مرتب سازی محصولات مرتبط را انتخاب کنید.', 'bakala'),
                    'options' => array(
                        'ASC' => esc_html__('ASC', 'bakala'),
                        'DESC' => esc_html__('DESC', 'bakala'),
                    ),
                    'default' => 'ASC',
                ),
                array(
                    'id' => 'show_outofstock_custom_related',
                    'type' => 'switch',
                    'title' => __('نمایش محصولات ناموجود در محصولات مرتبط سفارشی', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه محصولات ناموجود نیز در محصولات مرتبط سفارشی نمایش داده می شوند.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'show_shortdesc',
                    'type' => 'switch',
                    'title' => __('Dispaly Product Short Description', 'bakala'),
                    'subtitle' => __('Dispaly product short description on product page', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'empty_price_label',
                    'type' => 'text',
                    'default' => __('Call', 'bakala'),
                    'title' => __('Empty price label', 'bakala'),
                ),
                array(
                    'id' => 'free_product_label',
                    'type' => 'text',
                    'default' => __('Free', 'bakala'),
                    'title' => __('Free products label', 'bakala'),
                ),
                array(
                    'id' => 'alert_box_section',
                    'type' => 'section',
                    'title' => esc_html__('باکس هشدار', 'bakala'),
                    'indent' => true,
                ),
                array(
                    'id' => 'alert_box',
                    'type' => 'switch',
                    'title' => __('باکس هشدار', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه باکس هشدار به برگه محصول اضافه می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'alert_box_content',
                    'type' => 'textarea',
                    'title' => __('محتوای باکس هشدار', 'bakala'),
                    'required' => array('alert_box', '=', '1')
                ),
                array(
                    'id' => 'alert_box_section_end',
                    'type' => 'section',
                    'indent' => false,
                ),
                array(
                    'id' => 'cart_fixed',
                    'type' => 'switch',
                    'title' => __('افزودن به سبد خرید چسبان موبایل', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه در موبایل افزودن به سبد خرید به پایین چسبان می شود.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'price_add_holder',
                    'type' => 'switch',
                    'title' => __(' قیمت در کنار افزودن به سبد خرید', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه در موبایل قیمت در کنار افزودن به سبد خرید قرار می گیرید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('cart_fixed', '=', true)
                ),
                array(
                    'id' => 'add_to_cart_type',
                    'type' => 'switch',
                    'title' => __('نحوه نمایش دکمه افزودن به سبد خرید در موبایل', 'bakala'),
                    'subtitle' => __('نحوه نمایش دکمه افزودن به سبد خرید در صفحه محصول در موبایل را تعیین کنید.', 'bakala'),
                    'default' => 1,
                    'on' => __('آیکون', 'bakala'),
                    'off' => __('متن', 'bakala'),
                    'required' => array('cart_fixed', '=', true)
                ),


                array(
                    'id' => 'product_sizes',
                    'type' => 'switch',
                    'title' => __('راهنمای اندازه', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، جدول راهنمای اندازه به محصول اضافه می شود..', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'feature_icons_pc',
                    'type' => 'switch',
                    'title' => __('آیکن های خدمات فروشگاه دسکتاپ', 'bakala'),
                    'subtitle' => __('نمایش آیکن های خدمات در صفحه محصول دسکتاپ.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'feature_icons_mobile',
                    'type' => 'switch',
                    'title' => __('آیکن های خدمات فروشگاه موبایل', 'bakala'),
                    'subtitle' => __('نمایش آیکن های خدمات در صفحه محصول موبایل.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'feature_icons_position',
                    'type' => 'button_set',
                    'title' => __('جایگاه آیکن های خدمات فروشگاه', 'bakala'),
                    'subtitle' => __('تعیین کنید که آیکن های خدمات در صفحه محصول کجا نمایش دهد.', 'bakala'),
                    'options' => array(
                        'after' => __('بعد از باکس محصول (جایگاه قبلی)', 'bakala'),
                        'before' => __('زیر باکس افزودن به سبد خرید', 'bakala'),
                    ),
                    'default' => 'after',
                    'required' => array('single_product_style', '=', 'boxed')
                ),
                array(
                    'id' => 'feature_icons_position',
                    'type' => 'button_set',
                    'title' => __('جایگاه آیکن های خدمات فروشگاه', 'bakala'),
                    'subtitle' => __('تعیین کنید که آیکن های خدمات در صفحه محصول کجا نمایش دهد.', 'bakala'),
                    'options' => array(
                        'after' => __('بعد از باکس محصول (جایگاه قبلی)', 'bakala'),
                        'before' => __('زیر باکس افزودن به سبد خرید', 'bakala'),
                    ),
                    'default' => 'after',
                    'required' => array('single_product_style', '=', 'boxed')
                ),
                array(
                    'id' => 'price_update_date',
                    'type' => 'switch',
                    'title' => __('بروزرسانی قیمت محصول', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، تاریخ بروزرسانی قیمت محصول نمایش داده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'price_update_color',
                    'type' => 'color',
                    'title' => __('رنگ ایکن چشمک زن', 'bakala'),
                    'default' => '#81d742',
                    'validate' => 'color',
                    'required' => array('price_update_date', '=', '1')
                ),
                array(
                    'id' => 'price_update_date_position_pc',
                    'type' => 'select',
                    'title' => __('جایگاه بروزرسانی قیمت محصول در دسکتاپ', 'bakala'),
                    'subtitle' => __('تعیین کنید که بروزرسانی قیمت در صفحه محصول کجا نمایش دهد.', 'bakala'),
                    'options' => array(
                        'woocommerce_before_add_to_cart_form' => __('قبل از فرم سبد خرید', 'bakala'),
                        'woocommerce_after_add_to_cart_form' => __('بعد از فرم سبد خرید', 'bakala'),
                        'woocommerce_after_add_to_cart_button' => __('بعد از دکمه سبد خرید', 'bakala'),
                        'woocommerce_before_add_to_cart_quantity' => __('قبل از فیلد تعداد', 'bakala'),
                    ),
                    'default' => 'woocommerce_before_add_to_cart_quantity',
                ),
                array(
                    'id' => 'price_update_date_position_mobile',
                    'type' => 'select',
                    'title' => __('جایگاه بروزرسانی قیمت محصول در موبایل', 'bakala'),
                    'subtitle' => __('تعیین کنید که بروزرسانی قیمت در صفحه محصول کجا نمایش دهد.', 'bakala'),
                    'options' => array(
                        'woocommerce_before_add_to_cart_form' => __('قبل از فرم سبد خرید', 'bakala'),
                        'woocommerce_after_add_to_cart_form' => __('بعد از فرم سبد خرید', 'bakala'),
                        'after_brand' => __('بعد از برند', 'bakala'),

                    ),
                    'default' => 'after_brand',
                ),
                array(
                    'id' => 'short_desc_position',
                    'type' => 'button_set',
                    'title' => __('جایگاه توضیح کوتاه محصول', 'bakala'),
                    'subtitle' => __('تعیین کنید که توضیح کوتاه در صفحه محصول کجا نمایش دهد.', 'bakala'),
                    'options' => array(
                        'after_title' => __('بعد از عنوان محصول', 'bakala'),
                        'tab' => __('در تب نقد و بررسی', 'bakala'),
                    ),
                    'default' => 'tab',
                ),
                array(
                    'id' => 'main_features_position',
                    'type' => 'button_set',
                    'title' => __('جایگاه ویژگی های اصلی محصول', 'bakala'),
                    'subtitle' => __('تعیین کنید که ویژگی های اصلی در صفحه محصول کجا نمایش دهد.', 'bakala'),
                    'options' => array(
                        'center' => __('(جایگاه قبلی)ستون وسط محصول', 'bakala'),
                        'left' => __('ستون سمت چپ محصول', 'bakala'),
                    ),
                    'default' => 'center',
                ),
                array(
                    'id' => 'mainfea_auto',
                    'type' => 'switch',
                    'title' => __('نمایش ویژگی های محصول بجای ویژگی های اصلی', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، درصورتیکه ویژگی های اصلی را پر نکنید، از ویژگی های محصول استفاده می شود.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'main_features_style_pc',
                    'type' => 'button_set',
                    'title' => __('استایل ویژگی های اصلی محصول در دسکتاپ', 'bakala'),
                    'subtitle' => __('تعیین کنید که ویژگی های اصلی در صفحه محصول چطور نمایش دهد.', 'bakala'),
                    'options' => array(
                        'list' => __('لیستی(قدیمی)', 'bakala'),
                        'table' => __('جدولی', 'bakala'),
                        'box' => __('باکسی', 'bakala'),
                    ),
                    'default' => 'list',
                ),
                array(
                    'id' => 'main_features_style_mobile',
                    'type' => 'button_set',
                    'title' => __('استایل ویژگی های اصلی محصول در موبایل', 'bakala'),
                    'subtitle' => __('تعیین کنید که ویژگی های اصلی در صفحه محصول چطور نمایش دهد.', 'bakala'),
                    'options' => array(
                        'list' => __('لیستی(قدیمی)', 'bakala'),
                        'table' => __('جدولی', 'bakala'),
                        'box' => __('اسکرولی', 'bakala'),
                    ),
                    'default' => 'list',
                ),

                array(
                    'id' => 'specifications_style_pc',
                    'type' => 'button_set',
                    'title' => __('استایل مشخصات محصول در دسکتاپ', 'bakala'),
                    'subtitle' => __('تعیین کنید که مشخصات در صفحه محصول چطور نمایش دهد.', 'bakala'),
                    'options' => array(
                        'list' => __('لیستی(قدیمی)', 'bakala'),
                        'table' => __('جدولی', 'bakala'),
                    ),
                    'default' => 'list',
                ),
                array(
                    'id' => 'specifications_style_mobile',
                    'type' => 'button_set',
                    'title' => __('استایل مشخصات محصول در موبایل', 'bakala'),
                    'subtitle' => __('تعیین کنید که مشخصات در صفحه محصول چطور نمایش دهد.', 'bakala'),
                    'options' => array(
                        'list' => __('لیستی(قدیمی)', 'bakala'),
                        'table' => __('جدولی', 'bakala'),
                    ),
                    'default' => 'list',
                ),
                array(
                    'id' => 'special_box_section',
                    'type' => 'section',
                    'title' => esc_html__('باکس ویژه', 'bakala'),
                    'indent' => true,
                ),
                array(
                    'id' => 'special_box',
                    'type' => 'switch',
                    'title' => __('باکس ویژه', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه باکس ویژه به برگه محصول اضافه می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'special_box_fields',
                    'type' => 'switch',
                    'title' => __('تغییر فیلدهای باکس ویژه با موارد زیر', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، فیلدهای باکس ویژه با فیلدهای زیر جایگزین می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('special_box', '=', '1')
                ),
                array(
                    'id' => 'special_box_title',
                    'type' => 'text',
                    'title' => __('عنوان باکس ویژه', 'bakala'),
                    'required' => array('special_box_fields', '=', '1')
                ),
                array(
                    'id' => 'special_box_list',
                    'type' => 'textarea',
                    'title' => __('لیست باکس ویژه', 'bakala'),
                    'required' => array('special_box_fields', '=', '1')
                ),
                array(
                    'id' => 'special_box_link',
                    'type' => 'text',
                    'title' => __('لینک باکس ویژه', 'bakala'),
                    'required' => array('special_box_fields', '=', '1')
                ),
                array(
                    'id' => 'special_box_icon',
                    'type' => 'text',
                    'title' => __('تصویر آیکون باکس ویژه', 'bakala'),
                    'required' => array('special_box_fields', '=', '1')
                ),
                array(
                    'id' => 'special_box_category',
                    'type' => 'select',
                    'multi' => true,
                    'data' => 'terms',
                    'args' => array('taxonomies' => 'product_cat'),
                    'title' => __('نمایش باکس ویژه فقط در دسته بندی های', 'bakala'),
                    'subtitle' => __('دسته بندی هایی که میخواهید باکس ویژه در محصولات آن ها نمایش داده شود را انتخاب کنید.', 'bakala'),
                    'required' => array('special_box', '=', true),
                ),
                array(
                    'id' => 'special_box_category_exclude',
                    'type' => 'select',
                    'multi' => true,
                    'data' => 'terms',
                    'args' => array('taxonomies' => 'product_cat'),
                    'title' => __('عدم نمایش باکس ویژه فقط در دسته بندی های', 'bakala'),
                    'subtitle' => __('دسته بندی هایی که میخواهید باکس ویژه در محصولات آن ها نمایش داده نشود را انتخاب کنید.', 'bakala'),
                    'required' => array('special_box', '=', true),
                ),
                array(
                    'id' => 'special_box_section_end',
                    'type' => 'section',
                    'indent' => false,
                ),
                array(
                    'id' => 'free_shipping_section',
                    'type' => 'section',
                    'title' => esc_html__('باکس ارسال رایگان', 'bakala'),
                    'indent' => true,
                ),
                array(
                    'id' => 'free_shipping_alert',
                    'type' => 'switch',
                    'title' => __('باکس ارسال رایگان', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه باکس ارسال رایگان به برگه محصول اضافه می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'free_shipping_title',
                    'type' => 'text',
                    'title' => __('عنوان باکس ارسال رایگان', 'bakala'),
                    'required' => array('free_shipping_alert', '=', '1')
                ),
                array(
                    'id' => 'free_shipping_text',
                    'type' => 'textarea',
                    'title' => __('متن باکس ارسال رایگان', 'bakala'),
                    'required' => array('free_shipping_alert', '=', '1')
                ),
                array(
                    'id' => 'free_shipping_link',
                    'type' => 'text',
                    'title' => __('لینک باکس ارسال رایگان', 'bakala'),
                    'required' => array('free_shipping_alert', '=', '1')
                ),
                array(
                    'id' => 'free_shipping_icon',
                    'type' => 'text',
                    'title' => __('تصویر آیکون باکس ارسال رایگان', 'bakala'),
                    'required' => array('free_shipping_alert', '=', '1')
                ),
                array(
                    'id' => 'free_shipping_category',
                    'type' => 'select',
                    'multi' => true,
                    'data' => 'terms',
                    'args' => array('taxonomies' => 'product_cat'),
                    'title' => __('نمایش باکس رایگان فقط در دسته بندی های', 'bakala'),
                    'subtitle' => __('دسته بندی هایی که میخواهید باکس رایگان در محصولات آن ها نمایش داده شود را انتخاب کنید.', 'bakala'),
                    'required' => array('free_shipping_alert', '=', true),
                ),
                array(
                    'id' => 'free_shipping_category_exclude',
                    'type' => 'select',
                    'multi' => true,
                    'data' => 'terms',
                    'args' => array('taxonomies' => 'product_cat'),
                    'title' => __('عدم نمایش باکس رایگان در دسته بندی های', 'bakala'),
                    'subtitle' => __('دسته بندی هایی که میخواهید باکس رایگان در محصولات آن ها نمایش داده نشود را انتخاب کنید.', 'bakala'),
                    'required' => array('free_shipping_alert', '=', true),
                ),
                array(
                    'id' => 'free_shipping_section_end',
                    'type' => 'section',
                    'indent' => false,
                ),
                array(
                    'id' => 'show_price_out_of_stock',
                    'type' => 'switch',
                    'title' => __('نمایش قیمت محصولات ناموجود', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، قیمت محصولات ناموجود نمایش داده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'show_loadtime',
                    'type' => 'switch',
                    'title' => __('نمایش زمان ارسال محصول', 'bakala'),
                    'subtitle' => __('اگر میخواهید زمان ارسال در محصول نمایش داده نشود این گزینه را غیرفعال کنید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'pretext_loadtime',
                    'type' => 'text',
                    'title' => __('پیش متن زمان ارسال محصول', 'bakala'),
                    'default' => __('ارسال کالا از', 'bakala'),
                    'required' => array('show_loadtime', '=', '1')
                ),
                array(
                    'id' => 'alert_stock',
                    'type' => 'switch',
                    'title' => __('نمایش اعلان تعداد موجودی', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، درصورتیکه تعداد موجودی محصول کمتر از 5 باشد به مشتری تعداد موجودی را نمایش می دهد.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'schema_product',
                    'type' => 'switch',
                    'title' => __('اسکیما خودکار محصول', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، بصورت خودکار اسکیما محصول اضافه می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'product_excerpt_limit',
                    'type' => 'slider',
                    'title' => __('تعداد کاراکتر خلاصه نقد و بررسی', 'bakala'),
                    'subtitle' => __('تعداد کاراکتر خلاصه نقد و بررسی محصول در موبایل را تعیین کنید.', 'bakala'),
                    "default" => 500,
                    "min" => 200,
                    "step" => 100,
                    "max" => 10000,
                    'display_value' => 'text',

                ),
                array(
                    'id' => 'recomendation_product',
                    'type' => 'switch',
                    'title' => __('پیشنهاد محصول', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، کاربران محصول را پیشنهاد کرده اند به محصول اضافه می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'gallery_style',
                    'type' => 'button_set',
                    'title' => __('استایل گالری محصول دسکتاپ', 'bakala'),
                    'subtitle' => __('تعیین کنید که گالری در صفحه محصول چطور نمایش دهد.', 'bakala'),
                    'options' => array(
                        'one' => __('استایل اول', 'bakala'),
                        'two' => __('استایل دوم', 'bakala'),
                    ),
                    'default' => 'one',
                ),
                array(
                    'id' => 'gallery_style_mobile',
                    'type' => 'button_set',
                    'title' => __('استایل گالری محصول موبایل', 'bakala'),
                    'subtitle' => __('تعیین کنید که گالری در صفحه محصول چطور نمایش دهد.', 'bakala'),
                    'options' => array(
                        'one' => __('استایل اول', 'bakala'),
                        'two' => __('استایل دوم', 'bakala'),
                    ),
                    'default' => 'one',
                ),
                array(
                    'id' => 'product_description_image',
                    'type' => 'media',
                    'title' => __('تصویر نقد و بررسی', 'bakala'),
                    'default' => array('url' => get_template_directory_uri() . '/vendor/files/pen-paper.png'),
                    'desc' => __('تصویر نقد و بررسی را انتخاب کنید', 'bakala'),
                ),
                array(
                    'id' => 'product_tabs_type',
                    'type' => 'button_set',
                    'title' => __('حالت نمایش تب های محصول', 'bakala'),
                    'subtitle' => __('تعیین کنید که تب ها در صفحه محصول چطور نمایش دهد.', 'bakala'),
                    'description' => __('اگر میخواهید هنگام اسکرول به تب بعدی هدایت شوید، حالت اسکرول و در غیراینصورت کلیک را انتخاب کنید!', 'bakala'),
                    'options' => array(
                        'click' => __('کلیک', 'bakala'),
                        'scroll' => __('اسکرول', 'bakala'),
                    ),
                    'default' => 'click',
                ),
                array(
                    'id' => 'hide_dimensions',
                    'type' => 'switch',
                    'title' => __('پنهان سازی وزن و ابعاد', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، وزن و ابعاد در مشخصات محصول نمایش داده نمی شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('پنهان', 'bakala'),
                    'off' => __('نمایش', 'bakala'),
                ),

                array(
                    'id' => 'extra_btn_product_section',
                    'type' => 'section',
                    'title' => esc_html__('دکمه اضافی محصول', 'bakala'),
                    'indent' => true,
                ),
                array(
                    'id' => 'extra_btn_product',
                    'type' => 'switch',
                    'title' => __('دکمه اضافی محصول', 'bakala'),
                    'subtitle' => __('این دکمه زیر دکمه افزودن به سبد خرید در صفحه محصول نمایش داده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'extra_btn_product_snapppay',
                    'type' => 'switch',
                    'title' => __('استایل و متن خودکار اسنپ پی', 'bakala'),
                    'subtitle' => __('اگر این گزینه را فعال کنید؛ استایل و متن خودکار اسنپ پی قرار داده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('extra_btn_product', '=', '1')
                ),
                array(
                    'id' => 'extra_btn_product_text',
                    'type' => 'text',
                    'title' => __('متن دکمه', 'bakala'),
                    'placeholder' => __('ارتباط با فروش', 'bakala'),
                    'required' => array('extra_btn_product', '=', '1')
                ),
                array(
                    'id' => 'extra_btn_product_text2',
                    'type' => 'text',
                    'title' => __('متن دوم دکمه', 'bakala'),
                    'subtitle' => __('می توانید متن دومی به عنوان زیرعنوان به دکمه اضافه کنید', 'bakala'),
                    'placeholder' => __('تماس با کارشناسان', 'bakala'),
                    'required' => array('extra_btn_product', '=', '1')
                ),
                array(
                    'id' => 'extra_btn_product_icon',
                    'type' => 'media',
                    'title' => __('آیکن دکمه', 'bakala'),
                    'subtitle' => __('می توانید آیکن به دکمه اضافه کنید.', 'bakala'),
                    'required' => array('extra_btn_product', '=', 1),
                ),
                array(
                    'id' => 'extra_btn_product_link',
                    'type' => 'text',
                    'title' => __('لینک دکمه', 'bakala'),
                    'required' => array('extra_btn_product', '=', '1')
                ),
                array(
                    'id' => 'extra_btn_product_bg',
                    'type' => 'color_gradient',
                    'title' => __('پس زمینه دکمه', 'bakala'),
                    'subtitle' => __('The Gradient Colors Can Change from here', 'bakala'),
                    'desc' => __('Gradient Colors must Set Here', 'bakala'),
                    'validate' => 'color',
                    'required' => array('extra_btn_product', '=', '1')

                ),
                array(
                    'id' => 'extra_btn_product_color',
                    'type' => 'color',
                    'title' => __('رنگ متن دکمه', 'bakala'),
                    // 'default' => '#FFFFFF',
                    'validate' => 'color',
                    'required' => array('extra_btn_product', '=', '1')
                ),


                array(
                    'id' => 'extra_btn_product_section_end',
                    'type' => 'section',
                    'indent' => false,
                ),

                array(
                    'id' => 'extra_product_section',
                    'type' => 'section',
                    'title' => esc_html__('محصول اضافی', 'bakala'),
                    'indent' => true,
                ),
                array(
                    'id' => 'extra_product',
                    'type' => 'switch',
                    'title' => __('محصول اضافی', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، امکان اضافه کردن محصول اضافی در صفحه محصول وجود دارد.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'extra_product_details',
                    'type' => 'switch',
                    'title' => __('دکمه جزئیات محصول اضافی', 'bakala'),
                    'subtitle' => __('می توانید دکمه جزئیات محصول اضافی را نمایش ندهید.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('extra_product', '=', 1),
                ),
                array(
                    'id' => 'extra_product_details_bg',
                    'type' => 'color',
                    'title' => __('رنگ پس زمینه دکمه', 'bakala'),
                    'validate' => 'color',
                    'required' => array(
                        array('extra_product', '=', 1),
                        array('extra_product_details', '=', '1')
                    )

                ),
                array(
                    'id' => 'extra_product_details_color',
                    'type' => 'color',
                    'title' => __('رنگ متن دکمه', 'bakala'),
                    'validate' => 'color',
                    'required' => array(
                        array('extra_product', '=', 1),
                        array('extra_product_details', '=', '1')
                    )
                ),
                array(
                    'id' => 'extra_product_section_end',
                    'type' => 'section',
                    'indent' => false,
                ),


            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('Comment template', 'bakala'),
            'id' => 'comment_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-format-chat',
            'fields' => array(
                array(
                    'id' => 'new_comment_template',
                    'type' => 'switch',
                    'title' => __('Enable new comment template', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'commente_note',
                    'type' => 'text',
                    'title' => __('Comment note', 'bakala'),
                    'desc' => __('This text will show in comment tab content.', 'bakala'),
                    'required' => array('new_comment_template', '=', true)
                ),
                array(
                    'id' => 'comment_desc_title',
                    'type' => 'text',
                    'title' => __('Comment page title ', 'bakala'),
                    'desc' => __('This text will show in add new comment page as title.', 'bakala'),
                    'required' => array('new_comment_template', '=', true)
                ),
                array(
                    'id' => 'comment_desc',
                    'type' => 'editor',
                    'title' => __('Comment description', 'bakala'),
                    'subtitle' => __('This text will show in add new comment page.', 'bakala'),
                    'args' => array(
                        'wpautop' => false,
                        'teeny' => true
                    ),
                    'required' => array('new_comment_template', '=', true)
                ),
                array(
                    'id' => 'comment_rules_page',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => __('Select comment rules Page', 'bakala'),
                    'desc' => __('Select page that has comment rules.', 'bakala'),
                    'required' => array('new_comment_template', '=', true)
                ),
                array(
                    'id' => 'dcomment_rate_titles',
                    'type' => 'multi_text',
                    'title' => __('Default Comment rate titles', 'bakala'),
                    'show_empty' => false,
                    'required' => array('new_comment_template', '=', true)
                ),
                array(
                    'id' => 'adv_disadv_admin',
                    'type' => 'switch',
                    'title' => __('Enable advantages & disadvantages for admin', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'comment_recaptcha',
                    'type' => 'switch',
                    'title' => __('فعالسازی ریکپچا در فرم دیدگاه', 'bakala'),
                    'subtitle' => __('از ریکپچا نسخه v2 Checkbox استفاده کنید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('new_comment_template', '=', true)
                ),
                array(
                    'id' => 'recaptcha_site_key',
                    'type' => 'text',
                    'title' => __('SITE KEY', 'bakala'),
                    'subtitle' => __('SITE KEY دریافت شده از گوگل را وارد کنید.', 'bakala'),
                    'required' => array('comment_recaptcha', '=', true)
                ),
                array(
                    'id' => 'recaptcha_secret_key',
                    'type' => 'text',
                    'title' => __('SECRET KEY', 'bakala'),
                    'subtitle' => __('SECRET KEY دریافت شده از گوگل را وارد کنید.', 'bakala'),
                    'required' => array('comment_recaptcha', '=', true)
                ),
                array(
                    'title' => esc_html__('صفحه بندی', 'bakala'),
                    'subtitle' => esc_html__('دیدگاه ها را بصورت صفحه بندی شده نمایش بدهید.', 'bakala'),
                    'id' => 'pagination_comment',
                    'type' => 'switch',
                    'on' => esc_html__('Enabled', 'bakala'),
                    'off' => esc_html__('Disabled', 'bakala'),
                    'default' => 0,
                ),
            )
        ));
        Redux::set_section($opt_name, array(
            'title' => __('پرسش و پاسخ', 'bakala'),
            'id' => 'qa_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-editor-help',
            'fields' => array(
                array(
                    'id' => 'product_qa',
                    'type' => 'switch',
                    'title' => __('پرسش پاسخ محصول', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، پرسش و پاسخ به محصول اضافه می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'product_qa_email_admin',
                    'type' => 'switch',
                    'title' => __('اعلان ایمیلی مدیر', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه پس از ثبت پرسش به مدیر سایت ایمیل ارسال می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('product_qa', '=', true)
                ),
                array(
                    'id' => 'product_qa_email_admin_email',
                    'type' => 'text',
                    'title' => __('ایمیل مدیر', 'bakala'),
                    'subtitle' => __('درصورت خالی بودن به ایمیل مدیریت در وردپرس ارسال می شود.', 'bakala'),
                    'required' => array('product_qa_email_admin', '=', true)
                ),
                array(
                    'id' => 'product_qa_email_user',
                    'type' => 'switch',
                    'title' => __('اعلان ایمیلی کاربر', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه پس از ثبت پرسش به کاربر (درصورتیکه ایمیل کاربر وارد شده باشد) ایمیل ارسال می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('product_qa', '=', true)
                ),
                array(
                    'id' => 'product_qa_sms_admin',
                    'type' => 'switch',
                    'title' => __('اعلان پیامک مدیر', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه پس از ثبت پرسش به مدیر سایت پیامک ارسال می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('product_qa', '=', true)
                ),
                array(
                    'id' => 'product_qa_sms_admin_phone',
                    'type' => 'text',
                    'title' => __('شماره تماس مدیر', 'bakala'),
                    'required' => array('product_qa_sms_admin', '=', true)
                ),
                array(
                    'title' => esc_html(__('متن پیامک مدیر', 'bakala')),
                    'id' => 'product_qa_sms_admin_text',
                    'type' => 'text',
                    'description' => 'متن پیشنهادی: پرسش جدیدی در محصول %product-name% ثبت شده',
                    'placeholder' => 'متن پیشنهادی: پرسش جدیدی در محصول %product-name% ثبت شده',
                    'required' => array(
                        array('product_qa_sms_admin_question', '=', 1),
                        array('sp_sms', '=', array('parsgreen', 'segalnet'))
                    )
                ),

                array(
                    'title' => esc_html(__('کد پترن مدیر', 'bakala')),
                    'id' => 'product_qa_sms_admin_pattern',
                    'type' => 'text',
                    'desc' => __('کد پترن را وارد کنید.', 'bakala'),
                    'required' => array(
                        array('product_qa_sms_admin', '=', 1),
                        array('sp_sms', '=', array('meli', 'ippanel'))
                    )
                ),
                array(
                    'id' => 'product_qa_sms_admin_meli',
                    'type' => 'raw',
                    'title' => __('<div class="balala_alert"><div>متن پترن خود را طوری تنظیم کنید که ترتیب متغیرها به صورت زیر باشد:</div><div style="font-weight:bold;margin-top:10px !important;color: #FDB910;">نام محصول</div><hr><p><strong>متن پیشنهادی:</strong> پرسش جدیدی در محصول {1} ثبت شد.</p> </div>', 'bakala'),
                    'required' => array(
                        array('product_qa_sms_admin_question', '=', 1),
                        array('sp_sms', '=', 'meli')
                    )
                ),

                array(
                    'id' => 'product_qa_sms_user_question',
                    'type' => 'switch',
                    'title' => __('اعلان پیامکی کاربر پس از ثبت پرسش', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه پس از ثبت پرسش به کاربر (درصورتیکه شماره موبایل کاربر وارد شده باشد) پیامک ارسال می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('product_qa', '=', true)
                ),
                array(
                    'title' => esc_html(__('متن پیامک مشتری', 'bakala')),
                    'id' => 'product_qa_sms_user_text',
                    'type' => 'text',
                    'description' => 'متن پیشنهادی: %name% عزیز به پرسش شما در محصول %product-name% ثبت شد. لینک محصول: %product-link%',
                    'placeholder' => 'متن پیشنهادی: %name% عزیز به پرسش شما در محصول %product-name% ثبت شد. لینک محصول: %product-link%',
                    'required' => array(
                        array('product_qa_sms_admin', '=', 1),
                        array('sp_sms', '=', array('parsgreen', 'segalnet'))
                    )
                ),

                array(
                    'title' => esc_html(__('کد پترن مشتری', 'bakala')),
                    'id' => 'product_qa_sms_user_pattern',
                    'type' => 'text',
                    'desc' => __('کد پترن را وارد کنید.', 'bakala'),
                    'required' => array(
                        array('product_qa_sms_user_question', '=', 1),
                        array('sp_sms', '=', array('meli', 'ippanel'))
                    )
                ),

                array(
                    'id' => 'product_qa_sms_user_ippanel',
                    'type' => 'raw',
                    'title' => __('<div class="balala_alert"><p><strong>متن پیشنهادی:</strong> %name% عزیز پرسش شما در محصول %product-name% ثبت شد. لینک محصول: %product-link%</p> </div>', 'bakala'),
                    'required' => array(
                        array('product_qa_sms_user_question', '=', 1),
                        array('sp_sms', '=', 'ippanel')
                    )
                ),
                array(
                    'id' => 'product_qa_sms_user_meli',
                    'type' => 'raw',
                    'title' => __('<div class="balala_alert"><div>متن پترن خود را طوری تنظیم کنید که ترتیب متغیرها به صورت زیر باشد:</div><div style="font-weight:bold;margin-top:10px !important;color: #FDB910;">نام کاربر-نام محصول-لینک محصول</div><hr><p><strong>متن پیشنهادی:</strong> {0} عزیز پرسش شما در محصول {1} ثبت شد. لینک محصول: {2}</p> </div>', 'bakala'),
                    'required' => array(
                        array('product_qa_sms_user_question', '=', 1),
                        array('sp_sms', '=', 'meli')
                    )
                ),
                array(
                    'title' => esc_html(__('متغیر ورودی نام کاربر', 'bakala')),
                    'id' => 'product_qa_sms_pattern_var_name',
                    'type' => 'text',
                    'default' => 'name',
                    'desc' => __('متغیر ورودی نام کاربر در پترن را وارد کنید. بهتر است مقدار پیشفرض را قرار دهید.', 'bakala'),
                    'required' => array(
                        array('product_qa_sms_admin', '=', 1),
                        array('sp_sms', '=', 'ippanel')
                    )
                ),
                array(
                    'title' => esc_html(__('متغیر ورودی نام محصول', 'bakala')),
                    'id' => 'product_qa_sms_pattern_var_product_name',
                    'type' => 'text',
                    'default' => 'product-name',
                    'desc' => __('متغیر ورودی نام محصول در پترن را وارد کنید. بهتر است مقدار پیشفرض را قرار دهید.', 'bakala'),
                    'required' => array(
                        array('product_qa_sms_admin', '=', 1),
                        array('sp_sms', '=', 'ippanel')
                    )
                ),
                array(
                    'title' => esc_html(__('متغیر ورودی لینک محصول', 'bakala')),
                    'id' => 'product_qa_sms_pattern_var_product_link',
                    'type' => 'text',
                    'default' => 'product-link',
                    'desc' => __('متغیر ورودی لینک محصول در پترن را وارد کنید. بهتر است مقدار پیشفرض را قرار دهید.', 'bakala'),
                    'required' => array(
                        array('product_qa_sms_admin', '=', 1),
                        array('sp_sms', '=', 'ippanel')
                    )
                ),
                array(
                    'id' => 'qa_migrate',
                    'type' => 'raw',
                    'content' => '<div class="balala_alert" style="background:#000;"><h3 style="color:#FDB910">انتقال پرسش و پاسخ های قدیمی</h3><div class="lr_testing"><button id="migration_qa" type="button">به‌روزرسانی</button></div></div>',
                ),
                // array(
                //     'id' => 'product_qa_sms_user_answer',
                //     'type' => 'switch',
                //     'title' => __('اعلان پیامکی کاربر پس از پاسخ', 'bakala'),
                //     'subtitle' => __('با فعالسازی این گزینه پس از ثبت پاسخ به پرسش به کاربر (درصورتیکه شماره موبایل کاربر وارد شده باشد) پیامک ارسال می شود.', 'bakala'),
                //     'default' => 0,
                //     'on' => __('Enable', 'bakala'),
                //     'off' => __('Disable', 'bakala'),
                //     'required' => array('product_qa', '=', true)
                // ),

            )
        ));
        Redux::set_section($opt_name, array(
            'title' => __('Notify', 'bakala'),
            'id' => 'notify_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-megaphone',
            'fields' => array(
                array(
                    'id' => 'show_white_catnotify',
                    'type' => 'switch',
                    'title' => __('Enable Notify Function', 'bakala'),
                    'subtitle' => __('Enable notify function on product page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'notify_offer',
                    'type' => 'switch',
                    'title' => __('Enable Notify For Special Offer', 'bakala'),
                    'subtitle' => __('Enable notify for offers on product page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('show_white_catnotify', '=', true)
                ),
                array(
                    'id' => 'notify_stock',
                    'type' => 'switch',
                    'title' => __('Enable Notify For Stock', 'bakala'),
                    'subtitle' => __('Enable notify for stock on product page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('show_white_catnotify', '=', true)
                ),
                array(
                    'id' => 'notify_with_email',
                    'type' => 'switch',
                    'title' => __('Enable Notify With Email', 'bakala'),
                    'subtitle' => __('Enable notify with email on product page.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('show_white_catnotify', '=', true)
                ),
                array(
                    'id' => 'notify_with_bakala',
                    'type' => 'button_set',
                    'title' => __('Choose how will sms send', 'bakala'),
                    'subtitle' => __('You should set plugin settings (Products Newsletter).', 'bakala'),
                    'options' => array(
                        'bakala' => __('bakala', 'bakala'),
                        'woosms' => __('Woo sms plugin', 'bakala'),
                    ),
                    'default' => 'bakala'
                ),
                array(
                    'id' => 'notify_email_sub_stock',
                    'type' => 'text',
                    'title' => __('Notify Email Subject For Stock', 'bakala'),
                    'subtitle' => __('Insert subject of notify email for stock.', 'bakala'),
                ),
                array(
                    'id' => 'notify_email_text_stock',
                    'type' => 'editor',
                    'title' => __('Notify Email Text For Stock', 'bakala'),
                    'subtitle' => __('Insert text of notify email for stock. You can use #product# for render product link in text.', 'bakala'),
                    'args' => array(
                        'wpautop' => false,
                        'teeny' => true
                    ),
                ),
                array(
                    'id' => 'notify_email_sub_offer',
                    'type' => 'text',
                    'title' => __('Notify Email Subject For Special Offer', 'bakala'),
                    'subtitle' => __('Insert subject of notify email for special offer.', 'bakala'),
                ),
                array(
                    'id' => 'notify_email_text_offer',
                    'type' => 'editor',
                    'title' => __('Notify Email Text For Special Offer', 'bakala'),
                    'subtitle' => __('Insert text of notify email for special offer. You can use #product# for render product link in text.', 'bakala'),
                    'args' => array(
                        'wpautop' => false,
                        'teeny' => true
                    ),
                ),
                array(
                    'id' => 'notify_with_sms',
                    'type' => 'switch',
                    'title' => __('Enable Notify With SMS', 'bakala'),
                    'subtitle' => __('Enable notify with SMS on product page. Woocommerce SMS plugin should be activate.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('show_white_catnotify', '=', true)
                ),
                array(
                    'id' => 'notify_sms_text_stock',
                    'type' => 'textarea',
                    'title' => __('Notify SMS Text For Stock', 'bakala'),
                    'desc' => __('Insert text of notify sms for stock. You can use #product# for render product link in text.', 'bakala'),
                ),
                array(
                    'id' => 'notify_sms_text_offer',
                    'type' => 'textarea',
                    'title' => __('Notify SMS Text For Special Offer', 'bakala'),
                    'desc' => __('Insert text of notify sms for special offer. You can use #product# for render product link in text.', 'bakala'),
                ),
            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('Compare', 'bakala'),
            'id' => 'compare_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-clipboard',
            'fields' => array(
                array(
                    'id' => 'compare_page',
                    'type' => 'select',
                    'data' => 'pages',
                    'title' => __('Select Compare Page', 'bakala'),
                    'desc' => __('Select page that has [popup-compare] shortcode.', 'bakala'),
                    'required' => array('white_catcompare', '=', true)
                ),
                array(
                    'id' => 'white_catcompare',
                    'type' => 'switch',
                    'title' => __('Enable bakala Compare System', 'bakala'),
                    'subtitle' => __('Enable to use special compare system on bakala theme.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'compare_main_features',
                    'type' => 'switch',
                    'title' => __('مقایسه با ویژگی های اصلی', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، مقایسه با ویژگی های اصلی نیز به مقایسه افزوده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('white_catcompare', '=', true)
                ),
                array(
                    'id' => 'compare_cat_type',
                    'type' => 'button_set',
                    'title' => __('نوع مقایسه', 'bakala'),
                    'subtitle' => __('انتخاب کنید که از بین چه دسته بندی هایی میخواهید مقایسه انجام شود.', 'bakala'),
                    'options' => array(
                        'all' => __('همه دسته بندی ها', 'bakala'),
                        'last' => __('فقط دسته بندی آخر', 'bakala'),
                    ),
                    'default' => 'last'
                ),
            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('حساب کاربری', 'bakala'),
            'id' => 'account_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-admin-users',
            'fields' => array(
                array(
                    'id' => 'account_notification',
                    'type' => 'switch',
                    'title' => __('فعالسازی تب اعلانات در حساب کاربری ووکامرس', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، در منوی وردپرس گزینه ای تحت عنوان اعلان ها اضافه می شود و می توانید در حساب کاربری مشتریان خود اعلان ارسال کنید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'myaccount_wishlist',
                    'type' => 'switch',
                    'title' => __('فعالسازی تب لیست علاقه مندی ها در حساب کاربری ووکامرس', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، لیست علاقه مندی هایی کاربر در حساب کاربری نمایش داده می شود.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'myaccount_tracking_order',
                    'type' => 'switch',
                    'title' => __('فعالسازی تب پیگیری سفارش در حساب کاربری ووکامرس', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، پیگیری سفارش در حساب کاربری نمایش داده می شود.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'myaccount_dashboard_type',
                    'type' => 'button_set',
                    'title' => __('حالت نمایش داشبورد', 'bakala'),
                    'subtitle' => __('حالت نمایش صفحه حساب کاربری ووکامرس', 'bakala'),
                    'options' => array(
                        'new' => __('نوین', 'bakala'),
                        'old' => __('نسخه قبلی', 'bakala'),
                    ),
                    'default' => 'new',
                ),
                array(
                    'id' => 'myaccount_orders_type',
                    'type' => 'button_set',
                    'title' => __('حالت نمایش سفارشات', 'bakala'),
                    'subtitle' => __('حالت نمایش صفحه سفارشات در حساب کاربری ووکامرس', 'bakala'),
                    'options' => array(
                        'new' => __('نوین', 'bakala'),
                        'old' => __('نسخه قبلی', 'bakala'),
                        'old-new' => __('نسخه قبلی+نوین', 'bakala'),
                    ),
                    'default' => 'new',
                ),
                array(
                    'id' => 'post_tracking_code',
                    'type' => 'switch',
                    'title' => __('کد رهگیری پست', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، در ویرایش هر سفارش فیلدی با عنوان شماره مرسوله اضافه می شود که پس از ثبت کد مرسوله، در سفارش کاربر مشاهده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

                array(
                    'id' => 'ajax_orders',
                    'type' => 'switch',
                    'title' => __('سفارشات ایجکسی', 'bakala'),
                    'subtitle' => __('در حالت ایجکسی بار سرور کاهش پیدا میکند و در لود اولیه تمامی سفارشات برای کاربر لود نمی شود؛ اگر در قسمت سفارشات حساب کاربری خطایی دریافت کردید این حالت را غیرفعال کنید.', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
            )
        ));
        Redux::set_section($opt_name, array(
            'title' => __('وضعیت های سفارش', 'bakala'),
            'id' => 'order_statuses_section',
            'subsection' => true,
            'icon' => 'dashicons dashicons-screenoptions',
            'fields' => bakala_image_order_status_fields()
        ));
        Redux::set_section($opt_name, array(
            'title' => __('دکمه سبد خرید', 'bakala'),
            'id' => 'add_to_cart_button',
            'subsection' => true,
            'icon' => 'dashicons dashicons-button',
            'fields' => array(
                array(
                    'id' => 'add_to_cart_button_remove',
                    'type' => 'section',
                    'title' => esc_html__('حذف دکمه سبد خرید', 'bakala'),
                    'indent' => true,
                ),
                array(
                    'id' => 'add_to_cart_button_remove_all',
                    'type' => 'switch',
                    'title' => __('حذف دکمه سبد خرید از کل سایت', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، دکمه افزودن به سبد خرید از سایت حذف می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'add_to_cart_button_remove_category',
                    'type' => 'select',
                    'multi' => true,
                    'data' => 'terms',
                    'args' => array('taxonomies' => 'product_cat'),
                    'title' => __('حذف دکمه سبد خرید از دسته بندی ها', 'bakala'),
                    'subtitle' => __('دکمه افزودن به سبد خرید را در دسته بندی های مورد نظر حذف کنید.', 'bakala'),
                    'required' => array('add_to_cart_button_remove_all', '=', false),
                ),
                array(
                    'id' => 'add_to_cart_button_remove_single',
                    'type' => 'switch',
                    'title' => __('حذف دکمه سبد خرید از هر محصول', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، در ویرایش هر محصول می توانید دکمه افزودن به سبد خرید را حذف کنید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('add_to_cart_button_remove_all', '=', false),
                ),

                array(
                    'id' => 'add_to_cart_button_change_text',
                    'type' => 'section',
                    'title' => esc_html__('متن دکمه سبد خرید', 'bakala'),
                    'indent' => true,
                ),
                array(
                    'id' => 'add_to_cart_button_text',
                    'type' => 'text',
                    'title' => __('متن جایگزین دکمه افزودن به سبد خرید', 'bakala'),
                    'placeholder' => __('ثبت سفارش', 'bakala'),
                ),
                array(
                    'id' => 'add_to_cart_button_change_text_all',
                    'type' => 'switch',
                    'title' => __('تغییر متن دکمه سبد خرید در کل سایت', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، متن دکمه افزودن به سبد خرید در سایت تغییر می کند.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'add_to_cart_button_change_text_category',
                    'type' => 'select',
                    'multi' => true,
                    'data' => 'terms',
                    'args' => array('taxonomies' => 'product_cat'),
                    'title' => __('تغییر متن دکمه سبد خرید در دسته بندی ها', 'bakala'),
                    'subtitle' => __('متن دکمه افزودن به سبد خرید را در دسته بندی های مورد نظر تغییر دهید.', 'bakala'),
                    'required' => array('add_to_cart_button_change_text_all', '=', false),
                ),
                array(
                    'id' => 'add_to_cart_button_change_text_single',
                    'type' => 'switch',
                    'title' => __('تغییر متن دکمه سبد خرید در هر محصول', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، در ویرایش هر محصول می توانید متن دکمه افزودن به سبد خرید را تغییر دهید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('add_to_cart_button_change_text_all', '=', false),
                ),

                array(
                    'id' => 'add_to_cart_button_change_link',
                    'type' => 'section',
                    'title' => esc_html__('لینک دکمه سبد خرید', 'bakala'),
                    'indent' => true,
                ),
                array(
                    'id' => 'add_to_cart_button_link',
                    'type' => 'text',
                    'title' => __('لینک جایگزین دکمه افزودن به سبد خرید', 'bakala'),
                    'placeholder' => __('https://wa.me/99', 'bakala'),
                ),
                array(
                    'id' => 'add_to_cart_button_change_link_all',
                    'type' => 'switch',
                    'title' => __('تغییر لینک دکمه سبد خرید در کل سایت', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، لینک دکمه افزودن به سبد خرید در سایت تغییر می کند.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'add_to_cart_button_change_link_category',
                    'type' => 'select',
                    'multi' => true,
                    'data' => 'terms',
                    'args' => array('taxonomies' => 'product_cat'),
                    'title' => __('تغییر لینک دکمه سبد خرید در دسته بندی ها', 'bakala'),
                    'subtitle' => __('لینک دکمه افزودن به سبد خرید را در دسته بندی های مورد نظر تغییر دهید.', 'bakala'),
                    'required' => array('add_to_cart_button_change_text_all', '=', false),
                ),
                array(
                    'id' => 'add_to_cart_button_change_link_single',
                    'type' => 'switch',
                    'title' => __('تغییر لینک دکمه سبد خرید در هر محصول', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، در ویرایش هر محصول می توانید لینک دکمه افزودن به سبد خرید را تغییر دهید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('add_to_cart_button_change_text_all', '=', false),
                ),
            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('محصولات متغیر', 'bakala'),
            'id' => 'default_variable',
            'subsection' => true,
            'icon' => 'dashicons dashicons-image-filter',
            'fields' => array(
                array(
                    'id' => 'default_variable_enable',
                    'type' => 'switch',
                    'title' => __('متغیر پیشفرض', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، متغیر پیشفرض محصولات، بر اساس موارد بعدی تعیین می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'default_variable_sort',
                    'type' => 'select',
                    'title' => __('مرتب سازی متغیر پیشفرض', 'bakala'),
                    'subtitle' => __('نحوه مرتب سازی متغیر پیشفرض را انتخاب کنید.', 'bakala'),
                    'options' => array(
                        'position' => 'جایگاه',
                        'id' => 'id',
                        'price-low' => 'قیمت پایینتر',
                        'price-high' => 'قیمت بالاتر'
                    ),
                    'default' => 'position',
                    'required' => array('default_variable_enable', '=', true),
                ),
                array(
                    'id' => 'default_variable_then_sort',
                    'type' => 'select',
                    'title' => __('مرتب سازی دوم متغیر پیشفرض', 'bakala'),
                    'subtitle' => __('درصورتیکه متغیرها قیمت برابر داشتند، بر چه اساس مرتب شوند.', 'bakala'),
                    'options' => array(
                        'then_stock' => 'تعداد موجودی',
                        'then_sales' => 'تعداد فروش',
                        'then_id' => 'id',
                    ),
                    'default' => 'then_stock',
                    'required' => array('default_variable_enable', '=', true),
                ),
                array(
                    'id' => 'keep_manually_set_defaults_variable',
                    'type' => 'switch',
                    'title' => __('تنظیم دستی متغیر پیشفرض', 'bakala'),
                    'subtitle' => __('اگر قبلاً پیش‌فرض‌های دستی را برای برخی از محصولات تنظیم کرده‌اید و می‌خواهید آن‌ها را حفظ کنید، این را فعال کنید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('default_variable_enable', '=', true),
                ),
                array(
                    'id' => 'grey_out_variations_when_out_of_stock',
                    'type' => 'switch',
                    'title' => __('غیرفعال کردن متغیر ناموجود', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، کاربر امکان انتخاب متغیر ناموجود را ندارد.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('default_variable_enable', '=', true),
                ),
                array(
                    'id' => 'hide_variations_when_out_of_stock',
                    'type' => 'switch',
                    'title' => __('پنهان سازی متغیر ناموجود', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، متغیر ناموجود، از صفحه محصول پنهان می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('default_variable_enable', '=', true),
                ),
                array(
                    'id' => 'show_reset_variations',
                    'type' => 'switch',
                    'title' => __('نمایش دکمه ریست فرم متغیرها', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، دکمه ریست کردن متغیرها در صفحه محصول نمایش داده می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'default_variable_postmeta',
                    'type' => 'switch',
                    'title' => __('آپدیت متغیر پیشفرض در دیتابیس', 'bakala'),
                    'subtitle' => __('اگر از افزونه هایی مانند ترب استفاده می کنید بهتر است این گزینه را فعال کنید تا در دیتابیس متغیر پیشفرض با توجه به موارد فوق آپدیت شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('default_variable_enable', '=', true),
                ),
                array(
                    'id' => 'warning_default_variable_postmeta',
                    'type' => 'info',
                    'title' => esc_html__('هشدار!', 'bakala'),
                    'style' => 'warning',
                    'desc' => esc_html__('با فعال کردن آپدیت متغیر در دیتابیس، متغیر های پیشفرضی که بصورت دستی در محصولات تعریف شده اند از بین خواهند رفت! قبل از فعالسازی این گزینه از دیتابیس بکاپ تهیه کنید!', 'bakala'),
                    'required' => array('default_variable_postmeta', '=', 1),
                ),
                array(
                    'id' => 'swatches',
                    'type' => 'switch',
                    'title' => __('استفاده از سواچز قالب', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، سواچز قالب فعال می شود. دقت کنید که افزونه سواچز فعال نباشد.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('پیامک ها', 'bakala'),
            'id' => 'woocommerce_sms',
            'subsection' => true,
            'icon' => 'dashicons dashicons-testimonial',

            'fields' => array(
                array(
                    'id' => 'reply_comment_start',
                    'type' => 'section',
                    'title' => esc_html__('پیامک پاسخ دیدگاه', 'bakala'),
                    'indent' => true,

                ),
                array(
                    'id' => 'reply_comment_sms',
                    'type' => 'switch',
                    'title' => __('ارسال پیامک پاسخ دیدگاه', 'bakala'),
                    'subtitle' => __('پس از پاسخ به دیدگاه مشتری برای کاربر پیامکی ارسال می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'title' => esc_html(__('متن پیامک', 'bakala')),
                    'id' => 'reply_comment_text',
                    'type' => 'text',
                    'description' => 'متن پیشنهادی: %name% عزیز به دیدگاه شما در محصول %product-name% پاسخ داده شد. از طریق لینک زیر می توانید پاسخ دیدگاه را مشاهده کنید: %product-link%',
                    'placeholder' => '%name% عزیز به دیدگاه شما در محصول %product-name% پاسخ داده شد. از طریق لینک زیر می توانید پاسخ دیدگاه را مشاهده کنید: %product-link%',
                    'required' => array(
                        array('reply_comment_sms', '=', 1),
                        array('sp_sms', '=', array('parsgreen', 'segalnet'))
                    )
                ),
                array(
                    'title' => esc_html(__('کد پترن', 'bakala')),
                    'id' => 'reply_comment_pattern',
                    'type' => 'text',
                    'desc' => __('کد پترن را وارد کنید.', 'bakala'),
                    'required' => array(
                        array('reply_comment_sms', '=', 1),
                        array('sp_sms', '=', array('meli', 'ippanel'))
                    )
                ),
                array(
                    'id' => 'reply_comment_info_meli',
                    'type' => 'raw',
                    'title' => __('<div class="balala_alert"><div>متن پترن خود را طوری تنظیم کنید که ترتیب متغیرها به صورت زیر باشد:</div><div style="font-weight:bold;margin-top:10px !important;color: #FDB910;">نام کاربر-نام محصول-لینک محصول</div><hr><p><strong>متن پیشنهادی:</strong> {0} عزیز به دیدگاه شما در محصول {1} پاسخ داده شد. از طریق لینک زیر می توانید پاسخ دیدگاه را مشاهده کنید: {2}</p> </div>', 'bakala'),
                    'required' => array(
                        array('reply_comment_sms', '=', 1),
                        array('sp_sms', '=', 'meli')
                    )
                ),
                array(
                    'id' => 'reply_comment_info_ippanel',
                    'type' => 'raw',
                    'title' => __('<div class="balala_alert"><p><strong>متن پیشنهادی:</strong> %name% عزیز به دیدگاه شما در محصول %product-name% پاسخ داده شد. از طریق لینک زیر می توانید پاسخ دیدگاه را مشاهده کنید: %product-link%</p> </div>', 'bakala'),
                    'required' => array(
                        array('reply_comment_sms', '=', 1),
                        array('sp_sms', '=', 'ippanel')
                    )
                ),
                array(
                    'title' => esc_html(__('متغیر ورودی نام کاربر', 'bakala')),
                    'id' => 'reply_comment_pattern_var_name',
                    'type' => 'text',
                    'default' => 'name',
                    'desc' => __('متغیر ورودی نام کاربر در پترن را وارد کنید. بهتر است مقدار پیشفرض را قرار دهید.', 'bakala'),
                    'required' => array(
                        array('reply_comment_sms', '=', 1),
                        array('sp_sms', '=', 'ippanel')
                    )
                ),
                array(
                    'title' => esc_html(__('متغیر ورودی نام محصول', 'bakala')),
                    'id' => 'reply_comment_pattern_var_product_name',
                    'type' => 'text',
                    'default' => 'product-name',
                    'desc' => __('متغیر ورودی نام محصول در پترن را وارد کنید. بهتر است مقدار پیشفرض را قرار دهید.', 'bakala'),
                    'required' => array(
                        array('reply_comment_sms', '=', 1),
                        array('sp_sms', '=', 'ippanel')
                    )
                ),
                array(
                    'title' => esc_html(__('متغیر ورودی لینک محصول', 'bakala')),
                    'id' => 'reply_comment_pattern_var_product_link',
                    'type' => 'text',
                    'default' => 'product-link',
                    'desc' => __('متغیر ورودی لینک محصول در پترن را وارد کنید. بهتر است مقدار پیشفرض را قرار دهید.', 'bakala'),
                    'required' => array(
                        array('reply_comment_sms', '=', 1),
                        array('sp_sms', '=', 'ippanel')
                    )
                ),
                array(
                    'id' => 'reply_comment_end',
                    'type' => 'section',
                    'indent' => false,
                ),

            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('برچسب ویژه', 'bakala'),
            'id' => 'custom_label',
            'subsection' => true,
            'icon' => 'dashicons dashicons-awards',
            'fields' => array(
                array(
                    'id' => 'custom_lable_anable',
                    'type' => 'switch',
                    'title' => __('برچسب ویژه محصول', 'bakala'),
                    'subtitle' => __('برچسب (لیبل) سفارشی به محصول اضافه کنید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'title' => esc_html(__('متن برچسب', 'bakala')),
                    'id' => 'custom_label_text',
                    'type' => 'text',
                    'placeholder' => __('ویژه', 'bakala'),
                    'required' => array('custom_lable_anable', '=', 1),
                ),

                array(
                    'id' => 'custom_label_category',
                    'type' => 'select',
                    'multi' => true,
                    'data' => 'terms',
                    'args' => array('taxonomies' => 'product_cat'),
                    'title' => __('نمایش برچسب فقط در دسته بندی های خاص', 'bakala'),
                    'subtitle' => __('دسته بندی محصولاتی را که می خواهید    برچسب در آن ها نمایش شود انتخاب کنید', 'bakala'),
                    'required' => array('custom_lable_anable', '=', 1),
                ),
                array(
                    'id' => 'custom_lable_single',
                    'type' => 'switch',
                    'title' => __('افزودن برچسب سفارشی در محصول', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، در ویرایش محصول، گزینه برچسب اضافه می شود و می توانید بصورت سفارشی در هر محصول برچسب متفاوت ایجاد کنید.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('custom_lable_anable', '=', 1),
                ),
                array(
                    'id' => 'custom_label_bg',
                    'type' => 'color',
                    'title' => __('رنگ پس زمینه برچسب', 'bakala'),
                    'default' => '#E20142',
                    'validate' => 'color',
                    'required' => array('custom_lable_anable', '=', 1),
                ),
                array(
                    'id' => 'custom_label_color',
                    'type' => 'color',
                    'title' => __('رنگ متن برچسب', 'bakala'),
                    'default' => '#FFFFFF',
                    'validate' => 'color',
                    'required' => array('custom_lable_anable', '=', 1),
                ),
            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('پیگیری سفارشات', 'bakala'),
            'id' => 'track_orders',
            'subsection' => true,
            'icon' => 'dashicons dashicons-buddicons-tracking',
            'fields' => array(
                array(
                    'id' => 'order_tracking_authentication',
                    'type' => 'switch',
                    'title' => __('احراز هویت موبایل در پیگیری سفارشات', 'bakala'),
                    'subtitle' => __('با غیرفعال کردن این گزینه، احراز هویت موبایل در پیگیری سفارشات انجام نمی شود و مشتریان بدون تایید کد و صرفا با زدن شماره موبایل به وضعیت سفارش دسترسی دارند. ', 'bakala'),
                    'default' => 1,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'order_tracking_type',
                    'type' => 'button_set',
                    'title' => __('نحوه نمایش وضعیت سفارش در پیگیری سفارشات', 'bakala'),
                    'options' => array(
                        'image' => __('گرافیکی', 'bakala'),
                        'text' => __('متنی', 'bakala'),
                    ),
                    'default' => 'image',
                ),
                array(
                    'title' => esc_html__('وضعیت های در حال انجام', 'bakala'),
                    'subtitle' => esc_html__('وضعیت هایی که میخواهید در وضعیت "در حال انجام" نمایش داده شوند را انتخاب کنید.', 'bakala'),
                    'id' => 'track_orders_status_1',
                    'type' => 'select',
                    'multi' => true,
                    'options' => !empty($order_statuses_array) ? $order_statuses_array : wc_get_order_statuses(),
                    'required' => array('order_tracking_type', '=', 'image'),
                ),
                array(
                    'title' => esc_html__('وضعیت های در حال بررسی', 'bakala'),
                    'subtitle' => esc_html__('وضعیت هایی که میخواهید در وضعیت "در حال بررسی" نمایش داده شوند را انتخاب کنید.', 'bakala'),
                    'id' => 'track_orders_status_2',
                    'type' => 'select',
                    'multi' => true,
                    'options' => !empty($order_statuses_array) ? $order_statuses_array : wc_get_order_statuses(),
                    'required' => array('order_tracking_type', '=', 'image'),
                ),
                array(
                    'title' => esc_html__('وضعیت های بسته بندی', 'bakala'),
                    'subtitle' => esc_html__('وضعیت هایی که میخواهید در وضعیت "بسته بندی" نمایش داده شوند را انتخاب کنید.', 'bakala'),
                    'id' => 'track_orders_status_3',
                    'type' => 'select',
                    'multi' => true,
                    'options' => !empty($order_statuses_array) ? $order_statuses_array : wc_get_order_statuses(),
                    'required' => array('order_tracking_type', '=', 'image'),
                ),
                array(
                    'title' => esc_html__('وضعیت های تکمیل شده', 'bakala'),
                    'subtitle' => esc_html__('وضعیت هایی که میخواهید در وضعیت "تکمیل شده" نمایش داده شوند را انتخاب کنید.', 'bakala'),
                    'id' => 'track_orders_status_4',
                    'type' => 'select',
                    'multi' => true,
                    'options' => !empty($order_statuses_array) ? $order_statuses_array : wc_get_order_statuses(),
                    'required' => array('order_tracking_type', '=', 'image'),
                ),
                array(
                    'id' => 'delivered_status_order',
                    'type' => 'switch',
                    'title' => __('فعالسازی وضعیت تحویل شده', 'bakala'),
                    'subtitle' => __('با فعالسازی این گزینه، در وضعیت های سفارش پیگیری سفارشات، وضعیت "تحویل شده" نیز اضافه می شود.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('order_tracking_type', '=', 'image'),
                ),
                array(
                    'title' => esc_html__('وضعیت های تحویل شده', 'bakala'),
                    'subtitle' => esc_html__('وضعیت هایی که میخواهید در وضعیت "تحویل شده" نمایش داده شوند را انتخاب کنید.', 'bakala'),
                    'id' => 'track_orders_status_5',
                    'type' => 'select',
                    'multi' => true,
                    'options' => !empty($order_statuses_array) ? $order_statuses_array : wc_get_order_statuses(),
                    'required' => array(
                        'delivered_status_order',
                        '=',
                        1,
                        'order_tracking_type',
                        '=',
                        'image',
                    ),
                ),

                array(
                    'title' => esc_html__('جزئیات مرسوله', 'bakala'),
                    'subtitle' => esc_html__('مواردی که می خواهید از جزئیات مرسوله نمایش داده شود را انتخاب کنید.', 'bakala'),
                    'id' => 'track_orders_details',
                    'type' => 'select',
                    'multi' => true,
                    'options' => array(
                        'name' => 'نام کاربر',
                        'pay_method' => ' روش پرداخت',
                        'destination' => 'مقصد',
                        'amount' => 'مبلغ پرداخت',
                        'product_pic' => 'تصویر محصول',
                        'product_name' => 'نام محصول',
                    ),
                ),
                /*array(
                    'id' => 'section-tracking-sms',
                    'type' => 'section',
                    'title' => esc_html__('تنظیمات پیامک پیگیری سفارش', 'bakala'),
                    'indent' => true
                ),
                array(
                    'title' => esc_html(__('کد پترن', 'bakala')),
                    'id' => 'tracking_sms_pattern',
                    'type' => 'text',
                    'desc' => __('کد پترن را وارد کنید.', 'bakala'),
                ),
                array(
                    'id' => 'tracking_sms_info',
                    'type' => 'raw',
                    'title' => __('<div class="balala_alert"><div>متن پترن خود را طوری تنظیم کنید که ترتیب متغیرها به صورت زیر باشد:</div><div style="font-weight:bold;margin-top:10px !important;color: #FDB910;"><p>نام کاربر: name</p><p>کد رهگیری: code</p><p>شماره سفارش:id</p></div> </div>', 'bakala'),

                ),*/

            )
        ));
        Redux::set_section($opt_name, array(
            'title' => __('حداقل/حداکثر تعداد محصول', 'bakala'),
            'id' => 'min_max_qty',
            'subsection' => true,
            'icon' => 'dashicons dashicons-filter',
            'fields' => array(
                array(
                    'id' => 'min_max_qty_enable',
                    'type' => 'switch',
                    'title' => __('فعال‌سازی محدودیت‌های تعداد محصول', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'title' => __('حداقل محدودیت تعداد', 'bakala'),
                    'id' => 'min_qty',
                    'type' => 'slider',
                    'subtitle' => __('حداقل تعداد مورد نیاز برای هر محصول. برای لغو محدودیت از صفر استفاده کنید.', 'bakala'),
                    "default" => 0,
                    "min" => 0,
                    "step" => 1,
                    "max" => 500,
                    'display_value' => 'text',
                    'required' => array('min_max_qty_enable', '=', 1),
                ),
                array(
                    'title' => __('حداکثر محدودیت تعداد', 'bakala'),
                    'id' => 'max_qty',
                    'type' => 'slider',
                    'subtitle' => __('حداکثر تعداد مورد نیاز برای هر محصول. برای لغو محدودیت از صفر استفاده کنید.', 'bakala'),
                    "default" => 0,
                    "min" => 0,
                    "step" => 1,
                    "max" => 500,
                    'display_value' => 'text',
                    'required' => array('min_max_qty_enable', '=', 1),
                ),
                array(
                    'id' => 'variable_min_max',
                    'type' => 'switch',
                    'title' => __('اعمال محدودیت روی هر متغیر', 'bakala'),
                    'desc' => __('در صورت فعال بودن این گزینه، محدودیت روی هر متغیر اعمال می شود؛ به عنوان مثال اگر حداکثر محدودیت روی  باشد، درصورتیکه این گزینه فعال باشه، کاربر می تواند  رنگ آبی و  رنگ زرد خریداری کند', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                    'required' => array('min_max_qty_enable', '=', 1),
                ),
                array(
                    'id' => 'step_quantity',
                    'type' => 'slider',
                    'title' => __('گام های تعداد محصول'),
                    'subtitle' => __('تعیین کنید چند تا چند تا تعداد محصول افزایش/کاهش یابد. بطور مثال 100 تایی', 'bakala'),
                    'min' => 1,
                    'max' => 999,
                    'step' => 1,
                    'default' => 1,
                ),
            )
        ));
        

        Redux::set_section($opt_name, array(
            'title' => __('سرچ لاین', 'bakala'),
            'id' => 'searchline',
            'subsection' => true,
            'icon' => 'dashicons dashicons-search',
            'fields' => array(
                array(
                    'id' => 'searchline_token',
                    'type' => 'text',
                    'title' => __('توکن سرچ لاین', 'bakala'),
                    'subtitle' => __('توکن دریافتی از سرچ لاین را وارد کنید.', 'bakala'),
                ),
                array(
                    'id' => 'searchline_verify',
                    'type' => 'switch',
                    'title' => __('صحت سنجی اطلاعات سرچ لاین', 'bakala'),
                    'subtitle' => __('برای فعالسازی این سرویس دقت کنید که این سرویس در پنل سرچ لاین فعال باشد.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),

            )
        ));

        Redux::set_section($opt_name, array(
            'title' => __('پشتیبان فروشگاه', 'bakala'),
            'id' => 'supports-shop',
            // 'subsection' => true,
            'icon' => 'dashicons dashicons-editor-help',
            'fields' => array(
                array(
    'id'       => 'support_team',
    'type'     => 'repeater',
    'group_values' => true,
    'init_empty' => true,
            //'item_name' => '', // Add a repeater block name to the Add and Delete buttons
    'title'    => 'مدیریت پشتیبان‌ها',
    'subtitle' => 'لیست پشتیبان‌های سایت',
    'fields'   => array(
        array(
            'id'    => 'name',
            'type'  => 'text',
            'title' => 'نام پشتیبان'
        ),
        array(
            'id'    => 'image',
            'type'  => 'media',
            'title' => 'تصویر پشتیبان'
        ),
        array(
            'id'    => 'phone',
            'type'  => 'text',
            'title' => 'شماره تماس'
        ),
        array(
            'id'    => 'telegram',
            'type'  => 'text',
            'title' => 'لینک تلگرام'
        ),
        array(
            'id'    => 'whatsapp',
            'type'  => 'text',
            'title' => 'لینک واتساپ'
        ),
    )
),

            )
        ));
    } //end woocommerce codition
    /*
    Redux::set_section($opt_name, array(
        'title' => __('هوش مصنوعی', 'bakala'),
        'id' => 'ai',
        'icon' => 'dashicons dashicons-superhero-alt',
    ));
    Redux::set_section($opt_name, array(
        'title' => __('ربات ترب', 'bakala'),
        'id' => 'torob',
        'subsection' => true,
        'icon' => 'dashicons dashicons-superhero',
        'fields' => array(
            array(
                'id' => 'torob_enable',
                'type' => 'switch',
                'title' => __('فعالسازی ربات ترب', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),

            array(
                'id' => 'torob_email',
                'type' => 'text',
                'title' => __('ایمیل جهت ثبت نام', 'bakala'),
                'subtitle' => __('درصورتیکه خالی بگذارید از ایمیل مدیر سایت استفاده می شود.', 'bakala'),
                'required' => array('torob_enable', '=', 1),
            ),
            array(
                'id' => 'torob_phone',
                'type' => 'text',
                'title' => __('شماره موبایل جهت ثبت نام', 'bakala'),
                'subtitle' => __('درصورتیکه خالی بگذارید از شماره موبایل مدیر سایت استفاده می شود.', 'bakala'),
                'required' => array('torob_enable', '=', 1),
            ),


        )
    ));
    */
    Redux::set_section($opt_name, array(
        'title' => __('افزایش فروش', 'bakala'),
        'id' => 'marketing',
        'icon' => 'dashicons dashicons-smiley',
    ));
    Redux::set_section($opt_name, array(
        'title' => __('سبد خرید رها شده', 'bakala'),
        'id' => 'abandoned_cart',
        'subsection' => true,
        'icon' => 'dashicons dashicons-hourglass',
        'fields' => array(
            array(
                'id' => 'abandoned_cart_enable',
                'type' => 'switch',
                'title' => __('فعالسازی سبد خرید رها شده', 'bakala'),
                'subtitle' => __('پس از فعالسازی هنگام افزودن به سبد خرید، شماره موبایل مشتری را دریافت کرده و پس از تعداد روز مشخص پیامک ارسال می شود', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'title' => esc_html(__('ساعات سپری شده', 'bakala')),
                'id' => 'abandoned_order_hours',
                'type' => 'slider',
                'subtitle' => __('تعیین کنید که پس از چند ساعت پیامک برای کاربر ارسال شود.', 'bakala'),
                "default" => 4,
                "min" => 1,
                "step" => 1,
                "max" => 500,
                'display_value' => 'text',
                'required' => array('abandoned_cart_enable', '=', 1),
            ),
            array(
                'id' => 'abandoned_cart_sms_type',
                'type' => 'button_set',
                'title' => __('نوع ارسال پیامک', 'bakala'),
                'subtitle' => __('برای پنل کاوه نگار حتما ساده را انتخاب کنید', 'bakala'),
                'options' => array(
                    'simple' => __('ساده', 'bakala'),
                    'pattern' => __('پترن', 'bakala'),
                ),
                'default' => 'simple',
                'required' => array('abandoned_cart_enable', '=', true)
            ),
            array(
                'title' => esc_html(__('متن ارسال پیامک', 'bakala')),
                'id' => 'abandoned_cart_text',
                'type' => 'textarea',
                'subtitle' => __('به متغیرها که در پایین توضیح داده شده دقت کنید.', 'bakala'),
                'required' => array('abandoned_cart_sms_type', '=', 'simple'),
            ),
            array(
                'title' => esc_html(__('کد پترن', 'bakala')),
                'id' => 'abandoned_cart_pattern',
                'type' => 'text',
                'desc' => __('کد پترن پنل پیامکی را وارد کنید.', 'bakala'),
                'required' => array(
                    array('abandoned_cart_enable', '=', 1),
                    array('abandoned_cart_sms_type', '=', 'pattern')
                )
            ),
            array(
                'id' => 'abandoned_cart_info_simple',
                'type' => 'raw',
                'title' => __('<div class="balala_alert"><h3 style="color:#FDB910">مثال متن پیامک:</h3><div>#name# عزیز <br> یک سفارش رها شده در وبسایت باکالا داری <br> با 5% تخفیف سفارشت رو کامل کن <br> #link#</div><p><strong>متن دارای دو متغیر می باشد: </strong> نام: #name# - لینک: #link#</p></div>', 'bakala'),
                'required' => array(
                    array('abandoned_cart_enable', '=', 1),
                    array('abandoned_cart_sms_type', '=', 'simple')
                )
            ),
            array(
                'id' => 'abandoned_cart_info_pattern',
                'type' => 'raw',
                'title' => __('<div class="balala_alert"><h3 style="color:#FDB910">مثال متن الگو:</h3><div>علی عزیز <br> یک سفارش رها شده در وبسایت باکالا داری <br> با 5% تخفیف سفارشت رو کامل کن <br> domain.com/4Xde</div><p><strong>متن دارای دو متغیر باشد: </strong> متغیر اول: %name% - متغیر دوم: %link%</p></div>', 'bakala'),
                'required' => array(
                    array('abandoned_cart_enable', '=', 1),
                    array('abandoned_cart_sms_type', '=', 'pattern')
                )
            ),

        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('یادآور نظرسنجی', 'bakala'),
        'id' => 'review_reminder',
        'subsection' => true,
        'icon' => 'dashicons dashicons-testimonial',

        'fields' => array(

            array(
                'id' => 'review_reminder_sms',
                'type' => 'switch',
                'title' => __('ارسال پیامک یادآور نظرسنجی', 'bakala'),
                'subtitle' => __('پس از مدت زمان مشخص شده بعد از تکمیل شدن سفارش، برای مشتری پیامکی جهت یادآوری نظرسنجی ارسال می شود.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'review_page',
                'type' => 'select',
                'data' => 'pages',
                'title' => __('برگه نظرسنجی محصولات', 'bakala'),
                'subtitle' => __('برگه ای که حاوی شورت کد [bakala_review] است را انتخاب کنید.', 'bakala'),
                'required' => array('review_reminder_sms', '=', 1),
            ),
            array(
                'title' => esc_html(__('کد پترن', 'bakala')),
                'id' => 'review_reminder_pattern',
                'type' => 'text',
                'desc' => __('کد پترن را وارد کنید.', 'bakala'),
                'required' => array(
                    array('review_reminder_sms', '=', 1),
                    array('sp_sms', '=', array('meli', 'ippanel'))
                )
            ),

            array(
                'id' => 'review_reminder_pattern_info_meli',
                'type' => 'raw',
                'title' => __('<div class="balala_alert"><div>متن پترن خود را طوری تنظیم کنید که ترتیب متغیرها به صورت زیر باشد:</div><div style="font-weight:bold;margin-top:10px !important;color: #FDB910;">نام کاربر-شماره سفارش-لینک صفحه نظرسنجی</div><hr><p><strong>متن پیشنهادی:</strong> {0} عزیز از خریدتان ممنونیم. لطفا از طریق نشانی زیر به محصولات خریداری شده در سفارش {1} امتیاز دهید و ما را در بهبود کیفیت محصولات و خدمات یاری کنید. لینک: {2}</p> </div>', 'bakala'),
                'required' => array(
                    array('review_reminder_sms', '=', 1),
                    array('sp_sms', '=', 'meli')
                )
            ),
            array(
                'id' => 'review_reminder_pattern_info_ippanel',
                'type' => 'raw',
                'title' => __('<div class="balala_alert"><p><strong>متن پیشنهادی:</strong> %name% عزیز از خریدتان ممنونیم. لطفا از طریق نشانی زیر به محصولات خریداری شده در سفارش %order-id% امتیاز دهید و ما را در بهبود کیفیت محصولات و خدمات یاری کنید.
                    لینک: %product-link%</p> </div>', 'bakala'),
                'required' => array(
                    array('review_reminder_sms', '=', 1),
                    array('sp_sms', '=', 'ippanel')
                )
            ),
            array(
                'title' => esc_html(__('متغیر ورودی نام کاربر', 'bakala')),
                'id' => 'review_reminder_pattern_var_name',
                'type' => 'text',
                'default' => 'name',
                'desc' => __('متغیر ورودی نام کاربر در پترن را وارد کنید. بهتر است مقدار پیشفرض را قرار دهید.', 'bakala'),
                'required' => array(
                    array('review_reminder_sms', '=', 1),
                    array('sp_sms', '=', 'ippanel')
                )
            ),
            array(
                'title' => esc_html(__('متغیر ورودی شماره سفارش', 'bakala')),
                'id' => 'review_reminder_pattern_var_order_id',
                'type' => 'text',
                'default' => 'order-id',
                'desc' => __('متغیر ورودی شماره سفارش در پترن را وارد کنید. بهتر است مقدار پیشفرض را قرار دهید.', 'bakala'),
                'required' => array(
                    array('review_reminder_sms', '=', 1),
                    array('sp_sms', '=', 'ippanel')
                )
            ),
            array(
                'title' => esc_html(__('متغیر ورودی لینک محصول', 'bakala')),
                'id' => 'review_reminder_pattern_var_product_link',
                'type' => 'text',
                'default' => 'product-link',
                'desc' => __('متغیر ورودی لینک محصول در پترن را وارد کنید. بهتر است مقدار پیشفرض را قرار دهید.', 'bakala'),
                'required' => array(
                    array('review_reminder_sms', '=', 1),
                    array('sp_sms', '=', 'ippanel')
                )
            ),
            array(
                'title' => esc_html(__('متن پیامک', 'bakala')),
                'id' => 'review_reminder_text',
                'type' => 'text',
                'description' => 'متن پیشنهادی: %name% عزیز از خریدتان ممنونیم. لطفا از طریق نشانی زیر به محصولات خریداری شده در سفارش %order-id% امتیاز دهید و ما را در بهبود کیفیت محصولات و خدمات یاری کنید.
                    لینک: %product-link%',
                'placeholder' => '%name% عزیز از خریدتان ممنونیم. لطفا از طریق نشانی زیر به محصولات خریداری شده در سفارش %order-id% امتیاز دهید و ما را در بهبود کیفیت محصولات و خدمات یاری کنید.
                    لینک: %product-link%',
                'required' => array(
                    array('review_reminder_sms', '=', 1),
                    array('sp_sms', '=', array('parsgreen', 'segalnet'))
                )
            ),
            array(
                'title' => __('تعداد ساعات سپری شده از سفارش', 'bakala'),
                'id' => 'review_reminder_delay',
                'type' => 'slider',
                'subtitle' => __('تعیین کنید که پس از چند ساعت از تکمیل شدن سفارش، پیامک یادآور ارسال شود.', 'bakala'),
                "default" => 5,
                "min" => 1,
                "step" => 1,
                "max" => 500,
                'display_value' => 'text',
                'required' => array('review_reminder_sms', '=', 1),
            ),

        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('پاپ آپ صورتحساب', 'bakala'),
        'id' => 'checkout_popup_section',
        'subsection' => true,
        'icon' => 'dashicons dashicons-feedback',

        'fields' => array(
            array(
                'id' => 'checkout_popup',
                'type' => 'switch',
                'title' => 'فعالسازی پاپ آپ هشدار صورتحساب',
                'subtitle' => __('با فعالسازی این گزینه، در صفحه صورتحساب پاپ آپی با محتوای دلخواه نمایش داده می شود.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'checkout_popup_vpn',
                'type' => 'switch',
                'title' => 'نمایش فقط به کاربران با vpn',
                'subtitle' => __('با فعالسازی این گزینه، پاپ آپ فقط به کاربران با ای پی غیر ایران نمایش داده می شود.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'info_checkout_popup_vpn',
                'type' => 'info',
                'title' => esc_html__('عدم عملکرد نمایش پاپ آپ به کاربران با vpn!', 'bakala'),
                'style' => 'warning',
                'desc' => esc_html__('درصورتیکه این امکان عملکرد صحیح نداشت از هاست خود بخواهید تا آدرس ip-api.com را از بلک لیست فایروال خارج کنند', 'bakala'),
                'required' => array('checkout_popup_vpn', '=', true)
            ),
            array(
                'id' => 'checkout_popup_content',
                'type' => 'editor',
                'title' => __('محتوای پاپ آپ هشدار صورتحساب', 'bakala'),
                'args' => array(
                    'teeny' => true,
                    'textarea_rows' => 10
                ),
                'required' => array('checkout_popup', '=', true)
            ),
            array(
                'id' => 'checkout_popup_button',
                'type' => 'text',
                'title' => __('متن دکمه پاپ آپ هشدار صورتحساب', 'bakala'),
                'required' => array('checkout_popup', '=', true)
            ),
            array(
                'id' => 'checkout_popup_count',
                'type' => 'slider',
                'title' => __('تعداد دفعات نمایش پاپ آپ در روز', 'bakala'),
                "default" => 1,
                "min" => 1,
                "step" => 1,
                "max" => 50,
                'display_value' => 'text',
                'required' => array('checkout_popup', '=', true)
            ),
            array(
                'id' => 'checkout_popup_btn_bg',
                'type' => 'color',
                'title' => __('رنگ پس زمینه دکمه پاپ اپ', 'bakala'),
                'required' => array('checkout_popup', '=', 1),
                'validate' => 'color',
                'default' => '#35363d',
            ),
            array(
                'id' => 'checkout_popup_btn_color',
                'type' => 'color',
                'title' => __('رنگ متن دکمه پاپ اپ', 'bakala'),
                'required' => array('checkout_popup', '=', 1),
                'validate' => 'color',
                'default' => '#ffffff',
            ),
            array(
                'id' => 'checkout_popup_close_bg',
                'type' => 'color',
                'title' => __('رنگ پس زمینه بستن پاپ اپ', 'bakala'),
                'required' => array('checkout_popup', '=', 1),
                'validate' => 'color',
                'default' => 'darkred',
            ),
            array(
                'id' => 'checkout_popup_close_color',
                'type' => 'color',
                'title' => __('رنگ متن بستن پاپ اپ', 'bakala'),
                'required' => array('checkout_popup', '=', 1),
                'validate' => 'color',
                'default' => '#ffffff',
            ),
        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('خبرنامه پیامکی', 'bakala'),
        'id' => 'sms_newsletter',
        'subsection' => true,
        'icon' => 'dashicons dashicons-email-alt',

        'fields' => array(
            array(
                'id' => 'sms_newsletter_enable',
                'type' => 'switch',
                'title' => 'فعالسازی خبرنامه پیامکی',
                'subtitle' => __('برای استفاده از این امکان، ابتدا از تنظیمات عمومی/پنل پیامکی را تنظیم کنید.', 'bakala'),
                'description' => __('شورت کد: [bakala_newsletter]', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),

        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('Blog', 'bakala'),
        'id' => 'blog_section',
        'icon' => 'dashicons dashicons-welcome-write-blog',
        'fields' => array(
            array(
                'id' => 'reading_time',
                'type' => 'switch',
                'title' => __('زمان مطالعه پست', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'share_post',
                'type' => 'switch',
                'title' => __('اشتراک گذاری', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'post_thumbnail',
                'type' => 'switch',
                'title' => __('نمایش تصویر شاخص', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'post_layout',
                'type' => 'image_select',
                'title' => __('چیدمان پست', 'bakala'),
                'subtitle' => __('تعیین کنید که چیدمان نوشته تکی چگونه باشد.', 'bakala'),
                // 'desc'     => __('This is the description field, again good for additional info.', 'bakala'),
                'options' => array(
                    'none' => array(
                        'alt' => 'بدون سایدبار',
                        'img' => get_template_directory_uri() . '/vendor/images/none.png',
                    ),
                    'left' => array(
                        'alt' => 'سایدبار سمت چپ',
                        'img' => get_template_directory_uri() . '/vendor/images/left.png',
                    ),
                    'right' => array(
                        'alt' => 'سایدبار سمت راست',
                        'img' => get_template_directory_uri() . '/vendor/images/right.png',
                    ),
                ),
                'default' => 'left',
            ),

        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('Social', 'bakala'),
        'id' => 'social_section',
        'icon' => 'dashicons dashicons-share',
        'fields' => array(
            array(
                'id' => 'social_title',
                'type' => 'text',
                'title' => __('Social Media Title', 'bakala'),
                'subtitle' => __('Insert your social media title', 'bakala'),
            ),
            array(
                'id' => 'facebook',
                'type' => 'text',
                'title' => __('Facebook', 'bakala'),
                'subtitle' => __('Insert your facebook link', 'bakala'),
            ),
            array(
                'id' => 'twitter',
                'type' => 'text',
                'title' => __('Twitter', 'bakala'),
                'subtitle' => __('Insert your twitter link', 'bakala'),
            ),
            array(
                'id' => 'googleplus',
                'type' => 'text',
                'title' => __('Google Plus', 'bakala'),
                'subtitle' => __('Insert your googleplus link', 'bakala'),
            ),
            array(
                'id' => 'instagram',
                'type' => 'text',
                'title' => __('Instagram', 'bakala'),
                'subtitle' => __('Insert your instagram link', 'bakala'),
            ),
            array(
                'id' => 'youtube',
                'type' => 'text',
                'title' => __('Aparat', 'bakala'),
                'subtitle' => __('Insert your aparat link', 'bakala'),
            ),
            array(
                'id' => 'vimeo',
                'type' => 'text',
                'title' => __('Telegram', 'bakala'),
                'subtitle' => __('Insert your telegram link', 'bakala'),
            ),
            array(
                'id' => 'other_socials',
                'type' => 'slides',
                'title' => __('شبکه های اجتماعی دیگر', 'bakala'),
                'subtitle' => __('شبکه های اجتماعی دیگری که در موارد فوق وجود ندارد را بصورت سفارشی اضافه کنید.', 'bakala'),

            ),
            array(
                'id' => 'show-apps',
                'type' => 'switch',
                'title' => __('نمایش نوار اپ در فوتر', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'app_title',
                'type' => 'text',
                'title' => __('عنوان دلخواه نوار اپلیکیشن', 'bakala'),
                'subtitle' => __('عنوان دلخواه نوار اپلیکیشن خود را وارد کنید', 'bakala'),
                'required' => array('show-apps', '=', 1),
            ),
            array(
                'id' => 'app_img',
                'type' => 'media',
                'title' => __('تصویر اپلیکیشن', 'bakala'),
                'default' => array('url' => get_template_directory_uri() . '/vendor/images/appicon.png'),
                'required' => array('show-apps', '=', 1),
            ),
            array(
                'id' => 'vine',
                'type' => 'text',
                'title' => __('Ios App link', 'bakala'),
                'subtitle' => __('Insert your appstore app link', 'bakala'),
                'required' => array('show-apps', '=', 1),
            ),
            array(
                'id' => 'soundcloud',
                'type' => 'text',
                'title' => __('Android App', 'bakala'),
                'subtitle' => __('Insert your cafebazar link', 'bakala'),
                'required' => array('show-apps', '=', 1),
            ),
            array(
                'id' => 'google_play',
                'type' => 'text',
                'title' => __('Google play App', 'bakala'),
                'subtitle' => __('Insert your googleplay link', 'bakala'),
                'required' => array('show-apps', '=', 1),
            ),
            array(
                'id' => 'myket',
                'type' => 'text',
                'title' => __('Myket App', 'bakala'),
                'subtitle' => __('Insert your Myket link', 'bakala'),
                'required' => array('show-apps', '=', 1),
            ),
        )
    ));


    if (class_exists('WeDevs_Dokan')) {

        Redux::set_section($opt_name, array(
            'title' => __('Dokan', 'bakala'),
            'id' => 'dokan_section',
            'icon' => 'dashicons dashicons-store',
            'fields' => array(
                array(
                    'id' => 'single_vendor',
                    'type' => 'switch',
                    'title' => __('Display Vendor Information', 'bakala'),
                    'subtitle' => __('Enable to show vendor information on single product page.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'external_products',
                    'type' => 'switch',
                    'title' => __('External products', 'bakala'),
                    'subtitle' => __('Allow vendors to create external products.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'cart_vendor',
                    'type' => 'switch',
                    'title' => __('Display Vendor Name In Cart', 'bakala'),
                    'subtitle' => __('Enable to show vendor name on cart page for each product.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'dokan_product_features',
                    'type' => 'switch',
                    'title' => __('Display Product Features Section For Vendors', 'bakala'),
                    'subtitle' => __('Enable to show product main features section for vendors on submit products.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
                array(
                    'id' => 'dokan_order_map',
                    'type' => 'switch',
                    'title' => __('Display Customer Location On Map For Vendor', 'bakala'),
                    'subtitle' => __('Enable to show customer location on map for vendors on order details page.', 'bakala'),
                    'default' => 0,
                    'on' => __('Enable', 'bakala'),
                    'off' => __('Disable', 'bakala'),
                ),
            )
        ));
    }
    Redux::set_section($opt_name, array(
        'title' => __('برچسب ها', 'bakala'),
        'id' => 'labels',
        'subsection' => false,
        'icon' => 'dashicons dashicons-format-quote',
        'fields' => array(
            array(
                'id' => 'info_warning_labels',
                'type' => 'info',
                //'title' => esc_html__('اخطار!', 'bakala'),
                'style' => 'warning',
                'desc' => esc_html__('این متن ها با متن پوسته جایگزین خواهند شد. اگر خالی رها شوند، متن پیشفرض نمایش داده خواهد شد.', 'bakala'),
            ),
            array(
                'id' => 'lr-label',
                'type' => 'text',
                'placeholder' => __("ورود / ثبت نام", "bakala"),
            ),

            array(
                'id' => 'profile-label',
                'type' => 'text',
                'placeholder' => __("پروفایل", "bakala"),
            ),
            array(
                'id' => 'logout-label',
                'type' => 'text',
                'placeholder' => __("خروج از حساب کاربری", "bakala"),
            ),
            array(
                'id' => 'show-cart-label',
                'type' => 'text',
                'placeholder' => __("مشاهده سبد خرید", "bakala"),
            ),
            array(
                'id' => 'add-cart-label',
                'type' => 'text',
                'placeholder' => __("افزودن به سبد خرید", "bakala"),
            ),
            array(
                'id' => 'viewed-label',
                'type' => 'text',
                'placeholder' => __("کالاهایی که دیده اید", "bakala"),
            ),
            array(
                'id' => 'related-label',
                'type' => 'text',
                'placeholder' => __("محصولات مرتبط", "bakala"),
            ),
            array(
                'id' => 'cart-label',
                'type' => 'text',
                'placeholder' => __("سبد خرید", "bakala"),
            ),
            array(
                'id' => 'continue-buy-label',
                'type' => 'text',
                'placeholder' => __("ادامه خرید", "bakala"),
            ),
            array(
                'id' => 'support-label',
                'type' => 'text',
                'placeholder' => __("پشتیبانی", "bakala"),
            ),
            array(
                'id' => 'tel-label',
                'type' => 'text',
                'placeholder' => __("تلفنی", "bakala"),
            ),
        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('Custom JS/CSS', 'bakala'),
        'id' => 'jscss_section',
        'icon' => 'dashicons dashicons-media-code',
        'fields' => array(
            array(
                'id' => 'custom_js',
                'type' => 'ace_editor',
                'title' => __('Custom JS', 'bakala'),
                'mode' => 'javascript',
                'subtitle' => __('Add some custom JavaScript to your theme by adding it to this textarea.', 'bakala'),
            ),
            array(
                'id' => 'custom_css',
                'type' => 'ace_editor',
                'mode' => 'css',
                'title' => __('Custom CSS', 'bakala'),
                'subtitle' => __('Add some custom CSS to your theme by adding it to this textarea.', 'bakala'),
            ),
            array(
                'title' => esc_html__('Custom CSS for mobile', 'bakala'),
                'subtitle' => esc_html__('Paste your custom CSS code for mobile here.', 'bakala'),
                'id' => 'custom_css_mobile',
                'type' => 'ace_editor',
                'mode' => 'css',
            ),
            array(
                'id' => 'tracking_code',
                'type' => 'ace_editor',
                'mode' => 'javascript',
                'title' => __('Tracking Code', 'bakala'),
                'subtitle' => __('Paste Google Analytics (or other) tracking code here with script tag.', 'bakala'),
            ),
            array(
                'id' => 'google_tags',
                'type' => 'textarea',
                'title' => __('Google tags', 'bakala'),
                'desc' => __('Put your codes here', 'bakala'),
            ),
        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('بهینه سازی', 'bakala'),
        'id' => 'performance',
        'icon' => 'dashicons dashicons-performance',
        'fields' => array(
            array(
                'id' => 'remove_google_fonts',
                'type' => 'switch',
                'title' => __('حذف فونت های گوگل', 'bakala'),
                'subtitle' => __('اگر از فونت های گوگل استفاده میکنید این گزینه را غیرفعال کنید.', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),

            array(
                'id' => 'remove_jquery_migrate',
                'type' => 'switch',
                'title' => __('حذف jquery migrate', 'bakala'),
                'subtitle' => __('اگر مشکلی در ظاهر سایت به وجود آمد این گزینه را غیرفعال کنید.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'preload_fonts',
                'type' => 'switch',
                'title' => __('پیش بارگذاری فونت های قالب', 'bakala'),
                'subtitle' => __('فعالسازی این گزینه میتواند به سرعت لود سایت و سئو کمک کند.', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),

            array(
                'id' => 'preload_fonts_info',
                'type' => 'info',
                'title' => esc_html__('اخطار!', 'bakala'),
                'style' => 'critical',
                'icon' => 'el-icon-info-sign',
                'desc' => 'به منظور عملکرد صحیح، از پیش بارگذاری فونت های قالب در افزونه های کش خودداری کنید',
                'required' => array('preload_fonts', '=', 1),
            ),
            array(
                'id' => 'remove_fontawesome',
                'type' => 'switch',
                'title' => __('حذف فونت اوسام', 'bakala'),
                'subtitle' => __('اگر از فونت اوسام در سایت استفاده نمیکنید این گزینه را فعال کنید.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'remove_shop_page',
                'type' => 'switch',
                'title' => __('حذف برگه فروشگاه (/shop)', 'bakala'),
                'subtitle' => __('با حذف این برگه بار سرور کاهش می یابد و سایت عملکرد بهتری خواهد داشت.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'shop_page_redirect',
                'title' => __('ادرس ریدایرکت برگه فروشگاه', 'bakala'),
                'subtitle' => __('آدرس ریدایرکت را بصورت کامل وارد کنید که پس از حذف فروشگاه به این ادرس ریدایرکت شود.', 'bakala'),
                'type' => 'text',
                'required' => array('remove_shop_page', '=', 1),
            ),
        )
    ));
    Redux::set_section($opt_name, array(
        'title' => __('دیگر تنظیمات', 'bakala'),
        'id' => 'others',
        'icon' => 'dashicons dashicons-admin-generic',
        'fields' => array(
            array(
                'id' => 'classic_widgets',
                'type' => 'switch',
                'title' => __('بازگشت به ابزارک های قدیمی', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه، ابزارک های وردپرس به ابزارک کلاسیک تبدیل میشوند', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'admin_style_plus',
                'type' => 'switch',
                'title' => __('تغییر ظاهر داشبورد وردپرس', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه، ظاهر داشبورد وردپرس به ظاهر نوین تغییر میکند.', 'bakala'),
                'default' => 1,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),

            array(
                'id' => 'skeleton_loader_pc',
                'type' => 'switch',
                'title' => __('اسکلت لودر دسکتاپ', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه نوعی پیش بارگذاری به المان ها بجز صفحه محصول در دسکتاپ اضافه می شود.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'skeleton_loader_mobile',
                'type' => 'switch',
                'title' => __('اسکلت لودر موبایل', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه نوعی پیش بارگذاری به المان ها بجز صفحه محصول در موبایل اضافه می شود.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'skeleton_loader_product_pc',
                'type' => 'switch',
                'title' => __('اسکلت لودر محصول دسکتاپ', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه نوعی پیش بارگذاری به المان های صفحه محصول در دسکتاپ اضافه می شود.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),
            array(
                'id' => 'skeleton_loader_product_mobile',
                'type' => 'switch',
                'title' => __('اسکلت لودر محصول موبایل', 'bakala'),
                'subtitle' => __('با فعالسازی این گزینه نوعی پیش بارگذاری به المان های صفحه محصول در موبایل اضافه می شود.', 'bakala'),
                'default' => 0,
                'on' => __('Enable', 'bakala'),
                'off' => __('Disable', 'bakala'),
            ),

        )
    ));
    Redux::setSection( $opt_name, array(
        'title'  => 'کش Cache',
        'id'     => 'cache_section',
        'icon' => 'dashicons dashicons-dashboard', 
        'desc'   => 'مدیریت کش قالب و پاکسازی خودکار کش WP Rocket.',
        'fields' => array(
            array(
                'id'       => 'clear_template_cache_button',
                'type'     => 'raw',
                'content'  => '<form method="post"><button name="clear_template_cache" class="button button-primary">پاک کردن کش قالب</button></form>',
            ),
            array(
                'id'       => 'auto_clear_wp_rocket_cache',
                'type'     => 'switch',
                'title'    => 'پاکسازی خودکار کش راکت',
                'subtitle' => 'هنگام اعمال تغییرات در سایت، کش WP Rocket به صورت خودکار پاک خواهد شد.',
                'default'  => false, // به صورت پیش‌فرض غیرفعال
                'on'       => 'فعال',
                'off'      => 'غیرفعال',
            ),
            
        ),
    ) );

Redux::set_section( $opt_name, [
		'title'  => __( 'درون‌ریزی دموها', 'bakala' ),
		'id'     => 'demo_importer',
		'desc'   => __(
			'<p class="desc-demo-importer">لطفاً قبل از درون‌ریزی دمو، مطمئن شوید که:<br>
        ۱. مقدار <code>memory_limit</code> حداقل ۲۵۶ مگابایت باشد.<br>
        ۲. مقدار <code>max_execution_time</code> حداقل ۳۰۰ باشد.<br>
        ۳. مقدار <code>post_max_size</code> حداقل ۶۴ مگابایت باشد.<br>
        ۴. مقدار <code>upload_max_filesize</code> حداقل ۶۴ مگابایت باشد.<br><br>
        با کلیک بر روی دکمه "درون‌ریزی"، محتوای دمو انتخابی بارگیری و تنظیم می‌شود.</p>',
			'bakala'
		),
		'icon'   => 'el el-download-alt',
		'fields' => [
			[
				'id'      => 'demo_import_content',
				'type'    => 'raw',
				'content' => bakala_generate_demo_importer_html(),
			],
		],
	] );

endif;
/*
 * <--- END SECTIONS
 */
