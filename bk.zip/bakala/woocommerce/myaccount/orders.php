<?php
/**
 * Orders
 *
 * Shows orders on the account page.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/orders.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 9.5.0
 */
 
global $bakala_options;

if($bakala_options['myaccount_orders_type']=='old-new'){
    require_once 'orders-old.php';
    require_once 'orders-new.php';
}elseif($bakala_options['myaccount_orders_type']=='new'){
    require_once 'orders-new.php';
}else{
    require_once 'orders-old.php';
}