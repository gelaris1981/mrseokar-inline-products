<?php

/**
 * My Account Dashboard
 *
 * Shows the first intro screen on the account dashboard.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/dashboard.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @author      WooThemes
 * @package     WooCommerce/Templates
 * @version 100.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

$wishlist = get_user_meta($current_user->ID, 'bakala_wishlist', true);
$firstname = get_user_meta($current_user->ID, 'first_name', true);
$lastname = get_user_meta($current_user->ID, 'last_name', true);
if ($firstname && $lastname) {
    $user_name = $firstname . ' ' . $lastname;
} else {
    $user_name = $current_user->display_name;
}
$user_email = $current_user->user_email;
$user_register = strtotime($current_user->user_registered);
//$user_mobile = get_user_meta ( $current_user->ID, 'billing_mobile', true ) ? get_user_meta ( $current_user->ID, 'billing_mobile', true ) : '--' ;
$user_mobile = get_the_author_meta('digits_phone_no', $current_user->ID) ? esc_attr(get_the_author_meta('digits_phone_no', $current_user->ID)) : '--';
$user_phone = get_user_meta($current_user->ID, 'billing_phone', true) ? get_user_meta($current_user->ID, 'billing_phone', true) : '--';
$user_state = get_user_meta($current_user->ID, 'billing_state', true) ? get_user_meta($current_user->ID, 'billing_state', true) : '--';
$user_city = get_user_meta($current_user->ID, 'billing_city', true) ? get_user_meta($current_user->ID, 'billing_city', true) : '--';
$user_address = get_user_meta($current_user->ID, 'billing_address_1', true) ? get_user_meta($current_user->ID, 'billing_address_1', true) : '--';
$user_postcode = get_user_meta($current_user->ID, 'billing_postcode', true) ? get_user_meta($current_user->ID, 'billing_postcode', true) : '--';


$processing_orders = wc_get_orders(array('status' => array('wc-processing'), 'customer_id' => $current_user->ID));
$completed_orders = wc_get_orders(array('status' => array('wc-completed'), 'customer_id' => $current_user->ID));
$cancelled_orders = wc_get_orders(array('status' => array('wc-cancelled'), 'customer_id' => $current_user->ID));

$viewed_products_count;

$bakala_national_code = get_user_meta(get_current_user_id(), 'bakala_national_code', true);

?>
<?php if(empty($bakala_national_code)): ?>
<div class="identity-alert profile-section">
    <div class="identity-alert-wrap profile-section__header">
        <div class="identity-alert-text">
            <i class="fas fa-info-circle"></i>
            <span><?= __('To increase the security of your account and prevent abuse, please confirm your identity','bakala') ?></span>
        </div>
        <div class="identity-alert-more profile-section__more">
            <a class="identity-alert-link" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . 'edit-account/'; ?>"><span><?= __('identity confirmation','bakala') ?></span>
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
    </div>
</div>
<?php endif; ?>
<div class="my-orders-summary profile-section">
    <div class="my-orders-summary__header profile-section__header">
        <div class="my-orders-summary__title profile-section__title">
            <div>
                <p><?= __('My orders','bakala') ?></p>
            </div>
            <div class="title-border"></div>
        </div>
        <span class="my-orders-summary__more profile-section__more">
            <a class="my-orders-link" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . 'orders/'; ?>"><span><?= __('view all','bakala') ?></span>
                <i class="fa fa-chevron-left"></i>
            </a>
        </span>
    </div>
    <div class="my-orders-summary__main">
        <a class="my-orders-summary__status processing" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . 'orders/#processing'; ?>">
            <div class="order-status-icon">
                <img src="<?= get_template_directory_uri() . '/vendor/images/order-processing.png'; ?>" alt="order-processing">
            </div>
            <div class="order-status-info">
                <div class="order-status-count"><?= $processing_orders ? count($processing_orders) : '0'; ?> <?= __('order','bakala') ?></div>
                <span class="order-status-name"><?= __('Current','bakala') ?></span>
            </div>
        </a>
        <a class="my-orders-summary__status completed" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . 'orders/#completed'; ?>">
            <div class="order-status-icon">
                <img src="<?= get_template_directory_uri() . '/vendor/images/order-completed.png'; ?>" alt="order-processing">
            </div>
            <div class="order-status-info">
                <div class="order-status-count"><?= $completed_orders ? count($completed_orders) : '0'; ?> <?= __('order','bakala') ?></div>
                <span class="order-status-name"><?= __('Delivered','bakala') ?></span>
            </div>
        </a>
        <a class="my-orders-summary__status cancelled" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . 'orders/#cancelled'; ?>">
            <div class="order-status-icon">
                <img src="<?= get_template_directory_uri() . '/vendor/images/order-cancelled.png'; ?>" alt="order-processing">
            </div>
            <div class="order-status-info">
                <div class="order-status-count"><?= $cancelled_orders ? count($cancelled_orders) : '0'; ?> <?= __('order','bakala') ?></div>
                <span class="order-status-name"><?= __('Canceled','bakala') ?></span>
            </div>
        </a>
    </div>
</div>
<div class="my-wishlist profile-section">
    <div class="my-wishlist__header profile-section__header">
        <div class="my-wishlist__title profile-section__title">
            <div>
                <p><?= __('from your lists','bakala') ?></p>
            </div>
            <div class="title-border"></div>
        </div>
        <span class="my-wishlist__more profile-section__more">
            <a class="my-wishlist-link" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . 'your-wishlist/'; ?>"><span><?= __('view all','bakala') ?></span>
                <i class="fa fa-chevron-left"></i>
            </a>
        </span>
    </div>
    <div class="my-orders-summary__main">
        <div class="pro_carousel" id="myaccount-wishlist">
            <?php
            if ($wishlist) {
                foreach ($wishlist as $product_id) :
                    $_product = wc_get_product($product_id);
                    if ($_product) { ?>
                        <div class="item type-product">
                            <a href="<?php echo get_permalink($product_id); ?>">
                                <?php
                                $thumb = get_the_post_thumbnail($product_id, 'thumbnail');
                                if ($thumb) {
                                    echo $thumb;
                                } else {
                                    echo wc_placeholder_img();
                                }
                                ?>
                                <h3 class="wishlist-product-title"><?= get_the_title($product_id) ?></h3>
                            </a>
                            <div class="detail">
                                <div class="price">
                                    <?php
                                    $stockamount = $_product->get_stock_quantity();
                                    if ($stockamount !== 0) {
                                        echo $_product->get_price_html();
                                    } else {
                                        echo  __('unavailable','bakala');
                                    }
                                    ?>
                                </div>



                            </div>

                        </div>
            <?php
                    }
                endforeach;
            }
            ?>
        </div>
    </div>
</div>
<div class="my-viewed-products profile-section">
    <div class="my-viewed-products__header profile-section__header">
        <div class="my-viewed-products__title profile-section__title">
            <div>
                <p><?= __('Recently viewed products','bakala') ?></p>
            </div>
            <div class="title-border"></div>
        </div>
        <span class="my-viewed-products__more profile-section__more">
            <a class="my-viewed-products-link" href="<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . 'your-viewed-products/'; ?>"><span><?= __('مشاهده همه','bakala') ?></span>
                <i class="fa fa-chevron-left"></i>
            </a>
        </span>
    </div>
    <div class="my-viewed-products__main">
        <div class="pro_carousel" id="myaccount-viewed-products">
            <?php
            ob_start();
            global $bakala_options;
            $viewed_products = (!empty($_COOKIE['woocommerce_recently_viewed']) ? (array) explode('|', $_COOKIE['woocommerce_recently_viewed']) : array());
            $viewed_products = array_reverse(array_filter(array_map('absint', $viewed_products)));

            $viewed_products_count .= count($viewed_products);
            if (!empty($viewed_products)) {
                $query_args = array('post_status' => 'publish', 'post_type' => 'product', 'post__in' => $viewed_products, 'orderby' => 'post__in');
                $viewed = new WP_Query($query_args);
                if ($viewed->have_posts()) {

                    while ($viewed->have_posts()) :
                        $viewed->the_post();
                        $product_id = $viewed->ID;
                        $product = wc_get_product(get_the_ID());
            ?>
                        <div class="item type-product">
                            <a href="<?php echo get_permalink($product_id); ?>">
                                <?php
                                $thumb = get_the_post_thumbnail($product_id, 'thumbnail');
                                if ($thumb) {
                                    echo $thumb;
                                } else {
                                    echo wc_placeholder_img();
                                }
                                ?>
                                <h3 class="viewed-products-product-title"><?= get_the_title($product_id) ?></h3>
                            </a>
                            <div class="detail">
                                <div class="price">
                                    <?php
                                    echo $product->get_price_html();
                                    ?>
                                </div>


                            </div>
                        </div>
            <?php

                    endwhile;
                }
            }
            wp_reset_postdata();
            ?>
        </div>

    </div>
</div>
<?php
/**
 * My Account dashboard.
 *
 * @since 2.6.0
 */
do_action('woocommerce_account_dashboard');

/**
 * Deprecated woocommerce_before_my_account action.
 *
 * @deprecated 2.6.0
 */
do_action('woocommerce_before_my_account');

/**
 * Deprecated woocommerce_after_my_account action.
 *
 * @deprecated 2.6.0
 */
do_action('woocommerce_after_my_account');

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */

add_action('wp_footer', function () {
    ob_start();


    $current_user_id = get_current_user_id();
    $wishlist = get_user_meta($current_user_id, 'bakala_wishlist', true);
    if($wishlist){
        $wishlist_count = count($wishlist) <= 4 ? count($wishlist) : '4';
    ?>
        <script>
            jQuery("document").ready(function($) {
                $('#myaccount-wishlist').slick({
                    dots: false,
                    infinite: true,
                    autoplay: true,
                    arrows: true,
                    speed: 300,
                    autoplaySpeed: 7000,
                    slidesToShow: '<?= $wishlist_count ?>',
                    slidesToScroll: '<?= $wishlist_count ?>',
                    rtl: <?php echo is_rtl() ? json_encode(true) : json_encode(false); ?>,
                    pauseOnFocus: false,
                    prevArrow: '<button type="button" class="owl-prev"> < </button>',
                    nextArrow: '<button type="button" class="owl-next"> > </button>',
                    responsive: [{
                            breakpoint: 1024,
                            settings: {
                                slidesToShow: 3,
                                slidesToScroll: 3,
                                infinite: true,
                                dots: true
                            }
                        },
                        {
                            breakpoint: 600,
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 2
                            }
                        },
                        {
                            breakpoint: 480,
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 2
                            }
                        }
                    ]
                });
                
            });
        </script>
    <?php
    }
    $viewed_products = (!empty($_COOKIE['woocommerce_recently_viewed']) ? (array) explode('|', $_COOKIE['woocommerce_recently_viewed']) : array());
    $viewed_products = array_reverse(array_filter(array_map('absint', $viewed_products)));
    if($viewed_products){
        $viewed_products_count = count($viewed_products);
    ?>
        <script>
            jQuery("document").ready(function($) {
                $('#myaccount-viewed-products').slick({
                    dots: false,
                    infinite: true,
                    autoplay: true,
                    arrows: true,
                    speed: 300,
                    autoplaySpeed: 7000,
                    slidesToShow: '<?= $viewed_products_count ?>',
                    slidesToScroll: '<?= $viewed_products_count ?>',
                    rtl: <?php echo is_rtl() ? json_encode(true) : json_encode(false); ?>,
                    pauseOnFocus: false,
                    prevArrow: '<button type="button" class="owl-prev"> < </button>',
                    nextArrow: '<button type="button" class="owl-next"> > </button>',
                    responsive: [{
                            breakpoint: 1024,
                            settings: {
                                slidesToShow: 3,
                                slidesToScroll: 3,
                                infinite: true,
                                dots: false
                            }
                        },
                        {
                            breakpoint: 600,
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 2
                            }
                        },
                        {
                            breakpoint: 480,
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 2
                            }
                        }
                    ]
                });
            });
        </script>
    <?php
    }
});