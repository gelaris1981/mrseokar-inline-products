<?php

/**
 * Orders
 *
 * Shows orders on the account page.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/orders.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 100.0.0
 */
 
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_account_orders', $has_orders ); ?>

<?php
// Fetch all order statuses for current user using wc_get_orders
$current_user_id = get_current_user_id();

// واکشی وضعیت‌های یکتا با استفاده از wc_get_orders
$order_statuses = [];
$query_args = [
    'customer_id' => $current_user_id,
    'limit'       => -1, // بدون محدودیت
    'return'      => 'ids', // فقط شناسه‌ها
];

$orders = wc_get_orders($query_args);

// گروه‌بندی وضعیت‌ها
if (!empty($orders)) {
    foreach ($orders as $order_id) {
        $order = wc_get_order($order_id);
        $status = $order->get_status();
        $status_cleaned = str_replace('wc-', '', $status);
        $order_statuses[$status_cleaned] = wc_get_order_status_name('wc-' . $status);
    }
}

// شمارش سفارش‌ها برای هر وضعیت
$status_counts = [];
foreach (array_keys($order_statuses) as $status_slug) {
    $count_args = [
        'customer_id' => $current_user_id,
        'status'      => 'wc-' . $status_slug,
        'return'      => 'ids',
    ];
    $status_counts[$status_slug] = count(wc_get_orders($count_args));
}
?>

<?php if (!empty($order_statuses)) : ?>
<div class="container">
<div class="head" style="margin-bottom:2em;">
        <h2 class="title"><i class="icon icon-caret-left-blue"></i><?php _e('Your Orders', 'bakala') ?></h2>
    </div>
	<!-- Dynamic Tabs -->
	<ul class="nav nav-tabs" id="ordersTab" role="tablist">
		<?php
        $active = true;
        foreach ($order_statuses as $status_slug => $status_name) {
            $count_query = $status_counts[$status_slug];
            ?>
            <li class="nav-item">
                <button class="nav-link <?php echo $active ? 'active' : ''; ?>" id="<?php echo esc_attr($status_slug); ?>-tab" data-bs-toggle="tab" data-bs-target="#<?php echo esc_attr($status_slug); ?>" type="button" role="tab" aria-controls="<?php echo esc_attr($status_slug); ?>" aria-selected="<?php echo $active ? 'true' : 'false'; ?>">
                    <?php echo esc_html($status_name); ?>
                    <span class="order-count"><?= $count_query ?></span>
                            <div class="tab-border"></div>
                </button>
            </li>
            <?php
            $active = false;
        }
        ?>
	</ul>

	<!-- Tab Content -->
	<div class="tab-content bakala-orders" id="myTabContent">
		<?php
		$active = true;
		foreach ($order_statuses as $status_slug => $status_name) :
			?>
			<div class="tab-pane fade <?php echo $active ? 'show active' : ''; ?>" id="<?php echo esc_attr($status_slug); ?>" role="tabpanel" aria-labelledby="<?php echo esc_attr($status_slug); ?>-tab">
				<div id="<?php echo esc_attr($status_slug); ?>-orders" class="orders">
					<!-- Orders will be loaded here via AJAX -->
				</div>
			</div>
			<?php
			$active = false;
		endforeach;
		?>
	</div>
</div>

<script>
jQuery(document).ready(function ($) {
    function loadOrders(status, page = 1) {
        $('.lr-loader').show();
        $.ajax({
            url: '/bakala/ajax/load_orders', // استفاده از روت جدید
            type: 'GET',
            data: {
                status: status,
                page: page,
            },
            success: function (response) {
                $('.lr-loader').hide();
                $('#' + status + '-orders').html(response);

                // مدیریت کلیک روی دکمه‌های صفحه‌بندی
                $('#' + status + '-orders').find('.pagination-btn').on('click', function () {
                    var newPage = $(this).data('page');
                    loadOrders(status, newPage);
                });
            },
            error: function () {
                $('#loader').hide();
                alert('خطایی در لود سفارش‌ها رخ داده است.');
            },
        });
    }

    // Load initial content
    $('.nav-link.active').each(function () {
        var status = $(this).attr('id').replace('-tab', '');
        loadOrders(status);
    });

    // Handle tab click
    $('.nav-link').on('click', function () {
        var status = $(this).attr('id').replace('-tab', '');
        loadOrders(status);
    });
});


</script>

<?php else : ?>
	<div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info">
		<a class="woocommerce-Button button" href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>">
			<?php _e('Go shop', 'woocommerce'); ?>
		</a>
		<?php _e('No order has been made yet.', 'woocommerce'); ?>
	</div>
<?php endif; ?>

<?php do_action('woocommerce_after_account_orders', $has_orders); ?>

