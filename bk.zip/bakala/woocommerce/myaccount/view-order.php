<?php

/**
 * View Order
 *
 * Shows the details of a particular order on the account page.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/view-order.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 100.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}
global $bakala_options;
$order_status = $order->get_status();
$status1 = empty($bakala_options['track_orders_status_1']) ? array() : $bakala_options['track_orders_status_1'];
$status2 = empty($bakala_options['track_orders_status_2']) ? array() : $bakala_options['track_orders_status_2'];
$status3 = empty($bakala_options['track_orders_status_3']) ? array() : $bakala_options['track_orders_status_3'];
$status4 = empty($bakala_options['track_orders_status_4']) ? array() : $bakala_options['track_orders_status_4'];
$status5 = empty($bakala_options['track_orders_status_5']) ? array() : $bakala_options['track_orders_status_5'];

$tracking_code = get_post_meta($order->get_id(), '_tracking_code', true) ? get_post_meta($order->get_id(), '_tracking_code', true) : '';
            $tracking_delivery_date = get_post_meta($order->get_id(), '_tracking_delivery_date', true) ? get_post_meta($order->get_id(), '_tracking_delivery_date', true) : '';
            $tracking_form = get_post_meta($order->get_id(), '_tracking_form', true) ? get_post_meta($order->get_id(), '_tracking_form', true) : 0;
            if ($tracking_form == 'post') {
                $tracking_name = 'پست پیشتاز';
            } elseif ($tracking_form == 'tipax') {
                $tracking_name = 'تیپاکس';
            }elseif ($tracking_form == 'chapar') {
                $tracking_name = 'چاپار';
            }elseif ($tracking_form == 'kalaresan') {
                $tracking_name = 'کالا رسان';
            }elseif ($tracking_form == 'mahex') {
                $tracking_name = 'ماهکس';
            } else {
                $tracking_name = '';
            }
            if ($tracking_form == 'post') {
                $tracking_url = 'https://tracking.post.ir/?id=' . $tracking_code;
            } elseif ($tracking_form == 'tipax') {
                $tracking_url = 'https://tipaxco.com/?id=' . $tracking_code;
            } elseif ($tracking_form == 'chapar') {
                $tracking_url = 'https://chaparnet.com/track/';
            } elseif ($tracking_form == 'kalaresan') {
                $tracking_url = 'https://kalaresan.ir/tracking.php';
            } elseif ($tracking_form == 'ماهکس') {
                $tracking_url = 'https://mahex.com/tracking/';
            } else {
                $tracking_name = '';
            }
?>

<p class="order-info box noback <?php if ($order->has_status('failed') || $order->has_status('cancelled')) {
                                    echo 'red';
                                } else {
                                    echo 'green';
                                } ?>" style="text-align:center;padding:20px;margin-bottom:2em;"><?php
                                                                                                /* translators: 1: order number 2: order date 3: order status */
                                                                                                printf(
                                                                                                    __('Order #%1$s was placed on %2$s and is currently %3$s.', 'woocommerce'),
                                                                                                    '<mark class="order-number">' . $order->get_order_number() . '</mark>',
                                                                                                    '<mark class="order-date">' . wc_format_datetime($order->get_date_created()) . '</mark>',
                                                                                                    '<mark class="order-status">' . wc_get_order_status_name($order->get_status()) . '</mark>'
                                                                                                );
                                                                                                ?></p>
<?php if ($order_status != 'cancelled') { ?>
    <ol class="bakala_progresss" data-stepss="3">
        <li class="<?= $order_status == 'on-hold' || $order_status == 'box' || $order_status == 'completed' ? 'dones' : null; ?> <?= $order_status == 'processing' || in_array('wc-' . $order_status, $status1) ? 'actives' : null; ?>">
            <span class="names "><?= __('In progress', 'bakala') ?></span>
            <span class="steps">
                <?php if ($order_status == 'processing' || in_array('wc-' . $order_status, $status1)) { ?>
                    <span class="bakala_borderi"></span>
                    <div class="bakala_tooltioop">
                        <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/recive.png' ?>">
                        <span style="visibility: visible" class="bakala_tooltiooptextstatus"><?= __('Receive order on', 'bakala') ?><mark style=" background: none;font-weight: 600;color: #f9af08;"><?= wc_format_datetime($order->get_date_created()); ?> </mark></span>
                    </div>
                <?php } else {
                ?>
                    <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/recive.png' ?>"></span>
                <?php
                } ?>
            </span>
        </li>
        <li class="<?= $order_status == 'box' || $order_status == 'completed' ? 'dones' : null; ?> <?= $order_status == 'on-hold' || in_array('wc-' . $order_status, $status2) ? 'actives' : null; ?>">
            <span class="names"><?= __('Under review', 'bakala') ?></span>
            <span class="steps">
                <?php if ($order_status == 'on-hold' || in_array('wc-' . $order_status, $status2)) { ?>
                    <span class="bakala_borderi"></span>
                    <div class="bakala_tooltioop">
                        <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/onhold.png' ?>">
                        <span style="visibility: visible" class="bakala_tooltiooptextbox"><?= __('Your order on', 'bakala') ?><mark style=" background: none;font-weight: 600;color: #f9af08;"><?= $order->get_date_modified; ?> </mark> در وضعیت در انتظار بررسی قرار گرفت</span>
                    </div>
                <?php } else {
                ?>
                    <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/onhold.png' ?>"></span>
                <?php
                } ?>
            </span>
        </li>
        <li class="<?= $order_status == 'completed' ? 'dones' : null; ?> <?= $order_status == 'box' || in_array('wc-' . $order_status, $status3) ? 'actives' : null; ?>">
            <span class="names"><?= __('Packaging', 'bakala') ?></span>
            <span class="steps">
                <?php if ($order_status == 'box' || in_array('wc-' . $order_status, $status3)) { ?>
                    <span class="bakala_borderi"></span>
                    <div class="bakala_tooltioop">
                        <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/packing.png' ?>">
                        <span style="visibility: visible" class="bakala_tooltiooptextbox"><?= __('Your order on', 'bakala') ?><mark style=" background: none;font-weight: 600;color: #f9af08;"><time datetime="?= date_i18n(get_option('date_format'), strtotime($order->modified_date)); ?>"><?= date_i18n(get_option('date_format'), strtotime($order->modified_date)); ?></time> </mark> در وضعیت بسته بندی قرار گرفت</span>
                    </div>
                <?php } else {
                ?>
                    <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/packing.png' ?>"></span>
                <?php
                } ?>
            </span>

        </li>
        <li class="<?= $order_status == 'delivered' ? 'dones' : null; ?> <?= $order_status == 'completed' || in_array('wc-' . $order_status, $status4) ? 'actives' : null; ?>">
            <span class="names "><?= __('Completed', 'bakala') ?></span>
            <span class="steps">
                <?php if ($order_status == 'completed' || in_array('wc-' . $order_status, $status4)) { ?>
                    <span class="bakala_borderi"></span>
                    <div class="bakala_tooltioop">
                        <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/order-tracking-finished.png' ?>">
<span style="visibility: visible" class="bakala_tooltiooptextbox">
    <?= __('Order number', 'bakala') ?> <?= $order->ID ?>
    <?php if($tracking_code){ ?>
        <?= __('with tracking code', 'bakala') ?>
        <mark style="background: none; font-weight: 600; color: #f9af08;">
            <a id="tracking-code" href="<?= $tracking_url ?>"><?= $tracking_code ?></a>
        </mark>
    <?php } ?>
    <?= __('was shipped by', 'bakala') ?> <?= $tracking_name ?> <?= __('on', 'bakala') ?> <?= $tracking_send_date ?>.
</span>
                    </div>
                <?php } else {
                ?>
                    <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/order-tracking-finished.png' ?>"></span>
                <?php
                } ?>
            </span>
        </li>
        <?php if ($bakala_options['enable_delivered_order_status'] == 1) { ?>
            <li class="<?= $order_status == 'delivered' || in_array('wc-' . $order_status, $status5) ? 'actives' : null; ?>">
                <span class="names "><?= __('Delivered', 'bakala') ?></span>
                <span class="steps">
                    <?php if ($order_status == 'delivered' || in_array('wc-' . $order_status, $status5)) { ?>
                        <span class="bakala_borderi"></span>
                        <div class="bakala_tooltioop">
                            <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/deliver.png' ?>">
<span style="visibility: visible" class="bakala_tooltiooptextdeliver">
    <?= __('Order number', 'bakala') ?> <?= $order->ID ?> <?= __('was delivered on', 'bakala') ?> <?= $tracking_delivery_date ?> 
    <?= __('with tracking code', 'bakala') ?> 
    <mark style="background: none; font-weight: 600; color: #f9af08;">
        <a id="tracking-code" href="<?= $tracking_url ?>"><?= $tracking_code ?></a>
    </mark> <?= __('to the customer.', 'bakala') ?>
</span>
                        </div>

                    <?php } else {
                    ?>
                        <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/deliver.png' ?>"></span>
                    <?php
                    } ?>
                </span>
            </li>
        <?php } ?>
    </ol>
<?php } ?>
<?php if ($notes = $order->get_customer_order_notes()) : ?>
    <div class="head">
        <h2 class="title"><i class="icon icon-caret-left-blue"></i><?php _e('Order updates', 'woocommerce'); ?></h2>
    </div>

    <div class="order_receipt box noback" style="padding:20px;">
        <table>
            <thead>
                <tr>
                    <td class="first" style="padding:5px;width:50px;"><?php _e('#Num', 'bakala'); ?></td>
                    <td><?php _e('Description', 'bakala'); ?></td>
                    <td class="last"><?php _e('Date', 'bakala'); ?></td>
                </tr>
            </thead>
            <tbody>
                <?php $n = 1;
                foreach ($notes as $note) {  ?>
                    <tr>
                        <td style="font-size:12px;padding:5px;"><?php echo $n; ?></td>
                        <td style="font-size:12px;padding:5px;"><?php echo wpautop(wptexturize($note->comment_content)); ?></td>
                        <td style="font-size:12px;padding:5px;"><?php echo date_i18n(__('l j F Y, h:i a', 'woocommerce'), strtotime($note->comment_date)); ?></td>
                    </tr>
                <?php $n++;
                } ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>

<?php do_action('woocommerce_view_order', $order_id); ?>

<?php
$tracking_code = get_post_meta($order->get_id(), '_tracking_code', true) ? get_post_meta($order->get_id(), '_tracking_code', true) : '';
            $tracking_delivery_date = get_post_meta($order->get_id(), '_tracking_delivery_date', true) ? get_post_meta($order->get_id(), '_tracking_delivery_date', true) : '';
            $tracking_form = get_post_meta($order->get_id(), '_tracking_form', true) ? get_post_meta($order->get_id(), '_tracking_form', true) : 0;
            if ($tracking_form == 'post') {
                $tracking_name = 'پست پیشتاز';
            } elseif ($tracking_form == 'tipax') {
                $tracking_name = 'تیپاکس';
            }elseif ($tracking_form == 'chapar') {
                $tracking_name = 'چاپار';
            }elseif ($tracking_form == 'kalaresan') {
                $tracking_name = 'کالا رسان';
            }elseif ($tracking_form == 'mahex') {
                $tracking_name = 'ماهکس';
            } else {
                $tracking_name = '';
            }
            if ($tracking_form == 'post') {
                $tracking_url = 'https://tracking.post.ir/?id=' . $tracking_code;
            } elseif ($tracking_form == 'tipax') {
                $tracking_url = 'https://tipaxco.com/?id=' . $tracking_code;
            } elseif ($tracking_form == 'chapar') {
                $tracking_url = 'https://chaparnet.com/track/';
            } elseif ($tracking_form == 'kalaresan') {
                $tracking_url = 'https://kalaresan.ir/tracking.php';
            } elseif ($tracking_form == 'ماهکس') {
                $tracking_url = 'https://mahex.com/tracking/';
            } else {
                $tracking_name = '';
            }
if ($order->get_meta('_tracking_code') && $bakala_options['post_tracking_code'] == 1) {
    $tracking_code = $order->get_meta('_tracking_code');
    $tracking_link = $order->get_meta('_tracking_form') == 'post' ? "https://tracking.post.ir/?id=$tracking_code" : "https://tipaxco.com/tracking";
?>
    <div class="bakala-tracking-order">
        <div class="align-items-baseline bakala-tracking-title d-flex">
            <i class="icon icon-caret-left-blue"></i>
            <h2><?= __('کد رهگیری ', 'bakala').$tracking_name; ?></h2>
        </div>
        <div class="bakala-tracking-code">
            <a href="<?= $tracking_url ?>"><?= $tracking_code ?></a>
        </div>
    </div>
<?php }


?>