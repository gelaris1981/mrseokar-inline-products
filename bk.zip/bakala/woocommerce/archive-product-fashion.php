<?php
global $bakala_options;
do_action('woocommerce_before_main_content');
if (isset($bakala_options['side_width']) && $bakala_options['side_width'] == 'big') {
    $side_width = 3;
    $shop_width = 9;
} else {
    $side_width = 2;
    $shop_width = 10;
}

if (is_mobile_or_tablet()) {
    ?>
    <?php if ($bakala_options['category_panel_type']) : ?>
        <div class="archive-product-sticky fixed-bottom">
            <div class="open-category-panel">
                <div class="panel-icon-holder clearfix">
                    <i class="icon icon-orderby"></i> <?php _e('Orderby', 'bakala'); ?>
                </div>
            </div>
            <div class="open-filter-panel">
                <div class="panel-icon-holder clearfix">
                    <i class="icon icon-filter"></i> <?php _e('Filter', 'bakala'); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="category-panel">
        <div class="panel-title">
            <?php _e('Orderby', 'bakala'); ?>
            <i class="icon close-icon close_category_panels"></i>
        </div>

        <div class="matrix-category-content">
            <?php
            do_action('bakala_sortby_section');
            ?>
        </div>
    </div>
    <div class="shop-page" style="margin-top: -5px;">
        <div class="<?php if (is_active_sidebar('shop-sidebar')) {
            echo 'col-md-9';
        } ?> <?php echo $class; ?>">
            <div class="archive-list-view">
                <?php
                remove_action('woocommerce_before_shop_loop', 'wc_print_notices', 10);
                remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
                remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);
                ?>
            </div>
            <?php if ($bakala_options['category_panel_type'] == '0') : ?>
                <div class="archive-product-sticky fixed-top">
                    <div class="open-category-panel">
                        <div class="panel-icon-holder clearfix">
                            <i class="icon icon-orderby"></i> <?php _e('Orderby', 'bakala'); ?>
                        </div>
                    </div>
                    <div class="open-filter-panel">
                        <div class="panel-icon-holder clearfix">
                            <i class="icon icon-filter"></i> <?php _e('Filter', 'bakala'); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="archive-list-products">
                <div class="content-box-shop">

                    <?php if (have_posts()) {

                    /**
                     * Hook: woocommerce_before_shop_loop.
                     *
                     * @hooked wc_print_notices - 10
                     * @hooked woocommerce_result_count - 20
                     * @hooked woocommerce_catalog_ordering - 30
                     */
                    remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
                    do_action('woocommerce_before_shop_loop'); ?>

                    <div class="products-box <?php if ((isset($_COOKIE['type_view']) && $_COOKIE['type_view'] == 'listing') || (!isset($_COOKIE['type_view']) && $bakala_options['archive_style'] == 'listing')) echo 'listing'; ?>">
                        <?php
                        woocommerce_product_loop_start();
                        $bakala_query_vars = true;
                        if (wc_get_loop_prop('total')) {


                            while (have_posts()) {
                                the_post();

                                /**
                                 * Hook: woocommerce_shop_loop.
                                 *
                                 * @hooked WC_Structured_Data::generate_product_data() - 10
                                 */
                                do_action('woocommerce_shop_loop');

                                wc_get_template_part('content', 'product');

                            }
                        }

                        woocommerce_product_loop_end();

                        /**
                         * Hook: woocommerce_after_shop_loop.
                         *
                         * @hooked woocommerce_pagination - 10
                         */
                        do_action('woocommerce_after_shop_loop');
                        } else {
                            /**
                             * Hook: woocommerce_no_products_found.
                             *
                             * @hooked wc_no_products_found - 10
                             */
                            do_action('woocommerce_no_products_found');
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if (is_active_sidebar('shop-sidebar')) { ?>
        <div class="filters-panel">
        <div class="panel-title">
            <?php single_cat_title(); ?>

            <i class="icon close-icon close_filter_panels"></i>
        </div>
        <?php
        dynamic_sidebar('shop-sidebar');

        echo "<div class='matrix-widget-footer'>
            <div class='matrix-widget-available'>
                
                <a href='" . home_url($wp->request) . "' id=\"reset-filtering\" class=\"action-reset\">" . __('Remove all', 'bakala') . "</a>
                <div class=\"available\">
                <a href='" . $url . "' class=\"instock_product_filter" . (!empty(get_query_var('oinstock')) ? ' checked' : '') . "\">" . __("Only instock products", "bakala") . "</a>
                </div>
            </div>
            <a class='matrix-widget-apply-filter'>" . __('Filter', 'bakala') . "</a></div>";
        echo "</div>";
    }
    ?>
    </div>

    </div>
<?php } else { ?>
    <h1 id="plp-title"><?= get_queried_object()->name; ?></h1>
    <div class="shop-page row">
        <?php if (is_active_sidebar('shop-sidebar')) { ?>

            <div class="col-md-<?php echo $side_width; ?> filters-panel">
                <?php echo do_shortcode('[wcas-search-form]'); ?>
                <?php dynamic_sidebar('shop-sidebar'); ?>
            </div>
        <?php } ?>


        <div class="position-relative <?php if (is_active_sidebar('shop-sidebar')) {
            echo 'col-md-' . $shop_width;
        } ?> <?php echo $class; ?>">

            <div class="content-box-shop">

                <?php if (have_posts()) {

                /**
                 * Hook: woocommerce_before_shop_loop.
                 *
                 * @hooked wc_print_notices - 10
                 * @hooked woocommerce_result_count - 20
                 * @hooked woocommerce_catalog_ordering - 30
                 */
                remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
                do_action('woocommerce_before_shop_loop'); ?>

                <div class="products-box <?php if ((isset($_COOKIE['type_view']) && $_COOKIE['type_view'] == 'listing') || (!isset($_COOKIE['type_view']) && $bakala_options['archive_style'] == 'listing')) echo 'listing'; ?>">
                    <?php
                    woocommerce_product_loop_start();
                    $bakala_query_vars = true;
                    if (wc_get_loop_prop('total')) {


                        while (have_posts()) {
                            the_post();

                            /**
                             * Hook: woocommerce_shop_loop.
                             *
                             * @hooked WC_Structured_Data::generate_product_data() - 10
                             */
                            do_action('woocommerce_shop_loop');

                            wc_get_template_part('content', 'product');

                        }
                    }

                    woocommerce_product_loop_end();

                    /**
                     * Hook: woocommerce_after_shop_loop.
                     *
                     * @hooked woocommerce_pagination - 10
                     */
                    do_action('woocommerce_after_shop_loop');
                    } else {
                        /**
                         * Hook: woocommerce_no_products_found.
                         *
                         * @hooked wc_no_products_found - 10
                         */
                        do_action('woocommerce_no_products_found');
                    }
                    ?>
                </div>
            </div>
        </div>

        <div class="woocommerce-products-header">
            <?php
            /**
             * woocommerce_archive_description hook.
             *
             * @hooked woocommerce_taxonomy_archive_description - 10
             * @hooked woocommerce_product_archive_description - 10
             */
            do_action('woocommerce_archive_description');
            ?>
        </div>
    </div>
<?php } ?>