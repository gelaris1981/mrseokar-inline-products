<?php

/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see        https://docs.woocommerce.com/document/template-structure/
 * @author        WooThemes
 * @package    WooCommerce/Templates
 * @version 100.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

get_header('shop');
global $bakala_options, $wp;
$category_id = get_queried_object_id();
$term_vals = get_term_meta($category_id);

$cat_display = !empty($term_vals['display_type']) ? $term_vals['display_type'] : ['both'];
$default_display_type = get_option('woocommerce_category_archive_display', 'default');
    
if (is_product_category() && ($cat_display[0] === 'both' || $cat_display[0] === 'subcategories' || $default_display_type === 'both' || $default_display_type === 'subcategories') && $bakala_options['subcategories_type'] == 1) {
    ?>
    <div class="bakala-main bakala-main-category" id="bakala-category-<?= $category_id ?>">
        <div class="container-fluid">
            <div class="row bakala-row">
                <div class="bakala-category-title"><?= __('products categorization', 'bakala') ?></div>
                <div class="col-12 bakala-col-row" id="bakala-col-row-<?= $category_id ?>">
                    <?php
                    
                    $term = get_queried_object();
                    $term_id = $term->term_id ? $term->term_id : 0;
                    $children = get_terms($term->taxonomy, array(
                        'parent' => $term->term_id,
                        'hide_empty' => false
                    ));
                    if (count($children) > 0) {
                        $child_ids = $children;
                        // Loop through WP_Term Objects
                        $id = 0;
                        foreach ($children as $child) {
                            
                            $id++;
                            if ($term_id != $child->term_id) {
                                $thumbnail_id = get_term_meta($child->term_id, 'thumbnail_id', true);
                                if ($thumbnail_id) {
                                    $image = wp_get_attachment_image($thumbnail_id, array('60', '60'));
                                } else {
                                    $src = $bakala_options['product_placeholder']['url'];
                                    $image = '<img src="' . $src . '">';
                                }
                                $link =get_term_link($child->term_id, 'product_cat');
                                ?>
                                <a class="field-category"
                                   href="<?= !is_wp_error($link) && is_string($link) ? $link : ''; ?>"
                                   id="<?= $category_id ?>-ms-bakala-category-<?= $id ?>">
                                    <div class="bakala-category-img">
                                        <?= $image ?>
                                    </div>
                                    <div class="bakala-category-title">
                                        <h5><?= $child->name ?></h5>
                                        <?php
                                        if ($child->count > 0 && $bakala_options['show_category_count'] == 1) {
                                            echo '<span class="bakala-category-count">(' . esc_html($child->count) . ')</span>';
                                        }
                                        ?>
                                    </div>
                                </a>
                                <?php
                            }
                        }
                    } ?>
                    <a class="field-category" id="field-category-more-<?= $category_id ?>" href="#">
                        <div class="field-category-title" id="field-category-title-<?= $category_id ?>">
                            <h5>۱۷+</h5>
                        </div>
                        <div class="field-category-num">
                            <p><?= __('Other categories', 'bakala') ?></p>
                        </div>
                    </a>
                    <script type="text/javascript">
                        (function ($) {
                            let countCategory = $("#bakala-col-row-<?= $category_id ?> a").length;
                            let i;
                            let arrayID = [];
                            let IDWidgetCat = "#<?= $category_id ?>-ms-bakala-category-";

                            if (countCategory > 8) {
                                for (i = 8; i < countCategory; i++) {
                                    $(IDWidgetCat + i).hide();
                                    arrayID.push(i);
                                    mobile();
                                }

                                $("#field-category-title-<?= $category_id ?> h5").text(arrayID.length + "+");

                                $("#field-category-more-<?= $category_id ?>").on("click", function (e) {
                                    e.preventDefault();
                                    arrayID.forEach(catID);
                                    $(this).toggle();
                                });
                            } else {
                                $("#field-category-more-<?= $category_id ?>").hide();
                            }

                            function catID(item) {
                                $(IDWidgetCat + item).fadeToggle(1000);
                            }

                            function mobile() {
                                const mql = window.matchMedia('screen and (max-width: 768px)');

                                function checkMedia(mql) {
                                    if (mql.matches) {
                                        $(IDWidgetCat + i).show();
                                        $("#field-category-more-<?= $category_id ?>").hide();
                                    }
                                }

                                checkMedia(mql);
                                mql.addListener(checkMedia);
                            }


                        })(jQuery)
                    </script>
                </div>
            </div>
        </div>
    </div>
    <?php
}

$class = '';
if (is_tax()) {
    if ($bakala_options['offer_menu_cat'] && get_queried_object()->term_id == $bakala_options['offer_menu_cat']) {
        echo '<div class="wonderful_offer_archive"><div class="container"> <span>' . __('Special Offers', 'bakala') . '</span></div></div>';
        $class = "special-offer-archive";
    }
}

/**
 * Hook: woocommerce_before_main_content.
 *
 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
 * @hooked woocommerce_breadcrumb - 20
 * @hooked WC_Structured_Data::generate_website_data() - 30
 */
do_action('woocommerce_before_main_content');
if($bakala_options['archive_description_position']=='before'){
?>
<div class="woocommerce-products-header">
    <?php
    /**
     * woocommerce_archive_description hook.
     *
     * @hooked woocommerce_taxonomy_archive_description - 10
     * @hooked woocommerce_product_archive_description - 10
     */
    do_action('woocommerce_archive_description');
    ?>
</div>
        <?php
}
if (isset($bakala_options['side_width']) && $bakala_options['side_width'] == 'big') {
    $side_width = 3;
    $shop_width = 9;
} else {
    $side_width = 2;
    $shop_width = 10;
}

if (is_mobile_or_tablet()) {
    ?>
    <?php if ($bakala_options['category_panel_type']): ?>
        <div class="archive-product-sticky fixed-bottom">
            <div class="open-category-panel">
                <div class="panel-icon-holder clearfix">
                    <i class="icon icon-orderby"></i> <?php _e('Orderby', 'bakala'); ?>
                </div>
            </div>
            <div class="open-filter-panel">
                <div class="panel-icon-holder clearfix">
                    <i class="icon icon-filter"></i> <?php _e('Filter', 'bakala'); ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="category-panel">
        <div class="panel-title">
            <?php _e('Orderby', 'bakala'); ?>
            <i class="icon close-icon close_category_panels"></i>
        </div>

        <div class="matrix-category-content">
            <?php
            do_action('bakala_sortby_section');
            ?>
        </div>
    </div>
    <div class="shop-page">
        <div class="<?php if (is_active_sidebar('shop-sidebar')) {
            echo 'col-md-9';
        } ?> <?php echo $class; ?>">
            <div class="archive-list-view">
                <div class="archive-list-view-main-label clearfix">
                    <span>
                        <?php if (apply_filters('woocommerce_show_page_title', true)) : ?>
                            <?php woocommerce_page_title(); ?>
                        <?php endif; ?>
                    </span>
                </div>

                <?php
                remove_action('woocommerce_before_shop_loop', 'wc_print_notices', 10);
                remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
                remove_action('woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30);
                do_action('woocommerce_before_shop_loop');
                ?>
            </div>
            <?php if ($bakala_options['category_panel_type'] == '0'): ?>
                <div class="archive-product-sticky fixed-top">
                    <div class="open-category-panel">
                        <div class="panel-icon-holder clearfix">
                            <i class="icon icon-orderby"></i> <?php _e('Orderby', 'bakala'); ?>
                        </div>
                    </div>
                    <div class="open-filter-panel">
                        <div class="panel-icon-holder clearfix">
                            <i class="icon icon-filter"></i> <?php _e('Filter', 'bakala'); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="archive-list-products <?php if ((isset($_COOKIE['type_view']) && $_COOKIE['type_view'] == 'listing') || (!isset($_COOKIE['type_view']) && $bakala_options['archive_style'] == 'listing')) echo 'listing'; ?>">

                <?php do_action('bakala_breadcrumb'); ?>
                <div class="products-box <?= !empty($bakala_options['pagination_type']) ? $bakala_options['pagination_type'] : null ?>">
                    <?php if (have_posts()) {

                        woocommerce_product_loop_start();

                        if (wc_get_loop_prop('total')) {
                            while (have_posts()) {
                                the_post();

                                /**
                                 * Hook: woocommerce_shop_loop.
                                 *
                                 * @hooked WC_Structured_Data::generate_product_data() - 10
                                 */
                                do_action('woocommerce_shop_loop');

                                wc_get_template_part('content', 'product');
                            }
                        }

                        woocommerce_product_loop_end();

                        /**
                         * Hook: woocommerce_after_shop_loop.
                         *
                         * @hooked woocommerce_pagination - 10
                         */
                        do_action('woocommerce_after_shop_loop');
                    } else {
                        /**
                         * Hook: woocommerce_no_products_found.
                         *
                         * @hooked wc_no_products_found - 10
                         */
                        do_action('woocommerce_no_products_found');
                    } ?>
                </div>
                <?php if($bakala_options['archive_description_position']!='before'){ ?>

                <div class="woocommerce-products-header">
                    <?php
                    /**
                     * woocommerce_archive_description hook.
                     *
                     * @hooked woocommerce_taxonomy_archive_description - 10
                     * @hooked woocommerce_product_archive_description - 10
                     */
                    do_action('woocommerce_archive_description');
                    ?>
                </div>
                <?php } ?>
            </div>
        </div>

        <?php if (is_active_sidebar('shop-sidebar')) { ?>
        <div class="filters-panel">
            <div class="panel-title">
                <?php single_cat_title(); ?>

                <i class="icon close-icon close_filter_panels"></i>
            </div>
            <?php
            dynamic_sidebar('shop-sidebar');

            echo "<div class='matrix-widget-footer'>
            <div class='matrix-widget-available'>
                
                <a href='" . home_url($wp->request) . "/' id=\"reset-filtering\" class=\"action-reset\">" . __('Remove all', 'bakala') . "</a>
                <div class=\"available\">
                <a href='?oinstock=true' class=\"instock_product_filter" . (!empty(get_query_var('oinstock')) ? ' checked' : '') . "\">" . __("Only instock products", "bakala") . "</a>
                </div>
            </div>
            <a class='matrix-widget-apply-filter'>" . __('Filter', 'bakala') . "</a></div>";
            echo "</div>";
            }
            ?>
        </div>

    </div>
    <?php
} else {
    ?>
    <div class="shop-page row">
        <?php if (is_active_sidebar('shop-sidebar')) { ?>
            <div class="col-md-<?php echo $side_width; ?> filters-panel">
                <?php dynamic_sidebar('shop-sidebar'); ?>
            </div>
        <?php } ?>


        <div class="position-relative <?php if (is_active_sidebar('shop-sidebar')) {
            echo 'col-md-' . $shop_width;
        } ?> <?php echo $class; ?>">
            <?php do_action('bakala_breadcrumb'); ?>
            <p class="woocommerce-result-count">
                <span class="options__meta">
                    <?php
                    global $wp_query;
                    $paged = max(1, $wp_query->get('paged'));
                    $per_page = $wp_query->get('posts_per_page');
                    $total = $wp_query->found_posts;
                    $first = ($per_page * $paged) - $per_page + 1;
                    $last = min($total, $wp_query->get('posts_per_page') * $paged); ?>
                    <span class="options__product-numbers--txt"><?php echo _e('Display ', 'bakala'); ?></span>
                    <span class="options__product-numbers--txt first"><?php echo($first); ?></span>
                    <span class="options__product-numbers--txt"> - </span>
                    <span class="options__product-numbers--txt last"><?php echo($last); ?></span>
                    <span class="options__product-numbers--txt"><?php echo _e(' Product Of ', 'bakala'); ?></span>
                    <span class="options__product-numbers--txt total"><?php echo($total); ?></span>
                </span>
            </p>

            <div class="content-box-shop">

                <?php if (have_posts()) {

                /**
                 * Hook: woocommerce_before_shop_loop.
                 *
                 * @hooked wc_print_notices - 10
                 * @hooked woocommerce_result_count - 20
                 * @hooked woocommerce_catalog_ordering - 30
                 */
                remove_action('woocommerce_before_shop_loop', 'woocommerce_result_count', 20);
                do_action('woocommerce_before_shop_loop'); ?>

                <div class="products-box <?php if ((isset($_COOKIE['type_view']) && $_COOKIE['type_view'] == 'listing') || (!isset($_COOKIE['type_view']) && $bakala_options['archive_style'] == 'listing')) echo 'listing'; ?> <?= !empty($bakala_options['pagination_type']) ? $bakala_options['pagination_type'] : null ?>">
                    <?php
                    woocommerce_product_loop_start();
                    $bakala_query_vars = true;
                    if (wc_get_loop_prop('total')) {


                        while (have_posts()) {
                            the_post();

                            /**
                             * Hook: woocommerce_shop_loop.
                             *
                             * @hooked WC_Structured_Data::generate_product_data() - 10
                             */
                            do_action('woocommerce_shop_loop');

                            wc_get_template_part('content', 'product');
                        }
                    }

                    woocommerce_product_loop_end();
                    
                    

                    /**
                     * Hook: woocommerce_after_shop_loop.
                     *
                     * @hooked woocommerce_pagination - 10
                     */
                    do_action('woocommerce_after_shop_loop');
                    } else {
                        /**
                         * Hook: woocommerce_no_products_found.
                         *
                         * @hooked wc_no_products_found - 10
                         */
                        do_action('woocommerce_no_products_found');
                    }
                    ?>
                </div>
            </div>
        </div>
<?php if($bakala_options['archive_description_position']!='before'){ ?>
        <div class="woocommerce-products-header">
            <?php
            /**
             * woocommerce_archive_description hook.
             *
             * @hooked woocommerce_taxonomy_archive_description - 10
             * @hooked woocommerce_product_archive_description - 10
             */
            do_action('woocommerce_archive_description');
            ?>
        </div>
        <?php } ?>
    </div>
    <?php
}

/**
 * Hook: woocommerce_after_main_content.
 *
 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
 */
do_action('woocommerce_after_main_content');
if (!is_mobile_or_tablet()) {
    /**
     * Hook: woocommerce_sidebar.
     *
     * @hooked woocommerce_get_sidebar - 10
     */
    do_action('woocommerce_sidebar');
}

get_footer('shop');