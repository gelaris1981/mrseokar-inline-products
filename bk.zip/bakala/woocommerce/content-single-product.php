<?php

/**
 * The template for displaying product content in the single-product.php template
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/content-single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see        https://docs.woocommerce.com/document/template-structure/
 * @author        WooThemes
 * @package    WooCommerce/Templates
 * @version 100.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

global $product, $post, $bakala_options;
$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average = $product->get_average_rating();
$comments = get_comments(array(
    'post_id' => $product->get_id(),
    'status' => 'approve', // Only approved comments
    'number' => 1, // Limit to 1 comment
));

if (!empty($comments)) {
    // There is at least one comment for the product
    $first_comment = $comments[0];
    $first_comment_rating = get_comment_meta($first_comment->comment_ID, 'comment_rates', true);
    if (!empty($first_comment_rating)) {
        // Display the rating of the first comment if available
        $average = array_sum($first_comment_rating) / count($first_comment_rating);
    }
}
$mainfea = get_post_meta($product->get_id(), 'main_features', true);
$short_desc = apply_filters('woocommerce_short_description', $post->post_excerpt);

if (is_mobile_or_tablet()) {

    $cart_count = bakala_get_cart_count();

    echo "";

    if (post_password_required()) {
        echo get_the_password_form();
        return NULL;
    }
    echo "" . '<div id="product-';
    the_ID();
    echo '" ';
    post_class();
    echo '>' . "";

    do_action('woocommerce_before_single_product');
    echo '<div class="p-section-one">' . ""; ?>
    <div class="single-pro">

        <?php
        if ($bakala_options['modern_header_mobile'] == 0 && isset($bakala_options['modern_header_mobile']) && $bakala_options['gallery_style_mobile'] != 'two') {
        ?>
            <ul class="product-tooltips">
                <li class="bakala-tooltip">
                    <span class="bakala-tooltiptext"><?php echo __('Add to wishlist', 'bakala'); ?></span>
                    <?php if (!is_user_logged_in()) {
                        if ($bakala_options['popup_login'] == true) :
                            if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                <span class="addtowishlist"><?php echo do_shortcode('[dm-login-modal]'); ?></span>
                            <?php } else { ?>
                                <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login" class="addtowishlist">
                                    <i class="bakala-icon icon-love"></i>
                                </a>
                            <?php }
                        else : ?>
                            <a class="addtowishlist"
                                href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"><i
                                    class="bakala-icon icon-love"></i></a>
                        <?php endif;
                    } else {
                        $wishlist = get_user_meta($current_user->ID, 'bakala_wishlist', true);
                        if (is_array($wishlist) && in_array($product->get_id(), $wishlist)) {
                            $active = ' active';
                        } else {
                            $active = '';
                        } ?>
                        <a data-product-id="<?php echo $product->get_id() ?>"
                            class="addtowishlist bakala-wishlist<?php echo $active; ?>"><i
                                class="bakala-icon icon-love"></i></a>
                    <?php
                    } ?>
                </li>
                <?php if (isset($bakala_options['show_share']) && $bakala_options['show_share']) { ?>
                    <li class="bakala-tooltip">
                        <span class="bakala-tooltiptext"><?php echo __('Share', 'bakala'); ?></span>
                        <a data-bs-toggle="modal" data-bs-target="#bakala_sharebtn" id="ProductSocialShareForm"><i
                                class="bakala-icon icon-share"></i></a>
                    </li>
                <?php } ?>

                <?php if (isset($bakala_options['show_white_catnotify']) && $bakala_options['show_white_catnotify'] && !$product->is_type('grouped')) {
                    $special_offer = is_special_offer(get_the_id());
                    if (!$special_offer || !$product->is_in_stock() || $product->get_price() == '') {
                        $stock_subscriber = check_user_stock_notify(get_the_id(), $current_user->ID);
                        $offer_subscriber = check_user_offer_notify(get_the_id(), $current_user->ID);
                        if ($stock_subscriber || $offer_subscriber) {
                            $is_subscriber = true;
                        } else {
                            $is_subscriber = false;
                        }
                ?>
                        <li class="bakala-tooltip">
                            <span class="bakala-tooltiptext"><?php echo __('Notify me', 'bakala'); ?></span>
                            <?php if (!is_user_logged_in()) {
                                if ($bakala_options['popup_login'] == true) :
                                    if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                        <span><?php echo do_shortcode('[dm-login-modal]'); ?><i
                                                class="bakala-icon icon-notif"></i></span>
                                    <?php } else { ?>
                                        <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login"><i
                                                class="bakala-icon icon-notif"></i></a>
                                    <?php }
                                else : ?>
                                    <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"><i
                                            class="bakala-icon icon-notif"></i></a>
                                <?php endif;
                            } else { ?>
                                <a href="" data-bs-toggle="modal" data-bs-target="#bakala_product_notify"
                                    class="<?php if ($is_subscriber) {
                                                echo 'done';
                                            } ?>"><i class="bakala-icon icon-notif"></i></a>
                            <?php } ?>
                        </li>
                    <?php }
                }
                $white_cat_compare = isset($bakala_options['white_catcompare']) ? $bakala_options['white_catcompare'] : false;
                $compare_page = isset($bakala_options['compare_page']) ? get_permalink($bakala_options['compare_page']) : false;
                if ($white_cat_compare && $compare_page) { ?>
                    <li class="bakala-tooltip">
                        <span class="bakala-tooltiptext"><?php echo __('Compare', 'bakala'); ?></span>
                        <div class="woocommerce product compare-button">
                            <a href="<?php echo $compare_page . '?products=' . get_the_id(); ?>" target="_blank"
                                rel="nofollow"><i class="bakala-icon icon-compare"></i></a>
                        </div>
                    </li>
                    <?php } else {
                    if (function_exists('yith_woocompare_premium_constructor')) { ?>
                        <li class="bakala-tooltip">
                            <span class="bakala-tooltiptext"><?php echo __('Compare', 'bakala'); ?></span>
                            <?php echo do_shortcode('[yith_compare_button]'); ?>
                        </li>
                <?php }
                } ?>
                <?php
                if (isset($bakala_options['show_price_change']) && $bakala_options['show_price_change']) {
                    $has_price_changes = get_post_meta(get_the_id(), 'has_price_changes', true);
                    if ($has_price_changes && $has_price_changes == 1) { ?>
                        <li class="bakala-tooltip">
                            <span class="bakala-tooltiptext"><?php echo __('Price change', 'bakala'); ?></span>
                            <a href="" data-bs-toggle="modal" data-bs-target="#bakala_price_change"><i
                                    class="bakala-icon icon-chart"></i></a>
                        </li>
                <?php }
                } ?>
                <?php
                $product_video_type = get_post_meta(get_the_id(), 'video_type', true);
                if ($product_video_type && $product_video_type != '') { ?>
                    <li class="bakala-tooltip icons">
                        <span class="bakala-tooltiptext"><?php echo __('Product video', 'bakala'); ?></span>
                        <a href="" data-bs-toggle="modal" data-bs-target="#modal-product-gallery"
                            class="modal-opener"><i class="bakala-icon icon-video"></i></a>
                    </li>
                <?php } ?>
            </ul>
        <?php }


        ?>
        <div class="product-gallery">
            <?php

            do_action('woocommerce_before_single_product_summary');
            ?>
        </div>
        <div class="product-det">
            <div class="col-md-12" style="overflow: hidden;">


                <div class="product-section">
                    <div class="info-header">
                        <?php do_action('woocommerce_single_product_before_title') ?>
                        <h1 class="product-title"><?php the_title(); ?></h1>
                        <span class="en-title"><?php echo get_post_meta($product->get_id(), 'product_english_name', true); ?></span>
                        <?php if ($bakala_options['short_desc_position'] == 'after_title'  && !empty($short_desc)) {
                            echo $short_desc;
                        }
                        ?>

                        <div class="product-sku-info d-flex">
                            <?php
                            if ($bakala_options['show_sku']) { ?>

                                <?php if (wc_product_sku_enabled() && ($product->get_sku()) || bakala_get_variations_skus($product->get_id())) : ?>
                                    <span class="sku_wrapper"><?php esc_html_e('SKU:', 'woocommerce'); ?> <span
                                            class="sku"><?php echo ($sku = $product->get_sku()) ? $sku : esc_html__('N/A', 'woocommerce'); ?></span></span>
                                <?php endif; ?>

                            <?php }
                            if ($average > 0) {
                                if ($rating_count > 0) {
                                    $count = $rating_count;
                                } elseif ($rating_count < 1 && !empty($comments)) {
                                    $count = get_comment_count($product->get_id())['approved'];
                                } else {
                                    $count = 0;
                                }
                                $comments = get_comments(array(
                                    'post_id' => get_the_ID(),
                                    'type'    => 'review',
                                ));

                                $comments_number = count($comments);
                            ?>
                                <div class="rate">
                                    <div class="stars">
                                        <img src="<?= get_template_directory_uri() . '/vendor/images/star-yellow.png' ?>">
                                        <span class="star-average"><?= $average > 0 ? round($average) : 5; ?></span>
                                        <span class="star-count"><?= "($count)"; ?></span>
                                    </div>
                                    <i class="fas fa-circle"></i>
                                    <div class="comments">
                                        <?= $comments_number . ' ' . __(' Comment ', 'bakala'); ?>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                        <?php
                        if ($bakala_options['show_category']) {

                            $prodterms = get_the_terms($post->id, 'product_cat');

                            if ($bakala_options['show_category'] && is_array($prodterms)) {

                                $term_ids = wp_list_pluck($prodterms, 'term_id');

                                $parents = array_filter(wp_list_pluck($prodterms, 'parent'));

                                $term_ids_not_parents = array_diff($term_ids, $parents);

                                $terms_not_parents = array_intersect_key($prodterms, $term_ids_not_parents);
                        ?>
                                <span class="posted_in">
                                    <?php
                                    if ($bakala_options['category_style'] == 'all') {
                                        foreach ($prodterms as $prodterm) {
                                    ?>
                                            <a href="<?= get_term_link($prodterm->term_id, 'product_cat'); ?>"><?= $prodterm->name; ?></a>
                                            <?php
                                            if (next($prodterms)) {
                                                echo '/';
                                            }
                                        }
                                    } elseif ($bakala_options['category_style'] == 'main') {
                                        if (is_plugin_active('wordpress-seo/wp-seo.php')) {
                                            $primary_cat_id = get_post_meta($product->get_id(), '_yoast_wpseo_primary_' . 'product_cat', true);
                                            if ($primary_cat_id) {
                                                $primary_cat = get_term($primary_cat_id, $taxonomy);
                                                if (isset($primary_cat->name)) {
                                            ?>
                                                    <a href="<?= get_term_link($primary_cat->term_id, 'product_cat'); ?>"><?= $primary_cat->name; ?></a>
                                                    <?php
                                                }
                                            } else {
                                                foreach ($prodterms as $prodterm) {
                                                    if ($prodterm->parent == 0) {
                                                    ?>
                                                        <a href="<?= get_term_link($prodterm->term_id, 'product_cat'); ?>"><?= $prodterm->name; ?></a>
                                                        <?php
                                                        if (next($prodterms)) {
                                                            echo '/';
                                                        }
                                                    }
                                                }
                                            }
                                        } elseif (is_plugin_active('seo-by-rank-math/rank-math.php')) {
                                            $primary_cat_id = get_post_meta($product->get_id(), 'rank_math_primary_product_cat', true);
                                            $has_primary_cat = false;

                                            if ($primary_cat_id) {
                                                $primary_cat = get_term($primary_cat_id, $taxonomy);
                                                if (isset($primary_cat->name)) {
                                                    $term_link = get_term_link($primary_cat->term_id, 'product_cat');
                                                    if (!is_wp_error($term_link)) {
                                                        $has_primary_cat = true;
                                                        ?>
                                                        <a href="<?= esc_url($term_link); ?>"><?= esc_html($primary_cat->name); ?></a>
                                                    <?php
                                                    }
                                                }
                                            }
                                            if (!$has_primary_cat) {
                                                bakala_display_category_hierarchy($sortedTerms);
                                            }
                                        } else {
                                            foreach ($prodterms as $prodterm) {
                                                if ($prodterm->parent == 0) {
                                                    ?>
                                                    <a href="<?= get_term_link($prodterm->term_id, 'product_cat'); ?>"><?= $prodterm->name; ?></a>
                                            <?php
                                                    if (next($prodterms)) {
                                                        echo '/';
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        foreach ($terms_not_parents as $term_not_parent) {
                                            ?>
                                            <a href="<?= get_term_link($term_not_parent->term_id, 'product_cat'); ?>"><?= $term_not_parent->name; ?></a>
                                <?php
                                            if (next($terms_not_parents)) {
                                                echo '/';
                                            }
                                        }
                                    }
                                }
                                ?>
                                </span>
                            <?php

                        }
                        do_action('bk_after_category_meta');
                            ?>

                            <?php if (isset($bakala_options['new_comment_template']) && $bakala_options['new_comment_template'] == true) {
                                $units_sold = $product->get_total_sales();
                                $comments = get_comments(array('post_id' => get_the_id(), 'status' => 'approve'));
                                $i = 0;
                                if ($comments) :
                                    foreach ($comments as $comment) {
                                        $recommendation = get_comment_meta($comment->comment_ID, 'recommendation', true);
                                        if ($recommendation == 'yes') $i++;
                                    }
                                endif;

                            ?>
                                <?php if ($i > 0 && $units_sold > 0 && $bakala_options['recomendation_product'] == 1) : ?>
                                    <div class="recomendation-product">
                                        <i class="bakala-icon tick"></i>
                                        <span><?php echo sprintf(__('%s (%d) Some buyers have suggested this product', 'bakala'), ceil($i / $units_sold * 100) . '%', $i); ?></span>
                                    </div>
                                <?php endif; ?>
                            <?php } else { ?>

                                <div class="white_catrating">
                                    <div class="disable-stars">
                                        <div style="width:<?php echo ($average / 5) * 100; ?>%" class="enable-stars"></div>
                                    </div>
                                    <div class="rating-count">
                                        <span><?php echo _e('Out Of ', 'bakala');
                                                echo $rating_count;
                                                echo _e(' Rate', 'bakala'); ?></span>
                                    </div>
                                </div>
                            <?php } ?>
                    </div>
                    <?php if (!empty(get_post_meta($product->get_id(), '_bakala_expiration_date', true))) { ?>
                        <div class="bakala_expire_date">
                            <span class="bakala_expire_date_title"><?= __('Expire Date', 'bakala') ?>:</span>
                            <span class="bakala_expire_date_val"><?= get_post_meta($product->get_id(), '_bakala_expiration_date', true); ?></span>
                        </div>
                    <?php } ?>
                    <?php if (!empty(get_post_meta($product->get_id(), '_bakala_manufacture_date', true))) { ?>
                        <div class="bakala_manufacture_date">
                            <span class="bakala_manufacture_date_title"><?= __('Manufacture Date', 'bakala') ?>:</span>
                            <span class="bakala_manufacture_date_val"><?= get_post_meta($product->get_id(), '_bakala_manufacture_date', true); ?></span>
                        </div>
                    <?php }
                    if (empty($mainfea) && isset($bakala_options['mainfea_auto']) && $bakala_options['mainfea_auto'] == 1) {
                        global $product;
                        $mainfea = [];

                        // دریافت ویژگی‌های محصول به عنوان یک آرایه
                        foreach ($product->get_attributes() as $attribute) {
                            $values = [];

                            // بررسی اینکه آیا ویژگی دارای اصطلاحات (terms) است
                            if ($attribute->is_taxonomy()) {
                                $terms = wc_get_product_terms($product->get_id(), $attribute->get_name(), ['fields' => 'names']);
                                $values = $terms;
                            } else {
                                // اگر ویژگی متن ساده است
                                $values = $attribute->get_options();
                            }

                            $mainfea[] = [
                                'title' => wc_attribute_label($attribute->get_name()), // نام ویژگی
                                'value' => implode(', ', $values), // مقادیر ویژگی
                            ];
                        }
                    }
                    if ($bakala_options['main_features_style_mobile'] == 'box' && $mainfea) {

                    ?>
                        <div class="bakala-product-specifications">
                            <div class="bakala-product-specifications-header">
                                <div class="bakala-product-specifications-title"><?= __('Product specifications', 'bakala') ?></div>
                                <div class="bakala-product-specifications-header-all" data-bs-toggle="modal" data-bs-target="#additional_info">
                                    مشاهده همه <i class="bakala-icon icon-left-arrow"></i>
                                </div>
                            </div>
                            <div class="bakala-product-specifications-wrap">
                                <ul class="bakala-product-specifications-list">
                                    <?php
                                    $i = 0;

                                    foreach ($mainfea as $singlefea) {
                                        $i = $i + 1;
                                        if ($i < 6) {
                                    ?>
                                            <li class="bakala-product-specification-item" data-bs-toggle="modal"
                                                data-bs-target="#additional_info">
                                                <div class="bakala-product-specification-item-wrap">
                                                    <p class="bakala-product-specification-item-label"><?= $singlefea['title'] ?></p>
                                                    <p class="bakala-product-specification-item-value"><?= $singlefea['value'] ?></p>
                                                </div>
                                            </li>

                                    <?php }
                                    } ?>

                                    <?php

                                    ?>
                                    <div class="bakala-product-specifications-all" data-bs-toggle="modal"
                                        data-bs-target="#additional_info">
                                        <?= __('view all', 'bakala') ?>
                                        <i class="bakala-icon icon-left-arrow"></i>
                                    </div>
                                </ul>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <?php
                remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_title', 5);
                remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10);
                remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20);
                remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
                remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_price');
                ?>
                <div class="product-section">

                    <?php do_action('woocommerce_single_product_summary');
                    $warranty = '';
                    if (isset($bakala_options['product_warranty_taxonomy']) && !$product->is_type('variable')) {
                        $warranty_taxonomy = $bakala_options['product_warranty_taxonomy'];
                        $warranty = $product->get_attribute($warranty_taxonomy);
                    }

                    if (!empty($warranty)) { ?>
                        <div class="warranty-info">
                            <span class="vendor-warranty">
                                <?php echo $warranty; ?>
                            </span>
                        </div>
                    <?php }
                    ?>

                </div>


                <div class="product-section">
                    <?php
                    if ($bakala_options['popup_desc'] == 0) {
                        echo $product->get_short_description();
                    }
                    ?>

                    <?php
                    if (function_exists('dokan_get_seller_rating')) :
                        $author_id = get_post_field('post_author', $product->get_id());
                        $store_info = dokan_get_store_info($author_id);
                    endif;
                    if (function_exists('dokan_get_seller_rating')) :
                        $dps_pt = get_user_meta($author_id, '_dps_pt', true);
                        $_processing_time = get_post_meta($product->get_id(), '_dps_processing_time', true);
                        $porduct_shipping_pt = ($_processing_time) ? $_processing_time : $dps_pt;

                        switch ($porduct_shipping_pt) {
                            case 1:
                                $shipping_time = __('1 work day', 'bakala');
                                break;
                            case 2:
                                $shipping_time = __('1 to 2 work day', 'bakala');
                                break;
                            case 3:
                                $shipping_time = __('1 to 3 work day', 'bakala');
                                break;
                            case 4:
                                $shipping_time = __('3 to 5 work day', 'bakala');
                                break;
                            case 5:
                                $shipping_time = __('1 to 2 work week', 'bakala');
                                break;
                            case 6:
                                $shipping_time = __('2 to 3 work week', 'bakala');
                                break;
                            case 7:
                                $shipping_time = __('3 to 4 work week', 'bakala');
                                break;
                            case 8:
                                $shipping_time = __('4 to 6 work week', 'bakala');
                                break;
                            case 9:
                                $shipping_time = __('6 to 8 work week', 'bakala');
                                break;
                            default:
                                $shipping_time = '';
                        }
                    ?>
                        <section class="bakala_seller_detail" style="width:100%">
                            <div class="bakala_seller_info bakala_seller_title">
                                <span class="bakala_seller_info_header"><?= _e('seller of goods', 'bakala') ?></span>
                                <img class="bakala_seller_info_avatar"
                                    src="<?php echo esc_url(get_avatar_url($author_id)); ?>" />
                                <span class="bakala_seller_info_content">
                                    <a target="blank"
                                        href="<?php echo dokan_get_store_url($author_id); ?>"><?php echo esc_html($store_info['store_name']); ?></a>
                                </span>
                            </div>
                            <div class="bakala_seller_info bakala_seller_rating">
                                <span class="bakala_seller_info_header"><?= _e('Purchase satisfaction', 'bakala') ?></span>
                                <span class="bakala_seller_info_icon"><i class="bakala-icon icon-rating"></i></span>
                                <span class="bakala_seller_info_content">
                                    <?php echo is_numeric(dokan_get_seller_rating($author_id)['rating']) ? dokan_get_seller_rating($author_id)['rating'] * 20 . ' %' : dokan_get_seller_rating($author_id)['rating']; ?>
                                </span>
                            </div>
                            <?php if ($bakala_options['show_loadtime'] == '1') { ?>
                                <div class="bakala_seller_info bakala_seller_loadtime">
                                    <span class="bakala_seller_info_header"><?= _e('shipping time', 'bakala') ?></span>
                                    <span class="bakala_seller_info_icon"><i
                                            class="bakala-icon icon-loadtime"></i></span>
                                    <span class="bakala_seller_info_content">
                                        <?php
                                        $custom_shipping_time = get_post_meta($post->id, '_bakala_shipping_time', true);
                                        $terms = get_the_terms($product->get_id(), 'product_cat');
                                        if (!empty($terms)) {
                                            foreach ($terms as $term) {
                                                $term_shipping_time = get_term_meta($term->term_id, 'bakala_shipping_time', true);
                                                if (!empty($term_shipping_time)) {
                                                    $shipping_timet_c = $term_shipping_time;
                                                    break; // اگر یکی از دسته بندی‌ها این فیلد را داشت، از حلقه خارج شوید
                                                }
                                            }
                                        }

                                        if ($shipping_time == '' && empty($custom_shipping_time) && empty($shipping_timet_c)) {
                                            echo _e('Ready to send', 'bakala');
                                        } elseif (!empty($custom_shipping_time)) {
                                            echo $custom_shipping_time;
                                        } elseif (!empty($shipping_timet_c)) {
                                            echo $shipping_timet_c;
                                        } else {
                                            echo $shipping_time;
                                        }
                                        ?>
                                    </span>
                                </div>
                            <?php } ?>
                        </section>

                    <?php
                    endif;
                    ?>

                    <?php


                    if ($mainfea && $bakala_options['main_features_style_mobile'] != 'box') { ?>
                        <div class="main-features-row">
                            <?php if ($bakala_options['product_brand_taxonomy_enable'] == 1) { ?>
                                <div class="brand-row">
                                    <?php
                                    if ($bakala_options['product_brand_taxonomy_img'] == 1) {
                                        white_cattemplate_single_brand();
                                    }
                                    bakala_get_product_brand();
                                    ?>
                                </div>
                            <?php } ?>
                            <div class="main-features-title"> <?php echo _e('Product Features', 'bakala'); ?> </div>
                            <?php if ($bakala_options['main_features_style_mobile'] == 'table') { ?>
                                <div class="main-features table_style">
                                    <?php
                                    $i = 0;
                                    foreach ($mainfea as $singlefea) {
                                        $i = $i++; ?>
                                        <div class="main-features-item">
                                            <div class="main-features-item-title"><span
                                                    class="title"><?php echo $singlefea['title']; ?></span></div>
                                            <div class="main-features-item-value"><span
                                                    class="value"><?php echo $singlefea['value']; ?></span></div>
                                        </div>
                                    <?php }
                                    ?>
                                </div>
                            <?php } else {
                            ?>
                                <ul class="main-features">
                                    <?php if ($mainfea) {
                                        $i = 0;
                                        foreach ($mainfea as $singlefea) {
                                            $i = $i + 1; ?>
                                            <li class="<?php if ($i > 4) {
                                                            echo 'hidden-mainfea';
                                                        } ?>"><i class="icon-circle"></i><span
                                                    class="title"><?php echo $singlefea['title']; ?></span>:<span
                                                    class="value"><?php echo $singlefea['value']; ?></span></li>
                                    <?php }
                                        if ($i > 4) {
                                            echo '<span id="more-link" class="">' . __("More items +", "bakala") . '</span>';
                                        }
                                    } ?>
                                </ul>
                            <?php
                            }
                            ?>
                        </div>
                    <?php
                    } else {
                    ?>
                        <div class="bakala-product-meta product_meta">
                            <?php if ($bakala_options['product_brand_taxonomy_enable'] == 1) { ?>
                                <div class="brand-row">
                                    <?php
                                    if ($bakala_options['product_brand_taxonomy_img'] == 1) {
                                        white_cattemplate_single_brand();
                                    }
                                    bakala_get_product_brand();
                                    ?>
                                </div>
                            <?php } ?>
                        </div>
                    <?php
                    }

                    ?>
                    <div class="bakala_price_update_better">

                        <?php
                        if ($bakala_options['price_update_date'] == 1 && ($bakala_options['price_update_date_position_mobile'] == 'after_brand' || empty($bakala_options['price_update_date_position_mobile']))) {
                            $modified_time = get_the_modified_time('U'); // گرفتن زمان به صورت timestamp
                            $current_time = current_time('timestamp'); // زمان فعلی به صورت timestamp
                            $time_diff = human_time_diff($modified_time, $current_time) . ' ' . __('ago', 'bakala'); // محاسبه تفاوت زمانی
                            $u_text = __('بروزرسانی قیمت:', 'bakala');
                            echo "<div class='bakala-update-price'> <span class='bakala-update-price-text'>$u_text </span><span class='bakala-update-price-date'>$time_diff </span> </div>";
                        }

                        if ($bakala_options['better_price'] == 1) {
                            do_action('bakala_better_price_hook');
                        }
                        ?>
                    </div>


                </div>
                <?php if ($bakala_options['feature_icons_mobile'] == 1) { ?>
                    <div class="product-section">
                        <?php
                        if ($bakala_options['switch_Express_Shipping'] || $bakala_options['switch_24_Hours_Support'] || $bakala_options['switch_Payment_at_the_place'] || $bakala_options['switch_back_guarantee'] || $bakala_options['switch_Guarantee_of_Origin']) {
                            wc_get_template('single-product/feature_icons.php');
                        }
                        ?>
                    </div>
                <?php } ?>
            </div>
            <?php
            do_action('woocommerce_single_product_end');
            ?>
        </div>
    </div>
    <?php


    if ((!$product->is_in_stock() && $bakala_options['notify_stock'] == "0")) {
        if ($bakala_options['cart_fixed'] == '0') {
    ?>
            <div class="bakala-outofstock">
                <div class="bakala-outofstock-title">
                    <p class="bakala-outofstock-text"><?= __('unavailable', 'bakala') ?></p>
                </div>
                <?php if ($bakala_options['show_price_out_of_stock']) { ?>
                    <div class="bakala-product-price">
                        <span class="price"><?php echo $product->get_price_html(); ?></span>
                    </div>
                <?php } ?>
                <p class="bakala-outofstock-alert"><?= __('This product is not available at the moment, but you can ring the bell and we will inform you as soon as it is available', 'bakala') ?></p>
            </div>
        <?php
        } else {
        ?>
            <div class="add-to-cart-holder outofstock">
                <div class="bakala-button-price">
                    <div class="add-to-cart-button">
                        <button type="button" class="button alt">
                            <?= __('ناموجود', 'bakala') ?>
                        </button>
                    </div>
                    <?php if ($bakala_options['show_price_out_of_stock']) { ?>
                        <div class="bakala-product-price">
                            <div id="price-holder">

                                <span class="price"><?php echo $product->get_price_html(); ?></span>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        <?php
        }
    }
    if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") {
        ?>
        <div class="bakala-outofstock">
            <div class="bakala-outofstock-title">
                <p class="bakala-outofstock-text"><?= __('Coming soon', 'bakala') ?></p>
            </div>
            <p class="bakala-outofstock-alert"><?= __('This product will be available soon.', 'bakala') ?></p>
        </div>
    <?php
    }


    echo '<div class="main-content">' . "";


    if (!$product->is_type('variable')) {
        //         do_action('bakala_template_single_price');
    }
    echo "" . '</div>' . "" . '</div><!-- .summary -->';
    echo '<div class="user-comments-total-rating">' . "" . '<div class="overal-rate-status clearfix">' . "" . '<div class="overal-rate-status-info col-lg-6 col-xs-6 col-sm-6 col-md-6">' . "" . '<span>';
    echo _e('Product Rate', 'bakala');
    echo '</span>' . "" . '<span>';
    echo _e('From Total ', 'bakala');
    echo '<span>';
    echo $rating_count;
    echo '</span>';
    echo _e(' Submited Rate', 'bakala');
    echo '</span>' . "" . '</div>' . "" . '<div class="overal-rate-status-average col-lg-6 col-xs-6 col-sm-6 col-md-6">' . "" . '<div class="star-rating-container">' . "" . '<span><span id="';
    echo $average;
    echo '" class="result">';
    echo $average;
    echo '</span>/5</span>' . "" . '<div class="matrix-wolfrating">' . "" . '<div class="disable-stars">' . "" . '<div style="width:';
    echo ($average / 5) * 100;
    echo '%" class="enable-stars"></div>' . "" . '</div>' . "" . '</div>' . "" . '</div>' . "" . '</div>' . "" . '</div>' . "" . '</div>' . "" . '</div>' . ""; ?>
    <?php if (($bakala_options['switch_Express_Shipping'] || $bakala_options['switch_24_Hours_Support'] || $bakala_options['switch_Payment_at_the_place'] || $bakala_options['switch_back_guarantee'] || $bakala_options['switch_Guarantee_of_Origin']) && $bakala_options['feature_icons_position'] != 'before' && $bakala_options['feature_icons_mobile'] != 0) { ?>
        <div class="c-product__feature--body">
            <aside class="c-product__feature">
                <div class="o-grid">
                    <div class="row">
                        <?php if ($bakala_options['switch_Express_Shipping'] == true) { ?>
                            <div class="c-product__feature-col">
                                <a href="<?php if (isset($bakala_options['Express_Shipping']) && $bakala_options['Express_Shipping']) {
                                                echo get_permalink($bakala_options['Express_Shipping']);
                                            } ?>" target="_blank" class="c-product__feature-item c-product__feature-item--1">
                                    <span><?php _e('facility', 'bakala'); ?></span><?php echo $bakala_options['text_Express_Shipping']; ?>
                                </a>
                            </div>
                        <?php } ?>
                        <?php if (isset($bakala_options['switch_24_Hours_Support']) && $bakala_options['switch_24_Hours_Support'] == true) { ?>
                            <div class="c-product__feature-col">
                                <a href="<?php if (isset($bakala_options['24_Hours_Support']) && $bakala_options['24_Hours_Support']) {
                                                echo get_permalink($bakala_options['24_Hours_Support']);
                                            } ?>" target="_blank" class="c-product__feature-item c-product__feature-item--2">
                                    <span><?php _e('facility', 'bakala'); ?></span><?php echo $bakala_options['text_24_Hours_Support']; ?>
                                </a>
                            </div>
                        <?php } ?>
                        <?php if ($bakala_options['switch_Payment_at_the_place'] == true) { ?>
                            <div class="c-product__feature-col"><a
                                    href="<?php if (isset($bakala_options['Payment_at_the_place']) && $bakala_options['Payment_at_the_place']) {
                                                echo get_permalink($bakala_options['Payment_at_the_place']);
                                            } ?>" target="_blank"
                                    class="c-product__feature-item c-product__feature-item--3">
                                    <span><?php _e('facility', 'bakala'); ?></span><?php echo $bakala_options['text_Payment_at_the_place']; ?>
                                </a>
                            </div>
                        <?php } ?>
                        <?php if ($bakala_options['switch_back_guarantee'] == true) { ?>
                            <div class="c-product__feature-col">
                                <a href="<?php if (isset($bakala_options['back_guarantee']) && $bakala_options['back_guarantee']) {
                                                echo get_permalink($bakala_options['back_guarantee']);
                                            } ?>" target="_blank" class="c-product__feature-item c-product__feature-item--4">
                                    <span><?php _e('facility', 'bakala'); ?></span><?php echo $bakala_options['text_back_guarantee']; ?>
                                </a>
                            </div>
                        <?php } ?>
                        <?php if ($bakala_options['switch_Guarantee_of_Origin'] == true) { ?>
                            <div class="c-product__feature-col">
                                <a href="<?php if (isset($bakala_options['Guarantee_of_Origin']) && $bakala_options['Guarantee_of_Origin']) {
                                                echo get_permalink($bakala_options['Guarantee_of_Origin']);
                                            } ?>" target="_blank" class="c-product__feature-item c-product__feature-item--5">
                                    <span><?php _e('facility', 'bakala'); ?></span><?php echo $bakala_options['text_Guarantee_of_Origin']; ?>
                                </a>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </aside>
        </div>
    <?php } ?>
<?php echo '<div>' . "";
    do_action('woocommerce_after_single_product_summary');

    //     bakala_ask_qustion_tab();
    echo "" . '</div>' . "" . '</div><!-- #product-';
    the_ID();
    echo ' -->' . "";
    do_action('woocommerce_after_single_product');
} else {
    $single_style = $bakala_options['single_product_style'];

    $product_id = $product->get_id();
    $brands_tax = white_catbrand_attribute();
    $terms = get_the_terms($product_id, $brands_tax);
    /**
     * woocommerce_before_single_product hook.
     * @hooked wc_print_notices - 10
     */
    do_action('woocommerce_before_single_product');

    if (post_password_required()) {
        echo get_the_password_form();
        return;
    }
?>

    <div id="product-<?php the_ID(); ?>" <?php post_class(); ?>>

        <div class="row p-section-one <?= $single_style == 'boxed' ? 'boxed-style' : ''; ?>">
            <div class="col-md-4 product-gallery">
                <?php
                /**
                 * woocommerce_before_single_product_summary hook.
                 *
                 * @hooked woocommerce_show_product_sale_flash - 10
                 * @hooked woocommerce_show_product_images - 20
                 */
                do_action('woocommerce_before_single_product_summary');
                ?>
            </div>

            <div class="col-md-8 product-det">
                <?php if ($single_style != 'boxed') { ?>
                    <div class="col-md-12 header">
                        <div class="col-md-8 info-header">
                            <?php do_action('woocommerce_single_product_before_title') ?>
                            <h1><?php the_title(); ?>
                                <span><?php echo get_post_meta($product->get_id(), 'product_english_name', true); ?></span>
                            </h1>
                        </div>

                    </div>
                <?php } ?>
                <?php if ($single_style == 'boxed') {
                    wc_get_template_part('single-product/templates/boxed');
                } else {
                    wc_get_template_part('single-product/templates/bakala');
                } ?>

            </div>
        </div><!-- .summary -->
        <?php if (($bakala_options['switch_Express_Shipping'] || $bakala_options['switch_24_Hours_Support'] || $bakala_options['switch_Payment_at_the_place'] || $bakala_options['switch_back_guarantee'] || $bakala_options['switch_Guarantee_of_Origin']) && $bakala_options['feature_icons_position'] != 'before' && $bakala_options['feature_icons_pc'] != 0) { ?>
            <div class="c-product__feature--body">
                <aside class="c-product__feature">
                    <div class="o-grid">
                        <div class="row">
                            <nav class="c-footer__feature-innerbox">
                                <?php if ($bakala_options['switch_Express_Shipping'] == true) { ?>
                                    <a class="c-footer__badge"
                                        href="<?php if (isset($bakala_options['Express_Shipping']) && $bakala_options['Express_Shipping']) {
                                                    echo get_permalink($bakala_options['Express_Shipping']);
                                                } ?>" target="_blank">
                                        <div class="c-footer__feature-item c-footer__feature-item--1" <?php if ($bakala_options['img_Express_Shipping']['url'] != '') {
                                                                                                            echo 'style="background-image:url(' . $bakala_options['img_Express_Shipping']['url'] . ')"';
                                                                                                        } ?>>
                                            <?php echo $bakala_options['text_Express_Shipping']; ?>
                                        </div>
                                    </a>
                                <?php } ?>
                                <?php if ($bakala_options['switch_Payment_at_the_place'] == true) { ?>
                                    <a class="c-footer__badge"
                                        href="<?php if (isset($bakala_options['Payment_at_the_place']) && $bakala_options['Payment_at_the_place']) {
                                                    echo get_permalink($bakala_options['Payment_at_the_place']);
                                                } ?>" target="_blank">
                                        <div class="c-footer__feature-item c-footer__feature-item--4" <?php if ($bakala_options['img_Payment_at_the_place']['url'] != '') {
                                                                                                            echo 'style="background-image:url(' . $bakala_options['img_Payment_at_the_place']['url'] . ')"';
                                                                                                        } ?>>
                                            <?php echo $bakala_options['text_Payment_at_the_place']; ?>
                                        </div>
                                    </a>
                                <?php } ?>
                                <?php if ($bakala_options['switch_back_guarantee'] == true) { ?>
                                    <a class="c-footer__badge"
                                        href="<?php if (isset($bakala_options['back_guarantee']) && $bakala_options['back_guarantee']) {
                                                    echo get_permalink($bakala_options['back_guarantee']);
                                                } ?>" target="_blank">
                                        <div class="c-footer__feature-item c-footer__feature-item--5" <?php if ($bakala_options['img_back_guarantee']['url'] != '') {
                                                                                                            echo 'style="background-image:url(' . $bakala_options['img_back_guarantee']['url'] . ')"';
                                                                                                        } ?>>
                                            <?php echo $bakala_options['text_back_guarantee']; ?>
                                        </div>
                                    </a>
                                <?php } ?>
                                <?php if ($bakala_options['switch_Guarantee_of_Origin'] == true) { ?>
                                    <a class="c-footer__badge"
                                        href="<?php if (isset($bakala_options['Guarantee_of_Origin']) && $bakala_options['Guarantee_of_Origin']) {
                                                    echo get_permalink($bakala_options['Guarantee_of_Origin']);
                                                } ?>" target="_blank">
                                        <div class="c-footer__feature-item c-footer__feature-item--6" <?php if ($bakala_options['img_Guarantee_of_Origin']['url'] != '') {
                                                                                                            echo 'style="background-image:url(' . $bakala_options['img_Guarantee_of_Origin']['url'] . ')"';
                                                                                                        } ?>>
                                            <?php echo $bakala_options['text_Guarantee_of_Origin']; ?>
                                        </div>
                                    </a>
                                <?php } ?>
                            </nav>
                        </div>
                    </div>
                </aside>
            </div>
        <?php } ?>
        <?php
        if ($bakala_options['product_tabs_type'] == 'scroll' && $bakala_options['single_product_style'] == 'boxed') {
            /**
             * woocommerce_after_single_product_summary hook.
             *
             * @hooked woocommerce_output_product_data_tabs - 10
             * @hooked woocommerce_upsell_display - 15
             * @hooked woocommerce_output_related_products - 20
             */
            remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10);
            remove_action('woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15);
            if ($bakala_options['related_products_position'] != 'before') {
                add_action('woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 99);
            }

            remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
            remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 5);
            if ($bakala_options['related_products_position'] != 'after') {
                woocommerce_output_related_products();
            }

        ?>
            <div class="bakala_product_tabs_section">
                <div class="bakala_product_float_box"></div>
                <?php woocommerce_output_product_data_tabs(); ?>
            </div>
    </div>
<?php
            woocommerce_upsell_display();

            do_action('woocommerce_after_single_product_summary');
        } else {
            /**
             * woocommerce_after_single_product_summary hook.
             *
             * @hooked woocommerce_output_product_data_tabs - 10
             * @hooked woocommerce_upsell_display - 15
             * @hooked woocommerce_output_related_products - 20
             */
            if (!$product->is_in_stock()) {
                remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 14);
            }
            do_action('woocommerce_after_single_product_summary');
        }
?>
</div>

<?php
    if ($bakala_options['show_tag']) {
        echo wc_get_product_tag_list($product->get_id(), '', '<span class="bakala-product-tags">', '</span>');
    }
    do_action('woocommerce_after_single_product'); ?>

<?php }