<?php
global $bakala_options;
$notif_count = '';
// redirects ===================================================================
if (isset($bakala_options['referer']) && $bakala_options['referer'] == true) {
    add_filter('woocommerce_login_redirect', 'bakala_login_redirect', 1100, 2);
    add_filter('woocommerce_registration_redirect', 'bakala_redirection_after_registration', 10, 1);

    //login redirect to referer url
    function bakala_login_redirect()
    {
        $location = wp_get_referer();
        if ($location) {
            wp_safe_redirect($location);
        } else {
            wp_safe_redirect(get_permalink(get_option('woocommerce_myaccount_page_id')));
        }
    }
    function bakala_redirection_after_registration($redirection_url)
    {
        $location = wp_get_referer();
        if ($location) {
            $redirection_url = $location;
        } else {
            $redirection_url = get_permalink(get_option('woocommerce_myaccount_page_id'));
        }

        return $redirection_url;
    }
}

// aditional fields in account form ============================================
if ($bakala_options['ed-nationalcode'] == true || $bakala_options['ed-bankcard'] == true || $bakala_options['ed-phone'] == true) {
    add_action('woocommerce_edit_account_form', 'add_new_fields_to_edit_account_form');
    function add_new_fields_to_edit_account_form()
    {
        global $bakala_options;
        $user = wp_get_current_user();
?>
        <fieldset>
            <legend><?php _e('Other informations', 'bakala'); ?></legend>
            <?php if ($bakala_options['ed-phone'] == true) : ?>
                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label for="billing_phone"><?php esc_html_e('Phone number', 'bakala'); ?> </label>
                    <input type="text" class="woocommerce-Input woocommerce-Input--phone input-text" name="billing_phone" id="billing_phone" value="<?php echo esc_attr($user->billing_phone); ?>" />
                </p>
            <?php endif;
            if ($bakala_options['ed-nationalcode'] == true) : ?>
                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label for="bakala_national_code"><?php esc_html_e('National code', 'bakala'); ?> </label>
                    <input type="text" class="woocommerce-Input woocommerce-Input--nationalcode input-text" name="bakala_national_code" id="bakala_national_code" value="<?php echo esc_attr($user->bakala_national_code); ?>" />
                </p>
            <?php endif;
            if ($bakala_options['ed-bankcard'] == true) : ?>
                <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
                    <label for="billing_bankcard"><?php esc_html_e('Bank card number', 'bakala'); ?> </label>
                    <input type="text" class="woocommerce-Input woocommerce-Input--bankcard input-text" name="billing_bankcard" id="billing_bankcard" value="<?php echo esc_attr($user->billing_bankcard); ?>" />
                </p>
            <?php endif; ?>
        </fieldset>
    <?php
    }

    add_action('woocommerce_save_account_details', 'save_new_fields_account_details', 12, 1);
    function save_new_fields_account_details($user_id)
    {
        if (isset($_POST['billing_phone']))
            update_user_meta($user_id, 'billing_phone', sanitize_text_field($_POST['billing_phone']));
        if (isset($_POST['bakala_national_code']))
            update_user_meta($user_id, 'bakala_national_code', sanitize_text_field($_POST['bakala_national_code']));
        if (isset($_POST['billing_bankcard']))
            update_user_meta($user_id, 'billing_bankcard', sanitize_text_field($_POST['billing_bankcard']));
    }
}

// avatars =====================================================================

add_action('wp_ajax_update_avatar', 'update_avatar_function'); // wp_ajax_{action}
add_action('wp_ajax_nopriv_update_avatar', 'update_avatar_function'); // wp_ajax_nopriv_{action}

function update_avatar_function()
{
    // تصفیه ورودی‌ها
    $new_avatar = sanitize_text_field($_POST['new_avatar_id']);
    $user_id = get_current_user_id();

    // بروزرسانی متا دیتا
    update_user_meta($user_id, 'user_avatar', $new_avatar);

    // دریافت URL آواتار
    $avatar_url = get_avatar_url($user_id);
    
    // ارسال URL به صورت ایمن
    wp_die(esc_url($avatar_url));
}


// Apply filter
add_filter('get_avatar_url', 'bakala_custom_avatar', 10, 3);

function bakala_custom_avatar($url, $id_or_email, $args)
{
    $user = false;

    if (is_numeric($id_or_email)) {

        $id = (int) $id_or_email;
        $user = get_user_by('id', $id);
    } elseif (is_object($id_or_email)) {

        if (!empty($id_or_email->user_id)) {
            $id = (int) $id_or_email->user_id;
            $user = get_user_by('id', $id);
        }
    } else {
        $user = get_user_by('email', $id_or_email);
    }

    if ($user && is_object($user)) {

        $user_avatar = get_user_meta($user->data->ID, 'user_avatar', true);
        if ($user_avatar && $user_avatar != 'default') {
            $url = get_template_directory_uri() . '/vendor/images/avatars/' . $user_avatar . '.png';
        }
    }

    return $url;
}

function get_gravatar($email, $s = 42, $d = 'mp', $r = 'g', $img = false, $atts = array())
{
    $url = 'https://www.gravatar.com/avatar/';
    $url .= md5(strtolower(trim($email)));
    $url .= "?s=$s&d=$d&r=$r";
    if ($img) {
        $url = '<img src="' . $url . '"';
        foreach ($atts as $key => $val)
            $url .= ' ' . $key . '="' . $val . '"';
        $url .= ' />';
    }
    return $url;
}

// Account Edit Adresses =======================================================
add_filter('woocommerce_default_address_fields', 'bakala_default_address_fields', 20, 1);
function bakala_default_address_fields($fields)
{
    // Only on account pages
    if (!is_account_page()) return $fields;

    ## ---- 1.  Remove 'address_2' and 'country' field ---- ##

    unset($fields['address_2']);

    ## ---- 2.  Sort Address fields ---- ##

    // Set the order (sorting fields) in the array below
    $sorted_fields = array('first_name', 'last_name', 'country', 'state', 'city', 'address_1', 'postcode', 'phone', 'email');

    $new_fields = array();
    $priority = 0;

    // Reordering billing and shipping fields
    foreach ($sorted_fields as $key_field) {
        $priority += 10;

        if ($key_field == 'company')
            $priority += 20; // keep space for email and phone fields

        if (isset($fields[$key_field])) {
            $new_fields[$key_field] = $fields[$key_field];
            $new_fields[$key_field]['priority'] = $priority;
        }
    }
    return $new_fields;
}
// user endpoint ===============================================================
add_filter('woocommerce_account_menu_items', 'bakala_user_new_links', 40);
function bakala_user_new_links($menu_links)
{
    global $bakala_options;

    if ($bakala_options['account_notification'] == 1) {
        $notifications = array('your-notifications' => __('Notifications', 'bakala'));
    } else {
        $notifications = array();
    }
    if ($bakala_options['myaccount_wishlist'] == 1) {
        $wishlist = array('your-wishlist' => __('Your wishlist', 'bakala'));
    } else {
        $wishlist = array();
    }

    if ($bakala_options['myaccount_tracking_order'] == 1) {
        $tracking = array('your-tracking' => __('Order tracking', 'bakala'));
    } else {
        $tracking = array();
    }
    $menu_links = array_slice($menu_links, 0, 4, true)
        + array('your-comments' => __('Your comments', 'bakala'))
        + $wishlist
        + $tracking
        + $notifications
        + array_slice($menu_links, 4, NULL, true);

    return $menu_links;
}

add_action('init', 'bakala_add_endpoint');
function bakala_add_endpoint()
{
    global $bakala_options;

    add_rewrite_endpoint('your-comments', EP_PAGES);
    if ($bakala_options['myaccount_wishlist'] == 1) {
        add_rewrite_endpoint('your-wishlist', EP_PAGES);
    }

    if ($bakala_options['myaccount_tracking_order'] == 1) {
        add_rewrite_endpoint('your-tracking', EP_PAGES);
    }
    if ($bakala_options['account_notification'] == 1) {
        add_rewrite_endpoint('your-notifications', EP_PAGES);
    }
}

add_action('woocommerce_account_your-comments_endpoint', 'bakala_my_account_comments_endpoint_content');
function bakala_my_account_comments_endpoint_content()
{ ?>
    <div class="report-wrapper box noback">
        <header class="report-title"><?php _e('Your comments', 'bakala'); ?></header>
        <div class="comments-wrapper">
            <?php
            $current_user = get_current_user_id();
            $page = (int) (!isset($_REQUEST["dpage"]) ? 1 : $_REQUEST["dpage"]);
            $limit = 10;

            $args = array(
                'user_id' => $current_user,
                'post_type' => 'product',
            );
            $comments = get_comments($args);
            $pages = ceil(count($comments) / $limit);
            if ($comments) {
                wp_list_comments(array('callback' => 'bakala_user_comments_callback', 'per_page' => $limit, 'page' => $page), $comments);
                echo '<div class="clearfix"></div>';
                global $wp;
                $args = array(
                    'base'         => home_url($wp->request) . '%_%',
                    'format'       => '?dpage=%#%',
                    'total'        => $pages,
                    'current'      => $page,
                    'show_all'     => False,
                    'end_size'  => 3,
                    'mid_size'  => 3,
                    'prev_text' => is_rtl() ? '→' : '←',
                    'next_text' => is_rtl() ? '←' : '→',
                    'type'         => 'plain'
                );

                // ECHO THE PAGENATION
                echo '<nav class="woocommerce-pagination bakala_pagination"><div class="pagination">';
                echo paginate_links($args);
                echo '</div></nav>';
            } else {
                echo '<p class="woocommerce-noreviews bakala-noreviews">' . __('There are no reviews yet.', 'bakala') . '</p>';
            }
            ?>
        </div>
    </div>
<?php }
function bakala_user_comments_callback($comment, $args, $depth)
{
    $GLOBALS['comment'] = $comment;
    $rate = get_comment_meta($comment->comment_ID, 'rating', true);
    $approved = $comment->comment_approved; ?>
    <div class="user-comment-wrapper col-sm-12 col-md-6" id="<?php echo 'comment-' . $comment->comment_ID; ?>">
        <div class="row">
            <div class="col-sm-4 right-section">
                <a href="<?php echo get_permalink($comment->comment_post_ID); ?>" class="image-holder">
                    <?php $thumb = get_the_post_thumbnail($comment->comment_post_ID, 'thumbnail');
                    if ($thumb) {
                        echo $thumb;
                    } else {
                        echo wc_placeholder_img();
                    } ?>
                </a>
                <?php if ($rate) : ?>
                    <div class="rate-holder">
                        <span><?php _e('My rate to product', 'bakala'); ?></span>
                        <div class="white_catrating">
                            <div class="disable-stars">
                                <div style="width:<?php echo ($rate / 5) * 100; ?>%" class="enable-stars"></div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-sm-8 left-section">
                <header class="user-comment-header">
                    <div class="title"><?php echo get_comment_meta($comment->comment_ID, 'comment_title', true); ?></div>
                </header>
                <div class="user-comment-body">
                    <?php comment_text($comment->comment_ID); ?>
                </div>
                <div class="comments-status">
                    <?php if ($approved == 1) {
                        echo '<span class="green">' . __('Approved', 'bakala') . '</span>';
                    } elseif ($approved == 0) {
                        echo '<span class="red">' . __('Not approved', 'bakala') . '</span>';
                    } elseif ($approved == 'spam') {
                        echo '<span class="red">' . __('Spam', 'bakala') . '</span>';
                    } else {
                        echo '<span class="yellow">' . __('Pending approval', 'bakala') . '</span>';
                    } ?>
                </div>
            </div>
        </div>
    </div>
<?php
}

add_action('woocommerce_account_your-wishlist_endpoint', 'bakala_my_account_wishlist_endpoint_content');
function bakala_my_account_wishlist_endpoint_content()
{
    $current_user = wp_get_current_user();
    $wishlist = get_user_meta($current_user->ID, 'bakala_wishlist', true); ?>
    <div class="report-wrapper box noback">
        <header class="report-title"><?php _e('Your latest wishlist', 'bakala'); ?></header>
        <?php if ($wishlist) {
            $page = (int) (!isset($_REQUEST["dpage"]) ? 1 : $_REQUEST["dpage"]);
            $limit = 10;
            $o = $limit * ($page - 1); //define offset
            $i = 0; //start line counter
            $pages = ceil(count($wishlist) / $limit); ?>
            <div class="your-withlist-wrapper">
                <div class="row">
                    <?php foreach ($wishlist as $product_id) {
                        if ($i++ < $o) continue;
                        if ($i > $o + $limit) break;
                        $_product = wc_get_product($product_id);
                        if ($_product && $_product->is_visible() && $_product->get_status() === 'publish') { ?>
                            <div class="wishlist-item col-sm-12 col-md-6">
                                <a data-product-id="<?php echo $product_id ?>" class="remove bakala-wishlist"></a>
                                <a href="<?php echo get_permalink($product_id); ?>">
                                    <?php $thumb = get_the_post_thumbnail($product_id, 'thumbnail');
                                    if ($thumb) {
                                        echo $thumb;
                                    } else {
                                        echo wc_placeholder_img();
                                    } ?>
                                </a>
                                <a href="<?php echo get_permalink($product_id); ?>">
                                    <?php echo '<span>' . get_the_title($product_id) . '</span>'; ?>
                                </a>
                                <span class="price"><?php echo $_product->get_price_html(); ?></span>
                                <a class="btn btn-blue woocommerce-Button button" href="<?php echo get_permalink($product_id); ?>">
                                    <?php _e("View product", "bakala"); ?>
                                </a>
                            </div>
                        <?php } ?>
                    <?php } ?>
                </div>
            </div>
        <?php
            echo '<div class="clearfix"></div>';
            global $wp;
            $args = array(
                'base'         => home_url($wp->request) . '%_%',
                'format'       => '?dpage=%#%',
                'total'        => $pages,
                'current'      => $page,
                'show_all'     => False,
                'end_size'     => 1,
                'mid_size'     => 2,
                'prev_next'    => True,
                'prev_text'    => __('« Previous', 'bakala'),
                'next_text'    => __('Next »', 'bakala'),
                'type'         => 'plain'
            );

            // ECHO THE PAGENATION
            echo '<nav class="woocommerce-pagination">';
            echo paginate_links($args);
            echo '</nav>';
        } else {
            echo '<p class="empty-wishlist">' . __("You dont have any product in your wishlist", "bakala") . '</p>';
        } ?>
    </div>
<?php }





add_action('woocommerce_account_your-tracking_endpoint', 'bakala_my_account_tracking_endpoint_content');

function bakala_my_account_tracking_endpoint_content()
{
    global $bakala_options;
?>
    <div class="bakala-order-tracking report-wrapper box noback <?= $bakala_options['order_tracking_authentication'] == 1 || is_null($bakala_options['order_tracking_authentication']) ? 'authentication_enabled' : 'authentication_disabled' ?>">
        <header class="report-title"><?php _e('Use this form to track the order status.', 'bakala'); ?></header>
        <form id="order-tracking">

            <div class="input-field form-group">
                <span class="icon icon-tracking-orer-phone"></span>
                <label for="order-tracking-phone"><?= $bakala_options['order_tracking_authentication'] == 1 || is_null($bakala_options['order_tracking_authentication']) ? __('Mobile number/order number', 'bakala') : __('phone number', 'bakala');  ?></label>
                <input id="order-tracking-phone" type="text" placeholder="<?= $bakala_options['order_tracking_authentication'] == 1 || is_null($bakala_options['order_tracking_authentication']) ? __('شماره موبایلی که در هنگام خرید وارد کرده اید/شماره سفارش پیامک شده', 'bakala') : __('شماره موبایلی که در هنگام خرید وارد کرده اید', 'bakala') ?>">
            </div>
            <p class="order-error" style="display:none"><?= __('Order not found!', 'bakala') ?></p>
            <button type="submit" class="btn"><?= __('Order tracking', 'bakala') ?></button>
        </form>
        <?php if ($bakala_options['order_tracking_authentication'] == 1 || is_null($bakala_options['order_tracking_authentication'])) { ?>

            <form id="otp-tracking-order" class="otp-form" method="post" style="display:none" data-autosubmit="false" autocompvare="off">
                <p class="otp-description"> <?= __('Enter the 4-digit verification code sent to the mobile number below.', 'bakala') ?></p>
                <div class="mobile-seting">
                    <span class="mobile-number"></span>
                </div>

                <div class="input-box token" id="otp-token">
                    <input type="number" class="token-input first-digit" id="digit-one" name="digit-one" data-next="digit-two" value="">
                    <input type="number" class="token-input second-digit" id="digit-two" name="digit-two" data-next="digit-three" data-previous="digit-one" value="">
                    <input type="number" class="token-input third-digit" id="digit-three" name="digit-three" data-next="digit-four" data-previous="digit-two" value="">
                    <input type="number" class="token-input fourth-digit" id="digit-four" name="digit-four" data-previous="digit-three" value="">
                </div>
                <p class="token-error otp-error" style="display:none"><?= __('The entered code is incorrect!', 'bakala') ?></p>
                <div class="countdown"></div>
                <button class="otp-submit" id="otp-submit" type="submit" name="submit"><?= __('Confirm code', 'bakala') ?></button>
                <button class="otp-recode" id="otp-recode" type="button" name="recode" style="display: none;"><?= __('Resend the code', 'bakala') ?></button>
            </form>
        <?php } ?>
        <div class="tracking-results">

            <div class="tracking-info"></div>
        </div>

    </div>
    <?php
}


function bakala_my_acoount_order_tracking()
{
    global $bakala_options, $wpdb;
    require_once BAKALA_THEMEROOT . '/inc/jdf.php';

    $otp_id = isset($_COOKIE['otp_id']) ? $_COOKIE['otp_id'] : '';
    $code = isset($_POST['token']) ? $_POST['token'] : '';
    $phone = $bakala_options['order_tracking_authentication'] == 0 ? $_POST['phone'] : $_COOKIE['phone'];
    $regx = "/^(\+98|0098|98|0)?9\d{9}$/";
    $otp_table = $wpdb->prefix . "bakala_otp";
    $otp_code = $wpdb->get_row($wpdb->prepare("SELECT * FROM $otp_table WHERE id = %d", $otp_id));
    if ($otp_id) {
        $verify = password_verify($code, $otp_code->otp);
    } else {
        $verify = true;
    }
    if ($verify || $bakala_options['order_tracking_authentication'] == 0) {
        if (preg_match($regx, $phone) == 1) {
            $table = $wpdb->prefix . 'usermeta';
            $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE meta_key = 'billing_phone' AND meta_value = %s", $phone));

            if ($result) {
                $user_id = $result->user_id;
                $customer = new WC_Customer($user_id);
                $order = $customer->get_last_order();
            } else {
                $order = null;
            }

            if (!$order) {
                $table = $wpdb->prefix . 'postmeta';

                $orders_query = $wpdb->get_results($wpdb->prepare("
                    SELECT post_id 
                    FROM {$table} 
                    WHERE meta_key = 'billing_phone' AND meta_value = %s ORDER BY post_id DESC LIMIT 1", $phone));

                if ($orders_query) {
                    $latest_order_id = $orders_query[0]->post_id;

                    if ($latest_order_id) {
                        $order = wc_get_order($latest_order_id);
                    }
                }
            }
        } else {
            $order = wc_get_order($phone);
        }

        if ($order) {

            $order_status = $order->get_status();
            if ($order_status == 'on-hold') {
                $status = 'on-hold';
            } elseif ($order_status == 'processing') {
                $status = 'processing';
            } elseif ($order_status == 'completed') {
                $status = 'completed';
            } else {
                $status = 'processing';
            }

            $order_data = $order->get_data();
            $order_shipping_total = $order_data['shipping_total'];
            $order_total = $order_data['total'];
            $order_payment_method_title = $order_data['payment_method_title'];
            $order_shipping_address = $order_data['shipping']['address_1'] . ' ' . $order_data['shipping']['address_2'];
            $order_shipping_city = $order_data['shipping']['city'];
            $order_shipping_state = $order_data['shipping']['state'];
            $order_shipping_postcode = $order_data['shipping']['postcode'];
            $order_shipping_name = $order_data['shipping']['first_name'] . ' ' . $order_data['shipping']['last_name'];

            $order_billing_name = $order_data['billing']['first_name'] . ' ' . $order_data['billing']['last_name'];
            $order_billing_email = $order_data['billing']['email'];
            $order_billing_phone = $order_data['billing']['phone'];
            $order_shipping_address = $order_data['billing']['address_1'] . ' ' . $order_data['billing']['address_2'];
            $order_billing_city = $order_data['billing']['city'];
            $order_billing_state = $order_data['billing']['state'];
            $order_billing_postcode = $order_data['billing']['postcode'];
            $tracking_send_date = get_post_meta($order->get_id(), '_tracking_send_date', true) ? get_post_meta($order->get_id(), '_tracking_send_date', true) : '';
            $tracking_code = get_post_meta($order->get_id(), '_tracking_code', true) ? get_post_meta($order->get_id(), '_tracking_code', true) : '';
            $tracking_delivery_date = get_post_meta($order->get_id(), '_tracking_delivery_date', true) ? get_post_meta($order->get_id(), '_tracking_delivery_date', true) : '';
            $tracking_form = get_post_meta($order->get_id(), '_tracking_form', true) ? get_post_meta($order->get_id(), '_tracking_form', true) : 0;
            if ($tracking_form == 'post') {
                $tracking_name = 'پست پیشتاز';
            } elseif ($tracking_form == 'tipax') {
                $tracking_name = 'تیپاکس';
            } elseif ($tracking_form == 'chapar') {
                $tracking_name = 'چاپار';
            } elseif ($tracking_form == 'kalaresan') {
                $tracking_name = 'کالا رسان';
            } elseif ($tracking_form == 'mahex') {
                $tracking_name = 'ماهکس';
            }elseif ($tracking_form == 'freight') {
                $tracking_name = 'باربری';
            } else {
                $tracking_name = '';
            }
            if ($tracking_form == 'post') {
                $tracking_url = 'https://tracking.post.ir/?id=' . $tracking_code;
            } elseif ($tracking_form == 'tipax') {
                $tracking_url = 'https://tipaxco.com/?id=' . $tracking_code;
            } elseif ($tracking_form == 'chapar') {
                $tracking_url = 'https://chaparnet.com/track/';
            } elseif ($tracking_form == 'kalaresan') {
                $tracking_url = 'https://kalaresan.ir/tracking.php';
            } elseif ($tracking_form == 'ماهکس') {
                $tracking_url = 'https://mahex.com/tracking/';
            } else {
                $tracking_url = '';
            }
            if ($bakala_options['order_tracking_type'] == 'image') {
    ?>
                <script type="text/javascript">
                    if (jQuery('.authentication_enabled').length) {
                        jQuery('#otp-tracking-order').hide();
                        jQuery('.items').flickity({
                            cellAlign: 'right',
                            rightToLeft: !0,
                            contain: !0,
                            cellSelector: '.productItem',
                            pageDots: !1,
                            groupCells: true
                        });
                        jQuery('.flickity-slider').css('transform', 'translateX(0.56%)');
                        jQuery('.flickity-slider .productItem').removeClass('is-selected');
                        jQuery('.flickity-slider .productItem').first().addClass('is-selected');
                    }
                </script>
            <?php } ?>
            <?php
            if (is_array($bakala_options['track_orders_details']) && in_array('product_pic', $bakala_options['track_orders_details'])) { ?>
                <div class="bakala_products_order">
                    <?php
                    $order_items = $order->get_items();
                    foreach ($order_items as $item_id => $item) {
                        $product = $item->get_product();
                        if ($product && apply_filters('woocommerce_order_item_visible', true, $item)) {
                            $is_visible = $product && $product->is_visible();
                            $product_permalink = apply_filters('woocommerce_order_item_permalink', $is_visible ? $product->get_permalink($item) : '', $item, $order);
                            $img_id = $product->get_image_id();
                            $src = wp_get_attachment_image_src($img_id, 'shop_catalog');

                    ?>
                            <a class="productItem" title="<?php echo $item->get_name(); ?>" href="<?php echo $product_permalink; ?>">
                                <span class="product_counti"><?php echo $item->get_quantity(); ?></span>
                                <img style="width:70px;height:auto;" alt="<?php echo $item->get_name(); ?>" src="<?php echo $src ? $src[0] : wc_placeholder_img_src(); ?>">
                            </a>
                    <?php }
                    } ?>
                </div>
            <?php } ?>
            <table class="bakala_order_details">
                <tbody>
                    <tr>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('name', $bakala_options['track_orders_details'])) { ?>
                            <th><?= esc_html_e('Customer name', 'bakala') ?></th>
                        <?php } ?>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('product_name', $bakala_options['track_orders_details'])) { ?>

                            <th><?= esc_html_e('Product Name', 'bakala') ?></th>
                        <?php } ?>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('pay_method', $bakala_options['track_orders_details'])) { ?>
                            <th><?= esc_html_e('Payment Method', 'bakala') ?></th>
                        <?php } ?>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('destination', $bakala_options['track_orders_details'])) { ?>
                            <th><?= esc_html_e('destination', 'bakala') ?></th>
                        <?php } ?>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('amount', $bakala_options['track_orders_details'])) { ?>
                            <th><?= esc_html_e('Payment', 'bakala') ?></th>
                        <?php } ?>
                        <?php if ($bakala_options['order_tracking_type'] == 'text') { ?>
                            <th><?= esc_html_e('Order status', 'bakala') ?></th>
                        <?php } ?>
                    </tr>
                    <tr>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('name', $bakala_options['track_orders_details'])) { ?>
                            <td><?= $order_billing_name ?></td>
                        <?php } ?>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('product_name', $bakala_options['track_orders_details'])) { ?>
                            <td>
                                <?php
                                $order_items = $order->get_items();
                                foreach ($order_items as $item_id => $item) {
                                    $product = $item->get_product();
                                    echo $item->get_name() . '<br>';
                                }
                                ?>
                            </td>
                        <?php } ?>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('pay_method', $bakala_options['track_orders_details'])) { ?>
                            <td><?= $order_payment_method_title ?></td>
                        <?php } ?>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('destination', $bakala_options['track_orders_details'])) { ?>
                            <td><?= $order_shipping_city ?></td>
                        <?php } ?>
                        <?php if (is_array($bakala_options['track_orders_details']) && in_array('amount', $bakala_options['track_orders_details'])) { ?>
                            <td><?= $order_total ?></td>
                        <?php } ?>
                        <?php if ($bakala_options['order_tracking_type'] == 'text') { ?>
                            <td>
                                <?= wc_get_order_status_name($order_status) ?>
                                <?php
                                if (!empty($tracking_code)) {
                                ?>
                                    <br>
                                    <span><?= __('Tracking Code','bakala') ?>: </span><a id="tracking-code" href="<?= $tracking_url ?>"><?= $tracking_code ?></a>
                                <?php
                                }
                                ?>
                            </td>
                        <?php } ?>
                    </tr>
                </tbody>
            </table>

            <?php if ($bakala_options['order_tracking_type'] == 'image' && $order_status != 'cancelled') { ?>
                <ol class="bakala_progresss" data-stepss="3">
                    <li class="<?= $order_status == 'on-hold' || $order_status == 'box' || $order_status == 'completed' ? 'dones' : null; ?> <?= $order_status == 'processing' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_1']) ? 'actives' : null; ?>">
                        <span class="names "><?= __('doing', 'bakala') ?></span>
                        <span class="steps">
                            <?php if ($order_status == 'processing' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_1'])) { ?>
                                <span class="bakala_borderi"></span>
                                <div class="bakala_tooltioop">
                                    <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/recive.png' ?>">
                                    <span style="visibility: visible" class="bakala_tooltiooptextstatus"><?= __('date of order received', 'bakala') ?> <mark style=" background: none;font-weight: 600;color: #f9af08;"><?= mjdate(get_option('date_format'), strtotime($order->get_date_created())) ?> </mark></span>
                                </div>
                            <?php } else {
                            ?>
                                <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/recive.png' ?>"></span>
                            <?php
                            } ?>
                        </span>
                    </li>
                    <li class="<?= $order_status == 'box' || $order_status == 'completed' ? 'dones' : null; ?> <?= $order_status == 'on-hold' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_2']) ? 'actives' : null; ?>">
                        <span class="names"><?= __('pending', 'bakala') ?></span>
                        <span class="steps">
                            <?php if ($order_status == 'on-hold' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_2'])) { ?>
                                <span class="bakala_borderi"></span>
                                <div class="bakala_tooltioop">
                                    <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/onhold.png' ?>">
                                    <span style="visibility: visible" class="bakala_tooltiooptextbox"><?= __('Your order on the date', 'bakala'); ?> <mark style=" background: none;font-weight: 600;color: #f9af08;"><?= mjdate(get_option('date_format'), strtotime($order->get_date_modified())); ?> </mark> در وضعیت در انتظار بررسی قرار گرفت</span>
                                </div>
                            <?php } else {
                            ?>
                                <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/onhold.png' ?>"></span>
                            <?php
                            } ?>
                        </span>
                    </li>
                    <li class="<?= $order_status == 'completed' ? 'dones' : null; ?> <?= isset($bakala_options['track_orders_status_3']) && ($order_status == 'box' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_3'])) ? 'actives' : null; ?>">
                        <span class="names"><?= __('packing', 'bakala') ?></span>
                        <span class="steps">
                            <?php if (isset($bakala_options['track_orders_status_3']) && ($order_status == 'box' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_3']))) { ?>
                                <span class="bakala_borderi"></span>
                                <div class="bakala_tooltioop">
                                    <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/packing.png' ?>">
                                    <span style="visibility: visible" class="bakala_tooltiooptextbox"><?= __('Your order on the date', 'bakala'); ?> <mark style=" background: none;font-weight: 600;color: #f9af08;"><time datetime="?= date_i18n(get_option('date_format'), strtotime($order->modified_date)); ?>"><?= mjdate(get_option('date_format'), strtotime($order->modified_date)); ?></time> </mark> در وضعیت بسته بندی قرار گرفت</span>
                                </div>
                            <?php } else {
                            ?>
                                <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/packing.png' ?>"></span>
                            <?php
                            } ?>
                        </span>

                    </li>
                    <li class="<?= $order_status == 'delivered' ? 'dones' : null; ?> <?= $order_status == 'completed' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_4']) ? 'actives' : null; ?>">
                        <span class="names "><?= __('completed', 'bakala') ?></span>
                        <span class="steps">
                            <?php if ($order_status == 'completed' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_4'])) { ?>
                                <span class="bakala_borderi"></span>
                                <div class="bakala_tooltioop">
                                    <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/order-tracking-finished.png' ?>">
                                    <span style="visibility: visible" class="bakala_tooltiooptextbox">سفارش <?= $order->get_id() ?> با کد پیگیری <mark style=" background: none;font-weight: 600;color: #f9af08;"><a id="tracking-code" href="<?= $tracking_url ?>"><?= $tracking_code ?></a></mark> توسط <?= $tracking_name ?> در تاریخ <?= $tracking_send_date ?> ارسال گردید</span>
                                </div>
                            <?php } else {
                            ?>
                                <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/order-tracking-finished.png' ?>"></span>
                            <?php
                            } ?>
                        </span>
                    </li>
                    <?php if (isset($bakala_options['enable_delivered_order_status']) && $bakala_options['enable_delivered_order_status'] == 1) { ?>
                        <li class="<?= isset($bakala_options['track_orders_status_5']) && ($order_status == 'delivered' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_5'])) ? 'actives' : null; ?>">
                            <span class="names "><?= __('delivered', 'bakala') ?></span>
                            <span class="steps">
                                <?php if (isset($bakala_options['track_orders_status_5']) && ($order_status == 'delivered' || in_array('wc-' . $order_status, $bakala_options['track_orders_status_5']))) { ?>
                                    <span class="bakala_borderi"></span>
                                    <div class="bakala_tooltioop">
                                        <img src="<?= get_template_directory_uri() . '/vendor/images/tracking/deliver.png' ?>">
                                        <span style="visibility: visible" class="bakala_tooltiooptextdeliver">سفارش <?= $order->get_id() ?> در تاریخ <?= $tracking_delivery_date ?> با کد پیگیری <mark style=" background: none;font-weight: 600;color: #f9af08;"><a id="tracking-code" href="<?= $tracking_url ?>"><?= $tracking_code ?></a></mark> تحویل مشتری گردید</span>
                                    </div>

                                <?php } else {
                                ?>
                                    <span><img src="<?= get_template_directory_uri() . '/vendor/images/tracking/deliver.png' ?>"></span>
                                <?php
                                } ?>
                            </span>
                        </li>
                    <?php } ?>
                </ol>

            <?php }
            if ($tracking_form == 'post') {
            ?>
            <?php
            } elseif ($tracking_form == 'tipax') {
            ?>
            <?php
            }
        } else {
            ?>
            <script type="text/javascript">
                jQuery('#otp-tracking-order').hide();
                jQuery('.order-error').show()
            </script>
        <?php
        }
    } else {
        ?>
        <script type="text/javascript">
            if (jQuery('.authentication_enabled').length) {
                jQuery('#otp-token input').css('borderColor', '#ee5a66')
                jQuery('.token-error').show()
            }
        </script>
    <?php
    }
    wp_die();
}

add_action('wp_ajax_bakala_my_acoount_order_tracking', 'bakala_my_acoount_order_tracking');
add_action('wp_ajax_nopriv_bakala_my_acoount_order_tracking', 'bakala_my_acoount_order_tracking');


function bakala_my_account_notifications_endpoint_content()
{ ?>
    <div class="report-wrapper box noback">
        <header class="report-title"><?php _e('Notifications', 'bakala'); ?></header>
        <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $notifications = new WP_Query(array(
            'posts_per_page' => 6,
            'post_type'      => 'notification',
        ));
        $notif_count = $notifications->post_count;
        while ($notifications->have_posts()) :
            $notifications->the_post();
        ?>
            <div class="notifications-wrapper">
                <div class="notification notification-<?php the_ID(); ?>">
                    <div class="image-col"><?php the_post_thumbnail(); ?></div>
                    <div class="content-col">
                        <h4 class="title"><?php the_title(); ?></h4>
                        <div class="content"><?= wp_trim_words(get_the_content(), 30); ?></div>
                        <div class="footer">
                            <a href="<?php the_permalink(); ?>" data-id="<?php the_ID(); ?>">
                                <?= __('view', 'bakala'); ?> <i class="fas fa-chevron-left"></i>
                            </a>
                            <span class="date"><?= esc_html(get_the_date()); ?></span>
                        </div>
                    </div>
                    <div class="notif-status">
                        <?php
                        $recenty_viewed = get_user_meta(get_current_user_id(), 'bakala_notif_viewed', true);
                        if ($recenty_viewed) {
                            $posts_id = $recenty_viewed;
                            if (is_array($posts_id) && in_array(get_the_ID(), $posts_id)) {
                                echo '<span class="seen">' . __('observed', 'bakala') . '</span>';
                            } else {
                                echo '<span class="unseen">' . __('have not been seen', 'bakala') . '</span>';
                            }
                        } else {
                            echo '<span class="unseen">' . __('have not been seen', 'bakala') . '</span>';
                        }
                        ?>
                    </div>
                </div>
            </div>
            <?php
        endwhile;

        $total_pages = $notifications->max_num_pages;
        if ($total_pages) {

            $current_page = max(1, get_query_var('paged'));
            echo '<div class="clearfix"></div>';
            $args = array(
                'base' => get_pagenum_link(1) . '%_%',
                'format' => '/page/%#%',
                'total'        => $total_pages,
                'current'      => $current_page,
                'prev_text'    => __('« Previous', 'bakala'),
                'next_text'    => __('Next »', 'bakala'),
            );

            // ECHO THE PAGENATION
            echo '<nav class="woocommerce-pagination">';
            echo paginate_links($args);
            echo '</nav>';
        }
        wp_reset_postdata();
    }
    add_action('woocommerce_account_your-notifications_endpoint', 'bakala_my_account_notifications_endpoint_content');

    function viewed_notification()
    {
        $post_id = $_POST['post_id'];
        setcookie("notif[$post_id]", $post_id, time() + (86400 * 30), "/");
    }
    add_action('wp_ajax_viewed_notification', 'viewed_notification');
    add_action('wp_ajax_nopriv_viewed_notification', 'viewed_notification');

    function bakala_myaccount_js()
    {

        global $bakala_options;
        if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
            $logo_href = $bakala_options['site_header_logo']['url'];
        } else {
            $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
        }
        if ($bakala_options['account_notification'] == 1) {

            $notif_count = wp_count_posts('notification')->publish;
            $recenty_viewed = get_user_meta(get_current_user_id(), 'bakala_notif_viewed', true);
            if (is_array($notif_count) && is_array($recenty_viewed)) {
                $viewed_count = intval($notif_count) - count(array_unique($recenty_viewed));

                if (is_user_logged_in() && $viewed_count > 0) {
            ?>
                    <script>
                        (function($) {
                            function setCookie(cname, cvalue, exdays) {
                                const d = new Date();
                                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                                let expires = "expires=" + d.toUTCString();
                                document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
                            }

                            function getCookie(cname) {
                                var name = cname + "=";
                                var decodedCookie = decodeURIComponent(document.cookie);
                                var ca = decodedCookie.split(';');
                                for (var i = 0; i < ca.length; i++) {
                                    var c = ca[i];
                                    while (c.charAt(0) == ' ') {
                                        c = c.substring(1);
                                    }
                                    if (c.indexOf(name) == 0) {
                                        return c.substring(name.length, c.length);
                                    }
                                }
                                return "";
                            }
                            if (window.location.href == "<?= get_permalink(get_option('woocommerce_myaccount_page_id')); ?>") {
                                $(window).on('load', function() {
                                    Swal.fire({
                                        title: 'You have a new notification!',
                                        //icon: 'info',
                                        imageUrl: '/wp-content/themes/bakala/vendor/images/notification.png',
                                        imageWidth: 100,
                                        showCloseButton: true,
                                        confirmButtonText: '<i class="fa fa-eye"></i> View notifications!',
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            window.location.href = "<?= get_permalink(get_option('woocommerce_myaccount_page_id')) . 'your-notifications/'; ?>";
                                            setCookie('bakala_seen_notif_modal', '1', 1);
                                        }
                                    })
                                })
                            }

                            $('li.woocommerce-MyAccount-navigation-link.woocommerce-MyAccount-navigation-link--your-notifications a').append('<span class="count"><?= $viewed_count ?></span>')
                            $('.woocommerce-MyAccount-content .notification .content-col .footer a').on('click', function() {
                                $.ajax({
                                    type: 'POST',
                                    url: "<?= admin_url('admin-ajax.php'); ?>",
                                    data: {
                                        action: 'viewed_notification',
                                        post_id: $(this).attr('data-id'),
                                    },

                                });
                            })


                        })(jQuery);
                    </script>

        <?php
                }
            }
        }
        ?>
        <script>
            (function($) {
                jQuery(".tracking-ifram").on("load", function() {
                    jQuery('#txtbSearch').val(jQuery('#tracking-code').text())
                })
                if ($('.authentication_enabled').length) {
                    var clock = $('.countdown').FlipClock({
                        autoStart: false,
                        callbacks: {
                            start: function() {
                                $('#otp-recode').attr('disabled', 'disabled');
                            },
                            stop: function() {
                                $('#otp-submit').hide();
                                $('#otp-recode').show();
                                $('#otp-recode').removeAttr('disabled');
                            }
                        }
                    });
                    $('form#order-tracking').on('submit', function(e) {
                        var nonce = jQuery('meta[name="csrf-token"]').attr('content');
                        jQuery.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': nonce
                            }
                        });
                        e.preventDefault();
                        var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
                        if (phone_pattern.test($('#order-tracking-phone').val())) {
                            var phone = $('#order-tracking-phone').val();
                        }
                        if ($('#order-tracking-phone').val().length > 0) {
                            $.ajax({
                                type: 'POST',
                                url: "<?= admin_url('admin-ajax.php'); ?>",
                                dataType: "json",
                                data: {
                                    action: 'bakala_authentication_order_tracking',
                                    phone: phone,
                                },
                                beforeSend: function() {
                                    $('.lr-loader').show()
                                },
                                success: function(response) {
                                    $('.lr-loader').hide()
                                    if (response.status_code == 200) {
                                        $('#otp-tracking-order').show();
                                        $('.mobile-number').text(phone);
                                        clock.setTime(<?= json_encode(intval($bakala_options['ippanel_time']) - 1) ?>);
                                        clock.setCountdown(true);
                                        clock.start();
                                        $('#digit-one').focus();
                                        $('#digit-four').keyup(function() {
                                            $('#otp-submit').trigger("click");
                                        });
                                    } else if (response.status_code == 404 || response.status_code == 500) {
                                        $('.order-error').show();
                                        $('.order-error').text(response.message)
                                    }
                                }
                            });
                        }
                        return false;
                    });
                    $('#otp-tracking-order').on('submit', function(e) {
                        e.preventDefault();
                        var digit1 = $('input#digit-one').val();
                        var digit2 = $('input#digit-two').val();
                        var digit3 = $('input#digit-three').val();
                        var digit4 = $('input#digit-four').val();
                        var digits = digit1.concat(digit2, digit3, digit4);
                        $.ajax({
                            url: "<?php echo admin_url('admin-ajax.php'); ?>",
                            type: 'POST',
                            data: {
                                action: "bakala_my_acoount_order_tracking",
                                token: digits,
                            },
                            beforeSend: function() {
                                $('.lr-loader').show()
                            },
                            success: function(response) {
                                $('.lr-loader').hide()
                                $('.tracking-info').html(response)
                            }
                        });

                        return false;
                    })

                    $('#otp-token').find('input').each(function() {
                        $(this).attr('maxlength', 1);
                        $(this).on('keyup', function(e) {
                            e.preventDefault();
                            var parent = $($(this).parent());

                            inputCharacter = String.fromCharCode(e.which);

                            acceptableNumbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];


                            if (e.keyCode == 8 || e.keyCode == 37) {
                                var prev = parent.find('input#' + $(this).data('previous'));


                                if (prev.length != undefined) {
                                    $(prev).select();
                                }


                            } else if (e.which == 229 || (e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
                                //} else if( checkIsInArray( inputCharacter , acceptableNumbers ) ) {
                                var next = parent.find('input#' + $(this).data('next'));

                                if (next.length != undefined) {
                                    $(next).select();
                                } else {
                                    if (parent.data('autosubmit')) {
                                        parent.submit();
                                    }
                                }
                            }
                        });
                    });
                } else {
                    $('form#order-tracking').on('submit', function(e) {
                        var nonce = jQuery('meta[name="csrf-token"]').attr('content');
                        jQuery.ajaxSetup({
                            headers: {
                                'X-CSRF-TOKEN': nonce
                            }
                        });
                        e.preventDefault();

                        var phone = $('#order-tracking-phone').val();

                        if ($('#order-tracking-phone').val().length > 0) {
                            $.ajax({
                                type: 'POST',
                                url: "<?= admin_url('admin-ajax.php'); ?>",
                                data: {
                                    action: 'bakala_my_acoount_order_tracking',
                                    phone: phone,
                                },
                                beforeSend: function() {
                                    $('.lr-loader').show()
                                },
                                success: function(response) {
                                    $('.lr-loader').hide()
                                    $('.tracking-info').html(response)
                                }
                            });
                        }
                        return false;
                    });
                }
            })(jQuery);
        </script>
        <?php
    }
    add_action('wp_footer', 'bakala_myaccount_js');

    function bakala_update_notif_viewed()
    {
        global $post;
        $current_post_id = get_the_ID();
        if (get_post_type($current_post_id) == 'notification') {
            // Get the current post id.
            $current_post_id = get_the_ID();

            if (is_user_logged_in()) {

                // Store recently viewed post ids in user meta.
                $recenty_viewed = get_user_meta(get_current_user_id(), 'bakala_notif_viewed', true);
                if ('' == $recenty_viewed) {
                    $recenty_viewed = array();
                }

                // Prepend id to the beginning of recently viewed id array.(http://php.net/manual/en/function.array-unshift.php)
                array_unshift($recenty_viewed, $current_post_id);

                // Keep the recently viewed items at 5. (http://www.php.net/manual/en/function.array-slice.php)
                $recenty_viewed = array_slice($recenty_viewed, 0, 5); // Extract a slice of the array

                // Update the user meta with new value.
                update_user_meta(get_current_user_id(), 'bakala_notif_viewed', $recenty_viewed);
            }
        }
    }
    add_action('wp_footer', 'bakala_update_notif_viewed');




    add_filter('woocommerce_get_endpoint_url', function ($url, $endpoint, $value, $permalink) {
        global $bakala_options;
        if ($endpoint === 'your-tracking' && isset($bakala_options['top_bar_trackorder']) && $bakala_options['top_bar_trackorder']) {
            $url = get_permalink($bakala_options['top_bar_trackorder']);
        }
        return $url;
    }, 10, 4);

    function bakala_orders_ajax()
    {
        require_once BAKALA_THEMEROOT . '/inc/jdf.php';

        $key = $_POST['key'];
        $status = wc_get_order_status_name($key);
        if (is_mobile_or_tablet()) {
        ?>
            <div class="orders">
                <?php
                $orders = bakala_get_orders($key);
                if ($orders) {
                    foreach ($orders as $order) :
                ?>
                        <div class="order">
                            <a href="<?php echo esc_url($order->get_view_order_url()); ?>">
                                <div class="order-header">
                                    <div class="order-status">
                                        <div>
                                            <i class="fas fa-circle"></i>
                                            <div><?= __($status, 'bakala'); ?></div>
                                        </div>
                                        <i class="fa fa-chevron-left"></i>
                                    </div>
                                    <div class="order-code">
                                        <div class="order-code-text"><?= __('Order code', 'bakala'); ?></div>
                                        <div class="order-code-num"><?= $order->get_order_number(); ?></div>
                                    </div>
                                    <div class="order-info">
                                        <div class="order-date">
                                            <time datetime="<?php echo esc_attr($order->get_date_created()->date('c')); ?>"><?php echo mjdate(get_option('date_format'), strtotime($order->get_date_created())); ?></time>
                                        </div>
                                        <div class="order-price">
                                            <div class="order-price-text"><?= __('Amount', 'bakala'); ?></div>
                                            <div class="order-price-num"><?= $order->get_formatted_order_total(); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <div class="order-middle">
                                <div class="order-products">
                                    <?php
                                    foreach ($order->get_items() as $item_id => $item) {
                                        $product_id = $item['product_id'];
                                        if (has_post_thumbnail($product_id)) {
                                            $img_id = get_post_thumbnail_id($product_id);
                                            $src = wp_get_attachment_image_src($img_id, 'shop_catalog')[0];
                                        } else {
                                            $src  = esc_url(wc_placeholder_img_src());
                                        }
                                        echo "
                            <img src='$src' />
                        ";
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="order-actions">
                                <?php
                                $actions = wc_get_account_orders_actions($order);

                                if (!empty($actions)) {
                                    foreach ($actions as $key => $action) {
                                ?>
                                        <a href="<?= esc_url($action['url']) ?>" class="<?= sanitize_html_class($key) ?>"><span class="edit-info"><?= esc_html($action['name']) ?></span></a>
                                <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    <?php endforeach;
                } else {
                    ?>
                    <div class="empty-order">
                        <div style="width: 180px; height: 135px;">
                            <img class="empty-order-img" width="180" height="135" alt="empty" style="object-fit: contain;" src="<?= get_template_directory_uri() . '/vendor/images/order-empty.png'; ?>">
                        </div>
                        <div class="order-empty-text"><?= __('You have not placed any orders yet', 'bakala') ?></div>
                    </div>
                <?php
                }
                ?>
            </div>
        <?php } else { ?>
            <div class="orders">
                <?php
                $orders = bakala_get_orders($key);
                if ($orders) {
                    foreach ($orders as $order) :
                        $processing_count = $order->get_item_count();
                ?>
                        <div class="order">
                            <a href="<?php echo esc_url($order->get_view_order_url()); ?>">
                                <div class="order-header">
                                    <div class="order-status">
                                        <div>
                                            <i class="fas fa-circle"></i>
                                            <div><?= __($status, 'bakala'); ?></div>
                                        </div>
                                        <i class="fa fa-chevron-left"></i>
                                    </div>
                                    <div class="order-info">
                                        <div class="order-date">
                                            <time datetime="<?php echo esc_attr($order->get_date_created()->date('c')); ?>"><?php echo mjdate(get_option('date_format'), strtotime($order->get_date_created())); ?></time>
                                        </div>
                                        <i class="fas fa-circle"></i>
                                        <div class="order-code">
                                            <div class="order-code-text"><?= __('order code', 'bakala'); ?></div>
                                            <div class="order-code-num"><?= $order->get_order_number(); ?></div>
                                        </div>
                                        <i class="fas fa-circle"></i>
                                        <div class="order-price">
                                            <div class="order-price-text"><?= __('Amount', 'bakala'); ?></div>
                                            <div class="order-price-num"><?= $order->get_formatted_order_total(); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </a>

                            <div class="order-middle">
                                <div class="order-products">
                                    <?php
                                    foreach ($order->get_items() as $item_id => $item) {
                                        $product_id = $item['product_id'];
                                        $link = get_permalink($product_id);
                                        if (has_post_thumbnail($product_id)) {
                                            $img_id = get_post_thumbnail_id($product_id);
                                            $src = wp_get_attachment_image_src($img_id, 'shop_catalog')[0];
                                        } else {
                                            $src  = esc_url(wc_placeholder_img_src());
                                        }
                                        echo "
                                            <a href='$link'><img src='$src' /></a>
                                        ";
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="order-actions">
                                <?php
                                $actions = wc_get_account_orders_actions($order);

                                if (!empty($actions)) {
                                    foreach ($actions as $key => $action) {
                                ?>
                                        <a href="<?= esc_url($action['url']) ?>" class="<?= sanitize_html_class($key) ?>"><span class="edit-info"><?= esc_html($action['name']) ?></span></a>
                                <?php
                                    }
                                }
                                ?>
                            </div>
                        </div>
                    <?php endforeach;
                } else {
                    ?>
                    <div class="empty-order">
                        <div style="width: 180px; height: 135px;">
                            <img class="empty-order-img" width="180" height="135" alt="empty" style="object-fit: contain;" src="<?= get_template_directory_uri() . '/vendor/images/order-empty.png'; ?>">
                        </div>
                        <div class="order-empty-text"><?= __('You have not placed any orders yet', 'bakala'); ?></div>
                    </div>
                <?php
                }
                ?>
            </div>


    <?php
        }
        exit;
    }
    add_action('wp_ajax_bakala_orders_ajax', 'bakala_orders_ajax');
    add_action('wp_ajax_nopriv_bakala_orders_ajax', 'bakala_orders_ajax');
    function bakala_deny_pay_order_outofstock($actions, $order)
    {
        $pay = true;
        foreach ($order->get_items() as $item_id => $item) {
            $product        = $item->get_product();
            if ($product) {
                if (!$product->is_in_stock()) {
                    $pay = false;
                }
            }
        }

        if ($pay == false) {
            $actions['pay']['url'] = '#outofstock';
            $actions['pay']['name'] = __('پرداخت', 'woocommerce');
        }

        return $actions;
    }
    add_filter('woocommerce_my_account_my_orders_actions', 'bakala_deny_pay_order_outofstock', 10, 2);