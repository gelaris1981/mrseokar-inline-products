<?php
if(!is_product_category() && !is_shop() && !is_mobile_or_tablet()){
    woocommerce_breadcrumb();
}

if(is_mobile_or_tablet()){
    ?>
    <div id="container"><main id="content">
    <?php
}else{
?>
    <div id="container" class="container"><main id="content" class="main-woo-div">
<?php } ?>