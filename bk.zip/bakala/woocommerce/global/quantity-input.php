<?php
/**
 * Product quantity inputs
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/global/quantity-input.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 100.0.0
 * 
 * <!--pattern="<?php echo esc_attr( $pattern ); ?>"-->
 */
defined( 'ABSPATH' ) || exit;
global $bakala_options,$product;
 if (isset($bakala_options['min_max_qty_enable']) && $bakala_options['min_max_qty_enable'] == 1) {
if($product) {
    $product_id = $product->get_id();
        $p_max = get_post_meta($product_id, '_bakala_max_qty', true);
        $g_max = isset($bakala_options['max_qty']) ? $bakala_options['max_qty'] : 0;
        $terms = get_the_terms($product_id, 'product_cat');
        if (!empty($terms)) {
            foreach ($terms as $term) {
                $term_max_qty = get_term_meta($term->term_id, 'bakala_max_qty', true);
                $term_min_qty = get_term_meta($term->term_id, 'bakala_min_qty', true);
                if (!empty($term_max_qty)) {
                    $c_max = $term_max_qty;
                    break;
                }
                if (!empty($term_min_qty)) {
                    $c_min = $term_min_qty;
                    break;
                }
            }
        }
        if (!empty($p_max)) {
            $max_allowed_quantity = $p_max;
        } elseif (empty($p_max) && !empty($c_max)) {
            $max_allowed_quantity = $c_max;
        } elseif (empty($p_max) && empty($c_max) && !empty($g_max)) {
            $max_allowed_quantity = $g_max;
        }
        $p_min = get_post_meta($product_id, '_bakala_min_qty', true);
        $g_min = isset($bakala_options['min_qty']) ? $bakala_options['min_qty'] : 0;
        if (!empty($p_min)) {
            $min_allowed_quantity = $p_min;
        } elseif (empty($p_min) && !empty($c_min)) {
            $min_allowed_quantity = $c_min;
        } elseif (empty($p_min) && empty($c_min) && !empty($g_min)) {
            $min_allowed_quantity = $g_min;
        }
    }
}
if ( $max_value && $min_value === $max_value ) {
	?>
	<div class="quantity hidden">
		<input type="hidden" id="<?php echo esc_attr( $input_id ); ?>" class="qty" name="<?php echo esc_attr( $input_name ); ?>" value="<?php echo esc_attr( $min_value ); ?>" />
	</div>
	<?php
} else {
	/* translators: %s: Quantity. */
	$labelledby = ! empty( $args['product_name'] ) ? sprintf( __( '%s quantity', 'woocommerce' ), strip_tags( $args['product_name'] ) ) : '';
	?>
	<div class="quantity">
		<label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php esc_html_e( 'Quantity', 'woocommerce' ); ?></label>
		<div class="bakala-minus"> <?php if(is_cart() && ($input_value - $min_value) <= $step){ echo '<i class="icon icon-trashbin"></i>';}else{echo '<span class="icon icon-bakala-minus"></span>'; } ?></div>
		<input
			type="number"
			id="<?php echo esc_attr( $input_id ); ?>"
			class="input-text qty text"
			step="<?php echo esc_attr( $step ); ?>"
			min="<?php echo isset($min_allowed_quantity) ? $min_allowed_quantity : esc_attr( $min_value ); ?>"
			max="<?php echo isset($max_allowed_quantity) ? intval($max_allowed_quantity) : esc_attr( 0 < $max_value ? $max_value : '' ); ?>"
			name="<?php echo esc_attr( $input_name ); ?>"
			value="<?php echo esc_attr( $input_value ); ?>"
			title="<?php echo esc_attr_x( 'Qty', 'Product quantity input tooltip', 'woocommerce' ); ?>"
			size="4"
			inputmode="<?php echo esc_attr( $inputmode ); ?>"
			aria-labelledby="<?php echo esc_attr( $labelledby ); ?>" />
		<div class="bakala-plus"><span class="icon icon-bakala-plus"></span></div>
	</div>
	<?php
}