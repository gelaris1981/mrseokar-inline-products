<?php

/**
 * Login form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/global/form-login.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version 100.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (is_user_logged_in()) {
    return;
}
global $bakala_options;
if ($bakala_options['lr_bakala'] == 1) {
    ob_start();


    if (!isset($_SESSION['count'])) {
        $_SESSION['count'] = 1;
        $_SESSION['first'] = time();
    }

    $life = (time() - intval($bakala_options['ippanel_time'])) - $_SESSION['first'];
    if ($life > intval($bakala_options['ippanel_time'])) {
        unset($_SESSION['count']);
        $_SESSION['first'] = time();
    }
    global $bakala_options;
    $phone_email = @$_POST['phone'];
    $regx = "/^(\+98|0098|98|0)?9\d{9}$/";
?>

    <div id="login-register-e" class="<?= $bakala_options['lr_password_enable'] == 1 ? 'lr_password_enable' : null ?>">
        <div class="lr-box">
          <div class="lr-logo">
            <?php
            if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
              $logo_href = $bakala_options['site_header_logo']['url'];
            } else {
              $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
            }
            ?>
            <a class="white-logo" href="<?php echo home_url('/'); ?>"><img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>"></a>
          </div>
          <form id="lr-send-form-e" class="lr-form" style="display:<?= (isset($_POST['send']) && count($errors) == 0) ? 'none' : 'flex' ?>" action="" method="post">
            <p class="title"><?= __('login or register','bakala') ?></p>
            <p class="lr-description">
              <?= $bakala_options['lr_email_enable'] == 1 ? __('Please enter your mobile number or email','bakala') : __('Please enter your mobile number.','bakala') ; ?>
            </p>
            <div class="input-box">
              <div class="input-field">
                <span class="input-icon icon-profile-input-login font-icon"></span>
                <?php if ($bakala_options['lr_email_enable'] == 1) : ?>
                  <input type="text" name="phone" id="phone-e" placeholder="<?= __('Mobile number or email','bakala') ?>" autofocus>
                <?php else : ?>
                  <input type="number" name="phone" id="phone-e" placeholder="<?= __('phone number','bakala') ?>" autofocus>
                <?php endif; ?>
                <p class="lr-error" id="error-phone-e" style="display:none"></p>
              </div>
              <?php if ($bakala_options['lr_password_enable'] == 1) : ?>
                <div class="input-field" id="lr-password-field-e" style="display:none">
                  <span class="input-icon icon-password-input-login font-icon"></span>
                  <input type="password" name="password" id="pass-e" placeholder="<?= __('password','bakala') ?>">
                  <p class="lr-error" id="error-pass-e" style="display:none"></p>
                </div>
              <?php endif; ?>
            </div>
            <div class="input-box">
              <?php if ($bakala_options['lr_password_enable'] == 1) : ?>
                <button class="lr-send plus-button" type="button" id="show-pass-e"><?= __('Login/Register with password','bakala') ?></button>
                <button class="lr-send plus-button" type="button" name="lr" id="lr-btn-e" style="display:none;"><?= __('ورود/ثبت نام','bakala') ?></button> <button class="lr-send" type="submit" name="send" id="send-e"><?= __('Login/Register with one-time password','bakala') ?></button>
              <?php else : ?>
                <button class="lr-send" type="submit" name="send" id="send-e"><?= __('Login/Register with one-time password','bakala') ?></button>
              <?php endif; ?>
            </div>
            <div class="input-box">
                <a class="forget btn" style="margin:10px 0;" target="_blank" href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
            </div>
            <?php if ($bakala_options['lr_privacy_policy'] == 1) : ?>
              <div class="custom-control custom-checkbox user-privacy">
                <input type="checkbox" readonly class="checkbox custom-control-input" id="privacy-policy-checkbox-e" checked="" name="privacy">
                <label for="privacy-policy-checkbox" class="custom-control-label">
					<a href="<?= get_permalink(wc_terms_and_conditions_page_id()); ?>"> <?= __('Conditions and rules', 'bakala') ?> </a>
					<?php
					$text = 'Use of site services ' . get_bloginfo("name") . ' I accept .';
					echo __($text, 'bakala');
					?>
				</label>
              </div>
            <?php endif; ?>

          </form>

          <form id="lr-submit-form-e" class="lr-form" method="post" style="display:<?= (isset($_POST['send']) && preg_match($regx, $phone_email) == 1) ? 'flex' : 'none' ?>" data-autosubmit="false" autocompvare="off">
            <p class="lr-description"> <?= __('Enter the 4-digit verification code sent to the mobile number below.','bakala') ?></p>
            <div class="mobile-seting">
              <span class="mobile-number"><?= $_COOKIE['phone'] ?></span>
              <button id="edit-phone-number-e">
                <span class="fa fa-edit"></span>
                <span><?= __('Edit number','bakala') ?></span>
              </button>
            </div>
            <div class="input-box token" id="lr-token-e">
              <input type="number" class="token-input first-digit" id="digit-1-e" name="digit-1" data-next="digit-2-e" value="">
              <input type="number" class="token-input second-digit" id="digit-2-e" name="digit-2" data-next="digit-3-e" data-previous="digit-1-e" value="">
              <input type="number" class="token-input third-digit" id="digit-3-e" name="digit-3" data-next="digit-4-e" data-previous="digit-2-e" value="">
              <input type="number" class="token-input fourth-digit" id="digit-4-e" name="digit-4" data-previous="digit-3-e" value="">
            </div>
            <p class="token-error lr-error" style="display:none"></p>
            <div id="lr-countdown-e"></div>
            <button class="lr-submit" id="lr-submit-e" type="submit" name="submit"><?= __('Confirm Code','bakala') ?></button>
            <button class="lr-recode" id="recode-e" type="button" name="recode" style="display: none;"><?= __('Resend the code','bakala') ?></button>
          </form>
          <?php if ($bakala_options['lr_email_enable'] == 1) : ?>
            <form id="lr-password-form-e" class="lr-form" method="post" style="display:<?= (isset($_POST['send']) && filter_var($phone_email, FILTER_VALIDATE_EMAIL)) ? 'flex' : 'none' ?>">
              <p class="lr-description"><?= __('Enter your password.','bakala') ?></p>
              <input type="password" name="password" id="password-e">
              <p class="password-error lr-error"></p>
              <button class="lr-submit" id="lr-password-e" type="submit" name="submit-password"><?= __('login / register','bakala') ?></button>
            </form>
          <?php endif; ?>
        </div>
      </div>
      <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo" src="<?= $logo_href ?>">
        <div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
      </div>

    <script>
        jQuery('#show-pass-e').click(function() {
            jQuery(this).hide();
            jQuery('#lr-btn-e').show();
            jQuery('#lr-password-field-e').show();
        });

        function getCookie(cname) {
            var name = cname + "=";
            var decodedCookie = decodeURIComponent(document.cookie);
            var ca = decodedCookie.split(';');
            for (var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        }

        function getEmail(email) {
            jQuery('#lr-send-form-e').hide();
            jQuery('#error-phone-e').hide();
            jQuery('#lr-password-form-e').show();
            jQuery('#lr-submit-form-e').hide();
            jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type: 'GET',
                data: {
                    action: 'get_latest_posts_by_category',
                    email: email
                },
                beforeSend: function() {
                    jQuery('body').append('<div class="page-modal"><div class="page-content" id="loader"><img alt="site-logo" class="site-logo" src="' + ajax_params.lurl + '"><div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div></div></div><div class="clearfix"></div>');
                },

                success: function(data) {
                    if (data == "yes") {
                        jQuery('.page-modal').remove();
                        jQuery('.mobile-number').text(getCookie('phone'))
                    } else {
                        jQuery('.page-modal').remove();
                    }
                }
            });
        }
        /////////////////////////////////
        function getphn() {
            jQuery('#lr-submit-form-e').show();
            jQuery('#lr-send-form-e').hide();
            jQuery('#error-phone-e').hide();
            clock.setTime(<?= json_encode(intval($bakala_options['ippanel_time']) - 1) ?>);
            clock.setCountdown(true);
            clock.start();
            jQuery('.page-modal').remove();
        }
        var digit1 = jQuery('input#digit-1-e').val();
        var digit2 = jQuery('input#digit-2-e').val();
        var digit3 = jQuery('input#digit-3-e').val();
        var digit4 = jQuery('input#digit-4-e').val();
        var digits = digit1.concat(digit2, digit3, digit4);
        var codeCookie = getCookie('opt_code');
        var clock = jQuery('#lr-countdown-e').FlipClock({
            autoStart: false,
            callbacks: {
                start: function() {
                    jQuery('#recode-e').attr('disabled', 'disabled');
                    jQuery('.mobile-number').text(getCookie('phone'))

                },
                stop: function() {
                    jQuery('#lr-submit').hide();
                    jQuery('#recode-e').show();

                    jQuery('#recode-e').removeAttr('disabled');
                }
            }
        });

        jQuery('#lr-send-form-e').on('submit', function(e) {
            e.preventDefault();
            var nonce = jQuery('meta[name="csrf-token"]').attr('content');
            jQuery.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': nonce
                }
            });
            if (jQuery('#pass-e').length < 1) {
                if (jQuery('#phone-e').val().length > 0) {
                    jQuery.ajax({
                        url: "<?php echo admin_url('admin-ajax.php'); ?>",
                        type: 'POST',
                        data: {
                            action: "bakala_send_code",
                            phone_email: jQuery('#phone-e').val(),
                        },
                        beforeSend: function() {
                            jQuery('body').append('<div class="page-modal"><div class="page-content" id="loader"><img alt="site-logo" class="site-logo" src="' + ajax_params.lurl + '"><div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div></div></div><div class="clearfix"></div>');
                        },
                        success: function(data) {
                            var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
                            var email_pattern = /^[a-zA-Z-' ]*$/;


                            if (phone_pattern.test(jQuery('#phone-e').val())) {
                                getphn();
                                jQuery('#digit-1-e').trigger("focus");
                                jQuery('#digit-4-e').keyup(function() {
                                    jQuery('#lr-submit-e').trigger("click");
                                    jQuery('body').append('<div class="page-modal"><div class="page-content" id="loader"><img alt="site-logo" class="site-logo" src="' + ajax_params.lurl + '"><div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div></div></div><div class="clearfix"></div>');
                                });

                            } else if (validateEmail(jQuery('#phone-e').val())) {
                                jQuery('.page-modal').remove();
                                getEmail(jQuery('#phone-e').val())
                            } else {
                                jQuery('#error-phone-e').show();
                            }

                        }
                    });
                } else {
                    jQuery('#error-phone-e').text('شماره موبایل یا ایمیل را وارد کنید!');
                    jQuery('#error-phone-e').show();
                }

            } else {
                if (phone_pattern.test(jQuery('#phone').val())) {
                    jQuery.ajax({
                        url: "<?php echo admin_url('admin-ajax.php'); ?>",
                        type: 'POST',
                        data: {
                            action: "bakala_send_code",
                            phone_email: jQuery('#phone-e').val(),
                        },
                        beforeSend: function() {
                            jQuery('body').append('<div class="page-modal"><div class="page-content" id="loader"><img alt="site-logo" class="site-logo" src="' + ajax_params.lurl + '"><div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div></div></div><div class="clearfix"></div>');
                        },
                        success: function(data) {
                            var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
                            var email_pattern = /^[a-zA-Z-' ]*$/;


                            if (phone_pattern.test(jQuery('#phone-e').val())) {

                                getphn();
                                jQuery('#digit-1-e').trigger("focus");
                                jQuery('#digit-4-e').keyup(function() {
                                    jQuery('#lr-submit-e').trigger("click");
                                    jQuery('body').append('<div class="page-modal"><div class="page-content" id="loader"><img alt="site-logo" class="site-logo" src="' + ajax_params.lurl + '"><div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div></div></div><div class="clearfix"></div>');
                                });

                            } else if (validateEmail(jQuery('#phone-e').val())) {
                                jQuery('.page-modal').remove();
                                getEmail(jQuery('#phone-e').val())
                            } else {
                                jQuery('#error-phone-e').show();
                            }

                        }
                    });
                } else {
                    jQuery('#error-phone').text('شماره موبایل را وارد کنید!');
                    jQuery('#error-phone').show();
                }
            }
            return false;
        })
        jQuery('#lr-btn-e').on('click', function() {
            var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
            var email_pattern = /^[a-zA-Z-' ]*$/;

            if (jQuery('#phone-e').val().length > 0 && jQuery('#pass-e').val().length >= 1 && (phone_pattern.test(jQuery('#phone-e').val()) || validateEmail(jQuery('#phone-e').val()))) {
                jQuery.ajax({
                    url: "<?php echo admin_url('admin-ajax.php'); ?>",
                    type: 'POST',
                    dataType: "json",
                    data: {
                        action: "bakala_lr_submit",
                        phone_email: jQuery('#phone-e').val(),
                        password: jQuery('#pass-e').val()
                    },
                    beforeSend: function() {
                        jQuery('body').append('<div class="page-modal"><div class="page-content" id="loader"><img alt="site-logo" class="site-logo" src="' + ajax_params.lurl + '"><div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div></div></div><div class="clearfix"></div>');
                    },
                    success: function(response) {
                        jQuery('.page-modal').remove();
                        if (response.status_code == 500) {
                            jQuery('#pass-e').css('borderColor', '#ee5a66')
                            jQuery('#error-pass-e').text(response.message)
                            jQuery('#error-pass-e').show()
                        } else {
                            const Toast = Swal.mixin({
                                toast: true,
                                position: 'center',
                                showConfirmButton: false,
                                timer: 4000,
                                timerProgressBar: true,
                                didOpen: (toast) => {
                                    toast.addEventListener('mouseenter', Swal.stopTimer)
                                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                                }
                            })
                            Toast.fire({
                                title: response.message,
                                icon: 'success',
                            }).then((result) => {
                                if (window.location.href == document.referrer) {
                                    location.reload();
                                } else {
                                    window.location = document.referrer;
                                }
                            })
                        }
                    }
                });
            }
        })
        var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
        var email_pattern = /^[a-zA-Z-' ]*$/;

        jQuery('#phone-e').keyup(function() {
            if (phone_pattern.test(jQuery(this).val()) == false && !Array.isArray(validateEmail(jQuery(this).val()))) {
                jQuery(this).parent().css('height', 'auto');
                jQuery('#error-phone-e').text('Enter a valid mobile number or email!');
                jQuery('#error-phone-e').show();
                jQuery(this).css('borderColor', '#ee5a66')
            } else {
                jQuery(this).parent().css('height', '65px');
                jQuery('#error-phone-e').hide();
                jQuery(this).css('borderColor', 'green')
            }
        });

        jQuery('#lr-submit-form-e').on('submit', function(e) {
            e.preventDefault();
            var digit1 = jQuery('input#digit-1-e').val();
            var digit2 = jQuery('input#digit-2-e').val();
            var digit3 = jQuery('input#digit-3-e').val();
            var digit4 = jQuery('input#digit-4-e').val();
            var digits = digit1.concat(digit2, digit3, digit4);
            jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type: 'POST',
                dataType: "json",
                data: {
                    action: "bakala_submit_code",
                    token: digits,
                },
                beforeSend: function() {
                    jQuery('.loader').show();
                },
                success: function(response) {
                    jQuery('.loader').hide();
                    if (response.status_code == 500) {
                        jQuery('#lr-token-e input').css('borderColor', '#ee5a66')
                        jQuery('.token-error').text(response.message)
                    } else {
                        jQuery('#bakala_login').modal('toggle');
                        const Toast = Swal.mixin({
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 4000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal.stopTimer)
                                toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        })
                        Toast.fire({
                            title: response.message,
                            icon: 'success',
                        }).then((result) => {
                            if (window.location.href == document.referrer) {
                                location.reload();
                            } else {
                                window.location = document.referrer;
                            }
                        })
                    }
                }
            });

            return false;
        })

        jQuery('#lr-password-form-e').on('submit', function(e) {
            e.preventDefault();
            var password = jQuery('input#password-e').val();
            jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type: 'POST',
                dataType: "json",
                data: {
                    action: "bakala_submit_password",
                    password: password,
                },
                beforeSend: function() {
                    jQuery('.loader').show();
                },
                success: function(response) {
                    jQuery('.loader').hide();
                    if (response.status_code == 500) {
                        jQuery('#password-e').css('borderColor', '#ee5a66')
                        jQuery('.password-error').text(response.message)
                    } else {
                        jQuery('#bakala_login').modal('toggle');
                        const Toast = Swal.mixin({
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 4000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal.stopTimer)
                                toast.addEventListener('mouseleave', Swal.resumeTimer)
                            }
                        })
                        Toast.fire({
                            title: response.message,
                            icon: 'success',
                        }).then((result) => {
                            if (window.location.href == document.referrer) {
                                location.reload();
                            } else {
                                window.location = document.referrer;
                            }
                        })
                    }
                }
            });

            return false;
        })
        ////////////////////

        //////////////////////
        jQuery('#recode-e').on('click', function() {
            jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type: 'POST',
                data: {
                    action: "bakala_send_code",
                    phone_email: jQuery('#phone-e').val(),
                },
                beforeSend: function() {
                    jQuery('body').append('<div class="page-modal"><div class="page-content" id="loader"><img alt="site-logo" class="site-logo" src="' + ajax_params.lurl + '"><div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div></div></div><div class="clearfix"></div>');
                },
                complete: function() {
                    jQuery('.page-modal').remove();
                },
                success: function(data) {
                    clock.setTime(<?= json_encode(intval($bakala_options['ippanel_time'])) ?>);
                    clock.setCountdown(true);
                    clock.start();
                    var pattern = /^(\+98|0098|98|0)?9\d{9}$/;
                    if (pattern.test(jQuery('#phone-e').val())) {
                        jQuery('#lr-submit-form-e').show();
                        jQuery('#lr-send-form-e').hide();
                        jQuery('#error-phone-e').hide();
                    } else {
                        jQuery('#error-phone-e').show();
                    }
                }
            });
        })

        jQuery('#edit-phone-number-e').click(function(e) {
            e.preventDefault();
            jQuery('#lr-submit-form-e').hide();
            jQuery('#lr-send-form-e').show();
        })


        String.prototype.toEnglishDigit = function() {
            var find = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
            var replace = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
            var replaceString = this;
            var regex;
            for (var i = 0; i < find.length; i++) {
                regex = new RegExp(find[i], "g");
                replaceString = replaceString.replace(regex, replace[i]);
            }
            return replaceString;
        };

        document.querySelectorAll('input').forEach(x => {
            x.oninput = function() {
                x.value = x.value.toEnglishDigit()
            }
        });
        jQuery('#lr-token-e').find('input').each(function() {
            jQuery(this).attr('maxlength', 1);
            jQuery(this).on('keyup', function(e) {
                e.preventDefault();
                var parent = jQuery(jQuery(this).parent());

                inputCharacter = String.fromCharCode(e.which);

                acceptableNumbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];


                if (e.keyCode == 8 || e.keyCode == 37) {
                    var prev = parent.find('input#' + jQuery(this).data('previous'));


                    if (prev.length != undefined) {
                        jQuery(prev).select();
                    }


                } else if (e.which == 229 || (e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
                    //} else if( checkIsInArray( inputCharacter , acceptableNumbers ) ) {
                    var next = parent.find('input#' + jQuery(this).data('next'));

                    if (next.length != undefined) {
                        jQuery(next).select();
                    } else {
                        if (parent.data('autosubmit')) {
                            parent.submit();
                        }
                    }
                }
            });
        });
    </script>
<?php
} else {
?>
    <form class="woocommerce-form woocommerce-form-login login" method="post" <?php echo ($hidden) ? 'style="display:none;"' : ''; ?>>

        <?php do_action('woocommerce_login_form_start'); ?>

        <?php echo ($message) ? wpautop(wptexturize($message)) : ''; // @codingStandardsIgnoreLine 
        ?>

        <p class="form-row form-row-first">
            <label for="username"><?php esc_html_e('Username or email', 'woocommerce'); ?>&nbsp;<span class="required">*</span></label>
            <input type="text" class="input-text" name="username" id="username" autocomplete="username" />
        </p>
        <p class="form-row form-row-last">
            <label for="password"><?php esc_html_e('Password', 'woocommerce'); ?>&nbsp;<span class="required">*</span></label>
            <input class="input-text" type="password" name="password" id="password" autocomplete="current-password" />
        </p>
        <div class="clear"></div>

        <?php do_action('woocommerce_login_form'); ?>

        <p class="form-row">
            <label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
                <input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span><?php esc_html_e('Remember me', 'woocommerce'); ?></span>
            </label>
            <?php wp_nonce_field('woocommerce-login', 'woocommerce-login-nonce'); ?>
            <input type="hidden" name="redirect" value="<?php echo esc_url($redirect); ?>" />
            <button type="submit" class="woocommerce-button button woocommerce-form-login__submit" name="login" value="<?php esc_attr_e('Login', 'woocommerce'); ?>"><?php esc_html_e('Login', 'woocommerce'); ?></button>
        </p>
        <p class="lost_password">
            <a href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php esc_html_e('Lost your password?', 'woocommerce'); ?></a>
        </p>

        <div class="clear"></div>

        <?php do_action('woocommerce_login_form_end'); ?>

    </form>
<?php }
