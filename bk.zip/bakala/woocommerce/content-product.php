<?php

/**
 * The template for displaying product content within loops
 * This template can be overridden by copying it to yourtheme/woocommerce/content-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 100.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

global $product, $bakala_options;

// Ensure visibility
if (empty($product) || !$product->is_visible()) {
    return;
}
$white_catcompare = isset($bakala_options['white_catcompare']) ? $bakala_options['white_catcompare'] : false;

$label = get_post_meta($product->get_id(), 'bakala_product_custom_label', true) ? get_post_meta($product->get_id(), 'bakala_product_custom_label', true) : $bakala_options['custom_label_text'];
$label_bg = get_post_meta($product->get_id(), 'bakala_product_custom_label_bg', true) ? get_post_meta($product->get_id(), 'bakala_product_custom_label_bg', true) : $bakala_options['custom_label_bg'];
$label_color = get_post_meta($product->get_id(), 'bakala_product_custom_label_color', true) ? get_post_meta($product->get_id(), 'bakala_product_custom_label_color', true) : $bakala_options['custom_label_color'];
$label_single = get_post_meta($product->get_id(), 'bakala_product_custom_label', true);
$label_all = $bakala_options['custom_label_text'];
if (array_key_exists('custom_label_category', $bakala_options) && is_array($bakala_options['custom_label_category'])) {
    $label_category = isset($bakala_options['custom_label_category']) ? array_values($bakala_options['custom_label_category']) : [];

    $l_categories = array_map(
        function ($value) {
            return (int)$value;
        },
        $label_category
    );
    if (has_term($l_categories, 'product_cat')) {
        $x = true;
    } else {
        $x = false;
    }
} else {
    $x = false;
}
$varible_price = true;
if ($product->is_type('variable') && $product->get_variation_price('min') == 0 && $product->get_variation_price('max') == 0) {
    $varible_price = false;
}
if (is_mobile_or_tablet()) {
    ?>
    <li <?php wc_product_class('', $product); ?>>
        <?php
        if (!empty($label_single) || ($x && !empty($label_all))) { ?>
            <span class="bakala_custom_label_product"
                  style="background:<?php echo $label_bg ?>;color:<?php echo $label_color ?>;"><?php echo __($label, 'bakala') ?></span>
        <?php } ?>
        <div class="product-box-inner">
            <div class="info-product">
                <a href="<?php echo get_the_permalink(); ?>"
                   title="<?php echo get_the_title(); ?>" <?php echo $bakala_options['cnew_tab'] == 1 ? 'target="_blank"' : 'target="_self"' ?>>
                    <div class="products-list">
                        <article class="row">
                            <div class="col-xs-4 pull-right">
                                <div class="product-thumb">
                                    <img alt="<?php echo esc_attr(get_the_title()); ?>" 
     src="<?php 
         if (has_post_thumbnail()) {
             $img_id = get_post_thumbnail_id($product->get_id());
             $src = wp_get_attachment_image_src($img_id, 'woocommerce_thumbnail');
             if ($src && isset($src[0])) {
                 echo esc_url($src[0]);
             } else {
                 echo esc_url(wc_placeholder_img_src());
             }
         } elseif (($parent_id = wp_get_post_parent_id($product->get_id())) && has_post_thumbnail($parent_id)) {
             $img_id = get_post_thumbnail_id($parent_id);
             $src = wp_get_attachment_image_src($img_id, 'woocommerce_thumbnail');
             if ($src && isset($src[0])) {
                 echo esc_url($src[0]);
             } else {
                 echo esc_url(wc_placeholder_img_src());
             }
         } else {
             echo esc_url(wc_placeholder_img_src());
         } 
     ?>" 
     class="img-responsive">

                                </div>
                            </div>
                            <div class="col-xs-8 col-sm-4 pull-right" data-type="info">
                                <a href="<?php echo get_the_permalink(); ?>" <?php echo $bakala_options['cnew_tab'] == 1 ? 'target="_blank"' : 'target="_self"' ?>>
                                    <header>
                                        <p class="product_title"><?php echo get_the_title(); ?></p>
                                    </header>
                                </a>
                                <?php
                                if (function_exists('yith_advanced_reviews_instance')) {
                                    $YWAR_AdvancedReview = yith_advanced_reviews_instance();
                                    $reviews_count = count($YWAR_AdvancedReview->get_product_reviews_by_rating($product->get_id()));
                                    $avg_rating_number = number_format($product->get_average_rating(), 1);
                                    ?>
                                    <div class="product-rating-wrapper clearfix">
                                        <div class="product-rating-box">
                                            <svg class="icon icon-star_filled-svg" fill="#fff">
                                                <use xlink:href="#icon-star_filled">
                                                    <svg id="icon-star_filled" viewBox="0 0 1024 1024">
                                                        <title>star_filled</title>
                                                        <path class="path1"
                                                              d="M817.582 956.314l-305.582-197.755-305.603 197.755 93.696-351.744-282.563-229.499 363.5-19.599 130.97-339.62 130.99 339.62 363.479 19.599-282.563 229.519 93.676 351.724z"></path>
                                                    </svg>
                                                </use>
                                            </svg>
                                            <span><?php echo $avg_rating_number; ?></span>
                                        </div>
                                        <span class="product-rating-bars-label"><?php echo _e('From ', 'bakala'); ?><span><?php echo $reviews_count; ?></span><?php echo _e(' Rate', 'bakala'); ?></span>
                                    </div>
                                <?php } ?>
                                <div class="product-color-list">
                                    <?php
                                    remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5);
                                    remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
                                    do_action('woocommerce_after_shop_loop_item_title');
                                    ?>
                                </div>

                                <div class="product-pricing-info">
                                    <?php
                                    if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                                        <span class="products__item-gift-price">
											<span class="products__item-price">
												<span class="products__item-price--final">
													<span class="coming_soon_archive"><?php echo _e('Coming soon', 'bakala'); ?></span>
												</span>
											</span>
										</span>

                                    <?php } elseif ($product->is_in_stock()) { ?>
                                        <div class="products__item-price">
                                            <?php if ($product->is_on_sale()) {
                                                echo $product->get_price_html();
                                            } else { ?>
                                                <span class="white_catfinal-price">
													<?php echo $product->get_price_html(); ?>
												</span>
                                            <?php }
                                            if (isset($bakala_options['show_modified_price_change']) && $bakala_options['show_modified_price_change'] == true) {
                                                $diff = get_latest_price_change($product);
                                                if (!empty($diff) && is_array($diff) && isset($diff['changes'])) : ?>
                                                    <div class="modified-info">
                                                        <span class="updated-price<?php 
                                                            if ($diff['changes'] < 0) {
                                                                echo ' down';
                                                            } elseif ($diff['changes'] > 0) {
                                                                echo ' up';
                                                            } ?>">
                                                            <?php 
                                                            echo wc_price($diff['changes']);
                                                            if ($diff['changes'] < 0) {
                                                                echo '<i class="arrow-down"></i>';
                                                            } elseif ($diff['changes'] > 0) {
                                                                echo '<i class="arrow-up"></i>';
                                                            } ?>
                                                        </span>
                                                        <?php 
                                                        $d = isset($diff['date']) ? strtotime($diff['date']) : null; 
                                                        if ($d) {
                                                            if (function_exists('mjdate')) { ?>
                                                                <span class="modifued-date"><?php echo __('Update: ', 'bakala') . mjdate("", $d); ?></span>
                                                            <?php } else { ?>
                                                                <span class="modifued-date"><?php echo __('Update: ', 'bakala') . date("j F Y", $d); ?></span>
                                                            <?php }
                                                        } ?>
                                                    </div>
                                                <?php endif;
                                            }

                                             ?>
                                        </div>

                                        <?php
                                        if ($product->is_on_sale()) {
                                            echo loop_saving_percentage($product);
                                        } ?>
                                        <?php

                                        if (isset($bakala_options['loop-cart']) && $bakala_options['loop-cart'] && $bakala_options['catalog_mode'] == false && bakala_remove_add_to_card_button() && !$product->is_type('variable') && !empty($product->get_price())) { ?>
                                            <div class="loop-add-to-cart">
                                                <?php
                                                if ($bakala_options['quantity_content_product'] == 1) {
                                                    woocommerce_quantity_input(array(
                                                        'input_name' => 'quantity',
                                                        'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                                                        'max_value' => apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product),
                                                        'input_value' => isset($_POST['quantity']) ? wc_stock_amount($_POST['quantity']) : $product->get_min_purchase_quantity(),
                                                    ));
                                                }
                                                do_action('woocommerce_after_shop_loop_item'); ?>
                                            </div>
                                            <?php
                                        }
                                        if ($product->is_type('variable') && $bakala_options['show_variables_shop'] == 1 && $varible_price && bakala_remove_add_to_card_button()) {
                                            echo '<button type="button" class="bakala-select-options">' . __('انتخاب گزینه ها', 'bakala') . '</button>';
                                        }

                                        ?>
                                    <?php } else { ?>
                                        <div class="product-pricing-info">
                                            <div class="white_catfinal-price">
                                                <?php
                                                if ($bakala_options['show_price_out_of_stock']) {
                                                    echo $product->get_price_html();
                                                }
                                                ?>
                                            </div>
                                            <span class="red-text"><?php _e('Out Of Stock ', 'bakala'); ?></span>
                                        </div>
                                    <?php } ?>
                                </div>
                                <?php matrix_archive_color(); ?>

                        </article>
                    </div>
                </a>
            </div>
            <?php if ($product->is_type('variable') && $bakala_options['show_variables_shop'] == 1) { ?>
                <div class="variable-cart-product">
                    <button type="button" class="back-to-product"><i class="bakala-icon-back"></i></button>
                    <?php echo do_shortcode('[variable_shop]') ?>
                </div>
            <?php } ?>
        </div>
    </li>
<?php } else { ?>
    <li <?php wc_product_class('', $product); ?>
            data-id=<?php echo $product->get_id(); ?> data-en="<?php echo get_post_meta($product->get_id(), 'product_english_name', true); ?>">
        <?php
        if (!empty($label_single) || ($x && !empty($label_all))) { ?>
            <span class="bakala_custom_label_product"
                  style="background:<?php echo $label_bg ?>;color:<?php echo $label_color ?>;"><?php echo __($label, 'bakala') ?></span>
        <?php } ?>
        <?php echo is_wonder($product); ?>

        <div class="product-box-inner ">
            <div class="info-product">
                <div class="products__item-img-color-wrapper">
                    <div class="products__item-image-wrapper <?php echo $bakala_options['product_hover_image'] == 1 && wc_get_product()->get_gallery_image_ids() ? 'has_second' : null; ?>">
                        <a href="<?php the_permalink() ?>"
                           title="<?php echo get_the_title(); ?>" <?php echo $bakala_options['cnew_tab'] == 1 ? 'target="_blank"' : 'target="_self"' ?>>

                            <img alt="<?php echo esc_attr(get_the_title()); ?>" class="products__item-image"
     src="<?php 
         if (has_post_thumbnail()) {
             $img_id = get_post_thumbnail_id($product->get_id());
             $src = wp_get_attachment_image_src($img_id, 'woocommerce_thumbnail');
             if ($src && isset($src[0])) {
                 echo esc_url($src[0]);
             } else {
                 echo esc_url(wc_placeholder_img_src());
             }
         } elseif (($parent_id = wp_get_post_parent_id($product->get_id())) && has_post_thumbnail($parent_id)) {
             $img_id = get_post_thumbnail_id($parent_id);
             $src = wp_get_attachment_image_src($img_id, 'woocommerce_thumbnail');
             if ($src && isset($src[0])) {
                 echo esc_url($src[0]);
             } else {
                 echo esc_url(wc_placeholder_img_src());
             }
         } else {
             echo esc_url(wc_placeholder_img_src());
         } 
     ?>">

                            <?php
                            if ($bakala_options['product_hover_image'] == 1 && wc_get_product()->get_gallery_image_ids()) {
                                $image_id = wc_get_product()->get_gallery_image_ids()[0];
                                if ($image_id) {
                                    echo wp_get_attachment_image($image_id, 'woocommerce_thumbnail', true, array("class" => "products__item-image second-image"));
                                } else {
                                    echo wp_get_attachment_image(wc_get_product()->get_image_id(), 'woocommerce_thumbnail', true, array("class" => "products__item-image second-image"));
                                }
                            }
                            ?>
                        </a>

                        <?php matrix_archive_color(); ?>
                        <span class="products__item-colors-wrapper">
							<span class="products__item--colors">
								<span class="colors-wrapper">
									<?php
                                    remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5);
                                    remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
                                    ?>
                                    <?php if ($white_catcompare && is_product_category()) { ?>
                                        <span class="products__item-compare">
											<label class="products__item-compare-txt"><?php echo _e('Compare', 'bakala'); ?><input
                                                        class="compare-chekcbox" value="on" type="checkbox"
                                                        onclick="bakala_jquery_compare(this)"
                                                        style="display:none;"></label>
										</span>
                                    <?php } ?>
								</span>
							</span>
						</span>
                    </div>
                    <div class="products__item-info">
                        <?php
                        remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash ', 10);
                        remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
                        do_action('woocommerce_before_shop_loop_item_title');
                        ?>
                        <p class="products__item-fatitle force-rtl"><a href="<?php the_permalink() ?>"
                                                                       title="<?php echo get_the_title(); ?>" <?php echo $bakala_options['cnew_tab'] == 1 ? 'target="_blank"' : 'target="_self"' ?>><?php echo get_the_title(); ?></a>
                        </p>
                        <?php do_action('woocommerce_after_shop_loop_item_title'); ?>
                        <?php if (function_exists('yith_advanced_reviews_instance')) { ?>
                            <span class="products__item-rate-wrapper">
								<span class="products__item-rate">
									<span class="rate">
										<span class="rate__value">
											<?php
                                            $YWAR_AdvancedReview = yith_advanced_reviews_instance();
                                            $reviews_count = count($YWAR_AdvancedReview->get_product_reviews_by_rating($product->get_id()));
                                            $avg_rating_number = number_format($product->get_average_rating(), 1);
                                            ?>
											<svg class="svg-star" width="14" height="14">
												<use xmlns:xlink="http://www.w3.org/1999/xlink"
                                                     xlink:href="#icon-star_filled"><svg id="icon-star_filled"
                                                                                         viewBox="0 0 1024 1024"
                                                                                         width="100%" height="100%">
														<title>star_filled</title>
														<path d="M817.582 956.314l-305.582-197.755-305.603 197.755 93.696-351.744-282.563-229.499 363.5-19.599 130.97-339.62 130.99 339.62 363.479 19.599-282.563 229.519 93.676 351.724z"></path>
													</svg></use>
											</svg>
											<?php echo $avg_rating_number; ?>
										</span>
										<?php echo _e('From ', 'bakala'); ?><?php echo $reviews_count; ?><?php echo _e(' Rate', 'bakala'); ?>
									</span>
								</span>
							</span>
                        <?php }

                        if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                            <span class="products__item-gift-price">
								<span class="products__item-price">
									<span class="products__item-price--final">
										<span class="coming_soon_archive"><?php echo _e('Coming soon', 'bakala'); ?></span>
									</span>
								</span>
							</span>
                        <?php } elseif ($product->is_in_stock()) { ?>
                        <span class="products__item-gift-price">
								<span class="products__item-price">
									<?php if ($product->is_on_sale()) {
                                        echo $product->get_price_html();
                                    } else { ?>
                                        <span class="white_catfinal-price">
											<?php echo $product->get_price_html(); ?>
										</span>
                                    <?php }
                                    if (isset($bakala_options['show_modified_price_change']) && $bakala_options['show_modified_price_change'] == true) {
                                        $diff = get_latest_price_change($product);
                                        if ($diff && array_key_exists('changes', $diff)) : ?>
                                            <div class="modified-info">
												<span class="updated-price<?php if ($diff['changes'] < 0) {
                                                    echo ' down';
                                                } elseif ($diff['changes'] > 0) {
                                                    echo ' up';
                                                } ?>">
													<?php echo wc_price($diff['changes']);
                                                    if ($diff['changes'] < 0) {
                                                        echo '<i class="arrow-down"></i>';
                                                    } elseif ($diff['changes'] > 0) {
                                                        echo '<i class="arrow-up"></i>';
                                                    } ?>
												</span>
												<?php $d = strtotime($diff['date']); ?>
                                                <?php if (function_exists('mjdate')) { ?>
                                                    <span class="modifued-date"><?php echo __('Update: ', 'bakala') . mjdate("", $d); ?></span>
                                                <?php } else { ?>
                                                    <span class="modifued-date"><?php _e('Update: ', 'bakala') . date("j F Y", $d); ?></span>
                                                <?php } ?>
											</div>
                                        <?php endif;
                                    } ?>
								</span>
								<?php if ($product->is_on_sale()) {
                                    echo loop_saving_percentage($product);
                                } ?>
							</span>

                        <div class="box-footer">
                            <?php
                            if (isset($bakala_options['loop-cart']) && $bakala_options['loop-cart'] && $bakala_options['catalog_mode'] == false && !$product->is_type('variable') && !empty($product->get_price()) && bakala_remove_add_to_card_button()) {
                                echo '<div class="loop-add-to-cart">';
                                if ($bakala_options['quantity_content_product'] == 1) {
                                    woocommerce_quantity_input(array(
                                        'input_name' => 'quantity',
                                        'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                                        'max_value' => apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product),
                                        'input_value' => isset($_POST['quantity']) ? wc_stock_amount($_POST['quantity']) : $product->get_min_purchase_quantity(),
                                    ));
                                }
                                do_action('woocommerce_after_shop_loop_item');
                                echo '</div>';
                            }
                            if ($product->is_type('variable') && $bakala_options['show_variables_shop'] == 1 && $varible_price && bakala_remove_add_to_card_button()) {

                                echo '<button type="button" class="bakala-select-options">' . __('Select options', 'bakala') . '</button>';
                            }

                            /* Start */

                            $review_count = $product->get_review_count();
                            $avg_rating_number = $product->get_average_rating() ? number_format($product->get_average_rating(), 1) : 5;
                            $star = '<div class="custom-stars"><div class="customStar"><div class=""></div><p>' . $avg_rating_number . '</p></div>';
                            if ($review_count > 0) {
                                ?>
                                <div class="custom-stars">
                                    <div class="customStar">
                                        <div class=""></div>
                                        <p><?= $avg_rating_number ?></p>
                                    </div>

                                    <p><?= __("From ", "bakala") . $review_count . __(" Vote", "bakala"); ?> </p>
                                </div>
                                <?php
                            } else {
                                ?>
                                <div class="custom-stars">
                                    <div class="customStar">
                                        <div class=""></div>
                                        <p><?= $avg_rating_number ?></p>
                                    </div>
                                </div>
                                <?php
                            }
                            if (function_exists('dokan_get_seller_rating')) :
                                $author_id = get_post_field('post_author', $product->get_id());
                                $store_info = dokan_get_store_info($author_id); ?>
                                <div class="c-seller__info-loop">
                                    <i class="icon"></i>
                                    <?php echo _e('Sell By', 'bakala'); ?>   <a target="blank" class="seller-v"
                                                                                href="<?php echo dokan_get_store_url($author_id); ?>">
                                        "<?php echo esc_html($store_info['store_name']); ?>"</a>
                                </div>
                            <?php endif;
                            } else { ?>
                                <span class="products__item-gift-price">
								    <div class="white_catfinal-price">
										    <?php
                                            if ($bakala_options['show_price_out_of_stock']) {
                                                echo $product->get_price_html();
                                            }
                                            ?>
										    </div>
									<span class="products__item-price">

										<span class="products__item-price--final">

											<span class="out_stock"><?php _e('Out Of Stock ', 'bakala'); ?></span>
										</span>
									</span>
								</span>
                            <?php }
                            ?>
                        </div>

                        <div class="main-featured-loop">
                            <?php
                            $mainfea = get_post_meta($product->get_id(), 'main_features', true);
                            if ($mainfea) { ?>
                                <div class="main-features-title"><?php echo _e('Product Features', 'bakala'); ?> </div>
                                <ul class="main-features">
                                    <?php
                                    $i = 0;
                                    foreach ($mainfea as $singlefea) {
                                        $i = $i + 1;
                                        if ($i < 6) : ?>
                                            <li><i class="icon-circle"></i><span
                                                        class="title"><?php echo $singlefea['title']; ?></span>:<span
                                                        class="value"><?php echo $singlefea['value']; ?></span></li>
                                        <?php
                                        endif;
                                    }
                                    ?>
                                </ul>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>

            <?php if ($product->is_type('variable') && $bakala_options['show_variables_shop'] == 1 && !is_cart()) { ?>
                <div class="variable-cart-product">
                    <button type="button" class="back-to-product"><i class="bakala-icon-back"></i></button>
                    <?php echo do_shortcode('[variable_shop]') ?>
                </div>

            <?php } ?>
    </li>
<?php }
