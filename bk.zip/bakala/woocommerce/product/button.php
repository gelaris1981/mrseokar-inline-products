<?php

$c = get_post( $c_id );

$button_text = 'راهنمای سایزبندی';
$button_text = ! ! ( $button_text ) ? $button_text : $c->post_title;
?>

<span class="bakala-sizes-product-size-chart-button" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala-sizes-product-size-charts-popup" data-chart-id="<?php echo esc_attr( $c_id ); ?>"><?php echo __($button_text,'bakala'); ?></span>


