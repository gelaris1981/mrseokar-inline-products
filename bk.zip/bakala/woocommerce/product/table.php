<?php

$t            = json_decode($table_meta);
$c            = get_post($c_id);
$is_popup     = isset($is_popup) && $is_popup;
$popup_type   = $is_popup ? 'tabbed_popup' : '';
$tabbed_class = '';
if ($is_popup && 'tabbed_popup' === $popup_type) {
	$tabbed_class = ' bakala-sizes-product-table-wrapper-tabbed-popup';
}
$t_style           = 'default';
$table_style_class = 'bakala-sizes-product-table-' . $t_style;

if ($is_popup) {

	$popup_type        = 'tabbed_popup';
	$description_title = __('راهنمای سایز بندی', 'bakala');

	$tab_title = __('سایز بندی', 'bakala');

	$p_style           = 'default';
	$popup_style_class = 'bakala-sizes-product-size-charts-popup-' . $p_style;
}
?>

<div id="bakala-sizes-product-size-charts-popup" class="modal fade" tabindex="-1">

	<div class="modal-dialog">
		<div class="modal-content">

			<div class="bakala-sizes-product-table-wrapper<?php echo esc_attr($tabbed_class); ?>">
				<ul class="nav nav-tabs" id="sizesTab" role="tablist">
					<li class="nav-item" role="presentation">
						<button class="nav-link active" id="sizes-table-tab" data-bs-toggle="tab" data-bs-target="#sizes-table-pane" type="button" role="tab" aria-selected="true">
							<?php echo $tab_title; ?>
							<div class="tab-border"></div>
						</button>
					</li>
					<li class="nav-item" role="presentation">
						<button class="nav-link" id="sizes-desc-tab" data-bs-toggle="tab" data-bs-target="#sizes-desc-pane" type="button" role="tab" aria-selected="true">
							<?php echo $description_title; ?>
							<div class="tab-border"></div>
						</button>
					</li>
				</ul>
				<div class="tab-content" id="sizesTabContent">
				<div class="tab-pane fade show active" id="sizes-table-pane" role="tabpanel" aria-labelledby="processing-tab" tabindex="0">

						<div class="bakala-sizes-product-table-responsive-container-with-shadow">
							<div class="bakala-sizes-right-shadow"></div>
							<div class="bakala-sizes-left-shadow"></div>
							<div class="bakala-sizes-product-table-responsive-container">
								<table class="bakala-sizes-product-table <?php echo esc_attr($table_style_class); ?>">
									<thead>
										<tr>
											<?php if (isset($t[0])) : ?>
												<?php foreach ($t[0] as $col) : ?>
													<th>
														<?php echo  htmlspecialchars($col); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
														?>
													</th>
												<?php endforeach; ?>
											<?php endif; ?>
										</tr>
									</thead>

									<tbody>
										<?php if (!!$t && is_array($t)) : ?>
											<?php foreach ($t as $idx => $row) : ?>
												<?php
												if (!$idx) {
													continue;
												}
												?>
												<tr>
													<?php foreach ($row as $col) : ?>
														<td>
															<div class="bakala-sizes-product-table-td-content">
																<?php echo  htmlspecialchars($col); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
																?>
															</div>
														</td>
													<?php endforeach; ?>
												</tr>
											<?php endforeach; ?>
										<?php endif; ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div class="tab-pane fade" id="sizes-desc-pane" role="tabpanel" tabindex="0">

						<?php
						$content = $c->post_content;

						$content = apply_filters('the_content', $content);


						$content = str_replace(']]>', ']]&gt;', $content);
						?>

						<?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
						?>

					</div>
					
				</div>
			</div>
		</div>
	</div><!-- .bakala-sizes-product-size-charts-popup-container end -->
</div><!-- .bakala-sizes-product-size-charts-popup end -->