<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

$has_row    = false;
$attributes = $product->get_attributes();
global $bakala_options;
ob_start();
if(is_mobile_or_tablet()){
    if ($bakala_options['specifications_style_mobile'] == 'table') {
    ?>
        <div class="product_attributes main-features table_style">
            <?php $z = 0;
            $j = 0;
            $limit = class_exists('JCWC_AdvancedAttrubutes') ? 1 : 3; ?>
            <?php foreach ($attributes as $attribute) :
                if ($z < $limit) {
                    if (empty($attribute['is_visible']) || ($attribute['is_taxonomy'] && !taxonomy_exists($attribute['name'])))
                        continue;
    
                    $values = wc_get_product_terms($product->get_id(), $attribute['name'], array('fields' => 'names'));
                    $att_val = apply_filters('woocommerce_attribute', wpautop(wptexturize(implode(', ', $values))), $attribute, $values);
                    if (empty($att_val))
                        continue;
                    if (get_class($attribute) == 'JCAA_Product_Attribute') {
            ?>
                        <div class="spec-wrapper">
                            <b class="title">
                                <i class="icon icon-caret-left-blue"></i>
                                <span><?php echo wc_attribute_label($attribute->get_name()); ?></span>
                            </b>
                            <ul class="spec-list">
    
                                <?php
                                $values = array();
    
                                if ($attribute->is_taxonomy()) {
    
                                    $attribute_taxonomy = $attribute->get_taxonomy_object();
                                    $attribute_values = wc_get_product_terms($product->get_id(), $attribute->get_name(), array('fields' => 'all'));
    
                                    foreach ($attribute_values as $attribute_value) {
                                        if ($z < 3) {
                                            $value_name = esc_html($attribute_value->name);
    
                                            if ($attribute_taxonomy->attribute_public) {
                                                $values[] = '<a href="' . esc_url(get_term_link($attribute_value->term_id, $attribute->get_name())) . '" rel="tag">' . $value_name . '</a>';
                                            } else {
                                                $values[] = $value_name;
                                            }
                                            $z++;
                                        }
                                    }
                                } else {
                                    $values = $attribute->get_options();
    
                                    foreach ($values as &$value) {
                                        $value = make_clickable(esc_html($value));
                                    }
                                }
    
                                echo apply_filters('woocommerce_attribute', wpautop(wptexturize(implode(', ', $values))), $attribute, $values);
                                ?>
                            </ul>
                        </div>
                        <?php
    
                    } else {
                        if ($j < 3) {
                        ?>
                            <div class="main-features-item">
                                <div class="main-features-item-title"><span class="title"><?php echo wc_attribute_label($attribute['name']); ?></span></div>
                                <div class="main-features-item-value"><span class="value"><?php echo $att_val; ?></span></div>
                            </div>
    
            <?php
                            $j++;
                        }
                    }
    
                    $has_row = true;
                    $z++;
                }
            endforeach; ?>
        </div><!-- .product_attributes -->
    <?php
    } else {
    ?>
        <div class="product_attributes">
            <?php $z = 0;
            $j = 0; ?>
            <?php foreach ($attributes as $attribute) :
                if (empty($attribute['is_visible']) || ($attribute['is_taxonomy'] && !taxonomy_exists($attribute['name'])))
                    continue;
    
                $values = wc_get_product_terms($product->get_id(), $attribute['name'], array('fields' => 'names'));
                $att_val = apply_filters('woocommerce_attribute', wpautop(wptexturize(implode(', ', $values))), $attribute, $values);
                if (empty($att_val))
                    continue;
                if (get_class($attribute) == 'JCAA_Product_Attribute') {
                    $pval = explode('</li>', $att_val);
                    $pval = array_slice($pval, 0, 3);
                    $fval = implode('</li>', $pval);
                    if ($z == 0) {
                        echo '<ul class="att_value">' . $fval . '</ul>';
                        $z = $z + 1;
                    }
                } else {
                    if ($j < 3) {
                        echo '<span class="att_label">' . wc_attribute_label($attribute['name']) . '</span>';
                        echo '<span class="att_value">' . $att_val . '</span>';
                        $j++;
                    }
                }
    
                $has_row = true;
            endforeach; ?>
    
        </div>
    <?php
    }
}else{
    if ($bakala_options['specifications_style_pc'] == 'table') {
    ?>
        <div class="product_attributes main-features table_style">
            <?php $z = 0;
            $j = 0;
            $limit = class_exists('JCWC_AdvancedAttrubutes') ? 1 : 3; ?>
            <?php foreach ($attributes as $attribute) :
                if ($z < $limit) {
                    if (empty($attribute['is_visible']) || ($attribute['is_taxonomy'] && !taxonomy_exists($attribute['name'])))
                        continue;
    
                    $values = wc_get_product_terms($product->get_id(), $attribute['name'], array('fields' => 'names'));
                    $att_val = apply_filters('woocommerce_attribute', wpautop(wptexturize(implode(', ', $values))), $attribute, $values);
                    if (empty($att_val))
                        continue;
                    if (get_class($attribute) == 'JCAA_Product_Attribute') {
            ?>
                        <div class="spec-wrapper">
                            <b class="title">
                                <i class="icon icon-caret-left-blue"></i>
                                <span><?php echo wc_attribute_label($attribute->get_name()); ?></span>
                            </b>
                            <ul class="spec-list">
    
                                <?php
                                $values = array();
    
                                if ($attribute->is_taxonomy()) {
    
                                    $attribute_taxonomy = $attribute->get_taxonomy_object();
                                    $attribute_values = wc_get_product_terms($product->get_id(), $attribute->get_name(), array('fields' => 'all'));
    
                                    foreach ($attribute_values as $attribute_value) {
                                        if ($z < 3) {
                                            $value_name = esc_html($attribute_value->name);
    
                                            if ($attribute_taxonomy->attribute_public) {
                                                $values[] = '<a href="' . esc_url(get_term_link($attribute_value->term_id, $attribute->get_name())) . '" rel="tag">' . $value_name . '</a>';
                                            } else {
                                                $values[] = $value_name;
                                            }
                                            $z++;
                                        }
                                    }
                                } else {
                                    $values = $attribute->get_options();
    
                                    foreach ($values as &$value) {
                                        $value = make_clickable(esc_html($value));
                                    }
                                }
    
                                echo apply_filters('woocommerce_attribute', wpautop(wptexturize(implode(', ', $values))), $attribute, $values);
                                ?>
                            </ul>
                        </div>
                        <?php
    
                    } else {
                        if ($j < 3) {
                        ?>
                            <div class="main-features-item">
                                <div class="main-features-item-title"><span class="title"><?php echo wc_attribute_label($attribute['name']); ?></span></div>
                                <div class="main-features-item-value"><span class="value"><?php echo $att_val; ?></span></div>
                            </div>
    
            <?php
                            $j++;
                        }
                    }
    
                    $has_row = true;
                    $z++;
                }
            endforeach; ?>
        </div><!-- .product_attributes -->
    <?php
    } else {
    ?>
        <div class="product_attributes">
            <?php $z = 0;
            $j = 0; ?>
            <?php foreach ($attributes as $attribute) :
                if (empty($attribute['is_visible']) || ($attribute['is_taxonomy'] && !taxonomy_exists($attribute['name'])))
                    continue;
    
                $values = wc_get_product_terms($product->get_id(), $attribute['name'], array('fields' => 'names'));
                $att_val = apply_filters('woocommerce_attribute', wpautop(wptexturize(implode(', ', $values))), $attribute, $values);
                if (empty($att_val))
                    continue;
                if (get_class($attribute) == 'JCAA_Product_Attribute') {
                    $pval = explode('</li>', $att_val);
                    $pval = array_slice($pval, 0, 3);
                    $fval = implode('</li>', $pval);
                    if ($z == 0) {
                        echo '<ul class="att_value">' . $fval . '</ul>';
                        $z = $z + 1;
                    }
                } else {
                    if ($j < 3) {
                        echo '<span class="att_label">' . wc_attribute_label($attribute['name']) . '</span>';
                        echo '<span class="att_value">' . $att_val . '</span>';
                        $j++;
                    }
                }
    
                $has_row = true;
            endforeach; ?>
    
        </div>
    <?php
    }
}
if ($has_row) {
    echo ob_get_clean();
} else {
    ob_end_clean();
}
