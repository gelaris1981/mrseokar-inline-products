<?php
global $bakala_options;
?>
						<nav class="c-footer__feature-innerbox">
												<?php if ($bakala_options['switch_Express_Shipping'] == true) { ?>
													<a class="c-footer__badge" href="<?php if (isset($bakala_options['Express_Shipping']) && $bakala_options['Express_Shipping']) {
																							echo get_permalink($bakala_options['Express_Shipping']);
																						} ?>" target="_blank">
														<div class="c-footer__feature-item c-footer__feature-item--1" <?php if ($bakala_options['img_Express_Shipping']['url'] != '') {
																															echo 'style="background-image:url(' . $bakala_options['img_Express_Shipping']['url'] . ')"';
																														} ?>>
															<?php echo $bakala_options['text_Express_Shipping']; ?>
														</div>
													</a>
												<?php } ?>
												<?php if ($bakala_options['switch_Payment_at_the_place'] == true) { ?>
													<a class="c-footer__badge" href="<?php if (isset($bakala_options['Payment_at_the_place']) && $bakala_options['Payment_at_the_place']) {
																							echo get_permalink($bakala_options['Payment_at_the_place']);
																						} ?>" target="_blank">
														<div class="c-footer__feature-item c-footer__feature-item--4" <?php if ($bakala_options['img_Payment_at_the_place']['url'] != '') {
																															echo 'style="background-image:url(' . $bakala_options['img_Payment_at_the_place']['url'] . ')"';
																														} ?>>
															<?php echo $bakala_options['text_Payment_at_the_place']; ?>
														</div>
													</a>
												<?php } ?>
												<?php if ($bakala_options['switch_back_guarantee'] == true) { ?>
													<a class="c-footer__badge" href="<?php if (isset($bakala_options['back_guarantee']) && $bakala_options['back_guarantee']) {
																							echo get_permalink($bakala_options['back_guarantee']);
																						} ?>" target="_blank">
														<div class="c-footer__feature-item c-footer__feature-item--5" <?php if ($bakala_options['img_back_guarantee']['url'] != '') {
																															echo 'style="background-image:url(' . $bakala_options['img_back_guarantee']['url'] . ')"';
																														} ?>>
															<?php echo $bakala_options['text_back_guarantee']; ?>
														</div>
													</a>
												<?php } ?>
												<?php if ($bakala_options['switch_Guarantee_of_Origin'] == true) { ?>
													<a class="c-footer__badge" href="<?php if (isset($bakala_options['Guarantee_of_Origin']) && $bakala_options['Guarantee_of_Origin']) {
																							echo get_permalink($bakala_options['Guarantee_of_Origin']);
																						} ?>" target="_blank">
														<div class="c-footer__feature-item c-footer__feature-item--6" <?php if ($bakala_options['img_Guarantee_of_Origin']['url'] != '') {
																															echo 'style="background-image:url(' . $bakala_options['img_Guarantee_of_Origin']['url'] . ')"';
																														} ?>>
															<?php echo $bakala_options['text_Guarantee_of_Origin']; ?>
														</div>
													</a>
												<?php } ?>
											</nav>
