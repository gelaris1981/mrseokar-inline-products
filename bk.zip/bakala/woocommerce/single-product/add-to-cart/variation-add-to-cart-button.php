<?php

/**
 * Single variation cart button
 *
 * @see    https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 100.0.0
 */
if (!defined('ABSPATH')) {
    exit;
}

global $product;
global $bakala_options,$post;
$is_remove=false;
if( isset($bakala_options['add_to_cart_button_remove_category']) && is_array($bakala_options['add_to_cart_button_remove_category']) ){
    $add_to_cart_button_remove_category = array_values($bakala_options['add_to_cart_button_remove_category']);
    $intArray = array_map(
        function ($value) {
            return (int)$value;
        },
        $add_to_cart_button_remove_category
    );
    $is_remove = has_term($intArray, 'product_cat');
}
$btn_text = $product->single_add_to_cart_text();
if (empty($bakala_options['add_to_cart_button_text']) && get_post_meta($post->ID, '_bakala_change_text_atcb', true) == false) {
    $btn_text = $product->single_add_to_cart_text();
} elseif (get_post_meta($post->ID, '_bakala_change_text_atcb', true)) {
    $btn_text = get_post_meta($post->ID, '_bakala_change_text_atcb', true);
} elseif($is_remove) {
    $btn_text = $bakala_options['add_to_cart_button_text'];
}elseif($bakala_options['add_to_cart_button_change_text_all']==1){
    $btn_text = $bakala_options['add_to_cart_button_text'];
}
if (is_mobile_or_tablet()) {
    ?>
    <div class="woocommerce-variation-add-to-cart variations_button <?= $bakala_options['cart_fixed'] ? 'cart-fixed' : 'cart-normal'; ?>">

        <?php if ((!isset($bakala_options['catalog_mode']) || $bakala_options['catalog_mode'] == false) && (get_post_meta($product->get_id(), '_coming_soon_product', true) != "on")) { ?>
            <?php if ($product->is_in_stock()) :
                if ($bakala_options['cart_fixed']) {
                    ?>
                    <?php if ($bakala_options['price_add_holder'] == 1) :
                        // Get cart items quantities
                        $product_id = $product->get_ID();
                        // Loop through cart items
                        foreach (WC()->cart->get_cart() as $cart_item) {
                            if (in_array($product_id, array($cart_item['product_id'], $cart_item['variation_id']))) {
                                $quantity = $cart_item['quantity'];
                                break; // stop the loop if product is found
                            }
                        }
                        ?>

                        <div class="add-to-cart-holder">
							<?php if($bakala_options['alert_stock'] == 1){
							    ?>
                            <div class="alert-stock"></div>
								<?php } ?>
                            <div class="bakala-button-price">
                                <div class="add-to-cart-button">
                                    <div id="quantity-holder">
                                        <?php
                                        do_action('woocommerce_before_add_to_cart_quantity');
                                        woocommerce_quantity_input(array(
                                            'input_name' => 'quantity',
                                            'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                                            'max_value' => apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product),
                                            'input_value' => isset($_POST['quantity']) ? wc_stock_amount($_POST['quantity']) : $product->get_min_purchase_quantity(),
                                            'product_name' => $product->get_name(),
                                        ));
                                        do_action('woocommerce_after_add_to_cart_quantity');
                                        ?>

                                    </div>
                                    <?php if ($bakala_options['add_to_cart_type'] == 0) : ?>
                                        <button type="submit" name="add-to-cart"
                                                class="single_add_to_cart_button button alt <?= $bakala_options['floating-cart'] == 1 ? 'ajax_btn' : null ?>"
                                                value="<?php echo esc_attr($product->get_id()); ?>"><?= $btn_text ?></button>
                                    <?php else : ?>
                                        <button type="submit" name="add-to-cart"
                                                class="single_add_to_cart_button button alt has-icon <?= $bakala_options['floating-cart'] == 1 ? 'ajax_btn' : null ?>"
                                                value="<?php echo esc_attr($product->get_id()); ?>"></button>
                                    <?php endif; ?>
                                </div>
                                <div class="bakala-product-price">

                                    <div id="price-holder"><?= $product->get_price_html(); ?></div>
                                </div>
                            </div>
                        </div>
                    <?php else : ?>
                        <div class="add-to-cart-holder">
                            <div class="alert-stock"></div>
                            <div class="add-to-cart-button">
                                <div id="quantity-holder">
                                    <?php
                                    do_action('woocommerce_before_add_to_cart_quantity');
                                    woocommerce_quantity_input(array(
                                        'input_name' => 'quantity',
                                        'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                                        'max_value' => apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product),
                                        'input_value' => isset($_POST['quantity']) ? wc_stock_amount($_POST['quantity']) : $product->get_min_purchase_quantity(),
                                        'product_name' => $product->get_name(),
                                    ));
                                    do_action('woocommerce_after_add_to_cart_quantity');
                                    ?>

                                </div>
                                <button type="submit" name="add-to-cart" class="single_add_to_cart_button button alt <?= $bakala_options['floating-cart'] == 1 ? 'ajax_btn' : null ?>"
                                        value="<?php echo esc_attr($product->get_id()); ?>"><?php echo esc_html($btn_text); ?></button>
                            </div>
                        </div>
                    <?php endif;
                } else {
                    ?>
                    <div class="bakala-product-price">
                        <div id="price-holder"><?= $product->get_price_html(); ?></div>
                    </div>
                    <?php do_action('woocommerce_before_add_to_cart_button'); ?>
                    <div class="add-to-cart-holder-normal">
                        <?php
                        do_action('woocommerce_before_add_to_cart_quantity');

                        woocommerce_quantity_input(
                            array(
                                'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                                'max_value' => apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product),
                                'input_value' => isset($_POST['quantity']) ? wc_stock_amount(wp_unslash($_POST['quantity'])) : $product->get_min_purchase_quantity(), // WPCS: CSRF ok, input var ok.
                            )
                        );

                        do_action('woocommerce_after_add_to_cart_quantity');
                        ?>

                        <button type="submit"
                                class="single_add_to_cart_button button alt <?= $bakala_options['floating-cart'] == 1 ? 'ajax_btn' : null ?>"><?php echo esc_html($product->single_add_to_cart_text()); ?></button>
                    </div>
                    <?php
                    do_action('woocommerce_after_add_to_cart_button');
                }
                ?>
                <input type="hidden" name="add-to-cart" value="<?php echo absint($product->get_id()); ?>"/>
                <input type="hidden" name="product_id" value="<?php echo absint($product->get_id()); ?>"/>
                <input type="hidden" name="variation_id" class="variation_id" value="0"/>
            <?php else :
                if (!isset($bakala_options['notify_stock']) || !$bakala_options['notify_stock']) {
                    ?>
                    <div class="add-to-cart-holder">
                        <div class="bakala-button-price">
                                    <div class="add-to-cart-button">
                                <button type="button" class="button alt">
                                    <?= __('ناموجود', 'bakala') ?>
                                </button>
                                </div>
                                <div class="bakala-product-price">
                                    <span class="price"><?php echo $product->get_price_html(); ?></span>
                                </div>
                                </div>
                    </div>
                <?php }
            endif; ?>
        <?php } ?>
    </div>
    <?php
} else {
    ?>
<?php do_action('woocommerce_before_add_to_cart_button'); ?>
 <?php
 if($product->is_in_stock()){
        if (!white_catis_catalog_mode() && get_post_meta($product->get_id(), '_coming_soon_product', true) != "on") : ?>
    <div class="woocommerce-variation-add-to-cart variations_button">
        <?php
        /**
         * @since 4.0.0.
         */
        do_action('woocommerce_before_add_to_cart_quantity');
        ?>

        <p class="single_quantity">
            <?php
            /**
             * @since 2.1.0.
             */

            /**
             * @since 4.0.0.
             */
             $p_max = get_post_meta($product->get_id(), '_bakala_max_qty', true);
        $g_max = isset($bakala_options['max_qty']) ? $bakala_options['max_qty'] : 0;
        $terms = get_the_terms($product->get_id(), 'product_cat');
        if (!empty($terms)) {
            foreach ($terms as $term) {
                $term_max_qty = get_term_meta($term->term_id, 'bakala_max_qty', true);
                $term_min_qty = get_term_meta($term->term_id, 'bakala_min_qty', true);
                if (!empty($term_max_qty)) {
                    $c_max = $term_max_qty;
                    break;
                }
                if (!empty($term_min_qty)) {
                    $c_min = $term_min_qty;
                    break;
                }
            }
        }
        if (!empty($p_max)) {
            $max_allowed_quantity = $p_max;
        } elseif (empty($p_max) && !empty($c_max)) {
            $max_allowed_quantity = $c_max;
        } elseif (empty($p_max) && empty($c_max) && !empty($g_max)) {
            $max_allowed_quantity = $g_max;
        }
        $p_min = get_post_meta($product->get_id(), '_bakala_min_qty', true);
        $g_min = isset($bakala_options['min_qty']) ? $bakala_options['min_qty'] : 0;
        if (!empty($p_min)) {
            $min_allowed_quantity = $p_min;
        } elseif (empty($p_min) && !empty($c_min)) {
            $min_allowed_quantity = $c_min;
        } elseif (empty($p_min) && empty($c_min) && !empty($g_min)) {
            $min_allowed_quantity = $g_min;
        }
    
            if (!white_catis_catalog_mode()) :
                woocommerce_quantity_input(array(
                    'input_name' => 'quantity',
                    'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                    'max_value' =>  5,
                    'input_value' => isset($_POST['quantity']) ? wc_stock_amount($_POST['quantity']) : $product->get_min_purchase_quantity(),
                ));
            endif;

            /**
             * @since 4.0.0.
             */
            do_action('woocommerce_after_add_to_cart_quantity');
            ?>
        </p>


       
            <div class="add-to-cart-holder">

                <button type="submit" name="add-to-cart" value="<?php echo esc_attr($product->get_id()); ?>"
                        class="single_add_to_cart_button button dk-button <?= $bakala_options['floating-cart'] == 1 ? 'ajax_btn' : null ?>">
                    <span class="dk-button-container hasIcon">
                        <?php echo esc_html($btn_text); ?>
                    </span>
                </button>


            </div>
            <?php do_action('woocommerce_after_add_to_cart_button'); ?>
        <input type="hidden" name="add-to-cart" value="<?php echo absint($product->get_id()); ?>"/>
        <input type="hidden" name="product_id" value="<?php echo absint($product->get_id()); ?>"/>
        <input type="hidden" name="variation_id" class="variation_id" value="0"/>
    </div>
    <?php else: ?>
    <div class="bakala-outofstock">
			<div class="bakala-outofstock-title">
				<p class="bakala-outofstock-text"><?= __('Coming soon', 'bakala') ?></p>
			</div>
			<p class="bakala-outofstock-alert"><?= __('This product will be available soon.', 'bakala') ?></p>
		</div>
        <?php endif;
 }else{
	 ?>
    <div class="bakala-outofstock">

                <div class="bakala-outofstock-title">
                    <p class="bakala-outofstock-text"><?= __('unavailable', 'bakala') ?></p>
                </div>
              
                <p class="bakala-outofstock-alert"><?= __('This product is not available at the moment, but you can ring the bell and we will inform you as soon as it is available', 'bakala') ?></p>
            </div>
		<?php
 }
		 ?>

<?php }