<?php
/**
 * External product add to cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/add-to-cart/external.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 100.0.0
 */

defined( 'ABSPATH' ) || exit;

global $post,$product,$bakala_options;

$button_text=get_post_meta( $post->ID, '_button_text', true );

if (empty($bakala_options['add_to_cart_button_text']) && get_post_meta($post->ID, '_bakala_change_text_atcb', true)==false) {
    $text = $button_text;
}elseif (get_post_meta($post->ID, '_bakala_change_text_atcb', true)) {
    $text = get_post_meta($post->ID, '_bakala_change_text_atcb', true);
} else {
    $text = $bakala_options['add_to_cart_button_text'];
}

do_action( 'woocommerce_before_add_to_cart_form' ); ?>

	<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
<?php if(is_mobile_or_tablet()){ 

if ($bakala_options['cart_fixed']) {
?>
    <?php if (!white_catis_catalog_mode() && get_post_meta($product->get_id(), '_coming_soon_product', true) != "on") : ?>
        <?php if ($product->is_in_stock()) : ?>
            <?php if ($bakala_options['price_add_holder'] == 1) :
            ?>

                <div class="add-to-cart-holder" style="<?= $product->get_stock_quantity() < 5 ? 'display:block !important;' : null; ?>">
                    <?php if ($product->get_stock_quantity() < 5 && $bakala_options['alert_stock'] == 1 && $product->get_stock_quantity() > 0) { ?>
                        <div class="alert-stock">
                            <div>تنها <span><?= $product->get_stock_quantity() ?></span></span> عدد در انبار باقی مانده</div>
                        </div>
                    <?php } ?>
                    <div class="bakala-button-price">
                        <div class="add-to-cart-button">

                            <a href="<?php echo esc_url($product_url); ?>" class="single_add_to_cart_button button alt external-product-btn" target="_blank" rel="nofollow noopener noreferer">
                                <?php echo esc_html($text); ?>
                            </a>

                        </div>
                        <div class="bakala-product-price">
                            <div id="price-holder">
                                <?php
                                if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                                    <p><?php echo __("Coming soon", "bakala"); ?></p>
                                <?php } else { ?>
                                    <span class="price"><?php echo $product->get_price_html(); ?></span>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>

            <?php else :
                wc_get_template('single-product/price.php');
            ?>

                <div class="add-to-cart-holder">
                    <div class="add-to-cart-button">

                        <a href="<?php echo esc_url($product_url); ?>" class="single_add_to_cart_button button alt external-product-btn" target="_blank" rel="nofollow noopener noreferer">
                            <?php echo esc_html($text); ?>
                        </a>
                    </div>
                </div>

            <?php endif; ?>
        <?php else :
        ?>

            <div class="add-to-cart-holder">
                <div class="bakala-button-price">
                    <div class="add-to-cart-button">
                        <button type="button" class="button alt">
                            <?= __('ناموجود', 'bakala') ?>
                        </button>
                    </div>
                    <div class="bakala-product-price">
                        <span class="price"><?php echo $product->get_price_html(); ?></span>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>

<?php
} else {
?>
    <div class="bakala-product-price">
        <div class="price-section clearfix">

            <?php
            if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                <p><?php echo __("Coming soon", "bakala"); ?></p>
            <?php } else { ?>
                <p class="price"><?php echo $product->get_price_html(); ?></p>
            <?php } ?>
        </div>
    </div>
    <?php do_action('woocommerce_before_add_to_cart_button'); ?>
    <div class="add-to-cart-holder-normal" style="margin-top: 20px;">


        <a href="<?php echo esc_url($product_url); ?>" class="single_add_to_cart_button button alt external-product-btn" target="_blank" rel="nofollow noopener noreferer">
            <?php echo esc_html($text); ?>
        </a>
        <?php do_action('woocommerce_after_add_to_cart_button'); ?>
    </div>
<?php
}
 }else{ ?>
	<a href="<?php echo esc_url( $product_url ); ?>" class="single_add_to_cart_button button alt external-product-btn" target="_blank" rel="nofollow noopener noreferer">
	   <?php echo esc_html( $text ); ?>
	</a>
<?php } ?>
	<?php wc_query_string_form_fields( $product_url ); ?>

	<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>

<?php do_action( 'woocommerce_after_add_to_cart_form' ); ?>