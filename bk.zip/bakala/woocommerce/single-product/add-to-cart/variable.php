<?php

/**
 * Variable product add to cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/add-to-cart/variable.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 100.0.0
 */
defined('ABSPATH') || exit;
global $product, $bakala_options, $post;
$single_style = $bakala_options['single_product_style'];
$attribute_keys = array_keys($attributes);
$variations_json = wp_json_encode($available_variations);
$variations_attr = function_exists('wc_esc_json') ? wc_esc_json($variations_json) : _wp_specialchars($variations_json, ENT_QUOTES, 'UTF-8', true);
$rating_count = $product->get_rating_count();
$review_count = $product->get_review_count();
$average = $product->get_average_rating();
$comments = get_comments(array(
    'post_id' => $product->get_id(),
	 'type' => 'review',
    'status' => 'approve', // Only approved comments
    'number' => 1, // Limit to 1 comment
));

if (!empty($comments)) {
    // There is at least one comment for the product
    $first_comment = $comments[0];
    $first_comment_rating = get_comment_meta($first_comment->comment_ID, 'comment_rates', true);
    if (!empty($first_comment_rating)) {
        // Display the rating of the first comment if available
        $average = array_sum($first_comment_rating) / count($first_comment_rating);
    }
}
$short_desc = apply_filters('woocommerce_short_description', $post->post_excerpt);


do_action('woocommerce_before_add_to_cart_form');

if (is_mobile_or_tablet()) {
    ?>
    <form class="variations_form cart"
          action="<?php echo esc_url(apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink())); ?>"
          method="post" enctype='multipart/form-data' data-product_id="<?php echo absint($product->get_id()); ?>"
          data-product_variations="<?php echo $variations_attr; // WPCS: XSS ok.
          ?>">
        <?php do_action('woocommerce_before_variations_form'); ?>

        <?php if (empty($available_variations) && false !== $available_variations) : ?>
            <p class="stock out-of-stock"><?php echo esc_html(apply_filters('woocommerce_out_of_stock_message', __('This product is currently out of stock and unavailable.', 'woocommerce'))); ?></p>
        <?php else : ?>
            <table class="variations" cellspacing="0">
                <tbody>
                <?php foreach ($attributes as $attribute_name => $options) : ?>
                    <tr>
                        <th class="label"><label
                                    for="<?php echo esc_attr(sanitize_title($attribute_name)); ?>"><?php echo wc_attribute_label($attribute_name); // WPCS: XSS ok.
                                ?></label></th>
                        <td class="value">
                            <?php
                            wc_dropdown_variation_attribute_options(
                                array(
                                    'options' => $options,
                                    'attribute' => $attribute_name,
                                    'product' => $product,
                                )
                            );
                            if ($bakala_options['show_reset_variations']) {
                                echo end($attribute_keys) === $attribute_name ? wp_kses_post(apply_filters('woocommerce_reset_variations_link', '<a class="reset_variations" href="#">' . esc_html__('Clear', 'woocommerce') . '</a>')) : '';
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <div class="variable-description"></div>
            <?php if ($bakala_options['price_add_holder'] == 0 && $bakala_options['cart_fixed'] == 1) { ?>
                <div class="bakala-product-price">
                    <div id="price-holder"><?= $product->get_price_html(); ?></div>
                </div>
                <?php

            }
            do_action('woocommerce_after_variations_table');
            $stock = wc_get_stock_html($product);
            if (empty($stock)) {
                echo '<div class="product-stock-count"></div>';
            }
            if (isset($bakala_options['product_warranty_taxonomy'])) {
                $warranty_taxonomy = $bakala_options['product_warranty_taxonomy'];
                $warranty = $product->get_attribute($warranty_taxonomy);
            }

            if ($warranty) { ?>
                <div class="warranty-info">
                    <span class="vendor-warranty">
                        <?php echo $warranty; ?>
                    </span>
                </div>
            <?php }
            ?>

            <div class="single_variation_wrap">
                <?php
                /**
                 * Hook: woocommerce_before_single_variation.
                 */
                do_action('woocommerce_before_single_variation');

                /**
                 * Hook: woocommerce_single_variation. Used to output the cart button and placeholder for variation data.
                 *
                 * @since 2.4.0
                 * @hooked woocommerce_single_variation - 10 Empty div for variation data.
                 * @hooked woocommerce_single_variation_add_to_cart_button - 20 Qty and cart button.
                 */
                do_action('woocommerce_single_variation');

                /**
                 * Hook: woocommerce_after_single_variation.
                 */
                do_action('woocommerce_after_single_variation');
                ?>
            </div>
        <?php endif; ?>

        <?php
        // do_action('bakala_better_price_hook');

        do_action('woocommerce_after_variations_form'); ?>
    </form>

    <?php
    do_action('woocommerce_after_add_to_cart_form');
} else {
    ?>
    <?php if ($bakala_options['single_product_style'] == 'boxed') : ?>
        <form class="variations_form cart"
              action="<?php echo esc_url(apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink())); ?>"
              method="post" enctype='multipart/form-data' data-product_id="<?php echo absint($product->get_id()); ?>"
              data-product_variations="<?php echo $variations_attr; // WPCS: XSS ok.
              ?>">
            <?php do_action('woocommerce_before_variations_form'); ?>
            <div class="row main-content">
                <div class="col-md-7">
                    <?php if ($single_style == 'boxed') { ?>
                        <div class="col-md-12 header">
                            <div class="col-md-8 info-header">
<?php do_action('woocommerce_single_product_before_title') ?>
                                <div class="product-title">
                                    <?php
                                    if ($bakala_options['product_brand_taxonomy_enable'] == 1 && $bakala_options['product_brand_taxonomy_img'] == 1) {
                                        white_cattemplate_single_brand();
                                    }
                                    ?>
                                    <h1>
                                        <?php the_title(); ?>
                                    </h1>
                                </div>

                                <small class="product-english-name"><?php echo get_post_meta($product->get_id(), 'product_english_name', true); ?></small>
                                <?php
                                $prodterms = get_the_terms($product->get_id(), 'product_cat');
                                if ($bakala_options['show_category'] && is_array($prodterms)) {


                        $term_ids = wp_list_pluck($prodterms, 'term_id');

                        $parents = array_filter(wp_list_pluck($prodterms, 'parent'));

                        $term_ids_not_parents = array_diff($term_ids, $parents);

                        $terms_not_parents = array_intersect_key($prodterms, $term_ids_not_parents);
                        ?>
                        <span class="posted_in">
                            <span style="color:#666"> <?= __('دسته بندی:', 'bakala') ?></span>
                            <?php
                            $terms = get_the_terms($product->get_id(), 'product_cat');
                            $sortedTerms = array(); // empty array to hold the sorted terms
                            bakala_sort_terms_hierarchically($terms, $sortedTerms);
                            if ($bakala_options['category_style'] == 'all') {
                                bakala_display_category_hierarchy($sortedTerms);

                            } elseif ($bakala_options['category_style'] == 'main') {
                                if (is_plugin_active('wordpress-seo/wp-seo.php')) {
                                    $primary_cat_id = get_post_meta($product->get_id(), '_yoast_wpseo_primary_' . 'product_cat', true);
                                    if ($primary_cat_id) {
                                        $primary_cat = get_term($primary_cat_id, $taxonomy);
                                        if (isset($primary_cat->name)) {
                                            ?>
                                            <a href="<?= get_term_link($primary_cat->term_id, 'product_cat'); ?>"><?= $primary_cat->name; ?></a>
                                            <?php
                                        }
                                    } else {
                                        foreach ($prodterms as $prodterm) {
                                            if ($prodterm->parent == 0) {
                                                ?>
                                                <a href="<?= get_term_link($prodterm->term_id, 'product_cat'); ?>"><?= $prodterm->name; ?></a>
                                                <?php
                                                if (next($prodterms)) {
                                                    echo '،';
                                                }
                                            }
                                        }
                                    }
                                } elseif (is_plugin_active('seo-by-rank-math/rank-math.php')) {
                                    $primary_cat_id = get_post_meta($product->get_id(), 'rank_math_primary_product_cat', true);
                                    $has_primary_cat = false;

                                    if ($primary_cat_id) {
                                        $primary_cat = get_term($primary_cat_id, $taxonomy);
                                        if (isset($primary_cat->name)) {
                                            $term_link = get_term_link($primary_cat->term_id, 'product_cat');
                                            if (!is_wp_error($term_link)) {
                                                $has_primary_cat = true;
                                                ?>
                                                <a href="<?= esc_url($term_link); ?>"><?= esc_html($primary_cat->name); ?></a>
                                            <?php
                                            }
                                        }
                                    }
                                    if (!$has_primary_cat) {
                                        bakala_display_category_hierarchy($sortedTerms);
                                    }
                                }else {
                                    foreach ($prodterms as $prodterm) {
                                        if ($prodterm->parent == 0) {
                                            ?>
                                            <a href="<?= get_term_link($prodterm->term_id, 'product_cat'); ?>"><?= $prodterm->name; ?></a>
                                            <?php
                                            if (next($prodterms)) {
                                                echo '،';
                                            }
                                        }
                                    }
                                }
                            } else {
                                foreach ($terms_not_parents as $term_not_parent) {
                                    ?>
                                    <a href="<?= get_term_link($term_not_parent->term_id, 'product_cat'); ?>"><?= $term_not_parent->name; ?></a>
                                    <?php
                                    if (next($terms_not_parents)) {
                                        echo '،';
                                    }
                                }
                            }
                            ?>
                        </span>

                        <?php
                    }
                                do_action('bk_after_category_meta');
                                ?>
                                <div class="dk-product-meta product_meta">

                                    <?php if ($bakala_options['show_sku'] || $bakala_options['show_category']) { ?>
                                        <?php bakala_get_product_brand(); ?>
                                        <?php if ($bakala_options['show_sku']) {
                                            if (wc_product_sku_enabled() && ($product->get_sku()) || bakala_get_variations_skus($product->get_id())) : ?>
                                                <span class="sku_wrapper"><?php esc_html_e('SKU:', 'woocommerce'); ?> <span
                                                            class="sku"><?php echo ($sku = $product->get_sku()) ? $sku : esc_html__('N/A', 'woocommerce'); ?></span></span>
                                            <?php endif;
                                        }
                                        if ($bakala_options['show_category'] && $bakala_options['single_product_style'] == 'bakala') {
                                            echo "";
                                            echo wc_get_product_category_list($product->get_id(), ', ', '<span class="posted_in">' . _n('Category:', 'Categories:', count($product->get_category_ids()), 'woocommerce') . ' ', '</span>');
                                            echo "";
                                        }
                                        ?>

                                    <?php }
									if($average > 0){
							if($rating_count > 0){
									$count = $rating_count;
								}elseif($rating_count < 1 && !empty($comments)){
									$count = get_comment_count($product->get_id())['approved'];
								}else{
									$count = 0;
								}
										$comments = get_comments( array(
    'post_id' => get_the_ID(),
    'type'    => 'review',
) );

$comments_number = count( $comments );
                        ?>
                        <div class="rate">
                            <div class="stars">
                                <div class="star-average">
                                    <i class="bakala-icon icon-star"></i>
                                    <span><?= $average > 0 ? round($average) : 5; ?></span>
                                </div>
                                <span class="star-count"><?= "از $count رای"; ?></span>
                            </div>
                            <i class="fas fa-circle"></i>
                            <div class="comments">
                                <?= $comments_number . ' ' . __(' Comment ', 'bakala'); ?>
                            </div>
                        </div>
                        <?php
						}
									 if (!empty(get_post_meta($product->get_id(), '_bakala_expiration_date', true))) { ?>
                                        <div class="bakala_expire_date">
                                            <span class="bakala_expire_date_title"><?= __('Expire Date', 'bakala') ?>:</span>
                                            <span class="bakala_expire_date_val"><?= get_post_meta($product->get_id(), '_bakala_expiration_date', true); ?></span>
                                        </div>
                                    <?php } ?>
                                    <?php if (!empty(get_post_meta($product->get_id(), '_bakala_manufacture_date', true))) { ?>
                                        <div class="bakala_manufacture_date">
                                            <span class="bakala_manufacture_date_title"><?= __('Manufacture Date', 'bakala') ?>:</span>
                                            <span class="bakala_manufacture_date_val"><?= get_post_meta($product->get_id(), '_bakala_manufacture_date', true); ?></span>
                                        </div>
                                    <?php } ?>
                                </div>
                                <?php if (isset($bakala_options['new_comment_template']) && $bakala_options['new_comment_template'] == true) {
                                    $units_sold = $product->get_total_sales();
                                    $comments = get_comments(array('post_id' => get_the_id(), 'status' => 'approve'));
                                    $i = 0;
                                    if ($comments) :
                                        foreach ($comments as $comment) {
                                            $recommendation = get_comment_meta($comment->comment_ID, 'recommendation', true);
                                            if ($recommendation == 'yes') $i++;
                                        }
                                    endif;

                                    ?>
                                    <?php if ($i > 0 && $bakala_options['recomendation_product'] == 1) : ?>
                                        <div class="recomendation-product">
                                            <i class="bakala-icon tick"></i>
                                            <span><?php echo sprintf(__('%s (%d) نفر از خریداران، این کالا را پیشنهاد کرده اند', 'bakala'), ceil($i / $units_sold * 100) . '%', $i); ?></span>
                                        </div>
                                    <?php endif; ?>
                                <?php } else { ?>
                                    <div class="white_catrating">
                                        <div class="disable-stars">
                                            <div style="width:<?php echo ($average / 5) * 100; ?>%"
                                                 class="enable-stars"></div>
                                        </div>
                                        <div class="rating-count">
									<span><?php echo _e('Out Of ', 'bakala');
                                        echo $rating_count;
                                        echo _e(' Rate', 'bakala'); ?></span>
                                        </div>
                                    </div>
                                <?php } ?>

                            </div>
                        </div>
                    <?php } ?>
                    <?php
                    if ($bakala_options['short_desc_position'] == 'after_title' && !empty($short_desc)) {
                        echo $short_desc;
                    }
                    if (empty($available_variations) && false !== $available_variations) : ?>
                        <p class="stock out-of-stock"><?php echo esc_html(apply_filters('woocommerce_out_of_stock_message', __('This product is currently out of stock and unavailable.', 'woocommerce'))); ?></p>
                    <?php else : ?>
                        <table class="variations" cellspacing="0">
                            <tbody>
                            <?php foreach ($attributes as $attribute_name => $options) : ?>
                                <tr>
                                    <td class="label"><label
                                                for="<?php echo esc_attr(sanitize_title($attribute_name)); ?>"><?php echo wc_attribute_label($attribute_name); // WPCS: XSS ok.
                                            ?></label></td>
                                    <td class="value">
                                        <?php
                                        wc_dropdown_variation_attribute_options(array(
                                            'options' => $options,
                                            'attribute' => $attribute_name,
                                            'product' => $product,
                                        ));
                                        if ($bakala_options['show_reset_variations']) {
                                            echo end($attribute_keys) === $attribute_name ? wp_kses_post(apply_filters('woocommerce_reset_variations_link', '<a class="reset_variations" href="#">' . esc_html__('Clear', 'woocommerce') . '</a>')) : '';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif;

                   if ($bakala_options['main_features_position'] != 'left') {
    // دریافت ویژگی‌های اصلی محصول
    $mainfea = get_post_meta($product->get_id(), 'main_features', true);
if (empty($mainfea) && isset($bakala_options['mainfea_auto']) && $bakala_options['mainfea_auto'] == 1) {
    global $product;
    $mainfea = [];

    // دریافت ویژگی‌های محصول به عنوان یک آرایه
    foreach ($product->get_attributes() as $attribute) {
        $values = [];

        // بررسی اینکه آیا ویژگی دارای اصطلاحات (terms) است
        if ($attribute->is_taxonomy()) {
            $terms = wc_get_product_terms($product->get_id(), $attribute->get_name(), ['fields' => 'names']);
            $values = $terms;
        } else {
            // اگر ویژگی متن ساده است
            $values = $attribute->get_options();
        }

        $mainfea[] = [
            'title' => wc_attribute_label($attribute->get_name()), // نام ویژگی
            'value' => implode(', ', $values), // مقادیر ویژگی
        ];
    }
}



    if ($mainfea) { ?>
        <div class="main-features-title"> <?php echo _e('Product Features', 'bakala'); ?> </div>
        <?php if ($bakala_options['main_features_style_pc'] == 'table') { ?>
            <div class="main-features table_style">
                <?php
                $i = 0;
                foreach ($mainfea as $singlefea) {
                    $i++; ?>
                    <div class="main-features-item">
                        <div class="main-features-item-title">
                            <span class="title"><?php echo esc_html($singlefea['title']); ?></span>
                        </div>
                        <div class="main-features-item-value">
                            <span class="value"><?php echo esc_html($singlefea['value']); ?></span>
                        </div>
                    </div>
                <?php } ?>
            </div>
        <?php } elseif ($bakala_options['main_features_style_pc'] == 'box') { ?>
            <div class="bakala-product-specifications">
                <div class="bakala-product-specifications-wrap">
                    <ul class="bakala-product-specifications-list">
                        <?php 
                        $i = 0;
                        foreach ($mainfea as $singlefea) {
                            $i++;
                            if ($i < 6) { ?>
                                <li class="bakala-product-specification-item">
                                    <div class="bakala-product-specification-item-wrap">
                                        <p class="bakala-product-specification-item-label"><?= esc_html($singlefea['title']) ?></p>
                                        <p class="bakala-product-specification-item-value"><?= esc_html($singlefea['value']) ?></p>
                                    </div>
                                </li>
                            <?php } 
                        } ?>
                    </ul>
                </div>
                <div class="bakala-product-specifications-all">
                    <hr class="bakala-product-specifications-all-seprator">
                    <button type="button" class="bakala-product-specifications-all-button">
                        <div class="bakala-product-specifications-all-button-text">
                            مشاهده همه ویژگی‌ها
                            <i class="bakala-icon icon-left-arrow"></i>
                        </div>
                    </button>
                    <hr class="bakala-product-specifications-all-seprator">
                </div>
            </div>
        <?php } else { ?>
            <ul class="main-features">
                <?php 
                $i = 0;
                foreach ($mainfea as $singlefea) {
                    $i++; ?>
                    <li class="<?php if ($i > 4) echo 'hidden-mainfea'; ?>">
                        <i class="icon-circle"></i>
                        <span class="title"><?php echo esc_html($singlefea['title']); ?></span>:
                        <span class="value"><?php echo esc_html($singlefea['value']); ?></span>
                    </li>
                <?php }
                if ($i > 4) {
                    echo '<span id="more-link" class="">' . __("More items +", "bakala") . '</span>';
                } ?>
            </ul>
        <?php }
    }
}

                    do_action('woocommerce_single_product_end');

                    ?>

                </div>

                <div class="col-md-5">
                    <div class="single_variation_wrap">
                        <?php
                        /**
                         * Hook: woocommerce_before_single_variation.
                         */
                        do_action('woocommerce_before_single_variation');
                        /**
                         * Hook: woocommerce_single_variation. Used to output the cart button and placeholder for variation data.
                         *
                         * @since 2.4.0
                         * @hooked woocommerce_single_variation - 10 Empty div for variation data.
                         * @hooked woocommerce_single_variation_add_to_cart_button - 20 Qty and cart button.
                         */
                        /**
                         * Hook: woocommerce_after_single_variation.
                         */
                        do_action('woocommerce_after_single_variation');
                        ?>
                    </div>
                </div>
                <?php do_action('woocommerce_after_variations_form'); ?>
            </div>
        </form>

        <?php
        do_action('woocommerce_after_add_to_cart_form');
    else : ?>
        <form class="variations_form cart"
              action="<?php echo esc_url(apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink())); ?>"
              method="post" enctype='multipart/form-data' data-product_id="<?php echo absint($product->get_id()); ?>"
              data-product_variations="<?php echo $variations_attr; // WPCS: XSS ok.
              ?>">
            <?php do_action('woocommerce_before_variations_form'); ?>

            <?php if (empty($available_variations) && false !== $available_variations) : ?>
                <p class="stock out-of-stock"><?php echo esc_html(apply_filters('woocommerce_out_of_stock_message', __('This product is currently out of stock and unavailable.', 'woocommerce'))); ?></p>
            <?php else : ?>
                <table class="variations" cellspacing="0">
                    <tbody>
                    <?php foreach ($attributes as $attribute_name => $options) : ?>
                        <tr>
                            <td class="label"><label
                                        for="<?php echo esc_attr(sanitize_title($attribute_name)); ?>"><?php echo wc_attribute_label($attribute_name); // WPCS: XSS ok.
                                    ?></label></td>
                            <td class="value">
                                <?php
                                wc_dropdown_variation_attribute_options(array(
                                    'options' => $options,
                                    'attribute' => $attribute_name,
                                    'product' => $product,
                                ));
                                if ($bakala_options['show_reset_variations']) {
                                    echo end($attribute_keys) === $attribute_name ? wp_kses_post(apply_filters('woocommerce_reset_variations_link', '<a class="reset_variations" href="#">' . esc_html__('Clear', 'woocommerce') . '</a>')) : '';
                                }
                                ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="single_variation_wrap">
                    <?php
                    /**
                     * Hook: woocommerce_before_single_variation.
                     */
                    do_action('woocommerce_before_single_variation');
                    /**
                     * Hook: woocommerce_single_variation. Used to output the cart button and placeholder for variation data.
                     *
                     * @since 2.4.0
                     * @hooked woocommerce_single_variation - 10 Empty div for variation data.
                     * @hooked woocommerce_single_variation_add_to_cart_button - 20 Qty and cart button.
                     */
                    do_action('bakala_before_atc');
                    do_action('woocommerce_single_variation');
                    /**
                     * Hook: woocommerce_after_single_variation.
                     */
                    do_action('woocommerce_after_single_variation');
                    ?>
                </div>
            <?php endif; ?>

            <?php do_action('woocommerce_after_variations_form'); ?>
        </form>

        <?php
        do_action('woocommerce_after_add_to_cart_form');
    endif;
}