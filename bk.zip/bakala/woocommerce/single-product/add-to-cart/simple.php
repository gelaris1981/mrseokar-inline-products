<?php

/**
 * Simple product add to cart
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/add-to-cart/simple.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see        https://docs.woocommerce.com/document/template-structure/
 * @author        WooThemes
 * @package    WooCommerce/Templates
 * @version 100.0.0
 */
if (!defined('ABSPATH')) {
    exit;
}

global $product, $bakala_options, $post;
$is_remove = false;
if (isset($bakala_options['add_to_cart_button_remove_category']) && is_array($bakala_options['add_to_cart_button_remove_category'])) {
    $add_to_cart_button_remove_category = array_values($bakala_options['add_to_cart_button_remove_category']);
    $intArray = array_map(
        function ($value) {
            return (int)$value;
        },
        $add_to_cart_button_remove_category
    );
    $is_remove = has_term($intArray, 'product_cat');
}
$btn_text = $product->single_add_to_cart_text();
if (empty($bakala_options['add_to_cart_button_text']) && get_post_meta($post->ID, '_bakala_change_text_atcb', true) == false) {
    $btn_text = $product->single_add_to_cart_text();
} elseif (get_post_meta($post->ID, '_bakala_change_text_atcb', true)) {
    $btn_text = get_post_meta($post->ID, '_bakala_change_text_atcb', true);
} elseif ($is_remove) {
    $btn_text = $bakala_options['add_to_cart_button_text'];
} elseif ($bakala_options['add_to_cart_button_change_text_all']) {
    $btn_text = $bakala_options['add_to_cart_button_text'];
}
echo wc_get_stock_html($product); // WPCS: XSS ok.
$atcb = bakala_remove_add_to_card_button();
$has_lcategory = false;
if (!empty($bakala_options['add_to_cart_button_change_link_category'])) {
    $add_to_cart_button_change_link_category = array_values($bakala_options['add_to_cart_button_change_link_category']);
    $l_categories = array_map(
        function ($value) {
            return (int)$value;
        },
        $add_to_cart_button_change_link_category
    );
    $has_lcategory = has_term($l_categories, 'product_cat');
}
?>

<?php do_action('woocommerce_before_add_to_cart_form'); ?>

<?php if ($product->is_in_stock()) :
    $sku = $product->get_sku();
    if (is_mobile_or_tablet()) {

        ?>
        <form class="cart <?= $bakala_options['cart_fixed'] ? 'cart-fixed' : 'cart-normal'; ?>" method="post"
              enctype='multipart/form-data'>
            <?php
            if ($bakala_options['cart_fixed']) {
                ?>
                <?php if (!white_catis_catalog_mode() && get_post_meta($product->get_id(), '_coming_soon_product', true) != "on") : ?>
                    <?php if ($product->is_in_stock()) : ?>
                        <?php if ($bakala_options['price_add_holder'] == 1) :
                            ?>

                            <div class="add-to-cart-holder <?= !$atcb ? 'remove_btn' : null ?>"
                                 style="<?= $product->get_stock_quantity() < 5 ? 'display:block !important;' : null; ?>">
                                <?php if ($product->get_stock_quantity() < 5 && $bakala_options['alert_stock'] == 1 && $product->get_stock_quantity() > 0) { ?>
                                    <div class="alert-stock">
                                        <div>تنها <span><?= $product->get_stock_quantity() ?></span></span> عدد در انبار
                                            باقی مانده
                                        </div>
                                    </div>
                                <?php } ?>
                                <div class="bakala-button-price">
                                    <?php if ($atcb) { ?>
                                        <div class="add-to-cart-button">
                                            <div id="quantity-holder">
                                                <?php
                                                do_action('woocommerce_before_add_to_cart_quantity');
                                                woocommerce_quantity_input(array(
                                                    'input_name' => 'quantity',
                                                    'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                                                    'max_value' => $product->get_max_purchase_quantity() ? $product->get_max_purchase_quantity() : -1,
                                                    'input_value' => isset($_POST['quantity']) ? wc_stock_amount(wp_unslash($_POST['quantity'])) : $product->get_min_purchase_quantity(),
                                                    'product_name' => $product->get_name(),
                                                ));
                                                do_action('woocommerce_after_add_to_cart_quantity');
                                                ?>
                                            </div>
                                            <?php if ($bakala_options['add_to_cart_type'] == 0) : ?>
                                                <a class='button single_add_to_cart_button alt dk-button add_to_cart_button ajax_add_to_cart'
                                                   href="<?php echo $product->add_to_cart_url() ?>"
                                                   value="<?php echo esc_attr($product->get_id()); ?>"
                                                   class="ajax_add_to_cart add_to_cart_button"
                                                   data-product_id="<?php echo get_the_ID(); ?>"
                                                   data-product_sku="<?php echo esc_attr($sku) ?>"
                                                   aria-label="Add <?php the_title_attribute() ?> to your cart"
                                                   data-quantity="1"><?php echo esc_html($btn_text); ?></a>
                                            <?php else : ?>
                                                <a class='button single_add_to_cart_button alt dk-button add_to_cart_button ajax_add_to_cart has-icon'
                                                   href="<?php echo $product->add_to_cart_url() ?>"
                                                   value="<?php echo esc_attr($product->get_id()); ?>"
                                                   class="ajax_add_to_cart add_to_cart_button"
                                                   data-product_id="<?php echo get_the_ID(); ?>"
                                                   data-product_sku="<?php echo esc_attr($sku) ?>"
                                                   aria-label="Add <?php the_title_attribute() ?> to your cart"
                                                   data-quantity="1"></a>
                                            <?php endif; ?>

                                        </div>
                                    <?php } ?>
                                    <div class="bakala-product-price">
                                        <div id="price-holder">
                                            <?php
                                            if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                                                <p><?php echo __("Coming soon", "bakala"); ?></p>
                                            <?php } else { ?>
                                                <span class="price"><?php echo $product->get_price_html(); ?></span>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php else :
                            wc_get_template('single-product/price.php');
                            ?>

                            <div class="add-to-cart-holder">
                                <div class="add-to-cart-button">
                                    <div id="quantity-holder">
                                        <?php
                                        do_action('woocommerce_before_add_to_cart_quantity');
                                        woocommerce_quantity_input(array(
                                            'input_name' => 'quantity',
                                            'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                                            'max_value' => $product->get_max_purchase_quantity() ? $product->get_max_purchase_quantity() : -1,
                                            'input_value' => isset($_POST['quantity']) ? wc_stock_amount(wp_unslash($_POST['quantity'])) : $product->get_min_purchase_quantity(),
                                            'product_name' => $product->get_name(),
                                        ));
                                        do_action('woocommerce_after_add_to_cart_quantity');
                                        ?>
                                    </div>
                                    <a class='button single_add_to_cart_button alt dk-button add_to_cart_button ajax_add_to_cart'
                                       href="<?php echo $product->add_to_cart_url() ?>"
                                       value="<?php echo esc_attr($product->get_id()); ?>"
                                       class="ajax_add_to_cart add_to_cart_button"
                                       data-product_id="<?php echo get_the_ID(); ?>"
                                       data-product_sku="<?php echo esc_attr($sku) ?>"
                                       aria-label="Add <?php the_title_attribute() ?> to your cart"
                                       data-quantity="1"><?php echo esc_html($btn_text); ?></a>
                                </div>
                            </div>

                        <?php endif; ?>
                    <?php else :
                        ?>

                        <div class="add-to-cart-holder">
                            <div class="bakala-button-price">
                                <div class="add-to-cart-button">
                                    <button type="button" class="button alt">
                                        <?= __('ناموجود', 'bakala') ?>
                                    </button>
                                </div>
                                <div class="bakala-product-price">
                                    <span class="price"><?php echo $product->get_price_html(); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <?php
            } else {
                ?>
                <div class="bakala-product-price">
                    <div class="price-section clearfix">

                        <?php
                        if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                            <p><?php echo __("Coming soon", "bakala"); ?></p>
                        <?php } else { ?>
                            <p class="price"><?php echo $product->get_price_html(); ?></p>
                        <?php } ?>
                    </div>
                </div>
                <?php do_action('woocommerce_before_add_to_cart_button'); ?>
                <div class="add-to-cart-holder-normal" style="margin-top: 20px;">
                    <?php
                    do_action('woocommerce_before_add_to_cart_quantity');

                    woocommerce_quantity_input(array(
                        'input_name' => 'quantity',
                        'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                        'max_value' => $product->get_max_purchase_quantity() ? $product->get_max_purchase_quantity() : -1,
                        'input_value' => isset($_POST['quantity']) ? wc_stock_amount(wp_unslash($_POST['quantity'])) : $product->get_min_purchase_quantity(),
                        'product_name' => $product->get_name(),
                    ));

                    do_action('woocommerce_after_add_to_cart_quantity');
                    ?>

                    <?php if ($bakala_options['floating-cart'] == 1) : ?>

                        <a class='button single_add_to_cart_button dk-button add_to_cart_button ajax_add_to_cart'
                           href="<?php echo $product->add_to_cart_url() ?>"
                           value="<?php echo esc_attr($product->get_id()); ?>"
                           class="ajax_add_to_cart add_to_cart_button" data-product_id="<?php echo get_the_ID(); ?>"
                           data-product_sku="<?php echo esc_attr($sku) ?>"
                           aria-label="Add <?php the_title_attribute() ?> to your cart" data-quantity="1"><span
                                    class="dk-button-container hasIcon">
                                    <?php echo esc_html($btn_text); ?>
                                </span>
                        </a>

                    <?php else : ?>
                        <button type="submit" name="add-to-cart" value="<?php echo esc_attr($product->get_id()); ?>"
                                class="single_add_to_cart_button button dk-button">
                                <span class="dk-button-container hasIcon">
                                    <?php echo esc_html($product->single_add_to_cart_text()); ?>
                                </span>
                        </button>
                    <?php endif; ?>
                    <?php do_action('woocommerce_after_add_to_cart_button'); ?>
                </div>
                <?php
            }

            if ($atcb == false && ($bakala_options['add_to_cart_button_change_link_all'] == 1 || $has_lcategory || !empty(get_post_meta($post->ID, '_bakala_change_link_atcb', true)))) {
                if (empty($bakala_options['add_to_cart_button_link']) && get_post_meta($post->ID, '_bakala_change_link_atcb', true) == false) {
                    $link = "#";
                } elseif (get_post_meta($post->ID, '_bakala_change_link_atcb', true)) {
                    $link = get_post_meta($post->ID, '_bakala_change_link_atcb', true);
                } else {
                    $link = $bakala_options['add_to_cart_button_link'];
                }
                if (empty($bakala_options['add_to_cart_button_text']) && get_post_meta($post->ID, '_bakala_change_text_atcb', true) == false) {
                    $text = $product->single_add_to_cart_text();
                } elseif (get_post_meta($post->ID, '_bakala_change_text_atcb', true)) {
                    $text = get_post_meta($post->ID, '_bakala_change_text_atcb', true);
                } else {
                    $text = $bakala_options['add_to_cart_button_text'];
                }
                if ($product->is_in_stock()) {
                    if ($bakala_options['price_add_holder'] == 1) {
                        if ($bakala_options['cart_fixed']) {
                            ?>
                            <div class="add-to-cart-holder">
                                <div class="bakala-button-price">
                                    <div class="add-to-cart-button">
                                        <a class='button dk-button no-atcb' href="<?php echo $link ?>">
                                            <?php echo $text; ?>
                                        </a>
                                    </div>
                                    <div class="bakala-product-price">
                                        <div class="price-section clearfix">

                                            <?php
                                            if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                                                <p><?php echo __("Coming soon", "bakala"); ?></p>
                                            <?php } else { ?>
                                                <p class="price"><?php echo $product->get_price_html(); ?></p>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        } else {
                            ?>
                            <div class="bakala-product-price">
                                <div class="price-section clearfix">

                                    <?php
                                    if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                                        <p><?php echo __("Coming soon", "bakala"); ?></p>
                                    <?php } else { ?>
                                        <p class="price"><?php echo $product->get_price_html(); ?></p>
                                    <?php } ?>
                                </div>
                            </div>
                            <?php do_action('woocommerce_before_add_to_cart_button'); ?>
                            <div class="add-to-cart-holder-normal" style="margin-top: 20px;">

                                <a class='button dk-button no-atcb' href="<?php echo $link ?>">
                                    <?php echo $text; ?>
                                </a>

                                <?php do_action('woocommerce_after_add_to_cart_button'); ?>

                            </div>
                            <?php
                        }
                    } else {
                        ?>
                        <div class="add-to-cart-holder">
                            <a class='button single_add_to_cart_button dk-button' href="<?php echo $link ?>"> <span
                                        class="dk-button-container hasIcon">
                                    <span class="dk-button-container hasIcon">
                                        <?php echo $text; ?>
                                    </span>
                            </a>
                        </div>
                        <?php
                    }
                } else {
                    ?>
                    <div class="add-to-cart-holder">
                        <button type="button" class="button alt">
                            ناموجود
                        </button>
                    </div>
                    <?php
                }
            }
            if ($atcb == false && $bakala_options['force_login_cart'] == '1' && empty(get_post_meta($post->ID, '_bakala_change_link_atcb', true)) && $bakala_options['add_to_cart_button_change_link_all'] != 1 && $bakala_options['catalog_mode'] == '0') {
                $isLoggedIn = is_user_logged_in();
                if (false == $isLoggedIn) {
                    if ($bakala_options['cart_fixed']) {

                        if ($product->is_in_stock()) {
                            if ($bakala_options['price_add_holder'] == 1) {
                                ?>
                                <div class="add-to-cart-holder force-login-add-cart-button">
                                    <div class="bakala-button-price">
                                        <div class="add-to-cart-button">
                                            <?php if ($bakala_options['add_to_cart_type'] == 0) { ?>
                                                <button type="button"
                                                        class="button dk-button add_to_cart_button"><?= $btn_text ?></button>
                                            <?php } else {
                                                ?>
                                                <button type="button"
                                                        class="button dk-button add_to_cart_button has-icon"></button>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                        <div class="bakala-product-price">
                                            <div class="price-section clearfix">

                                                <?php
                                                if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                                                    <p><?php echo __("Coming soon", "bakala"); ?></p>
                                                <?php } else { ?>
                                                    <p class="price"><?php echo $product->get_price_html(); ?></p>
                                                <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            } else {
                                ?>
                                <div class="add-to-cart-holder force-login-add-cart-button">
                                    <button type="button" class="button dk-button add_to_cart_button"><span
                                                class="dk-button-container hasIcon"><?= $product->single_add_to_cart_text() ?> </span>
                                    </button>
                                </div>
                                <?php
                            }
                        } else {
                            ?>
                            <div class="add-to-cart-holder">
                                <button type="button" class="button alt">
                                    <?= __('ناموجود', 'bakala') ?>
                                </button>
                            </div>
                            <?php
                        }
                    } else {
                        ?>
                        <div class="bakala-product-price">
                            <div class="price-section clearfix">

                                <?php
                                if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
                                    <p><?php echo __("Coming soon", "bakala"); ?></p>
                                <?php } else { ?>
                                    <p class="price"><?php echo $product->get_price_html(); ?></p>
                                <?php } ?>
                            </div>
                        </div>
                        <?php do_action('woocommerce_before_add_to_cart_button'); ?>
                        <div class="add-to-cart-holder-normal" style="margin-top: 20px;">

                            <button type="button"
                                    class="button dk-button add_to_cart_button"><?= $product->single_add_to_cart_text() ?></button>

                            <?php do_action('woocommerce_after_add_to_cart_button'); ?>
                        </div>
                        <?php
                    }
                }
            }
            ?>
        </form>
        <?php
    } else {
        ?>

        <form class="cart" method="post" enctype='multipart/form-data'>
            <?php
            /**
             * @since 2.1.0.
             */

            /**
             * @since 4.0.0.
             */
            do_action('woocommerce_before_add_to_cart_quantity');
            if ($atcb) {
                ?>
                <p class="single_quantity">
                    <?php
                    /**
                     * @since 2.1.0.
                     */

                    /**
                     * @since 4.0.0.
                     */
                    if ((!isset($bakala_options['catalog_mode']) || $bakala_options['catalog_mode'] == false) && get_post_meta($product->get_id(), '_coming_soon_product', true) != "on") {
                        woocommerce_quantity_input(array(
                            'input_name' => 'quantity',
                            'min_value' => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
                            'max_value' => $product->get_max_purchase_quantity() ? $product->get_max_purchase_quantity() : -1,
                            'input_value' => isset($_POST['quantity']) ? wc_stock_amount(wp_unslash($_POST['quantity'])) : $product->get_min_purchase_quantity(),
                            'product_name' => $product->get_name(),
                        ));
                    }
                    /**
                     * @since 4.0.0.
                     */
                    do_action('woocommerce_after_add_to_cart_quantity');
                    ?>
                </p>

                <?php if (!white_catis_catalog_mode() && get_post_meta($product->get_id(), '_coming_soon_product', true) != "on") :
                    do_action('woocommerce_before_add_to_cart_button');

                    ?>
                    <div class="add-to-cart-holder">
                        <?php if ($bakala_options['floating-cart'] == 1) : ?>

                            <a class='button single_add_to_cart_button dk-button add_to_cart_button ajax_add_to_cart'
                               href="<?php echo $product->add_to_cart_url() ?>"
                               value="<?php echo esc_attr($product->get_id()); ?>"
                               class="ajax_add_to_cart add_to_cart_button" data-product_id="<?php echo get_the_ID(); ?>"
                               data-product_sku="<?php echo esc_attr($sku) ?>"
                               aria-label="Add <?php the_title_attribute() ?> to your cart" data-quantity="1"><span
                                        class="dk-button-container hasIcon">
                                    <?php echo esc_html($btn_text); ?>
                                </span>
                            </a>

                        <?php else : ?>
                            <button type="submit" name="add-to-cart" value="<?php echo esc_attr($product->get_id()); ?>"
                                    class="single_add_to_cart_button button dk-button">
                                <span class="dk-button-container hasIcon">
                                    <?php echo esc_html($product->single_add_to_cart_text()); ?>
                                </span>
                            </button>
                        <?php endif; ?>

                    </div>
                    <?php
                    do_action('woocommerce_after_add_to_cart_button');
                endif;
            }
            if ($atcb == false && ($bakala_options['add_to_cart_button_change_link_all'] == 1 || $has_lcategory || !empty(get_post_meta($post->ID, '_bakala_change_link_atcb', true)))) {
                if (empty($bakala_options['add_to_cart_button_link']) && get_post_meta($post->ID, '_bakala_change_link_atcb', true) == false) {
                    $link = "#";
                } elseif (get_post_meta($post->ID, '_bakala_change_link_atcb', true)) {
                    $link = get_post_meta($post->ID, '_bakala_change_link_atcb', true);
                } else {
                    $link = $bakala_options['add_to_cart_button_link'];
                }
                if (empty($bakala_options['add_to_cart_button_text']) && get_post_meta($post->ID, '_bakala_change_text_atcb', true) == false) {
                    $text = $product->single_add_to_cart_text();
                } elseif (get_post_meta($post->ID, '_bakala_change_text_atcb', true)) {
                    $text = get_post_meta($post->ID, '_bakala_change_text_atcb', true);
                } elseif (!empty($bakala_options['add_to_cart_button_text'])) {
                    $text = $bakala_options['add_to_cart_button_text'];
                } else {
                    $text = 'افزودن به سبد خرید';
                }

                do_action('woocommerce_before_add_to_cart_button');
                ?>
                <div class="add-to-cart-holder">
                    <a class='button single_add_to_cart_button dk-button' href="<?php echo $link ?>"> <span
                                class="dk-button-container hasIcon">
                            <?php echo $text; ?>
                        </span>
                    </a>
                </div>
                <?php
                do_action('woocommerce_after_add_to_cart_button');
            }
            if ($atcb == false && $bakala_options['force_login_cart'] == '1' && empty(get_post_meta($post->ID, '_bakala_change_link_atcb', true)) && $bakala_options['add_to_cart_button_change_link_all'] != 1 && $bakala_options['catalog_mode'] == '0') {
                $isLoggedIn = is_user_logged_in();
                if (false == $isLoggedIn) {
                    do_action('woocommerce_before_add_to_cart_button');
                    ?>
                    <div class="add-to-cart-holder force-login-add-cart-button">
                        <button type="button"
                                class="button dk-button single_add_to_cart_button"> <?= $btn_text ?> </button>
                    </div>
                    <?php
                    do_action('woocommerce_after_add_to_cart_button');
                }
            }
            ?>
        </form>

        <?php
    }
endif; ?>
<?php do_action('woocommerce_after_add_to_cart_form');