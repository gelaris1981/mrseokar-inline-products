<?php

if (!defined('ABSPATH')) {
	exit;
}

global $post, $bakala_options;

$prod_categories = get_post_meta($post->ID, 'custom_related_products', true);

$product_args = array(
	'posts_per_page' => isset($bakala_options['custom_related_posts_per_page']) ? $bakala_options['custom_related_posts_per_page'] : 20,
	'post_status' => 'publish',
	'post_type' => 'product',
	'orderby' => 'rand',
	'order'    => 'ASC',
	'tax_query'             => array(
		array(
			'taxonomy'      => 'product_cat',
			'terms'         => !empty($prod_categories) ? $prod_categories : [],
			'field'         => 'term_id',
			'operator'      => 'IN'
		)
	),
	'meta_query' => array(
		array(
			'key' => '_stock_status',
			'value' => 'outofstock',
			'compare' => 'NOT IN',
		)
	)
);
if (isset($bakala_options['show_outofstock_custom_related']) && $bakala_options['show_outofstock_custom_related'] == 1) {
	unset($product_args['meta_query']);
}
$crp = new WP_Query($product_args);
if ($crp->have_posts()) :
	if (is_mobile_or_tablet()) {
?>
		<div class="product-carousel">
			<div class="carousel__wrapper">

				<div class="carousel__header">
					<h2><?php esc_html_e('پیشنهادات ما', 'woocommerce'); ?></h2>

					<?php
					$url = '';
					if (count($prod_categories) > 1) {
						$url = get_permalink(wc_get_page_id('shop'));
					} else {
						$cat = $prod_categories[0];
						$url = get_term_link((int)$cat, 'product_cat');
					}
					?>
					<a href="<?= $url ?>" class="trading-btn"><?= __('مشاهده همه','bakala') ?></a>


				</div>

				<div class="carousel__list trading-items">
					<?php while ($crp->have_posts()) :
						$crp->the_post();
						global $product;
						if ($product->is_in_stock() && $product->is_visible()) :
							$price_html = isset($bakala_options['price_html']) ? $bakala_options['price_html'] : false;

					?>

							<a class="carousel__item product" title="<?php the_title(); ?>" href="<?php the_permalink(); ?>">
								<img class="product__image" title="<?php the_title(); ?>" src="<?php if (has_post_thumbnail()) {
																									$img_id = get_post_thumbnail_id($product->get_id());
																									$src = wp_get_attachment_image_src($img_id, 'shop_catalog');
																									echo $src[0];
																								} elseif (($parent_id = wp_get_post_parent_id($product->get_id())) && has_post_thumbnail($parent_id)) {
																									$img_id = get_post_thumbnail_id($parent_id);
																									$src = wp_get_attachment_image_src($img_id, 'shop_catalog');
																									echo $src[0];
																								} else {
																									echo esc_url(wc_placeholder_img_src());
																								} ?>">
								<h4 class="product__title product__title--fa"><?php the_title(); ?></h4>
								<span class="products__item-price">
									<?php if ($product->is_on_sale()) { ?>
										<?php echo  $product->get_price_html(); ?>
									<?php } else { ?>
										<span class="matrix-wolffinal-price">
											<?php echo  $product->get_price_html(); ?>
										</span>
									<?php } ?>
								</span>
							</a>

					<?php endif;
					endwhile; ?>

				</div>
			</div>
		</div>
	<?php
	} else {
	?>
		<div class="section-products-carousel" style="margin-top:20px">

			<header>
				<h2><?php esc_html_e('پیشنهادات ما', 'woocommerce'); ?></h2>
				<div class="boxmore">
					<?php
					$url = '';
					if (count($prod_categories) > 1) {
						$url = get_permalink(wc_get_page_id('shop'));
					} else {
						$cat = $prod_categories[0];
						//var_dump($cat);
						$url = get_term_link((int)$cat, 'product_cat');
					}
					?>
					<a href="<?= $url ?>"><?= __('مشاهده همه','bakala') ?></a>

				</div>
			</header>

			<div class="scroller partial">

				<div class="items">
					<?php while ($crp->have_posts()) :
						$crp->the_post();
						global $product;
						if ($product->is_in_stock() && $product->is_visible()) :
							$price_html = isset($bakala_options['price_html']) ? $bakalakala_options['price_html'] : false;

					?>

							<a class="productItem" title="<?php the_title(); ?>" href="<?php the_permalink(); ?>">
								<img class="flickity-lazyloaded" alt="<?php the_title(); ?>" src="
                                    <?php
									if (has_post_thumbnail()) {
										$img_id = get_post_thumbnail_id($product->get_id());
										$src = wp_get_attachment_image_src($img_id, 'shop_catalog');
										echo $src[0];
									} elseif (($parent_id = wp_get_post_parent_id($product->get_id())) && has_post_thumbnail($parent_id)) {
										$img_id = get_post_thumbnail_id($parent_id);
										$src = wp_get_attachment_image_src($img_id, 'shop_catalog');
										echo $src[0];
									} else {
										echo esc_url(wc_placeholder_img_src());
									}
									?>">
								<h4><b class="fatitle"><?php the_title(); ?></b></h4>
								<?php
								if (get_post_meta($product->get_id(), '_coming_soon_product', true) == "on") { ?>
									<span class="products__item-gift-price">
										<span class="products__item-price">
											<span class="products__item-price--final">
												<span class="coming_soon_archive"><?php echo _e('Coming soon', 'bakalakala'); ?></span>
											</span>
										</span>
									</span>
								<?php } else { ?>


									<span class="products__item-price">
										<?php if ($product->is_on_sale()) {
											echo  $product->get_price_html();
										} else { ?>
											<span class="white_catfinal-price">
												<?php echo  $product->get_price_html(); ?>
											</span>
										<?php } ?>
									</span>
								<?php } ?>
							</a>

					<?php endif;
					endwhile; ?>

				</div>

			</div>

		</div>
<?php
	}
else :

	return false;
endif;
wp_reset_postdata();
?>