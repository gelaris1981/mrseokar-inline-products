<?php

/**
 * Single Product Image
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/product-image.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 100.0.0
 */

defined('ABSPATH') || exit;

// Note: `wc_get_gallery_image_html` was added in WC 3.3.2 and did not exist prior. This check protects against theme overrides being used on older versions of WC.
if (!function_exists('wc_get_gallery_image_html')) {
    return;
}

global $post, $product, $bakala_options, $current_user;

$columns = apply_filters('woocommerce_product_thumbnails_columns', 4);
$post_thumbnail_id = $product->get_image_id();
$wrapper_classes = apply_filters('woocommerce_single_product_image_gallery_classes', array(
    'woocommerce-product-gallery',
    'woocommerce-product-gallery--' . (has_post_thumbnail() ? 'with-images' : 'without-images'),
    'woocommerce-product-gallery--columns-' . absint($columns),
    'images',
));

$label = get_post_meta($product->get_id(), 'bakala_product_custom_label', true) ? get_post_meta($product->get_id(), 'bakala_product_custom_label', true) : $bakala_options['custom_label_text'];
$label_bg = get_post_meta($product->get_id(), 'bakala_product_custom_label_bg', true) ? get_post_meta($product->get_id(), 'bakala_product_custom_label_bg', true) : $bakala_options['custom_label_bg'];
$label_color = get_post_meta($product->get_id(), 'bakala_product_custom_label_color', true) ? get_post_meta($product->get_id(), 'bakala_product_custom_label_color', true) : $bakala_options['custom_label_color'];
$label_single = get_post_meta($product->get_id(), 'bakala_product_custom_label', true);
$label_all = $bakala_options['custom_label_text'];
if (isset($bakala_options['custom_label_category']) && is_array($bakala_options['custom_label_category']) && array_key_exists('custom_label_category',$bakala_options)) {
    $label_category = array_values($bakala_options['custom_label_category']);
    $l_categories = array_map(
        function ($value) {
            return (int)$value;
        },
        $label_category
    );
    if (has_term($l_categories, 'product_cat')) {
        $x = true;
    } else {
        $x = false;
    }
} else {
    $x = false;
}
$attachment_ids = $product->get_gallery_image_ids();
if (is_mobile_or_tablet()) {
    $start = get_post_meta(get_the_id(), '_sale_price_dates_from', true);
    $end = get_post_meta(get_the_id(), '_sale_price_dates_to', true);
    if ($start && $end && time() < $end) { ?>
        <?php if ($product->is_on_sale()) : ?>
            <div class="matrix_adaptive_countdown" style="position: absolute; left: 0;">
                <div class="matrix_adaptive_countdown_image">
                    <div class="promotion__title_single_adaptive">
                        <?php if (empty(get_option('amazingspecial_image'))) : ?>
                            <svg id="icon-PishnahadShegeftAngiz" viewBox="0 0 4078 1024" width="140px" height="100%">
                                <title>PishnahadShegeftAngiz</title>
                                <path fill="#EF3F3E" class="path1"
                                      d="M1808.176 624.649c-0.463 11.42-1.61 22.669-3.443 33.746-1.843 11.074-4.537 21.63-8.097 31.667-3.563 10.038-8.44 18.981-14.643 26.823-8.042-4.844-15.391-9.112-22.050-12.806-6.662-3.688-13.778-7.726-21.357-12.113 1.377-7.383 2.465-15.455 3.271-24.226 0.803-8.765 1.205-18.343 1.205-28.727 0-2.076 0-4.614 0-7.616 0-2.995-0.23-5.764-0.687-8.305v-319.111h66.489v287.269c0 10.85-0.23 21.979-0.69 33.4zM1605.24 604.037c-11.221-11.669-21.547-22.289-30.987-31.87-9.449-9.575-19.477-19.897-30.101-30.971l61.087-61.946c11.212 11.377 21.758 22.071 31.649 32.094 9.884 10.032 19.842 19.977 29.88 29.852-10.921 11.374-21.25 22.071-30.987 32.094-9.737 10.032-19.919 20.278-30.542 30.748zM1665.042 648.235l-0.015 66.174-867.763 0.978c-13.723-1.346-27.032-5.154-39.921-11.423-13.539-6.589-26.155-15.427-37.857-26.52-11.699 10.865-24.263 19.646-37.683 26.345-11.454 5.724-31.839 9.415-61.087 11.092v1.039l-236.228-0.169c-2.759 14.774-6.156 28.402-10.176 40.871-4.025 12.469-8.912 23.089-14.658 31.867-12.193 18.012-29.147 32.615-50.875 43.817-21.731 11.2-48.582 16.801-80.54 16.801-8.278 0-16.847-0.408-25.698-1.214-8.854-0.809-18.107-2.137-27.765-3.983v-64.080c8.045 2.772 16.436 4.789 25.177 6.061 8.738 1.266 17.362 1.907 25.87 1.907 11.037 0 21.786-1.272 32.25-3.811 10.461-2.545 20.008-6.527 28.629-11.951 8.624-5.43 15.921-12.469 21.903-21.13 5.978-8.658 10.117-19.223 12.417-31.692 1.15-16.396 2.125-33.482 2.934-51.264 0.803-17.779 1.205-36.37 1.205-55.768 0-4.384 0-9.234 0-14.548 0-5.543-0.117-10.507-0.343-14.894v-119.501h66.569v133.703c0 3.234 0 7.045 0 11.43 0 4.39-0.058 8.952-0.172 13.683-0.12 4.734-0.233 9.47-0.346 14.201-0.117 4.737-0.288 9.066-0.515 12.99l214.531-0.576c58.27-1.84 58.742-8.036 67.455-17.503 4.354-4.734 7.797-10.399 10.323-16.988 2.523-6.585 3.786-13.919 3.786-22.010v-128.953h65.732v128.953c0 8.091 1.318 15.424 3.958 22.010 2.634 6.589 6.077 12.254 10.326 16.988 4.24 4.737 9.231 8.612 14.968 11.61 5.733 3.008 11.702 4.973 17.899 5.893v0.696l495.622 0.175c9.639 0 18.076-1.438 25.306-4.323 7.232-2.879 13.14-6.742 17.733-11.583 4.59-4.838 8.033-10.311 10.329-16.421 2.293-6.104 3.446-12.276 3.446-18.499 0-6.681-1.205-13.192-3.618-19.533-2.41-6.337-5.969-12.043-10.672-17.114-4.709-5.068-10.62-9.106-17.733-12.101-7.119-2.995-15.381-4.495-24.791-4.495h-189.722c-9.415 0.463-18.309-0.402-26.685-2.594-8.382-2.189-15.725-5.647-22.037-10.372-6.316-4.725-11.307-10.488-14.977-17.288-3.676-6.797-5.509-14.695-5.509-23.684v-4.148c0-1.61 0.113-3.225 0.343-4.841 0.917-7.143 2.585-13.658 4.994-19.536s5.218-11.463 8.434-16.767c3.213-5.301 6.889-10.427 11.019-15.388 4.133-4.951 8.489-10.081 13.085-15.385 0.69-0.917 1.318-1.781 1.895-2.594 0.57-0.803 1.085-1.554 1.548-2.247 16.528-18.895 33.056-37.799 49.581-56.7 16.528-18.898 33.056-37.916 49.584-57.050 9.176 8.072 17.558 15.388 25.134 21.955 7.576 6.57 15.722 13.545 24.447 20.918l-120.167 138.988h190.409c17.442 0 33.626 3.173 48.551 9.51 14.919 6.34 27.771 14.811 38.562 25.41 10.786 10.605 19.281 22.994 25.48 37.168 6.196 14.177 9.296 28.991 9.296 44.431 0 13.37-4.363 31.462-13.085 54.281l259.909-1.306zM1002.622 430.684c1.147-7.833 3.041-14.98 5.681-21.437 2.637-6.451 5.856-12.5 9.642-18.15 3.786-5.647 7.974-11.178 12.567-16.596 4.59-5.414 9.296-11.006 14.118-16.77l84.014-97.154 28.923 25.931-152.19 175.984c-3.219-9.906-4.133-20.511-2.756-31.808zM362.254 419.359c-11.233-11.696-21.575-22.338-31.027-31.94-9.461-9.596-19.502-19.943-30.141-31.042l61.167-62.081c11.227 11.402 21.789 22.12 31.692 32.164 9.9 10.053 19.87 20.020 29.92 29.917-10.936 11.402-21.274 22.12-31.027 32.167-9.753 10.050-19.947 20.321-30.585 30.815zM588.291 817.4l57.010-56.363 57.016 56.369-57.016 56.372-57.010-56.366-57.010 56.366-57.016-56.372 57.016-56.369 57.010 56.363z"></path>
                                <path fill="#EF3F3E" class="path2"
                                      d="M3923.717 638.584c-6.552 14.379-15.345 27.032-26.379 37.955-11.031 10.927-23.788 19.726-38.271 26.394-14.48 6.677-29.77 10.47-45.856 11.387-15.86-0.457-31.493-4.081-46.889-10.869-15.403-6.782-29.426-15.924-42.067-27.43-13.333 12.886-27.528 22.203-42.579 27.948-15.060 5.752-30.288 9.204-45.685 10.35-15.173-0.224-30.462-3.621-45.859-10.179-15.4-6.555-29.537-15.924-42.407-28.12-11.724 10.813-24.368 19.554-37.928 26.222-12.929 6.362-26.376 10.203-40.341 11.546v0.53l-824.044-0.533c-13.741-1.34-27.016-5.126-39.823-11.368-13.447-6.558-26.149-15.357-38.1-26.397-11.724 10.813-24.306 19.554-37.753 26.222-11.439 5.678-23.337 9.348-35.687 11.025v1.052l-562.578-0.77v-66.204l556.026 0.727v-0.69c6.208-0.917 12.122-2.876 17.758-5.868 5.629-2.986 10.629-6.84 14.998-11.558 4.366-4.712 7.812-10.35 10.344-16.905 2.526-6.558 3.792-13.858 3.792-21.912v-128.359h66.198v128.359c0 8.054 1.263 15.354 3.792 21.912 2.529 6.555 5.975 12.193 10.344 16.905 4.366 4.718 9.363 8.572 14.998 11.558 5.629 2.992 11.552 4.951 17.758 5.868v0.69h60.683c-3.912-10.577-6.895-20.532-8.965-29.846-2.069-9.317-3.103-17.883-3.103-25.707v-65.214c0-16.789 3.216-32.547 9.654-47.273 6.432-14.716 15.17-27.602 26.204-38.645 11.031-11.040 23.963-19.781 38.789-26.222 14.823-6.438 30.625-9.661 47.408-9.661 16.776 0 32.581 3.222 47.408 9.661 14.827 6.441 27.755 15.182 38.789 26.222 11.034 11.043 19.766 23.929 26.204 38.645 6.432 14.725 9.654 30.484 9.654 47.273v65.214c0 7.824-1.095 16.39-3.277 25.707-2.186 9.314-5.23 19.269-9.136 29.846h369.958c9.654 0 18.101-1.435 25.342-4.314 7.242-2.873 13.156-6.73 17.758-11.558 4.596-4.832 8.042-10.292 10.341-16.39 2.296-6.092 3.449-12.251 3.449-18.46 0-6.671-1.208-13.168-3.621-19.496-2.413-6.325-5.978-12.018-10.688-17.080-4.715-5.059-10.635-9.084-17.758-12.076-7.128-2.986-15.403-4.485-24.824-4.485h-189.98c-9.428 0.463-18.331-0.399-26.719-2.588-8.394-2.186-15.749-5.635-22.068-10.353-6.325-4.712-11.322-10.464-14.998-17.252-3.679-6.782-5.515-14.664-5.515-23.635v-4.142c0-1.607 0.113-3.219 0.343-4.832 0.917-7.125 2.588-13.628 5-19.493 2.413-5.868 5.227-11.442 8.446-16.737 3.216-5.289 6.898-10.406 11.034-15.354 4.139-4.945 8.502-10.059 13.104-15.354 0.687-0.917 1.318-1.778 1.895-2.588 0.57-0.803 1.088-1.554 1.551-2.244 16.55-18.858 33.099-37.722 49.649-56.587 16.55-18.858 33.102-37.836 49.652-56.933 9.191 8.054 17.583 15.354 25.168 21.909 7.588 6.558 15.743 13.517 24.481 20.875l-120.332 138.712h190.669c17.466 0 33.669 3.164 48.615 9.489 14.937 6.328 27.807 14.781 38.615 25.361 10.801 10.583 19.309 22.945 25.514 37.091 6.208 14.146 9.311 28.93 9.311 44.339 0 13.346-4.369 31.401-13.104 54.174h59.303v-0.69c6.208-0.917 12.184-2.876 17.929-5.868 5.745-2.986 10.804-6.84 15.173-11.558 4.363-4.712 7.812-10.35 10.341-16.905 2.529-6.558 3.796-13.858 3.796-21.912v-128.359h65.852v128.359c0 8.971 1.607 17.025 4.829 24.153 3.216 7.134 7.413 13.113 12.585 17.941 5.172 4.832 11.086 8.514 17.754 11.043 6.665 2.532 13.447 3.796 20.345 3.796 6.895 0 13.671-1.263 20.342-3.796 6.662-2.529 12.585-6.211 17.754-11.043 5.172-4.829 9.363-10.807 12.585-17.941 3.216-7.128 4.829-15.182 4.829-24.153v-128.359h66.198v128.359c0 8.971 1.551 16.967 4.654 23.981 3.103 7.018 7.242 12.938 12.414 17.77 5.172 4.829 11.034 8.511 17.583 11.040 6.552 2.535 13.275 3.915 20.17 4.142 6.895-0.227 13.619-1.607 20.17-4.142 6.552-2.529 12.414-6.211 17.586-11.040 5.172-4.832 9.363-10.752 12.582-17.77 3.219-7.015 4.829-15.010 4.829-23.981v-128.359h65.855v129.738c0 16.335-3.277 31.692-9.826 46.065zM2873.663 529.031c0-10.12-1.61-18.861-4.826-26.225-3.222-7.358-7.413-13.398-12.585-18.113-5.172-4.712-11.154-8.223-17.929-10.525-6.785-2.296-13.619-3.333-20.517-3.106-6.895 0.463-13.677 2.017-20.342 4.66-6.668 2.646-12.585 6.383-17.754 11.212-5.172 4.832-9.311 10.755-12.414 17.77-3.103 7.021-4.654 15.13-4.654 24.328v62.452c0 8.971 1.551 16.967 4.654 23.981 3.103 7.021 7.242 12.941 12.414 17.77 5.169 4.832 11.086 8.572 17.754 11.215 6.665 2.649 13.447 4.087 20.342 4.314h-0.343c7.122 0.463 14.017-0.399 20.688-2.588 6.662-2.183 12.638-5.635 17.929-10.353 5.282-4.709 9.535-10.749 12.757-18.113 3.216-7.361 4.826-16.099 4.826-26.225v-62.452zM3786.737 358.020l-62.866 62.504-62.869-62.504-62.869 62.504-62.872-62.51 62.872-62.513 62.869 62.507 62.869-62.507 62.866 62.507 62.869-62.507 62.875 62.513-62.875 62.51-62.869-62.504zM3005.026 429.657c1.15-7.818 3.044-14.952 5.69-21.394 2.64-6.438 5.862-12.475 9.654-18.116 3.792-5.632 7.984-11.154 12.585-16.562 4.593-5.402 9.308-10.982 14.134-16.734l84.13-96.958 28.96 25.879-152.395 175.628c-3.222-9.887-4.139-20.471-2.759-31.744zM2762.151 301.651l62.872-62.51 62.875 62.51-62.875 62.513-62.872-62.513zM2057.213 542.959l-62.866 62.504-62.875-62.51 62.875-62.513 62.866 62.504 62.869-62.504 62.875 62.513-62.875 62.51-62.869-62.504z"></path>
                            </svg>
                        <?php else : ?>
                            <img src='<?php echo get_option('amazingspecial_image'); ?>'>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="matrix_adaptive_countdown_timer"></div>
            </div>

            <script>
                jQuery(document).ready(function () {
                    var clock;
                    clock = jQuery('.matrix_adaptive_countdown_timer').FlipClock({
                        clockFace: 'DailyCounter',
                        autoStart: false,

                    });
                    clock.setTime(<?php echo get_post_meta($product->get_id(), '_sale_price_dates_to', true) - time(); ?>);
                    clock.setCountdown(true);
                    clock.start();

                });
            </script>
        <?php endif;
    } ?>

    <div class="<?php echo esc_attr(implode(' ', array_map('sanitize_html_class', $wrapper_classes))); ?> <?= $bakala_options['gallery_style_mobile']=='two' || (isset($bakala_options['modern_header_mobile_style']) && $bakala_options['modern_header_mobile_style'] == 'two')  ? 'bakala_product_gallery_style_two' : null; ?>"
         data-columns="<?php echo esc_attr($columns); ?>" style="opacity: 0; transition: opacity .25s ease-in-out;">
        <?php bakala_display_product_timer(); ?>
        <?php
        if (!empty($label_single) || ($x && !empty($label_all))) { ?>
            <span class="bakala_custom_label_product"
                  style="background:<?= $label_bg ?>;color:<?= $label_color ?>;"><?= __($label, 'bakala') ?></span>
        <?php } ?>
        <?php if($bakala_options['gallery_style_mobile']=='two' || (isset($bakala_options['modern_header_mobile_style']) && $bakala_options['modern_header_mobile_style'] == 'two')){ ?>
            <ul class="product-tooltips">
                <li class="bakala-tooltip">
                    <span class="bakala-tooltiptext"><?php echo __('Add to wishlist', 'bakala'); ?></span>
                    <?php if (!is_user_logged_in()) {
                        if ($bakala_options['popup_login'] == true) :
                            if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                <span class="addtowishlist"><?php echo do_shortcode('[dm-login-modal]'); ?></span>
                            <?php } else { ?>
                                <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login" class="addtowishlist">
                                    <i class="bakala-icon icon-love"></i>
                                </a>
                            <?php }
                        else : ?>
                            <a class="addtowishlist" href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"><i class="bakala-icon icon-love"></i></a>
                        <?php endif;
                    } else {
                        $wishlist = get_user_meta($current_user->ID, 'bakala_wishlist', true);
                        if (is_array($wishlist) && in_array($product->get_id(), $wishlist)) {
                            $active = ' active';
                        } else {
                            $active = '';
                        } ?>
                        <a data-product-id="<?php echo $product->get_id() ?>" class="addtowishlist bakala-wishlist<?php echo $active; ?>"><i class="bakala-icon icon-love"></i></a>
                    <?php
                    } ?>
                </li>
                <?php if (isset($bakala_options['show_share']) && $bakala_options['show_share']) { ?>
                    <li class="bakala-tooltip">
                        <span class="bakala-tooltiptext"><?php echo __('Share', 'bakala'); ?></span>
                        <a data-bs-toggle="modal" data-bs-target="#bakala_sharebtn" id="ProductSocialShareForm"><i class="bakala-icon icon-share"></i></a>
                    </li>
                <?php } ?>

                <?php if (isset($bakala_options['show_white_catnotify']) && $bakala_options['show_white_catnotify'] && !$product->is_type('grouped')) {
                    $special_offer = is_special_offer(get_the_id());
                    if (!$special_offer || !$product->is_in_stock() || $product->get_price() == '') {
                        $stock_subscriber = check_user_stock_notify(get_the_id(), $current_user->ID);
                        $offer_subscriber = check_user_offer_notify(get_the_id(), $current_user->ID);
                        if ($stock_subscriber || $offer_subscriber) {
                            $is_subscriber = true;
                        } else {
                            $is_subscriber = false;
                        }
                ?>
                        <li class="bakala-tooltip">
                            <span class="bakala-tooltiptext"><?php echo __('Notify me', 'bakala'); ?></span>
                            <?php if (!is_user_logged_in()) {
                                if ($bakala_options['popup_login'] == true) :
                                    if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                        <span><?php echo do_shortcode('[dm-login-modal]'); ?><i class="bakala-icon icon-notif"></i></span>
                                    <?php } else { ?>
                                        <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login"><i class="bakala-icon icon-notif"></i></a>
                                    <?php }
                                else : ?>
                                    <a href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"><i class="bakala-icon icon-notif"></i></a>
                                <?php endif;
                            } else { ?>
                                <a href="" data-bs-toggle="modal" data-bs-target="#bakala_product_notify" class="<?php if ($is_subscriber) {
                                                                                                                        echo 'done';
                                                                                                                    } ?>"><i class="bakala-icon icon-notif"></i></a>
                            <?php } ?>
                        </li>
                    <?php }
                }
                $white_cat_compare = isset($bakala_options['white_catcompare']) ? $bakala_options['white_catcompare'] : false;
                $compare_page = isset($bakala_options['compare_page']) ? get_permalink($bakala_options['compare_page']) : false;
                if ($white_cat_compare && $compare_page) { ?>
                    <li class="bakala-tooltip">
                        <span class="bakala-tooltiptext"><?php echo __('Compare', 'bakala'); ?></span>
                        <div class="woocommerce product compare-button">
                            <a href="<?php echo $compare_page . '?products=' . get_the_id(); ?>" target="_blank" rel="nofollow"><i class="bakala-icon icon-compare"></i></a>
                        </div>
                    </li>
                    <?php } else {
                    if (function_exists('yith_woocompare_premium_constructor')) { ?>
                        <li class="bakala-tooltip">
                            <span class="bakala-tooltiptext"><?php echo __('Compare', 'bakala'); ?></span>
                            <?php echo do_shortcode('[yith_compare_button]'); ?>
                        </li>
                <?php }
                } ?>
                <?php
                if (isset($bakala_options['show_price_change']) && $bakala_options['show_price_change']) {
                    $has_price_changes = get_post_meta(get_the_id(), 'has_price_changes', true);
                    if ($has_price_changes && $has_price_changes == 1) { ?>
                        <li class="bakala-tooltip">
                            <span class="bakala-tooltiptext"><?php echo __('Price change', 'bakala'); ?></span>
                            <a href="" data-bs-toggle="modal" data-bs-target="#bakala_price_change"><i class="bakala-icon icon-chart"></i></a>
                        </li>
                <?php }
                } ?>
                <?php
                $product_video_type = get_post_meta(get_the_id(), 'video_type', true);
                if ($product_video_type && $product_video_type != '') { ?>
                    <li class="bakala-tooltip icons">
                        <span class="bakala-tooltiptext"><?php echo __('Product video', 'bakala'); ?></span>
                        <a href="" data-bs-toggle="modal" data-bs-target="#modal-product-gallery" class="modal-opener"><i class="bakala-icon icon-video"></i></a>
                    </li>
                <?php } ?>
            </ul>
        <?php } ?>
        <figure class="woocommerce-product-gallery__wrapper" data-bs-toggle="modal"
                data-bs-target="#modal-product-gallery">
            <?php
            if (has_post_thumbnail()) {
                $html = wc_get_gallery_image_html($post_thumbnail_id, true);
            } else {
                $html = '<div class="woocommerce-product-gallery__image--placeholder">';
                $html .= sprintf('<img src="%s" alt="%s" class="wp-post-image" />', esc_url(wc_placeholder_img_src()), esc_html__('Awaiting product image', 'woocommerce'));
                $html .= '</div>';
            }

            echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id);

            do_action('woocommerce_product_thumbnails');
            ?>


        </figure>
    </div>

    <?php if (isset($bakala_options['show_share']) && $bakala_options['show_share']) { ?>
        <div class="modal " id="bakala_sharebtn" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog bakala_qa_modal">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">اشتراک‌گذاری</h5>
                <a href="" data-bs-dismiss="modal" aria-label="Close" class="close-icon"></a>
            </div>
            <div class="modal-body">
                <p class="bakaka_share_title">این کالا را با دوستان خود به اشتراک بگذارید!</p>
                <button class="bakala_share_page_btn" onclick="bkCopyLink(this)" data-link="<?php echo esc_url(site_url()) . '/?p=' . $post->ID; ?>">
                    <i class="bakala-icon icon-copy"></i>
                    <span id="copyButtonText">کپی کردن لینک</span>
                </button>
            </div>
            
        </div>
    </div>
</div>
    <?php }
} else {
    ?>
    <div class="product-gallery-skeleton"></div>
        <div  class="bakala-gallery-thumbnails-skeleton">
            <?php
            $counter = 0;
            foreach ($attachment_ids as $attachment_id) {
            if ($counter == 4) {
					break;
				}
            ?>
                <div class="bakala-gallery-thumbnails-skeleton-item"></div>
            <?php 
            $counter++;
            } ?>
        </div>
    <div class="<?php echo esc_attr(implode(' ', array_map('sanitize_html_class', $wrapper_classes))); ?> <?= $bakala_options['gallery_style']=='two' ? 'bakala_product_gallery_style_two' : null; ?>"
         data-columns="<?php echo esc_attr($columns); ?>" >
        <div class="product-gallery-warp">
            <ul class="clearfix">
                <li class="bakala-tooltip">
                    <span class="bakala-tooltiptext"><?php echo __('Add to wishlist', 'bakala'); ?></span>
                    <?php if (!is_user_logged_in()) {
                        if ($bakala_options['popup_login'] == true) :
                            if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                <span class="icon icon-love addtowishlist"><?php echo do_shortcode('[dm-login-modal]'); ?></span>
                            <?php } else { ?>
                                <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login"
                                   class="icon icon-love addtowishlist"></a>
                            <?php }
                        else : ?>
                            <a class="icon icon-love addtowishlist"
                               href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"></a>
                        <?php endif;
                    } else {
                        $wishlist = get_user_meta($current_user->ID, 'bakala_wishlist', true);
                        if (is_array($wishlist) && in_array($product->get_id(), $wishlist)) {
                            $active = ' active';
                        } else {
                            $active = '';
                        } ?>
                        <a data-product-id="<?php echo $product->get_id() ?>"
                           class="icon icon-love addtowishlist bakala-wishlist<?php echo $active; ?>"></a>
                        <?php
                    } ?>
                </li>
                <?php if (isset($bakala_options['show_share']) && $bakala_options['show_share']) { ?>
                    <li class="bakala-tooltip">
                        <span class="bakala-tooltiptext"><?php echo __('Share', 'bakala'); ?></span>
                        <a data-bs-toggle="modal" data-bs-target="#bakala_sharebtn" id="ProductSocialShareForm"
                           class="icon icon-share"></a>
                    </li>
                <?php } ?>

                <?php if (isset($bakala_options['show_white_catnotify']) && $bakala_options['show_white_catnotify'] && !$product->is_type('grouped')) {
                    $special_offer = is_special_offer();
                    if (!$special_offer || !$product->is_in_stock() || $product->get_price() == '') {
                        $stock_subscriber = check_user_stock_notify(get_the_id(), $current_user->ID);
                        $offer_subscriber = check_user_offer_notify(get_the_id(), $current_user->ID);
                        if ($stock_subscriber || $offer_subscriber) {
                            $is_subscriber = true;
                        } else {
                            $is_subscriber = false;
                        }
                        ?>
                        <li class="bakala-tooltip">
                            <span class="bakala-tooltiptext"><?php echo __('Notify me', 'bakala'); ?></span>
                            <?php if (!is_user_logged_in()) {
                                if ($bakala_options['popup_login'] == true) :
                                    if ($bakala_options['digits'] == true && function_exists('digit_get_login_fields')) { ?>
                                        <span class="icon icon-notification"><?php echo do_shortcode('[dm-login-modal]'); ?></span>
                                    <?php } else { ?>
                                        <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login"
                                           class="icon icon-notification"></a>
                                    <?php }
                                else : ?>
                                    <a class="icon icon-notification"
                                       href="<?php echo get_permalink(get_option('woocommerce_myaccount_page_id')) . '?login=1'; ?>"></a>
                                <?php endif;
                            } else { ?>
                                <a href="" data-bs-toggle="modal" data-bs-target="#bakala_product_notify"
                                   class="icon icon-notification <?php if ($is_subscriber) {
                                       echo 'done';
                                   } ?>"></a>
                            <?php } ?>
                        </li>
                    <?php }
                }
                $white_cat_compare = isset($bakala_options['white_catcompare']) ? $bakala_options['white_catcompare'] : false;
                $compare_page = isset($bakala_options['compare_page']) ? get_permalink($bakala_options['compare_page']) : false;
                if ($white_cat_compare && $compare_page) { ?>
                    <li class="bakala-tooltip">
                        <span class="bakala-tooltiptext"><?php echo __('Compare', 'bakala'); ?></span>
                        <div class="woocommerce product compare-button">
                            <a href="<?php echo $compare_page . '?products=' . get_the_id(); ?>" target="_blank"
                               class="icon icon-compare" rel="nofollow"></a>
                        </div>
                    </li>
                <?php } else {
                    if (function_exists('yith_woocompare_premium_constructor')) { ?>
                        <li class="bakala-tooltip">
                            <span class="bakala-tooltiptext"><?php echo __('Compare', 'bakala'); ?></span>
                            <?php echo do_shortcode('[yith_compare_button]'); ?>
                        </li>
                    <?php }
                } ?>
                <?php
                if (isset($bakala_options['show_price_change']) && $bakala_options['show_price_change']) {
                    $has_price_changes = get_post_meta(get_the_id(), 'has_price_changes', true);
                    if ($has_price_changes && $has_price_changes == 1) { ?>
                        <li class="bakala-tooltip">
                            <span class="bakala-tooltiptext"><?php echo __('Price change', 'bakala'); ?></span>
                            <a href="" data-bs-toggle="modal" data-bs-target="#bakala_price_change"
                               class="icon icon-statistics"></a>
                        </li>
                    <?php }
                }

                $product_video_type = get_post_meta(get_the_id(), 'video_type', true);

                if ($product_video_type && $product_video_type != '') {
                    add_action('wp_head', function () {
                        ?>
                        <style>
                            #product-gallery li:first-child::before {
                                content: "\E10B";
                                font-family: bakala;
                                font-size: 24px;
                                line-height: 24px;
                                color: #fff;
                                position: absolute;
                                top: 50%;
                                left: 50%;
                                -webkit-transform: translate(-50%, -50%);
                                transform: translate(-50%, -50%);
                                z-index: 1;
                            }
                        </style>
                        <?php
                    });
                    ?>
                    <li data-bs-toggle="modal" data-bs-target="#modal-product-gallery" class="bakala-tooltip">
                        <span class="bakala-tooltiptext"><?php echo __('Product video', 'bakala'); ?></span>
                        <a class="current-product-video" title="<?php echo get_the_title(); ?>">Video</a>
                    </li>
                <?php } ?>

            </ul>
        </div>
        
        <?php
        if (!empty($label_single) || ($x && !empty($label_all))) { ?>
            <span class="bakala_custom_label_product"
                  style="background:<?= $label_bg ?>;color:<?= $label_color ?>;"><?= __($label, 'bakala') ?></span>
        <?php } ?>
        <figure class="woocommerce-product-gallery__wrapper">
            <?php
            if (has_post_thumbnail()) {
                $html = bakala_get_gallery_image_html($post_thumbnail_id, true);
            } else {
                $html = '<div class="woocommerce-product-gallery__image--placeholder">';
                $html .= sprintf('<img src="%s" alt="%s" class="wp-post-image" />', esc_url(wc_placeholder_img_src()), esc_html__('Awaiting product image', 'woocommerce'));
                $html .= '</div>';
            }

            echo apply_filters('woocommerce_single_product_image_thumbnail_html', $html, $post_thumbnail_id);

            do_action('woocommerce_product_thumbnails');
            ?>
        </figure>
        <?php if (isset($bakala_options['zoom_pic']) && $bakala_options['zoom_pic'] == true) { ?>
            <div id="show_zoom_container"></div>
            <script>
                function bakala_zoom() {
                    jQuery('.woocommerce-product-gallery__image .wp-post-image').elevateZoom({
                        zoomWindowIn: 200,
                        zoomWindowOut: 200,
                        zoomWindowWidth: 500,
                        zoomWindowHeight: 550,
                        easing: true,
                        zoomWindowPosition: "show_zoom_container",
                        lensSize: 200,
                        lensOpacity: 1,
                        lensColour: false, //colour of the lens background
                        cursor: "crosshair",
                        lensBorderColour: "#EF5661",
                        lensBorderSize: 2.5,
                        borderSize: 1,
                        borderColour: "#666",

                    });
                }

                bakala_zoom();
            </script>
        <?php } ?>
    </div>
    <?php do_action('bakala_woocommerce_after_product_gallery'); ?>
   <div class="modal " id="bakala_sharebtn" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog bakala_qa_modal">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">اشتراک‌گذاری</h5>
                <a href="" data-bs-dismiss="modal" aria-label="Close" class="close-icon"></a>
            </div>
            <div class="modal-body">
                <p class="bakaka_share_title">این کالا را با دوستان خود به اشتراک بگذارید!</p>
                <button class="bakala_share_page_btn" onclick="bkCopyLink(this)" data-link="<?php echo esc_url(site_url()) . '/?p=' . $post->ID; ?>">
                    <i class="bakala-icon icon-copy"></i>
                    <span id="copyButtonText">کپی کردن لینک</span>
                </button>
            </div>
            
        </div>
    </div>
</div>
    <?php
}