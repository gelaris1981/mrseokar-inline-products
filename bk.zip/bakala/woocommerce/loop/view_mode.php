<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $bakala_options;
?>

<span data-type_view="listing" onClick="bakala_change_type_view(this)" class="type_view type_view_listing <?php if( isset( $_COOKIE['type_view'] ) && $_COOKIE['type_view'] == 'listing' ) echo 'active'; ; if ( !isset( $_COOKIE['type_view'] ) && $bakala_options['archive_style'] == 'listing') echo 'active';?>"></span>
<span data-type_view="grid" onClick="bakala_change_type_view(this)" class="type_view type_view_grid <?php if( isset( $_COOKIE['type_view'] ) && $_COOKIE['type_view'] == 'grid' ) echo 'active'; if ( !isset( $_COOKIE['type_view'] ) && $bakala_options['archive_style'] == 'grid') echo 'active'; ?>"></span>
