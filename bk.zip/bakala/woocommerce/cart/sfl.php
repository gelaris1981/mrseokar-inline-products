<?php
$sflps = get_save_for_later();
$sfl_count = count($sflps);
?>
<div class="row sfl">
  <div class="col-sm-12 col-md-9">
    <form class="woocommerce-cart-form">
      <table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
        <tbody>
          <?php foreach ($sflps as $sflp) :
            $p_id = $sflp->p_id;
            $var_id = $sflp->var_id;
            $id = $sflp->id;
            $product = wc_get_product($p_id);
            if($product){
          ?>
            <tr class="woocommerce-cart-form__cart-item cart_item">
              <td class="product-remove">
                <a href="#" class="remove-next-shopping" data-pid="<?= $p_id ?>" data-id="<?= $id ?>"><i class="fa fa-times"></i></a>
              </td>
              <td class="product-thumbnail">
                <a href="<?= get_the_permalink($p_id); ?>"><?= get_the_post_thumbnail($p_id) ?></a>
              </td>
              <td class="product-name" data-title="محصول">
                <a href="<?= get_the_permalink($p_id); ?>"><?= get_the_title($p_id) ?></a>
                <div>
                  <a href="#" class="add--to--cart" data-pid="<?= $p_id ?>" data-varid="<?= $var_id ?>" data-id="<?= $id ?>">
                    <span data-icon="Icon-Action-MovetoCart"></span> <?= __('add to cart', 'bakala') ?> </a>
                  <a href="#" class="remove-next-shopping" data-pid="<?= $p_id ?>" data-id="<?= $id ?>">
                    <i class="fa fa-trash"></i> <?= __('Remove', 'bakala') ?> </a>
                </div>
              </td>
              <td class="product-subtotal" data-title="جمع جزء">
                <?= $product->get_price_html(); ?>
              </td>
            </tr>
          <?php 
            }
          endforeach; ?>
        </tbody>
      </table>
    </form>
  </div>
  <div id="sidebar-wrapper" class="col-12 col-md-3 sticky-sidebar">
    <div class="theiaStickySidebar" style="padding-top: 0px; padding-bottom: 0px; position: static; transform: none;">
      <div>
        <strong><?= __('What is the next shopping list?','bakala') ?></strong>
        <p><?= __('You can put the products that you have added to your shopping cart and you do not intend to buy them in the next shopping list and you can add them to the shopping cart and complete the purchase whenever you want.','bakala') ?></p>
        <div><?= $sfl_count .' '. __('The item is on your next shopping list','bakala') ?>  </div>
        <a href="#" class="add-all-next-shopping-cart">
          <span data-icon="Icon-Action-MovetoCart"></span> <?= __('Add all to cart','bakala') ?> </a>
      </div>
    </div>
  </div>
</div>