<?php

/**
 * Cart Page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 100.0.0
 */

defined('ABSPATH') || exit;

global $bakala_options, $post; ?>

<?php

$gift_product = isset($bakala_options['gift_product']) ? intval($bakala_options['gift_product']) : null;
if (isset($_GET['tab']) && $bakala_options['save_for_later'] == 1 && is_cart()) {
    $sfls = get_save_for_later();
    $sfl_count = count($sfls);
    if ($sfl_count > 0) {
        global $bakala_options;
        $sflps = get_save_for_later();
        $sfl_count = count($sflps);
        if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
            $logo_href = $bakala_options['site_header_logo']['url'];
        } else {
            $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
        }
        global $woocommerce;
        $cart_count = bakala_get_cart_count();
        ?>
        <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo"
                                                                         src="<?= $logo_href ?>">
            <div class="c-remodal-loader__bullets"><i
                        class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i
                        class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i
                        class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i
                        class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
        </div>
        <header class="post-header">
            <h1 class="post-title">
                <a href="<?php echo remove_query_arg('tab', wc_get_cart_url()) ?>" class="cart <?= !isset($_GET['tab']) ? 'active' : '' ?>">
                    <?= __('سبد خرید', 'bakala') ?>
                    <span class="count"><?= $cart_count ?></span>
                </a>
                <a href="<?php echo wc_get_cart_url(); ?>?tab=next-shopping"
                   class="next-shopping <?= isset($_GET['tab']) ? 'active' : '' ?>">
                    <?= __('Next shopping list', 'bakala') ?>
                    <span class="count" id="sfl_count"><?= $sfl_count ?></span>
                </a>

            </h1>
        </header>

        <?php
        if (is_user_logged_in()) {
            wc_get_template_part('cart/sfl');
        } else {
            ?>
            <div class="not-loggin-sfl">
                <p class="message-sfl"><?= __('To use the next shopping cart, please log in to your account first.', 'bakala') ?></p>
                <button type="button" class="login-btn" data-bs-toggle="modal"
                        data-bs-target="#bakala_login"><?= __('login / register', 'bakala') ?></button>
            </div>
            <?php
        }
    } else {
        $cart_count = bakala_get_cart_count();
        ?>
        <header class="post-header">
            <h1 class="post-title">
                <a href="<?php echo remove_query_arg('tab', wc_get_cart_url()) ?>" class="cart <?= !isset($_GET['tab']) ? 'active' : '' ?>">
                    <?= __('Cart', 'bakala') ?>
                    <span class="count"><?= $cart_count ?></span>
                </a>
                <a href="<?php echo wc_get_cart_url(); ?>?tab=next-shopping"
                   class="next-shopping <?= isset($_GET['tab']) ? 'active' : '' ?>">
                    <?= __('Next Shopping list', 'bakala') ?>
                    <span class="count" id="sfl_count"><?= $sfl_count ?></span>
                </a>

            </h1>
        </header>
        <?php
        if (is_user_logged_in()) {
            ?>
            <div class="sfl-empty">
                <img src="<?= get_template_directory_uri() . '/vendor/images/empty-sfl.png'; ?>" alt="">
                <p><?= __('Your next shopping list is empty!', 'bakala') ?></p>
                <p><?= __('You can put the products that you have added to your shopping cart and you do not intend to buy them in the next shopping list and add them to the shopping cart and complete the purchase whenever you want.', 'bakala') ?></p>
            </div>
            <?php
        } else {
            ?>
            <div class="not-login-sfl row">
                <div class="col-sm-12 col-md-9">
                    <p class="message-sfl"><?= __('To use the next shopping cart, please log in to your account first.', 'bakala') ?></p>
                    <button type="button" class="login-btn" data-bs-toggle="modal"
                            data-bs-target="#bakala_login"><?= __('login / register', 'bakala') ?></button>
                </div>
                <div id="sidebar-wrapper" class="col-12 col-md-3">
                    <div class="theiaStickySidebar"
                         style="padding-top: 0px; padding-bottom: 0px; position: static; transform: none;">
                        <div>
                            <strong><?= __('What is the next shopping list?', 'bakala') ?></strong>
                            <p><?= __('You can put the products that you have added to your shopping cart and you do not intend to buy them in the next shopping list and you can add them to the shopping cart and complete the purchase whenever you want.', 'bakala') ?></p>
                            <div><?= $sfl_count . ' ' . __('The item is on your next shopping list', 'bakala') ?> </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
    }
} else {

    ?>
    <div class="justify-content-between row">
    <?php if (is_mobile_or_tablet()) { ?>
        <div class="col-sm-12 col-md-9">

            <?php do_action('woocommerce_before_cart'); ?>
            <?php
            global $bakala_options;
            if (is_cart() && $bakala_options['save_for_later'] == 1) :
                $sflps = get_save_for_later();
                $sfl_count = count($sflps);
                if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
                    $logo_href = $bakala_options['site_header_logo']['url'];
                } else {
                    $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                }
                global $woocommerce;
                $cart_count = bakala_get_cart_count();
                ?>
                <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo"
                                                                                 src="<?= $logo_href ?>">
                    <div class="c-remodal-loader__bullets"><i
                                class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i
                                class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i
                                class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i
                                class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
                </div>

                <header class="post-header">
                    <h1 class="post-title">
                        <a href="<?php echo wc_get_cart_url(); ?>"
                           class="cart <?= !isset($_GET['tab']) ? 'active' : '' ?>">
                            <?= __('Cart', 'bakala') ?>
                            <span class="count"><?= $cart_count ?></span>
                        </a>
                        <a href="<?php echo wc_get_cart_url(); ?>?tab=next-shopping"
                           class="next-shopping <?= isset($_GET['tab']) ? 'active' : '' ?>">
                            <?= __('Next shopping cart', 'bakala') ?>
                            <span class="count" id="sfl_count"><?= $sfl_count ?></span>
                        </a>

                    </h1>
                </header>
            <?php endif; ?>
            <form class="woocommerce-cart-form" action="<?php echo esc_url(wc_get_cart_url()); ?>" method="post">
                <?php do_action('woocommerce_before_cart_table'); ?>

                <table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
                    <tbody>
                    <?php do_action('woocommerce_before_cart_contents'); ?>

                    <?php
                    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                        $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                        $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
                        $is_additional_product = array_key_exists('is_additional_product', $cart_item) ? $cart_item['is_additional_product'] : false;

                        if ($is_additional_product) {
                            continue;
                        }

                        if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_cart_item_visible', true, $cart_item, $cart_item_key)) {
                            $product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);
                            ?>
                            <tr class="woocommerce-cart-form__cart-item <?php echo esc_attr(apply_filters('woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key)); ?> <?= $bakala_options['gift'] == 1 && !empty($bakala_options['gift_price']) && $gift_product && $cart_item['product_id'] == $gift_product ? 'gift_product' : null; ?> <?= array_key_exists('bakala_product_add_on', $cart_item) && $cart_item['bakala_product_add_on'] && get_post_meta($product_id, 'bakala_product_add_on_type', true) == 'add_on' ? 'has_bakala_add_on' : null ?>"
                                data-cart-item-key="<?= $cart_item_key ?>">

                                <td class="product-remove">
                                    <?php
                                    echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                        'woocommerce_cart_item_remove_link',
                                        sprintf(
                                            '<a href="%s" class="remove" aria-label="%s" data-product_id="%s" data-product_sku="%s"><i class="icon cart-icon-close"></i></a>',
                                            esc_url(wc_get_cart_remove_url($cart_item_key)),
                                            esc_html__('Remove this item', 'woocommerce'),
                                            esc_attr($product_id),
                                            esc_attr($_product->get_sku())
                                        ),
                                        $cart_item_key
                                    );
                                    ?>
                                </td>

                                <td class="product-thumbnail">
                                    <?php
                                    $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key);

                                    if (!$product_permalink) {
                                        echo $thumbnail; // PHPCS: XSS ok.
                                    } else {
                                        printf('<a href="%s">%s</a>', esc_url($product_permalink), $thumbnail); // PHPCS: XSS ok.
                                    }
                                    ?>
                                    <?php
                                    if ($bakala_options['save_for_later'] == 1 && is_user_logged_in() && !is_mobile_or_tablet()) : ?>
                                        <div><a href="#" class="add-next-shopping" data-pid="<?= $product_id ?>"
                                                data-varid="<?= $cart_item['variation_id'] ? $cart_item['variation_id'] : null ?>"
                                                data-cart-key="<?= $cart_item_key ?>"><span
                                                        data-icon="save-for-later"></span><?= __('Save to next shopping list', 'bakala') ?><?= __('', 'bakala') ?>
                                            </a></div>
                                    <?php endif; ?>
                                </td>

                                <td class="product-name" data-title="<?php esc_attr_e('Product', 'woocommerce'); ?>">
                                    <?php
                                    if (!$product_permalink) {
                                        echo wp_kses_post(apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key) . ' ');
                                    } else {
                                        echo wp_kses_post(apply_filters('woocommerce_cart_item_name', sprintf('<a href="%s">%s</a>', esc_url($product_permalink), $_product->get_name()), $cart_item, $cart_item_key));
                                    }
                                    ?>
                                    <div class="product_info">
                                        <?php

                                        if (wc_product_sku_enabled() && ($_product->get_sku()) || bakala_get_variations_skus($_product->get_id())) : ?>
                                            <div class="item sku">
                                                <span class="sku_wrapper"><?php esc_html_e('SKU:', 'woocommerce'); ?> <span
                                                            class="sku"><?php echo ($sku = $_product->get_sku()) ? $sku : esc_html__('N/A', 'woocommerce'); ?></span></span>
                                            </div>
                                        <?php endif;

                                        ?>
                                        <div class="item loadtime">
                                            <span><i class="bakala_icon icon_clock"></i><?= __('item loadtime', 'bakala') ?> :</span>
                                            <span><?php bakala_get_leadTime($_product, $product_id) ?></span>
                                        </div>

                                    </div>

                                    <?php
                                    do_action('woocommerce_after_cart_item_name', $cart_item, $cart_item_key);

                                    // Meta data.
                                    echo wc_get_formatted_cart_item_data($cart_item); // PHPCS: XSS ok.


                                    // dokan compability
                                    if (function_exists('dokan_get_seller_rating') && isset($bakala_options) && $bakala_options['cart_vendor'] == true) {
                                        $author_id = get_post_field('post_author', $_product->get_id());
                                        $store_info = dokan_get_store_info($author_id); ?>
                                        <div class="cart-seller"><?php echo _e('Sell By', 'bakala') . ' ' . esc_html($store_info['store_name']); ?></div>
                                    <?php }

                                    // Backorder notification.
                                    if ($_product->backorders_require_notification() && $_product->is_on_backorder($cart_item['quantity'])) {
                                        echo wp_kses_post(apply_filters('woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__('Available on backorder', 'woocommerce') . '</p>', $product_id));
                                    }
                                    ?>
                                    <?php if ($bakala_options['save_for_later'] == 1 && is_user_logged_in() && is_mobile_or_tablet()) : ?>
                                        <div><a href="#" class="add-next-shopping" data-pid="<?= $product_id ?>"
                                                data-cart-key="<?= $cart_item_key ?>"><span
                                                        data-icon="save-for-later"></span><?= __('ذخیره در لیست خرید بعدی', 'bakala') ?>
                                            </a></div>
                                    <?php endif;
                                    if (!is_mobile_or_tablet()) : ?>
                                        <div class="product-quantity"
                                             data-title="<?php esc_attr_e('Quantity', 'woocommerce'); ?>">
                                            <?php
                                            if ($_product->is_sold_individually()) {
                                                $product_quantity = sprintf('1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key);
                                            } else {
                                                $product_quantity = woocommerce_quantity_input(
                                                    array(
                                                        'input_name' => "cart[{$cart_item_key}][qty]",
                                                        'input_value' => $cart_item['quantity'],
                                                        'max_value' => $_product->get_max_purchase_quantity(),
                                                        'min_value' => '0',
                                                        'product_name' => $_product->get_name(),
                                                    ),
                                                    $_product,
                                                    false
                                                );
                                            }

                                            echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item); // PHPCS: XSS ok.
                                            ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php
                                    if (array_key_exists('bakala_product_add_on', $cart_item) && $cart_item['bakala_product_add_on'] && get_post_meta($product_id, 'bakala_product_add_on_type', true) == 'add_on') {
                                    $product_ids = explode(',', $cart_item['bakala_product_add_on']);
                                    foreach ($product_ids

                                    as $product_id){
                                    $product_id = intval($cart_item['bakala_product_add_on']);
                                    $add_on_product = wc_get_product($product_id);
                                    $wc_session = WC()->session;
                                    $item_new_price = $wc_session->get('bakala_product_add_on_price_' . $cart_item_key);
                                    ?>
                                <td class="bakala_add_on_cart">
                                    <div class="bakala_add_on tickChb" style="background: #fff;">
                                        <div class="bakala_add_on__name">
                                            <div class="chb bakala_add_on__chb">
                                                <label>
                                                    <input type="checkbox"
                                                           class="bakala_add_on_checkbox" <?= ($item_new_price > $add_on_product->get_price() || empty($item_new_price)) ? 'checked' : null; ?>>
                                                    <span></span>
                                                </label>
                                            </div>
                                        </div>
                                        <div style="display: block;padding: 1px;">

                                            <img src="<?php if (has_post_thumbnail($product_id)) {
                                                $img_id = get_post_thumbnail_id($product_id);
                                                $src = wp_get_attachment_image_src($img_id, 'shop_catalog');
                                                echo $src[0];
                                            } elseif (($parent_id = wp_get_post_parent_id($product_id)) && has_post_thumbnail($parent_id)) {
                                                $img_id = get_post_thumbnail_id($parent_id);
                                                $src = wp_get_attachment_image_src($img_id, 'shop_catalog');
                                                echo $src[0];
                                            } else {
                                                echo esc_url(wc_placeholder_img_src());
                                            } ?>" alt="<?= get_the_title($product_id) ?>"
                                                 title="<?= get_the_title($product_id) ?>" style="height: 70px;">

                                        </div>
                                        <div class="bakala_add_on__info">
                                            <div class="bakala_add_on__info--txt">
                                                <?= get_the_title($product_id) ?>
                                            </div>
                                            <div class="bakala_add_on__info--footer">
                                                <div class="product__offer">

                                                    <div class="product__offer--new">
                                                        <?= $add_on_product->get_price_html() ?>
                                                    </div>

                                                </div>
                                                <a href="#" class="bakala_add_onMoreShow" data-bs-toggle="modal"
                                                   data-bs-target="#bakala_add_on_modal_<?= $product_id ?>">جزییات</a>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <div class="modal fade" id="bakala_add_on_modal_<?= $product_id ?>" tabindex="-1"
                                     aria-labelledby="bakala_add_on_modal" aria-hidden="true">
                                    <div class="modal-dialog bakala_qa_modal">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title"
                                                    id="exampleModalLabel"><?= get_the_title($product_id) ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <?= wpautop(get_post_field('post_content', $product_id)); ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <?php }
                                }
                                ?>
                                </td>
                                <?php if (is_mobile_or_tablet()) : ?>
                                    <td class="product-quantity"
                                        data-title="<?php esc_attr_e('Quantity', 'woocommerce'); ?>">
                                        <?php
                                        if ($_product->is_sold_individually()) {
                                            $product_quantity = sprintf('1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key);
                                        } else {
                                            $product_quantity = woocommerce_quantity_input(
                                                array(
                                                    'input_name' => "cart[{$cart_item_key}][qty]",
                                                    'input_value' => $cart_item['quantity'],
                                                    'max_value' => $_product->get_max_purchase_quantity(),
                                                    'min_value' => '0',
                                                    'product_name' => $_product->get_name(),
                                                ),
                                                $_product,
                                                false
                                            );
                                        }

                                        echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item); // PHPCS: XSS ok.
                                        ?>
                                    </td>
                                <?php endif; ?>

                                <td class="product-subtotal"
                                    data-title="<?php esc_attr_e('Subtotal', 'woocommerce'); ?>">
                                    <?php
                                    echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($_product, $cart_item['quantity']), $cart_item, $cart_item_key); // PHPCS: XSS ok.
                                    ?>
                                </td>

                            </tr>
                            <?php
                        }
                    }
                    ?>

                    <?php do_action('woocommerce_cart_contents'); ?>

                    <tr>
                        <td colspan="6" class="actions">

                            <div class="bakala_actions_cart">
                                <?php

                                if ($bakala_options['gift'] == 1 && !empty($bakala_options['gift_price']) && $gift_product) {
                                    $order_total = WC()->cart->get_cart_contents_total();
                                    $gift_price = $bakala_options['gift_price'];
                                    $product = wc_get_product($gift_product);
                                    if (intval($order_total) >= intval($gift_price)) {
                                        ?>
                                        <div class="bakala_product_gift">
                                            <div class="bakala_product_gift_image">
                                                <img src="<?php if (has_post_thumbnail($gift_product)) {
                                                    $img_id = get_post_thumbnail_id($gift_product);
                                                    $src = wp_get_attachment_image_src($img_id, 'shop_catalog');
                                                    echo $src[0];
                                                } elseif (($parent_id = wp_get_post_parent_id($gift_product)) && has_post_thumbnail($parent_id)) {
                                                    $img_id = get_post_thumbnail_id($parent_id);
                                                    $src = wp_get_attachment_image_src($img_id, 'shop_catalog');
                                                    echo $src[0];
                                                } else {
                                                    echo esc_url(wc_placeholder_img_src());
                                                } ?>" alt="<?= get_the_title($gift_product) ?>"
                                                     title="<?= get_the_title($gift_product) ?>">
                                            </div>
                                            <div class="bakala_product_gift_wrap">
                                                <a href="<?= get_permalink($gift_product) ?>"
                                                   class="bakala_product_gift_title"><?= get_the_title($gift_product) ?></a>
                                                <hr class="bakala_gift_divider">
                                                <div class="bakala_product_gift_info">
                                                    <div class="bakala_product_gift_load_time"><?php bakala_get_leadTime($product, $gift_product) ?></div>
                                                    <div class="bakala_product_gift_label"><?= __('Gift Product', 'bakala') ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                } ?>
                                <?php if (wc_coupons_enabled()) { ?>
                                    <div class="bakala_coupon">
                                        <div class="bakala_coupon_icon">
                                            <i class="bakala-icon icon-qrcode"></i>
                                        </div>
                                        <div class="bakala_coupon_wrap">
                                            <div class="bakala_coupon_input"><input type="text" name="coupon_code"
                                                                                    class="input-text" id="coupon_code"
                                                                                    value=""
                                                                                    placeholder="<?php esc_attr_e('Coupon code', 'woocommerce'); ?>"/>
                                            </div>
                                            <hr class="bakala_coupon_divider">
                                            <div class="bakala_product_coupon_info">
                                                <div class="bakala_product_coupon_title"><?php esc_html_e('Coupon', 'bakala'); ?></div>
                                                <div class="bakala_product_coupon_submit">
                                                    <button type="submit" class="button" name="apply_coupon"
                                                            value="<?php esc_attr_e('Apply coupon', 'bakala'); ?>"><?php esc_attr_e('Apply coupon', 'bakala'); ?></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <?php } ?>
                            </div>

                            <button type="submit" class="button" name="update_cart"
                                    value="<?php esc_attr_e('Update cart', 'woocommerce'); ?>"><?php esc_html_e('Update cart', 'woocommerce'); ?></button>

                            <?php do_action('woocommerce_cart_actions'); ?>

                            <?php wp_nonce_field('woocommerce-cart', 'woocommerce-cart-nonce'); ?>
                        </td>
                    </tr>

                    <?php do_action('woocommerce_after_cart_contents'); ?>
                    </tbody>
                </table>
                <?php do_action('woocommerce_after_cart_table'); ?>
            </form>


        </div>
    <?php } else { ?>
        <div class="col-sm-12 col-md-9">

            <?php do_action('woocommerce_before_cart'); ?>
            <?php
            global $bakala_options;
            if (is_cart() && $bakala_options['save_for_later'] == 1) :
                $sflps = get_save_for_later();
                $sfl_count = count($sflps);
                if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
                    $logo_href = $bakala_options['site_header_logo']['url'];
                } else {
                    $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
                }
                global $woocommerce;
                $cart_count = bakala_get_cart_count();
                ?>
                <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo"
                                                                                 src="<?= $logo_href ?>">
                    <div class="c-remodal-loader__bullets"><i
                                class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i
                                class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i
                                class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i
                                class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
                </div>

                <div class="align-items-center justify-content-between row">
                    <div class="col-sm-12 col-md-9">
                        <header class="post-header">
                            <h1 class="post-title">
                                <a href="<?php echo remove_query_arg('tab', wc_get_cart_url()); ?>"
                                   class="cart <?= !isset($_GET['tab']) ? 'active' : '' ?>">
                                    <?= __('Cart', 'bakala') ?>
                                    <span class="count"><?= $cart_count ?></span>
                                </a>
                                <a href="<?php echo wc_get_cart_url(); ?>?tab=next-shopping"
                                   class="next-shopping <?= isset($_GET['tab']) ? 'active' : '' ?>">
                                    <?= __('Next Shopping Cart', 'bakala') ?>
                                    <span class="count" id="sfl_count"><?= $sfl_count ?></span>
                                </a>

                            </h1>
                        </header>
                    </div>
                    <div class="col-md-3 col-sm-12 text-start">
                        <a class="bakala_continue_shopping" dir="ltr" href="/">
                            <i class="bakala-icon icon-return bakala_continue_shopping_icon"></i>
                            <div class="bakala_continue_shopping_text" style="text-align: right">
                                <small><?= __('Continue shopping', 'bakala') ?></small>
                                <strong><?= __('View products', 'bakala') ?></strong>
                            </div>
                        </a>

                    </div>
                </div>
            <?php endif; ?>
            <form class="woocommerce-cart-form" action="<?php echo esc_url(wc_get_cart_url()); ?>" method="post">
                <?php do_action('woocommerce_before_cart_table'); ?>

                <table class="shop_table shop_table_responsive cart woocommerce-cart-form__contents" cellspacing="0">
                    <tbody>
                    <?php do_action('woocommerce_before_cart_contents'); ?>

                    <?php

                    foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {

                        $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                        $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
                        $is_additional_product = array_key_exists('is_additional_product', $cart_item) ? $cart_item['is_additional_product'] : false;


                        if ($is_additional_product) {
                            continue;
                        }
                        if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_cart_item_visible', true, $cart_item, $cart_item_key)) {
                            $product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);
                            ?>
                            <tr class="woocommerce-cart-form__cart-item <?php echo esc_attr(apply_filters('woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key)); ?> <?= $bakala_options['gift'] == 1 && !empty($bakala_options['gift_price']) && $gift_product && $cart_item['product_id'] == $gift_product ? 'gift_product' : null; ?> <?= array_key_exists('bakala_product_add_on', $cart_item) && $cart_item['bakala_product_add_on'] && get_post_meta($product_id, 'bakala_product_add_on_type', true) == 'add_on' ? 'has_bakala_add_on' : null ?>"
                                data-cart-item-key="<?= $cart_item_key ?>">

                                <td class="product-remove">
                                    <?php
                                    echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                        'woocommerce_cart_item_remove_link',
                                        sprintf(
                                            '<a href="%s" class="remove" aria-label="%s" data-product_id="%s" data-product_sku="%s"><i class="icon cart-icon-close"></i></a>',
                                            esc_url(wc_get_cart_remove_url($cart_item_key)),
                                            esc_html__('Remove this item', 'woocommerce'),
                                            esc_attr($product_id),
                                            esc_attr($_product->get_sku())
                                        ),
                                        $cart_item_key
                                    );
                                    ?>
                                </td>

                                <td class="product-thumbnail">
                                    <?php
                                    $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key);

                                    if (!$product_permalink) {
                                        echo $thumbnail; // PHPCS: XSS ok.
                                    } else {
                                        printf('<a href="%s">%s</a>', esc_url($product_permalink), $thumbnail); // PHPCS: XSS ok.
                                    }
                                    ?>
                                    <?php
                                    if ($bakala_options['save_for_later'] == 1 && is_user_logged_in() && !is_mobile_or_tablet()) :
                                        ?>
                                        <div><a href="#" class="add-next-shopping" data-pid="<?= $product_id ?>"
                                                data-varid="<?= $cart_item['variation_id'] ? $cart_item['variation_id'] : null ?>"
                                                data-cart-key="<?= $cart_item_key ?>"><span
                                                        data-icon="save-for-later"></span><?= __('ذخیره در لیست خرید بعدی', 'bakala') ?><?= __('', 'bakala') ?>
                                            </a></div>
                                    <?php endif; ?>
                                </td>


                                <td class="product-name" data-title="<?php esc_attr_e('Product', 'woocommerce'); ?>">
                                    <?php
                                    if (!$product_permalink) {
                                        echo wp_kses_post(apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key) . ' ');
                                    } else {
                                        echo wp_kses_post(apply_filters('woocommerce_cart_item_name', sprintf('<a href="%s">%s</a>', esc_url($product_permalink), $_product->get_name()), $cart_item, $cart_item_key));
                                    }
                                    ?>
                                    <div class="product_info">
                                        <?php
                                        echo wc_get_formatted_cart_item_data($cart_item);
                                        if (wc_product_sku_enabled() && ($_product->get_sku()) || bakala_get_variations_skus($_product->get_id())) : ?>
                                            <div class="item sku">
                                                <span class="sku_wrapper"><?php esc_html_e('SKU:', 'woocommerce'); ?> <span
                                                            class="sku"><?php echo ($sku = $_product->get_sku()) ? $sku : esc_html__('N/A', 'woocommerce'); ?></span></span>
                                            </div>
                                        <?php endif; ?>
                                        <div class="item loadtime">
                                            <span><i class="bakala_icon icon_clock"></i><?= __('Lead time','bakala')?>:</span>
                                            <span><?php bakala_get_leadTime($_product, $product_id) ?></span>
                                        </div>

                                    </div>
                                    <?php
                                    do_action('woocommerce_after_cart_item_name', $cart_item, $cart_item_key);


                                    // dokan compability
                                    if (function_exists('dokan_get_seller_rating') && isset($bakala_options) && $bakala_options['cart_vendor'] == true) {
                                        $author_id = get_post_field('post_author', $_product->get_id());
                                        $store_info = dokan_get_store_info($author_id); ?>
                                        <div class="cart-seller"><?php echo _e('Sell By', 'bakala') . ' ' . esc_html($store_info['store_name']); ?></div>
                                    <?php }

                                    // Backorder notification.
                                    if ($_product->backorders_require_notification() && $_product->is_on_backorder($cart_item['quantity'])) {
                                        echo wp_kses_post(apply_filters('woocommerce_cart_item_backorder_notification', '<p class="backorder_notification">' . esc_html__('Available on backorder', 'woocommerce') . '</p>', $product_id));
                                    }
                                    ?>
                                    <?php if ($bakala_options['save_for_later'] == 1 && is_user_logged_in() && is_mobile_or_tablet()) : ?>
                                        <div><a href="#" class="add-next-shopping" data-pid="<?= $product_id ?>"
                                                data-cart-key="<?= $cart_item_key ?>"><span
                                                        data-icon="save-for-later"></span><?= __('ذخیره در لیست خرید بعدی', 'bakala') ?>
                                            </a></div>
                                    <?php endif;
                                    if (!is_mobile_or_tablet()) : ?>
                                        <div class="product-quantity"
                                             data-title="<?php esc_attr_e('Quantity', 'woocommerce'); ?>">
                                            <?php
                                            if ($_product->is_sold_individually()) {
                                                $product_quantity = sprintf('1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key);
                                            } else {
                                                $product_quantity = woocommerce_quantity_input(
                                                    array(
                                                        'input_name' => "cart[{$cart_item_key}][qty]",
                                                        'input_value' => $cart_item['quantity'],
                                                        'max_value' => $_product->get_max_purchase_quantity(),
                                                        'min_value' => '0',
                                                        'product_name' => $_product->get_name(),
                                                    ),
                                                    $_product,
                                                    false
                                                );
                                            }

                                            echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item); // PHPCS: XSS ok.
                                            echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($_product, $cart_item['quantity']), $cart_item, $cart_item_key); // PHPCS: XSS ok.
                                            ?>
                                        </div>
                                    <?php endif; ?>

                                    <?php
                                    if (array_key_exists('bakala_product_add_on', $cart_item) && $cart_item['bakala_product_add_on'] && get_post_meta($product_id, 'bakala_product_add_on_type', true) == 'add_on') {
                                        echo '<td class="bakala_add_on_cart">';
                                        $product_ids = explode(',', $cart_item['bakala_product_add_on']);

                                        foreach ($product_ids as $product_id) {
                                            $add_on_product = wc_get_product(intval($product_id));
                                            $wc_session = WC()->session;
                                            $item_new_price = $wc_session->get('bakala_product_add_on_price_' . $cart_item_key);
                                            ?>

                                            <div class="bakala_add_on tickChb" style="background: #fff;">
                                                <div class="bakala_add_on__name">
                                                    <div class="chb bakala_add_on__chb">
                                                        <label>
                                                            <input type="checkbox"
                                                                   class="bakala_add_on_checkbox" <?= ($item_new_price > $add_on_product->get_price() || empty($item_new_price)) ? 'checked' : null; ?>>
                                                            <span></span>
                                                        </label>
                                                    </div>
                                                </div>
                                                <div style="display: block;padding: 1px;">

                                                    <img src="<?php if (has_post_thumbnail($product_id)) {
                                                        $img_id = get_post_thumbnail_id($product_id);
                                                        $src = wp_get_attachment_image_src($img_id, 'shop_catalog');
                                                        echo $src[0];
                                                    } elseif (($parent_id = wp_get_post_parent_id($product_id)) && has_post_thumbnail($parent_id)) {
                                                        $img_id = get_post_thumbnail_id($parent_id);
                                                        $src = wp_get_attachment_image_src($img_id, 'shop_catalog');
                                                        echo $src[0];
                                                    } else {
                                                        echo esc_url(wc_placeholder_img_src());
                                                    } ?>" alt="<?= get_the_title($product_id) ?>"
                                                         title="<?= get_the_title($product_id) ?>"
                                                         style="height: 70px;">

                                                </div>
                                                <div class="bakala_add_on__info">
                                                    <div class="bakala_add_on__info--txt">
                                                        <?= get_the_title($product_id) ?>
                                                    </div>
                                                    <div class="bakala_add_on__info--footer">
                                                        <div class="product__offer">

                                                            <div class="product__offer--new">
                                                                <?= $add_on_product->get_price_html() ?>
                                                            </div>

                                                        </div>
                                                        <a href="#" class="bakala_add_onMoreShow" data-bs-toggle="modal"
                                                           data-bs-target="#bakala_add_on_modal_<?= $product_id ?>">جزییات</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal fade" id="bakala_add_on_modal_<?= $product_id ?>"
                                                 tabindex="-1" aria-labelledby="bakala_add_on_modal" aria-hidden="true">
                                                <div class="modal-dialog bakala_qa_modal">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title"
                                                                id="exampleModalLabel"><?= get_the_title($product_id) ?></h5>
                                                            <button type="button" class="btn-close"
                                                                    data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <?= wpautop(get_post_field('post_content', $product_id)); ?>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        <?php }
                                        echo '</td>';
                                    }
                                    ?>
                                </td>
                                <?php if (is_mobile_or_tablet()) : ?>
                                    <td class="product-quantity"
                                        data-title="<?php esc_attr_e('Quantity', 'woocommerce'); ?>">
                                        <?php
                                        if ($_product->is_sold_individually()) {
                                            $product_quantity = sprintf('1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key);
                                        } else {
                                            $product_quantity = woocommerce_quantity_input(
                                                array(
                                                    'input_name' => "cart[{$cart_item_key}][qty]",
                                                    'input_value' => $cart_item['quantity'],
                                                    'max_value' => $_product->get_max_purchase_quantity(),
                                                    'min_value' => '0',
                                                    'product_name' => $_product->get_name(),
                                                ),
                                                $_product,
                                                false
                                            );
                                        }

                                        echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item); // PHPCS: XSS ok.
                                        ?>

                                    </td>
                                <?php endif; ?>


                            </tr>
                            <?php
                        }
                    }
                    ?>

                    <?php do_action('woocommerce_cart_contents'); ?>

                    <tr>
                        <td colspan="6" class="actions">
                            <div class="bakala_actions_cart">
                                <?php

                                if ($bakala_options['gift'] == 1 && !empty($bakala_options['gift_price']) && $gift_product) {
                                    $order_total = WC()->cart->get_cart_contents_total();
                                    $gift_price = $bakala_options['gift_price'];
                                    $product = wc_get_product($gift_product);
                                    if (intval($order_total) >= intval($gift_price)) {
                                        ?>
                                        <div class="bakala_product_gift">
                                            <div class="bakala_product_gift_image">
                                                <img src="<?php if (has_post_thumbnail($gift_product)) {
                                                    $img_id = get_post_thumbnail_id($gift_product);
                                                    $src = wp_get_attachment_image_src($img_id, 'shop_catalog');
                                                    echo $src[0];
                                                } elseif (($parent_id = wp_get_post_parent_id($gift_product)) && has_post_thumbnail($parent_id)) {
                                                    $img_id = get_post_thumbnail_id($parent_id);
                                                    $src = wp_get_attachment_image_src($img_id, 'shop_catalog');
                                                    echo $src[0];
                                                } else {
                                                    echo esc_url(wc_placeholder_img_src());
                                                } ?>" alt="<?= get_the_title($gift_product) ?>"
                                                     title="<?= get_the_title($gift_product) ?>">
                                            </div>
                                            <div class="bakala_product_gift_wrap">
                                                <a href="<?= get_permalink($gift_product) ?>"
                                                   class="bakala_product_gift_title"><?= get_the_title($gift_product) ?></a>
                                                <hr class="bakala_gift_divider">
                                                <div class="bakala_product_gift_info">
                                                    <div class="bakala_product_gift_load_time"><?php bakala_get_leadTime($product, $gift_product) ?></div>
                                                    <div class="bakala_product_gift_label"><?= __('Gift Product', 'bakala') ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php }
                                } ?>
                                <?php if (wc_coupons_enabled()) { ?>
                                    <div class="bakala_coupon">
                                        <div class="bakala_coupon_icon">
                                            <i class="bakala-icon icon-qrcode"></i>
                                        </div>
                                        <div class="bakala_coupon_wrap">
                                            <div class="bakala_coupon_input"><input type="text" name="coupon_code"
                                                                                    class="input-text" id="coupon_code"
                                                                                    value=""
                                                                                    placeholder="<?php esc_attr_e('Coupon code', 'woocommerce'); ?>"/>
                                            </div>
                                            <hr class="bakala_coupon_divider">
                                            <div class="bakala_product_coupon_info">
                                                <div class="bakala_product_coupon_title"><?php esc_html_e('Coupon', 'bakala'); ?></div>
                                                <div class="bakala_product_coupon_submit">
                                                    <button type="submit" class="button" name="apply_coupon"
                                                            value="<?php esc_attr_e('Apply coupon', 'bakala'); ?>"><?php esc_attr_e('Apply coupon', 'bakala'); ?></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <?php } ?>
                            </div>

                            <button type="submit" class="button" name="update_cart"
                                    value="<?php esc_attr_e('Update cart', 'woocommerce'); ?>"><?php esc_html_e('Update cart', 'woocommerce'); ?></button>

                            <?php do_action('woocommerce_cart_actions'); ?>

                            <?php wp_nonce_field('woocommerce-cart', 'woocommerce-cart-nonce'); ?>
                        </td>
                    </tr>

                    <?php do_action('woocommerce_after_cart_contents'); ?>
                    </tbody>
                </table>
                <?php do_action('woocommerce_after_cart_table'); ?>
            </form>

        </div>
    <?php } ?>
    <?php if (is_mobile_or_tablet()) : ?>
    <div class="col-12 col-md-3">
    <?php else : ?>
    <div id="sidebar-wrapper" class="col-12 col-md-3 sticky-sidebar">
<?php endif; ?>
    <?php do_action('woocommerce_before_cart_collaterals'); ?>

    <div class="cart-collaterals">
        <?php
        /**
         * Cart collaterals hook.
         *
         * @hooked woocommerce_cross_sell_display
         * @hooked woocommerce_cart_totals - 10
         */
        do_action('woocommerce_cart_collaterals');
        ?>
    </div>
    <?php do_action('woocommerce_after_cart'); ?>
    </div>
<?php }