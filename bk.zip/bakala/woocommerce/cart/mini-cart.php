<?php
/**
 * Mini-cart
 *
 * Contains the markup for the mini-cart, used by the cart widget.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/mini-cart.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 100.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

do_action('woocommerce_before_mini_cart');

global $bakala_options; ?>

<?php if (function_exists('WC') && is_object(WC()->cart) && !empty(WC()->cart->get_cart())) : ?>
    <?php if ( $bakala_options['floating-cart'] == 1 ): ?>
        <ul class="ar-product <?php echo esc_attr($args['list_class']); ?>">
            <?php do_action('woocommerce_before_mini_cart_contents'); ?>
            <?php foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) : ?>
                <?php $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                    $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key); ?>
                    
                    <?php if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key) ): ?>
                        
                        <?php $product_name = apply_filters('woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key);
                            $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key);
                            $product_price = apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key);
                            $product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key);
                            if (has_post_thumbnail($product_id)) {
                                $thumbnail_url = wp_get_attachment_image_src(get_post_thumbnail_id($product_id));
                            } elseif (($parent_id = wp_get_post_parent_id($product_id)) && has_post_thumbnail($parent_id)) {
                                $thumbnail_url = wp_get_attachment_image_src(get_post_thumbnail_id($parent_id));
                            } else {
                                $thumbnail_url = wc_placeholder_img_src();
                            } ?>
                            
                        <li class="<?php echo esc_attr(apply_filters('woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key)); ?>" data-cart-item-key="<?php echo esc_attr($cart_item_key); ?>">
                            <?php if (!$_product->is_visible()) : ?>
<a href="javascript:void(0)">
                                    <div class="ar-product-side">
                                        <figure class="lazy ar-product-image">
                                            <?php echo $thumbnail ?>
                                        </figure>
                                    </div>
                                    <div class="d-flex flex-direction-nav">
                                        <h3><?php echo $product_name ?></h3>
                                    </div>
                                </a>
                                
                                <?php if ( $_product->is_sold_individually() ) {
                                        $min_quantity = 1;
                                        $max_quantity = 1;
                                    } else {
                                        $min_quantity = $_product->get_min_purchase_quantity();
                                        $max_quantity = $_product->get_max_purchase_quantity() ? $_product->get_max_purchase_quantity() : -1;
                                    } ?>
                                    
                                <?php $product_quantity = woocommerce_quantity_input(
                                            array(
                                                'input_name'   => 'cart[' . $cart_item_key . '][qty]',
                                                'input_value'  => $cart_item['quantity'],
                                                'max_value'    => $max_quantity,
                                                'min_value'    => $min_quantity,
                                                'product_name' => $_product->get_name(),
                                                'mini_cart'    => true
                                            ),
                                            $_product,
                                            false
                                ); ?>
                                
                                <div class="quantity-wrap flexed">
                                    <?php echo apply_filters('woocommerce_widget_cart_item_quantity', '<div class="cart_list_product_quantity">' . (sprintf('%s × %s', $cart_item['quantity'], $product_price) ) . '</div>', $cart_item, $cart_item_key); ?>
                                    
                                    <?php echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item); ?>
                                </div>
                                
                                <?php echo wc_get_formatted_cart_item_data($cart_item); ?>

                                
                                    <?php echo apply_filters('woocommerce_cart_item_remove_link', sprintf(
                                        '<a href="%s" class="remove remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s"><span class="ar-delete fa fa-trash-o ">×</span></a>',
                                        esc_url(wc_get_cart_remove_url($cart_item_key)),
                                        __('Remove this item', 'bakala'),
                                        esc_attr($product_id),
                                        esc_attr($cart_item_key),
                                        esc_attr($_product->get_sku())
                                    ), $cart_item_key);
                                    ?>
                                
                                <?php else : ?>
                                <a href="<?php echo esc_url($product_permalink); ?>">
                                    <div class="ar-product-side">
                                        <figure class="lazy ar-product-image">
                                            <?php echo $thumbnail ?>
                                        </figure>
                                    </div>
                                    <div class="d-flex flex-direction-nav">
                                        <h3><?php echo $product_name ?></h3>
                                    </div>
                                </a>
                                
                                <?php if ( $_product->is_sold_individually() ) {
                                        $min_quantity = 1;
                                        $max_quantity = 1;
                                    } else {
                                        $min_quantity = $_product->get_min_purchase_quantity();
                                        $max_quantity = $_product->get_max_purchase_quantity() ? $_product->get_max_purchase_quantity() : -1;
                                    } ?>
                                    
                                <?php $product_quantity = woocommerce_quantity_input(
                                            array(
                                                'input_name'   => 'cart[' . $cart_item_key . '][qty]',
                                                'input_value'  => $cart_item['quantity'],
                                                'max_value'    => $max_quantity,
                                                'min_value'    => $min_quantity,
                                                'product_name' => $_product->get_name(),
                                                'mini_cart'    => true
                                            ),
                                            $_product,
                                            false
                                ); ?>
                                
                                <div class="quantity-wrap flexed">
                                    <?php echo apply_filters('woocommerce_widget_cart_item_quantity', '<div class="cart_list_product_quantity">' . (sprintf('%s × %s', $cart_item['quantity'], $product_price) ) . '</div>', $cart_item, $cart_item_key); ?>
                                    
                                    <?php echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item); ?>
                                </div>
                                
                                <?php echo wc_get_formatted_cart_item_data($cart_item); ?>

                                    <?php echo apply_filters('woocommerce_cart_item_remove_link', sprintf(
                                        '<a href="%s" class="ar-delete remove remove_from_cart_button" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s">×</a>',
                                        esc_url(wc_get_cart_remove_url($cart_item_key)),
                                        __('Remove this item', 'bakala'),
                                        esc_attr($product_id),
                                        esc_attr($cart_item_key),
                                        esc_attr($_product->get_sku())
                                    ), $cart_item_key);
                                    ?>
                            <?php endif; ?>
                        </li>
                        
                    <?php endif; ?>
                    
            <?php endforeach; ?>
            <?php do_action('woocommerce_mini_cart_contents'); ?>
            
        </ul>
        
        <div class="ar-amount">
            <span>
                <?php _e('جمع کل', 'bakala'); ?>: 
            </span>
            <strong>
                <?php echo WC()->cart->get_cart_subtotal(); ?>
            </strong>
        </div>
        
        <?php do_action('woocommerce_widget_shopping_cart_before_buttons'); ?>
        
        <?php if ( $bakala_options['force_login_cart'] == 1 && !is_user_logged_in() ): ?>
            <a class="ar-cartbox" data-bs-toggle="modal" data-bs-toggle="modal" data-bs-target="#bakala_login">
                <?php echo esc_html__('مشاهده سبد خرید', 'bakala') ?>
            </a>
			<?php elseif ( $bakala_options['force_login_in_cart'] == 1 && !is_user_logged_in() ): ?>
            <a class="ar-cartbox" href="<?php echo esc_url(wc_get_cart_url()) ?>">
                <?php echo esc_html__('مشاهده سبد خرید', 'bakala') ?>
            </a>

        <?php else: ?>
            <a class="ar-cartbox" href="<?php echo esc_url(wc_get_cart_url()) ?>">
                <?php echo esc_html__('مشاهده سبد خرید', 'bakala') ?>
            </a>
            <a class="ar-order" href="<?php echo esc_url(wc_get_checkout_url()) ?>">
                <?php echo esc_html__('تسویه حساب', 'bakala') ?>
            </a>
        <?php endif; ?>
    <?php else: ?>
        <div class="c-navi-list__basket-header">
            <div class="c-navi-list__basket_count">
                <?php echo bakala_get_cart_count() . __(' Items', 'bakala'); ?>
            </div>
            <div class="c-navi-list__basket-total">
                <strong><?php echo __('Shipping Subtotal', 'bakala'); ?></strong> <?php echo WC()->cart->get_cart_subtotal(); ?>
            </div>
            
            <?php do_action('woocommerce_widget_shopping_cart_before_buttons'); ?>
            
            <a href="<?php echo wc_get_cart_url(); ?>" class="c-navi-list__basket-link">
                <?php echo $bakala_options['show-cart-label'] ? $bakala_options['show-cart-label'] : __('Show cart', 'bakala'); ?>
                <div class="c-navi-list__basket-arrow"></div>
            </a>
        </div>
        <ul class="woocommerce-mini-cart cart_list product_list_widget <?php echo esc_attr($args['list_class']); ?>">
            <?php do_action('woocommerce_before_mini_cart_contents'); ?>
            
            <?php foreach( WC()->cart->get_cart() as $cart_item_key => $cart_item ): ?>
                <?php
                    $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                    $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key); ?>
                
                <?php if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_widget_cart_item_visible', true, $cart_item, $cart_item_key) ): ?>
                    <?php 
                        $product_name = $_product->get_name();
                        $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key);
                        $product_price = apply_filters('woocommerce_cart_item_price', WC()->cart->get_product_price($_product), $cart_item, $cart_item_key);
                        $product_permalink = apply_filters('woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink($cart_item) : '', $cart_item, $cart_item_key); ?>
                        
                    <?php echo apply_filters('woocommerce_cart_item_remove_link', sprintf(
                        '<a href="%s" class="c-navi-list__basket-item-remove" aria-label="%s" data-product_id="%s" data-cart_item_key="%s" data-product_sku="%s"></a>',
                        esc_url(wc_get_cart_remove_url($cart_item_key)),
                        __('Remove this item', 'woocommerce'),
                        esc_attr($product_id),
                        esc_attr($cart_item_key),
                        esc_attr($_product->get_sku())
                    ), $cart_item_key); ?>
                        
                        
                    <li class="woocommerce-mini-cart-item <?php echo esc_attr(apply_filters('woocommerce_mini_cart_item_class', 'mini_cart_item', $cart_item, $cart_item_key)); ?>">
                        <?php if ( empty($product_permalink) ) : ?>
                            <?php echo $thumbnail . $product_name; ?>
                        <?php else: ?>
                            <a class="cart-thumb" href="<?php echo esc_url($product_permalink); ?>">
                                <?php echo $thumbnail; ?>
                            </a>
                            <a class="cart-title" href="<?php echo esc_url($product_permalink); ?>">
                                <?php echo $product_name; ?>
                            </a>
                        <?php endif; ?>
                        <div class="cart-qty">
                            <?php echo wc_get_formatted_cart_item_data($cart_item); ?>
                            <?php echo $product_price . ' | ' . $cart_item['quantity'] . __(' qty', 'bakala'); ?>
                        </div>
                    </li>
                    
                <?php endif; ?>
                
            <?php endforeach; ?>

            <?php do_action('woocommerce_mini_cart_contents'); ?>
        </ul>
        <a href="<?php echo wc_get_checkout_url(); ?>" class="c-navi-list__basket-submit"> <?php echo __('Chechout', 'bakala'); ?> </a>
    <?php endif; ?>
<?php else: ?>
    <p class="woocommerce-mini-cart__empty-message"><?php _e('No products in the cart.', 'woocommerce'); ?></p>
<?php endif; ?>

<?php do_action('woocommerce_after_mini_cart'); 