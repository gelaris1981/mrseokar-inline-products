<?php

/**
 * Cross-sells
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cross-sells.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 100.0.0
 */

defined('ABSPATH') || exit;

if ($cross_sells) : ?>

    <div class="cross-sells">
        <?php
        $heading = apply_filters('woocommerce_product_cross_sells_products_heading', __('You may be interested in&hellip;', 'woocommerce'));

?>
        <?php if (is_mobile_or_tablet()) : ?>
    <div class="product-carousel cross-sells-products">
        <div class="carousel__wrapper">
            <div class="carousel__header">
                <div class="related-title"><?php echo $heading; ?></div>
            </div>
            <div class="carousel__list">
                <?php foreach ($cross_sells as $cross_sell) : ?>
                    <?php
                    $post_object = get_post($cross_sell->get_id());
                    setup_postdata($GLOBALS['post'] = &$post_object);
                    ?>
                    <a class="carousel__item product" title="<?php echo esc_attr(get_the_title($cross_sell->get_id())); ?>" href="<?php echo esc_url(get_permalink($cross_sell->get_id())); ?>">
                        <?php
                        $thumb = get_the_post_thumbnail($cross_sell->get_id(), 'woocommerce_thumbnail');
                        if ($thumb) {
                            echo $thumb;
                        } else {
                            echo wc_placeholder_img();
                        }
                        ?>
                        <h3 class="product__title"><?php echo esc_html(get_the_title($cross_sell->get_id())); ?></h3>
                        <span class="products__item-price">
                            <?php
                            $stockamount = $cross_sell->get_stock_quantity();
                            if ($stockamount !== 0) {
                                echo $cross_sell->get_price_html();
                            } else {
                                esc_html_e('Out of stock', 'woocommerce');
                            }
                            ?>
                        </span>
                    </a>
                <?php endforeach; ?>
                <?php wp_reset_postdata(); ?>
            </div>
        </div>
    </div>
<?php else : ?>
    <div class="section-products-carousel cross-sells-products">
        <header>
            <div class="related-title"><?php echo $heading; ?></div>
        </header>
        <div class="product-skeleton-loader-items">
            <?php foreach ($cross_sells as $cross_sell) : ?>
                <div class="product-skeleton-loader">
                    <div class="product-skeleton-image"></div>
                    <div class="product-skeleton-title"></div>
                    <div class="product-skeleton-price"></div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="scroller partial">
            <div class="items">
                <?php foreach ($cross_sells as $cross_sell) : ?>
                    <?php
                    $post_object = get_post($cross_sell->get_id());
                    setup_postdata($GLOBALS['post'] = &$post_object);
                    ?>
                    <a class="productItem" title="<?php echo esc_attr(get_the_title($cross_sell->get_id())); ?>" href="<?php echo esc_url(get_permalink($cross_sell->get_id())); ?>">
                        <?php
                        $thumb = get_the_post_thumbnail($cross_sell->get_id(), 'woocommerce_thumbnail');
                        if ($thumb) {
                            echo $thumb;
                        } else {
                            echo wc_placeholder_img();
                        }
                        ?>
                        <h3><b class="fatitle"><?php echo esc_html(get_the_title($cross_sell->get_id())); ?></b></h3>
                        <span class="products__item-price">
                            <?php
                            $stockamount = $cross_sell->get_stock_quantity();
                            if ($stockamount !== 0) {
                                echo $cross_sell->get_price_html();
                            } else {
                                esc_html_e('Out of stock', 'woocommerce');
                            }
                            ?>
                        </span>
                    </a>
                <?php endforeach; ?>
                <?php wp_reset_postdata(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>



    </div>
<?php
endif;

wp_reset_postdata();
