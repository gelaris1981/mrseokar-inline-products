<?php

/**
 * Empty cart page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart-empty.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author  WooThemes
 * @package WooCommerce/Templates
 * @version 100.0.0
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}
global $bakala_options;
if (isset($bakala_options['offer_menu_cat']) && $bakala_options['offer_menu_cat']) {
	$term = get_term($bakala_options['offer_menu_cat']);
	if ($term) {
		$link = get_term_link($term);
	} elseif (isset($bakala_options['offer_menu_link']) && $bakala_options['offer_menu_link']) {
		$link = get_permalink($bakala_options['offer_menu_link']);
	}
}
if (isset($_GET['tab']) && $bakala_options['save_for_later']==1 && is_user_logged_in()) {
	$sfls = get_save_for_later();
	$sfl_count = count($sfls);

	if ($sfl_count > 0) {
	    global $bakala_options;
if (is_cart() && is_user_logged_in() && $bakala_options['save_for_later']==1) :
	$sflps = get_save_for_later();
	$sfl_count = count($sflps);
    if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
        $logo_href = $bakala_options['site_header_logo']['url'];
    } else {
        $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
    }
global $woocommerce;
$cart_count= $woocommerce->cart->cart_contents_count;
?>
    <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo" src="<?= $logo_href ?>">
        <div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
    </div>
    <header class="post-header">
        <h1 class="post-title">
            <a href="<?php echo remove_query_arg('tab', wc_get_cart_url()); ?>" class="cart <?= !isset($_GET['tab']) ? 'active' : '' ?>">
                <?= __('سبد خرید','bakala') ?>
                <span class="count"><?= $cart_count ?></span>
            </a>
            <a href="<?php echo wc_get_cart_url(); ?>?tab=next-shopping" class="next-shopping <?= isset($_GET['tab']) ? 'active' : '' ?>">
                <?= __('لیست خرید بعدی','bakala') ?>
                <span class="count"><?= $sfl_count ?></span>
            </a>
            
        </h1>
    </header>
    <?php endif;
		wc_get_template_part('cart/sfl');
	} else {

global $bakala_options;
if (is_cart() && is_user_logged_in() && $bakala_options['save_for_later']==1) :
	$sflps = get_save_for_later();
	$sfl_count = count($sflps);
    if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
        $logo_href = $bakala_options['site_header_logo']['url'];
    } else {
        $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
    }
global $woocommerce;
$cart_count= $woocommerce->cart->cart_contents_count;
?>
    <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo" src="<?= $logo_href ?>">
        <div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
    </div>
    <header class="post-header">
        <h1 class="post-title">
            <a href="<?php echo remove_query_arg('tab', wc_get_cart_url()); ?>" class="cart <?= !isset($_GET['tab']) ? 'active' : '' ?>">
                <?= __('Cart','bakala') ?>
                <span class="count"><?= $cart_count ?></span>
            </a>
            <a href="<?php echo wc_get_cart_url(); ?>?tab=next-shopping" class="next-shopping <?= isset($_GET['tab']) ? 'active' : '' ?>">
                <?= __('Next shopping list','bakala') ?>
                <span class="count"><?= $sfl_count ?></span>
            </a>
            
        </h1>
    </header>
    <?php endif; ?>
    	<div class="sfl-empty">
				<img src="<?= get_template_directory_uri() . '/vendor/images/empty-sfl.png'; ?>" alt="">
			<p><?= __('Your next shopping set is empty!','bakala') ?></p>
			<p><?= __('You can put the products that you have added to your shopping cart and you do not intend to buy them in the next shopping list and you can add them to the shopping cart and complete the purchase whenever you want.','bakala') ?></p>
		</div>
	<?php
	}
} else {

	wc_print_notices();

	/**
	 * @hooked wc_empty_cart_message - 10
	 */

	do_action('woocommerce_cart_is_empty'); 
	global $bakala_options;
if (is_cart() && is_user_logged_in() && $bakala_options['save_for_later']==1) :
	$sflps = get_save_for_later();
	$sfl_count = count($sflps);
    if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
        $logo_href = $bakala_options['site_header_logo']['url'];
    } else {
        $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
    }
global $woocommerce;
$cart_count= $woocommerce->cart->cart_contents_count;
?>
    <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo" src="<?= $logo_href ?>">
        <div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
    </div>
    <header class="post-header">
        <h1 class="post-title">
            <a href="<?php echo remove_query_arg('tab', wc_get_cart_url()); ?>" class="cart <?= !isset($_GET['tab']) ? 'active' : '' ?>">
                <?= __('Cart','bakala') ?>
                <span class="count"><?= $cart_count ?></span>
            </a>
            <a href="<?php echo wc_get_cart_url(); ?>?tab=next-shopping" class="next-shopping <?= isset($_GET['tab']) ? 'active' : '' ?>">
                <?= __('next shipping cart','bakala') ?>
                <span class="count"><?= $sfl_count ?></span>
            </a>
            
        </h1>
    </header>
    <?php endif; ?>
	<div class="cart-empty-div">
	    <?php if(isset($bakala_options['empty_cart_icon']) && !empty($bakala_options['empty_cart_icon']['url'])){ ?>
		    <img class="bakala_cart_empty_icon" src="<?= $bakala_options['empty_cart_icon']['url'] ?>" alt="cart empty icon">
		<?php }else{ ?>
		    <div class="c-checkout-empty__icon"></div>
		<?php } ?>
		<?php if (wc_get_page_id('shop') > 0) : ?>

			<div class="c-checkout-empty">
				<div class="c-checkout-empty__links">
					<p><?php echo _e('You can go to the following pages to see more products', 'bakala'); ?>
					</p>
					<div class="c-checkout-empty__link-urls">
						<a href="<?php echo $link; ?>"><?php echo _e('Special Offers', 'bakala'); ?></a>
						<a href="<?php echo wc_get_account_endpoint_url('your-wishlist'); ?>"><?php echo _e('My Wishlist', 'bakala'); ?></a>
						</a>
					</div>
				</div>
			</div>
			<p class="return-to-shop">
				<a class="button wc-backward" href="<?php echo esc_url(apply_filters('woocommerce_return_to_shop_redirect', wc_get_page_permalink('shop'))); ?>">
					<?php _e('Return to shop', 'woocommerce') ?>
				</a>
			</p>

		<?php endif; ?>
	</div>

<?php }
