<?php
global $bakala_options;

$phone_email = @$_POST['phone'];
$regx = "/^(\+98|0098|98|0)?9\d{9}$/";
if ( isset( $bakala_options['site_header_logo'] ) && strlen( $bakala_options['site_header_logo']['url'] ) > 0 ) {
	$logo_href = $bakala_options['site_header_logo']['url'];
} else {
	$logo_href = get_template_directory_uri().'/assets/images/logo.png';
}

session_start();

if (!isset($_SESSION['count'])) {
  $_SESSION['count'] = 1;
  $_SESSION['first'] = time();
}

$life = (time() - intval($bakala_options['ippanel_time'])) - $_SESSION['first'];
if ($life > intval($bakala_options['ippanel_time'])) {
  unset($_SESSION['count']);
  $_SESSION['first'] = time();
}
?>

<div id="login-register-c" class="<?= $bakala_options['lr_password_enable'] == 1 ? 'lr_password_enable' : null ?>">
        <div class="lr-box">
          <div class="lr-logo">
            <?php
            if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
              $logo_href = $bakala_options['site_header_logo']['url'];
            } else {
              $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
            }
            ?>
            <a class="white-logo" href="<?php echo home_url('/'); ?>"><img src="<?php echo $logo_href; ?>" alt="<?php echo get_bloginfo(); ?>"></a>
          </div>
          <form id="lr-send-form-c" class="lr-form" style="display:<?= (isset($_POST['send']) && count($errors) == 0) ? 'none' : 'flex' ?>" action="" method="post">
            <p class="title"><?= __('login/register','bakala') ?></p>
            <p class="lr-description">
              <?= $bakala_options['lr_email_enable'] == 1 ? __('Please enter your mobile number or email','bakala') : __('Please enter your mobile number.','bakala') ; ?>
            </p>
            <div class="input-box">
              <div class="input-field">
                <span class="input-icon icon-profile-input-login font-icon"></span>
                <?php if ($bakala_options['lr_email_enable'] == 1) : ?>
                  <input type="text" name="phone" id="phone-c" placeholder="<?= __('Number Phone Or Email','bakala') ?>" autofocus>
                <?php else : ?>
                  <input type="number" name="phone" id="phone-c" placeholder="<?= __('Number Phone','bakala') ?>" autofocus>
                <?php endif; ?>
                <p class="lr-error" id="error-phone-c" style="display:none"></p>
              </div>
              <?php if ($bakala_options['lr_password_enable'] == 1) : ?>
                <div class="input-field" id="lr-password-field-c" style="display:none">
                  <span class="input-icon icon-password-input-login font-icon"></span>
                  <input type="password" name="password" id="pass-c" placeholder="<?= __('Password','bakala') ?>">
                  <p class="lr-error" id="error-pass-c" style="display:none"></p>
                </div>
              <?php endif; ?>
            </div>
            <div class="input-box">
              <?php if ($bakala_options['lr_password_enable'] == 1) : ?>
                <button class="lr-send plus-button" type="button" id="show-pass-c"><?= __('login/register with password','bakala') ?></button>
                <button class="lr-send plus-button" type="button" name="lr" id="lr-btn-c" style="display:none;"><?= __('login/register','bakala') ?></button> <button class="lr-send" type="submit" name="send" id="send-c"><?= __('Login/Register with one-time password','bakala') ?></button>
              <?php else : ?>
                <button class="lr-send" type="submit" name="send" id="send-c"><?= __('Login/Register with one-time password','bakala') ?></button>
              <?php endif; ?>
            </div>
            <div class="input-box">
                <a class="forget btn" style="margin:10px 0;" target="_blank" href="<?php echo esc_url(wp_lostpassword_url()); ?>"><?php echo _e('Lost your password?', 'bakala'); ?></a>
            </div>
            <?php if ($bakala_options['lr_privacy_policy'] == 1) : ?>
              <div class="custom-control custom-checkbox user-privacy">
                <input type="checkbox" readonly class="checkbox custom-control-input" id="privacy-policy-checkbox-c" checked="" name="privacy">
                <label for="privacy-policy-checkbox" class="custom-control-label">
					<a href="<?= get_permalink(wc_terms_and_conditions_page_id()); ?>"> <?= __('Terms and Conditions', 'bakala') ?> </a>
					<?php
					$text = 'Use of site services ' . get_bloginfo("name") . ' I accept.';
					echo __($text, 'bakala');
					?>
				</label>
              </div>
            <?php endif; ?>

          </form>

          <form id="lr-submit-form-c" class="lr-form" method="post" style="display:<?= (isset($_POST['send']) && preg_match($regx, $phone_email) == 1) ? 'flex' : 'none' ?>" data-autosubmit="false" autocompvare="off">
            <p class="lr-description"> <?= __('Enter the 4-digit verification code sent to the mobile number below.','bakala') ?></p>
            <div class="mobile-seting">
              <span class="mobile-number"><?= $_COOKIE['phone'] ?></span>
              <button id="edit-phone-number-c">
                <span class="fa fa-edit"></span>
                <span><?= __('Edit number','bakala') ?></span>
              </button>
            </div>
            <div class="input-box token" id="lr-token-c">
              <input type="number" class="token-input first-digit" id="digit-1-c" name="digit-1" data-next="digit-2-c" value="">
              <input type="number" class="token-input second-digit" id="digit-2-c" name="digit-2" data-next="digit-3-c" data-previous="digit-1-c" value="">
              <input type="number" class="token-input third-digit" id="digit-3-c" name="digit-3" data-next="digit-4-c" data-previous="digit-2-c" value="">
              <input type="number" class="token-input fourth-digit" id="digit-4-c" name="digit-4" data-previous="digit-3-c" value="">
            </div>
            <p class="token-error lr-error" style="display:none"></p>
            <div id="lr-countdown-c"></div>
            <button class="lr-submit" id="lr-submit-c" type="submit" name="submit"><?= __('Confirm Code','bakala') ?></button>
            <button class="lr-recode" id="recode-c" type="button" name="recode" style="display: none;"><?= __('Resent Code','bakala') ?></button>
          </form>
          <?php if ($bakala_options['lr_email_enable'] == 1) : ?>
            <form id="lr-password-form-c" class="lr-form" method="post" style="display:<?= (isset($_POST['send']) && filter_var($phone_email, FILTER_VALIDATE_EMAIL)) ? 'flex' : 'none' ?>">
              <p class="lr-description"><?= __('Enter Your Password.','bakala') ?></p>
              <input type="password" name="password" id="password-c">
              <p class="password-error lr-error"></p>
              <button class="lr-submit" id="lr-password-c" type="submit" name="submit-password"><?= __('login/register','bakala') ?></button>
            </form>
          <?php endif; ?>
        </div>
      </div>
      <div class="page-content" id="loader" style="display:none;"><img alt="site-logo" class="site-logo" src="<?= $logo_href ?>">
        <div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div>
      </div>


<script>
    jQuery('#show-pass-c').click(function(){
        jQuery(this).hide();
        jQuery('#lr-btn-c').show();
        jQuery('#lr-password-field-c').show();
    });
    function getCookie(cname) {
        var name = cname + "=";
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return "";
    }

    function getEmail(email) {
        jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            type: 'GET',
            data:{
                action: 'get_latest_posts_by_category',
                email: email
            },
            beforeSend: function() {
                jQuery('.loader').show();
            },

            success: function(data) {
                jQuery('.loader').show();
                if (data == "yes") {
                    jQuery('#lr-send-form-c').hide();
                    jQuery('#error-phone-c').hide();
                    jQuery('#lr-password-form').show();
                    jQuery('#lr-submit-form-c').hide();
                    jQuery('.loader').hide();
                    jQuery('.mobile-number').text(getCookie('phone'))


                } else {
                    jQuery('#lr-send-form-c').hide();
                    jQuery('#error-phone-c').hide();
                    jQuery('#lr-password-form').show();
                    jQuery('#lr-submit-form-c').hide();
                    jQuery('.loader').hide();
                    //jQuery('#error-cmail').show();
                    //jQuery('.loader').hide();

                }
            }
        });
    }
    /////////////////////////////////
    function getphnCl() {
        jQuery('#lr-submit-form-c').show();
        jQuery('#lr-send-form-c').hide();
        jQuery('#error-phone-c').hide();
        registerClock.setTime(<?= json_encode(intval($bakala_options['ippanel_time'])-1) ?>);
        registerClock.setCountdown(true);
        registerClock.start();
        jQuery('.loader').hide();
    }
    var digit1 = jQuery('input#digit-1-c').val();
    var digit2 = jQuery('input#digit-2-c').val();
    var digit3 = jQuery('input#digit-3-c').val();
    var digit4 = jQuery('input#digit-4-c').val();
    var digits = digit1.concat(digit2, digit3, digit4);
    var codeCookie = getCookie('opt_code');
    var registerClock = jQuery('#lr-countdown-c').FlipClock({
        autoStart: false,
        callbacks: {
        start: function() {
          jQuery('#recode-c').attr('disabled', 'disabled');
          jQuery('.mobile-number').text(getCookie('phone'))

        },
        stop: function() {
          jQuery('#lr-submit-c').hide();
          jQuery('#recode-c').show();

          jQuery('#recode-c').removeAttr('disabled');
        }
      }
    });

    jQuery('#send-c').on('click', function() {
        var nonce = jQuery('meta[name="csrf-token"]').attr('content');
          jQuery.ajaxSetup({headers: {'X-CSRF-TOKEN': nonce}});
        if (jQuery('#pass-c').length < 1) {
            if (jQuery('#phone-c').val().length > 0) {
                jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type: 'GET',
                dataType: "json",
                data: {
                    action: "bakala_send_code",
                    phone_email: jQuery('#phone-c').val(),
                },
                beforeSend: function() {
                    jQuery('.loader').show();
                },
                success: function(response) {
                    if (response.status_code == 500) {
                jQuery('.loader').hide();
                const Toast = Swal.mixin({
                  toast: true,
                  position: 'center',
                  showConfirmButton: false,
                  timer: 2000,
                  timerProgressBar: true,
                  didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                  }
                })
                Toast.fire({
                  title: response.message,
                  icon: 'error',
                })
              } else {
                    var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
                    var email_pattern = /^[a-zA-Z-' ]*$/;
                    const validateEmail = (email) => {
                        return String(email)
                            .toLowerCase()
                            .match(
                                /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                            );
                    };
                    
                    if (phone_pattern.test(jQuery('#phone-c').val())) {
                        getphnCl();
                        jQuery('.loader').hide();
                        jQuery('#lr-submit-form-c').show();
                        jQuery('#digit-1-c').trigger("focus");
                        jQuery('#send-form-c').hide();
                        jQuery('#error-phone-c').hide();
                        jQuery('#digit-4-c').keyup(function() {
                            jQuery('#lr-submit-c').trigger("click");
                            jQuery('.loader').show();
                        
                    });
                    } else if (validateEmail(jQuery('#phone-c').val())) {
                        getEmail(jQuery('#phone-c').val())
                        jQuery('.loader').hide();
                        jQuery('#send-form-c').hide();
                        jQuery('#error-phone-c').hide();
                        jQuery('#lr-password-form-c').show();
                        jQuery('#lr-submit-form-c').hide();
                    } else {
                        jQuery('#error-phone-c').show();
                    }
              }
                }
            });
            }else{
                jQuery('#error-phone-c').text('Enter mobile number or email!');
                jQuery('#error-phone-c').show();
            }
        }else{
            if (phone_pattern.test(jQuery('#phone-c').val())) {
                jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type: 'GET',
                dataType: "json",
                data: {
                    action: "bakala_send_code",
                    phone_email: jQuery('#phone-c').val(),
                },
                beforeSend: function() {
                    jQuery('.loader').show();
                },
                success: function(response) {
              if (response.status_code == 500) {
                jQuery('.loader').hide();
                const Toast = Swal.mixin({
                  toast: true,
                  position: 'center',
                  showConfirmButton: false,
                  timer: 2000,
                  timerProgressBar: true,
                  didOpen: (toast) => {
                    toast.addEventListener('mouseenter', Swal.stopTimer)
                    toast.addEventListener('mouseleave', Swal.resumeTimer)
                  }
                })
                Toast.fire({
                  title: response.message,
                  icon: 'error',
                })
              } else {

                    var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
                    var email_pattern = /^[a-zA-Z-' ]*$/;
                    const validateEmail = (email) => {
                        return String(email)
                            .toLowerCase()
                            .match(
                                /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
                            );
                    };
                    
                    if (phone_pattern.test(jQuery('#phone-c').val())) {
                        getphnCl();
                        jQuery('.loader').hide();
                        jQuery('#lr-submit-form-c').show();
                        jQuery('#digit-1-c').trigger("focus");
                        jQuery('#send-form-c').hide();
                        jQuery('#error-phone-c').hide();
                        jQuery('#digit-4-c').keyup(function() {
                            jQuery('#lr-submit-c').trigger("click");
                            jQuery('.loader').show();
                        
                    });
                    } else if (validateEmail(jQuery('#phone-c').val())) {
                        getEmail(jQuery('#phone-c').val())
                        jQuery('.loader').hide();
                        jQuery('#send-form-c').hide();
                        jQuery('#error-phone-c').hide();
                        jQuery('#lr-password-form-c').show();
                        jQuery('#lr-submit-form-c').hide();
                    } else {
                        jQuery('#error-phone-c').show();
                    }
              }
                }
            });
            }
        }
    })
    
    jQuery('#lr-btn-c').on('click', function() {
        var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
        var email_pattern = /^[a-zA-Z-' ]*$/;
        const Toast = Swal.mixin({
            toast: true,
            position: 'center',
            showConfirmButton: false,
            timer: 4000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })
        if (jQuery('#phone-c').val().length > 0 && jQuery('#pass-c').val().length >= 1 && (phone_pattern.test(jQuery('#phone-c').val()) || validateEmail(jQuery('#phone-c').val()))) {
            jQuery.ajax({
                url: "<?php echo admin_url('admin-ajax.php'); ?>",
                type: 'POST',
                dataType: "json",
                data: {
                    action: "bakala_lr_submit_checkout_register",
                    phone_email: jQuery('#phone-c').val(),
                    password: jQuery('#pass-c').val()
                },
                beforeSend: function() {
                    jQuery('body').append('<div class="page-modal"><div class="page-content" id="loader"><img alt="site-logo" class="site-logo" src="' + ajax_params.lurl + '"><div class="c-remodal-loader__bullets"><i class="c-remodal-loader__bullet c-remodal-loader__bullet--1"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--2"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--3"></i><i class="c-remodal-loader__bullet c-remodal-loader__bullet--4"></i></div></div></div><div class="clearfix"></div>');
                },
                success: function(response) {
                    jQuery('.page-modal').remove();
                    if (response.status_code == 500) {
                        jQuery('#pass-c').css('borderColor', '#ee5a66')
                        jQuery('#error-pass-c').text(response.message)
                        jQuery('#error-pass-c').show()
                    }else if(response.status_code == 404){
                        Toast.fire({
                            title: response.message,
                            icon: 'error',
                        })
                    } else {
                        Toast.fire({
                            title: response.message,
                            icon: 'success',
                        }).then((result) => {
                            jQuery('.woocommerce-account-fields').hide();
                        })
                    }
                }
            });
        }
    });
    var phone_pattern = /^(\+98|0098|98|0)?9\d{9}$/;
    var email_pattern = /^[a-zA-Z-' ]*$/;
    
    jQuery('#phone-c').keyup(function() {
      if (phone_pattern.test(jQuery(this).val()) == false && !Array.isArray(validateEmail(jQuery(this).val()))) {
        jQuery(this).parent().css('height','auto');
        jQuery('#error-phone-c').text('Enter the correct mobile number or email!');
        jQuery('#error-phone-c').show();
        jQuery(this).css('borderColor', '#ee5a66')
      } else {
        jQuery(this).parent().css('height','65px');
        jQuery('#error-phone-c').hide();
        jQuery(this).css('borderColor', 'green')
      }
    });

    
    jQuery('#lr-submit-form-c').on('submit', function(e) {
        e.preventDefault();
        var digit1 = jQuery('input#digit-1-c').val();
        var digit2 = jQuery('input#digit-2-c').val();
        var digit3 = jQuery('input#digit-3-c').val();
        var digit4 = jQuery('input#digit-4-c').val();
        var digits = digit1.concat(digit2, digit3, digit4);
        const Toast = Swal.mixin({
            toast: true,
            position: 'center',
            showConfirmButton: false,
            timer: 4000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })
        jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            type: 'POST',
            dataType: "json",
            data: {
                action: "bakala_submit_code_checkout_register",
                token: digits,
            },
            beforeSend: function() {
                jQuery('.loader').show();
            },
            success: function(response) {
                jQuery('.loader').hide();
                if (response.status_code == 500) {
                    jQuery('#lr-token-c input').css('borderColor', '#ee5a66')
                    jQuery('.token-error').text(response.message)
                }else if(response.status_code == 404){
                    Toast.fire({
                        title: response.message,
                        icon: 'danger',
                    })
                }else {
                    Toast.fire({
                        title: response.message,
                        icon: 'success',
                    }).then((result) => {
                        jQuery('.woocommerce-account-fields').hide();
                    })
                }
            }
        });

        return false;
    })

    jQuery('#lr-password-form-c').on('submit', function(e) {
        e.preventDefault();
        var password = jQuery('input#password-c').val();
        const Toast = Swal.mixin({
            toast: true,
            position: 'center',
            showConfirmButton: false,
            timer: 4000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
        })
        jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            type: 'POST',
            dataType: "json",
            data: {
                action: "bakala_submit_password_checkout_register",
                password: password,
            },
            beforeSend: function() {
                jQuery('.loader').show();
            },
            success: function(response) {
                jQuery('.loader').hide();
                if (response.status_code == 500) {
                    jQuery('#password-c').css('borderColor', '#ee5a66')
                    jQuery('.password-error').text(response.message)
                }else if(response.status_code == 404){
                    Toast.fire({
                        title: response.message,
                        icon: 'danger',
                    })
                } else {
                    
                    Toast.fire({
                        title: response.message,
                        icon: 'success',
                    }).then((result) => {
                        jQuery('.woocommerce-account-fields').hide();
                    })
                }
            }
        });

        return false;
    })
    
    ////////////////////

    //////////////////////
    jQuery('#recode-c').on('click', function() {
        jQuery.ajax({
            url: "<?php echo admin_url('admin-ajax.php'); ?>",
            type: 'POST',
            data: {
                action: "bakala_send_code",
                phone_email: jQuery('#phone-c').val(),
            },
            beforeSend: function() {
                jQuery('.loader').show();
            },
            complete: function() {
                jQuery('.loader').hide();
                registerClock.setTime(<?= json_encode(intval($bakala_options['ippanel_time']))-1 ?>);
                registerClock.setCountdown(true);
                registerClock.start();
            },
            success: function(data) {
                var pattern = /^(\+98|0098|98|0)?9\d{9}$/;
                if (pattern.test(jQuery('#phone-c').val())) {
                    jQuery('#lr-submit-form-c').show();
                    jQuery('#send-form-c').hide();
                    jQuery('#error-phone-c').hide();
                } else {
                    jQuery('#error-phone-c').show();
                }
            }
        });
    })

    jQuery('#edit-phone-number-c').click(function() {
        jQuery('#lr-submit-form-c').hide();
        jQuery('#send-form-c').attr('style','display:block !important;');
    })


    String.prototype.toEnglishDigit = function() {
        var find = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
        var replace = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
        var replaceString = this;
        var regex;
        for (var i = 0; i < find.length; i++) {
            regex = new RegExp(find[i], "g");
            replaceString = replaceString.replace(regex, replace[i]);
        }
        return replaceString;
    };

    document.querySelectorAll('input').forEach(x => {
        x.oninput = function() {
            x.value = x.value.toEnglishDigit()
        }
    });
    jQuery('#lr-token-c').find('input').each(function() {
        jQuery(this).attr('maxlength', 1);
        jQuery(this).on('keyup', function(e) {
            e.preventDefault();
            var parent = jQuery(jQuery(this).parent());

            inputCharacter = String.fromCharCode(e.which);

            acceptableNumbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];


            if (e.keyCode == 8 || e.keyCode == 37) {
                var prev = parent.find('input#' + jQuery(this).data('previous'));


                if (prev.length != undefined) {
                    jQuery(prev).select();
                }


            } else if (e.which == 229 || (e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 65 && e.keyCode <= 90) || (e.keyCode >= 96 && e.keyCode <= 105) || e.keyCode === 39) {
                //} else if( checkIsInArray( inputCharacter , acceptableNumbers ) ) {
                var next = parent.find('input#' + jQuery(this).data('next'));

                if (next.length != undefined) {
                    jQuery(next).select();
                } else {
                    if (parent.data('autosubmit')) {
                        parent.submit();
                    }
                }
            }
        });
    });
</script>