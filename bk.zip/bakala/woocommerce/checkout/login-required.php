<?php global $bakala_options; ?>
<div class="sign">
  <div class="login <?= $bakala_options['lr_bakala'] == 1 ? 'lr_bakala' : null ?>">
	<i class="icon icons-lock"></i>
		<p><?php $bakala_options['lr_bakala'] == 1 ? _e( 'Please log in to continue shopping!', 'bakala' ) : _e( 'Do you member of this site?', 'bakala' ) ?></p>
		<?php global $bakala_options;
		if ( isset($bakala_options['popup_login']) && $bakala_options['popup_login'] == true ) {
		if( $bakala_options['digits'] == true  ) { 
		   echo do_shortcode('[dm-login-modal]');
		} else{?>
	        <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login"><?php _e( 'login/register' , 'bakala' ) ?> </a>
	   <?php }
	   }else{ ?>
	        <a  href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ).'?login=1'; ?>" ><?php _e( 'Login' , 'bakala' ) ?> </a>
	   <?php } ?>
  </div>
  <?php if ($bakala_options['lr_bakala'] == 0) { ?>
  <div class="signup">
	<i class="icon icons-admin-users"></i>
	<p><?php _e( 'Dont Have any Account?' , 'bakala' ) ?><p>
	<?php if($bakala_options['lr_bakala'] == 1): ?>
	    <a href="" data-bs-toggle="modal" data-bs-target="#bakala_login"><?php _e( 'Regester' , 'bakala' ) ?> </a>
	<?php else: ?>
	    <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>"><?php _e( 'Regester' , 'bakala' ) ?></a>
	<?php endif; ?>
	<div class="clearfix"></div>
  </div>
  <?php } ?>
</div>