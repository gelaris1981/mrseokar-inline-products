<?php

if (is_mobile_or_tablet()) {
    require_once __DIR__ . "/template-parts/content/page-checkout-mobile.php";
} else {
    require_once __DIR__ . "/template-parts/content/page-checkout-pc.php";
}

