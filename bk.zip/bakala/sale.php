<?php
/*
* Template Name: Discounted Products
*/

if (!defined('ABSPATH')) {
   exit;
}

get_header('shop'); ?>

<div class="woocommerce-products-header">
   <h1 class="woocommerce-products-header__title page-title"><?php esc_html_e('Discounted Products', 'your-theme-textdomain'); ?></h1>
</div>

<?php
// WP_Query برای دریافت محصولات تخفیف خورده
$args = array(
   'post_type' => 'product',
   'posts_per_page' => -1, // تمام محصولات تخفیف خورده را بیاور
   'meta_query' => array(
       array(
           'key' => '_sale_price',
           'value' => 0,
           'compare' => '>',
           'type' => 'NUMERIC',
       ),
   ),
);

$query = new WP_Query($args);

if ($query->have_posts()) :
   echo '<ul class="products columns-4">';

   while ($query->have_posts()) :
       $query->the_post();

       wc_get_template_part('content', 'product');

   endwhile;

   echo '</ul>';
else :
   echo '<p>' . esc_html__('No discounted products found.', 'your-theme-textdomain') . '</p>';
endif;

wp_reset_postdata();

get_footer('shop');
?>
