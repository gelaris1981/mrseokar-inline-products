<?php

if (is_mobile_or_tablet()) {
    require_once __DIR__ . "/template-parts/content/page-mobile.php";
} else {
    require_once __DIR__ . "/template-parts/content/page-pc.php";
}