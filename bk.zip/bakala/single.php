<?php

get_header();
if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('single')) {


  global $bakala_options;
  if (isset($bakala_options['site_header_logo']) && strlen($bakala_options['site_header_logo']['url']) > 0) {
    $logo_href = $bakala_options['site_header_logo']['url'];
  } else {
    $logo_href = get_template_directory_uri() . '/vendor/images/logo.png';
  }
  $class = 'left_sidebar';
  if(isset($bakala_options['post_layout']) && $bakala_options['post_layout'] == 'right'){
      $class='right_sidebar';
  }elseif(isset($bakala_options['post_layout']) && $bakala_options['post_layout'] == 'left'){
      $class = 'left_sidebar';
  }elseif(isset($bakala_options['post_layout']) && $bakala_options['post_layout'] == 'none'){
      $class = 'none_sidebar';
  }
?>
  <div class="container-bakala main-warp">
    <div class="row <?= $class ?>">
        <?php if(isset($bakala_options['post_layout']) && $bakala_options['post_layout'] == 'right'){ ?>
      <aside class="col-sm-3 blog-sidebar">
        <?php if (is_active_sidebar('blog-sidebar')) {
          dynamic_sidebar('blog-sidebar');
        } ?>
      </aside>
      <?php } ?>
      <section class="col-sm-9">
        <?php bakala_breadcrumbs(); ?>
        <?php while (have_posts()) : the_post(); ?>
          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> itemscope itemtype="http://schema.org/BlogPosting">
            <meta itemscope itemprop="mainEntityOfPage" itemType="https://schema.org/WebPage" itemid="<?php the_permalink(); ?>" />
            <div class="post-title">
              <h1 class="entry-title" itemprop="headline"><?php the_title(); ?></h1>
            </div>
            <div class="post-meta">
              <span class="post-author" itemprop="author" itemscope itemtype="https://schema.org/Person"><?php echo get_avatar(get_the_author_meta('ID'), 35); ?><a class="author_name" href="<?= get_author_posts_url(get_the_author_meta('ID')) ?>"><span itemprop="name"><?php the_author() ?></span></a></span>
              <div>
                <i class="icon-clock-icon"></i>
                <span class="post-date">
                  <meta itemprop="datePublished" content="<?php echo date("Y-m-d", get_post_time()); ?>">
                  <meta itemprop="dateModified" content="<?php echo date("Y-m-d", get_post_modified_time()); ?>" />
                  <?php the_time('d F Y') ?><span class="time-divider">|</span><?php the_time('h:i') ?>
                </span>
              </div>
              <div itemprop="publisher" itemscope itemtype="https://schema.org/Organization" class="hidden publisher">
                <div itemprop="logo" itemscope itemtype="https://schema.org/ImageObject">
                  <meta itemprop="url" content="<?php echo $logo_href; ?>">
                </div>
                <meta itemprop="name" content="<?php bloginfo('name'); ?>">
              </div>
              <span class="post-edit"></span>
              <?php if($bakala_options['reading_time'] != '0'){ ?>
              <span class="bakala_reading_time"><i class="bakala-icon icon-time"></i><?= __('Estimated reading time', 'bakala') ?>: <?= bakala_reading_time() ?> </span>
              <?php } ?>
            </div>

            <div class="post-content single">
              <div class="post-body">
                <?php if($bakala_options['post_thumbnail'] != '0'){ ?>
                    <figure class="post-attachment">
                      <?php the_post_thumbnail(); ?>
                      <meta itemprop="image" content="<?php the_post_thumbnail_url(); ?>">
                      <figcaption class="hidden-seo"><?php the_title(); ?></figcaption>
                    </figure>
                <?php } ?>
                <div itemprop="articleBody">
                  <?php the_content(); ?>
                </div>
              </div>
              <?php if($bakala_options['share_post'] != '0'){ ?>
              <div class="post_share">
            <i class="bakala-icon share_icon"></i>
            <span data-bs-toggle="modal" data-bs-target="#bakala_sharebtn" ><?= __('Share','bakala') ?> </span>
           </div>
            <div class="modal " id="bakala_sharebtn" tabindex="-1" role="dialog" aria-hidden="true" style="display: none;">
    <div class="modal-dialog bakala_qa_modal">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">اشتراک‌گذاری</h5>
                <a href="" data-bs-dismiss="modal" aria-label="Close" class="close-icon"></a>
            </div>
            <div class="modal-body">
                <p class="bakaka_share_title">این مطلب را با دوستان خود به اشتراک بگذارید!</p>
                <button class="bakala_share_page_btn" onclick="bkCopyLink(this)" data-link="<?php echo esc_url(site_url()) . '/?p=' . $post->ID; ?>">
                    <i class="bakala-icon icon-copy"></i>
                    <span id="copyButtonText">کپی کردن لینک</span>
                </button>
            </div>
            
        </div>
    </div>
</div>

              <?php
              }
              $posttags = get_the_tags();
              if ($posttags) { ?>
                <div class="post-tags">
                  <span class="tag"><?php _e('Tags: ', 'bakala'); ?></span>
                  <?php
                  foreach ($posttags as $tag) {
                    echo '<a href="' . get_tag_link($tag->term_id) . '" rel="tag">' . $tag->name . '</a>';
                  }
                  ?>
                </div>
              <?php } ?>
            </div>
          </article>
        <?php

          // If comments are open or we have at least one comment, load up the comment template.
          if (comments_open() || get_comments_number()) :
            comments_template();
          endif;

        endwhile; // End of the loop.
        ?>
      </section>
    <?php if(isset($bakala_options['post_layout']) && $bakala_options['post_layout'] == 'left'){ ?>
      <aside class="col-sm-3 blog-sidebar">
        <?php if (is_active_sidebar('blog-sidebar')) {
          dynamic_sidebar('blog-sidebar');
        } ?>
      </aside>
      <?php } ?>
      <?php if(!isset($bakala_options['post_layout'])){ ?>
      <aside class="col-sm-3 blog-sidebar">
        <?php if (is_active_sidebar('blog-sidebar')) {
          dynamic_sidebar('blog-sidebar');
        } ?>
      </aside>
      <?php } ?>
    </div>
  </div>

<?php
}
get_footer();